/*
 *  Copyright (C) 2001 David Hoag
 *  ObjectWave Corporation
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *  For a full copy of the license see:
 *  http://www.opensource.org/licenses/lgpl-license.html
 */
package com.objectwave.persist;
import java.sql.*;
import java.util.*;
/**
 *  Can assist with the basic implementation of a broker.
 *
 * @author  David Hoag
 * @version  $Id: AbstractBroker.java,v 2.1 2002/02/08 22:41:28 dave_hoag Exp $
 */
public abstract class AbstractBroker implements Broker
{
	protected static boolean metrics = System.getProperty("ow.persistMetrics") != null;
	/**
	 */
	public boolean verbose = System.getProperty("ow.persistVerbose") != null;
	protected BrokerPropertyIF props;
	protected SQLConvertExceptionIF exceptionConverter;
	/**
	 */
	public AbstractBroker()
	{
		setBrokerProperty(BrokerFactory.getDefaultProperties());
	}
	/**
	 *  Utility method to assist with migration to logger interface.
	 *
	 * @param  str A String to display. Used for debugging and logging purposes.
	 */
	public static void println(String str)
	{
		BrokerFactory.println(str);
	}
	/**
	 *  A BrokerPropertyIF is the mechanism by which properties are set for the
	 *  broker. By default, these are simply System properties. But any
	 *  implementation of the BrokerPropertyIF would be valid.
	 *
	 * @param  b The source of property information.
	 */
	public void setBrokerProperty(BrokerPropertyIF b)
	{
		props = b;
		props.configure(this);
		verbose = props.getProperty("ow.persistVerbose") != null;
		metrics = props.getProperty("ow.persistMetrics") != null;
	}
	/**
	 *  A converter is used to generate application specific exceptions
	 *
	 * @param  aValue The new ExceptionConverter value
	 */
	public void setExceptionConverter(SQLConvertExceptionIF aValue)
	{
		exceptionConverter = aValue;
	}
	/**
	 *  A converter is used to generate application specific exceptions
	 *
	 * @return  The ExceptionConverter value
	 */
	public SQLConvertExceptionIF getExceptionConverter()
	{
		return exceptionConverter;
	}
	/**
	 *  Get the number of objects that match this would be found by this query.
	 *
	 * @param  q SQLQuery that abstracts the query conditions.
	 * @return  int Number of objects matching query.
	 * @exception  QueryException
	 */
	public int count(SQLQuery q) throws QueryException
	{
		Vector v = (Vector) find(q);
		return v.size();
	}
	/**
	 *  This default implementation may not be the most efficient, but it should
	 *  work.
	 *
	 * @param  deleteList
	 * @exception  QueryException
	 */
	public synchronized void deleteObjects(ArrayList deleteList) throws QueryException
	{
		int size = deleteList.size();
		for(int i = 0; i < size; ++i)
		{
			Persistence obj = (Persistence) deleteList.get(i);
			obj.delete();
		}
	}
	/**
	 *  Default of close is to do nothing
	 */
	public void close()
	{
	}
	/**
	 *  This will ALWAYS return an exception. This allows an Exception converter to
	 *  be installed into the broker. This converter can change exception to
	 *  specific exception types based upon database error codes. This would,
	 *  obviously, be database specific and hence why it is not part of RDBBroker.
	 *
	 * @param  ex
	 * @param  additionalInfo
	 * @return
	 */
	protected QueryException convertException(SQLException ex, String additionalInfo)
	{
		if(getExceptionConverter() == null)
		{
			return new QueryException(ex.toString(), ex, additionalInfo);
		}
		return getExceptionConverter().convert(ex, additionalInfo);
	}
	/**
	 *  This will ALWAYS return an exception. This allows an Exception converter to
	 *  be installed into the broker. This converter can change exception to
	 *  specific exception types based upon database error codes. This would,
	 *  obviously, be database specific and hence why it is not part of RDBBroker.
	 *
	 * @param  ex
	 * @return
	 */
	protected QueryException convertException(QueryException ex)
	{
		if(getExceptionConverter() == null)
		{
			return ex;
		}
		return getExceptionConverter().convert(ex);
	}
}
