/*
 *  Copyright (C) 2001 David Hoag
 *  ObjectWave Corporation
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *  For a full copy of the license see:
 *  http://www.opensource.org/licenses/lgpl-license.html
 */
package com.objectwave.persist;

import com.objectwave.logging.MessageLog;
import com.objectwave.persist.constraints.*;
import java.lang.reflect.Field;
import java.util.ArrayList;
/**
 *  A class that is used to describe an object's attribute.
 *  An instance of this class will exist for every attribute defined in the system.
 *
 * @author  David Hoag
 * @version  $Id: AttributeTypeColumn.java,v 2.3 2002/08/23 18:05:15 dave_hoag Exp $
 */
public class AttributeTypeColumn implements Comparable
{
	/**
	 */
	public final static Type INSTANCE = new Type("Instance Link");
	/**
	 */
	public final static Type FOREIGN = new Type("Foreign Key Link");
	/**
	 */
	public final static Type COLLECTION = new Type("Collection Link");
	/**
	 */
	public final static Type ATTRIBUTE = new Type("Attribute ");
	/**
	 */
	public final static Type PRIMARYATT = new Type("PrimaryKey ");
	/**
	 */
	public final static Type TYPEATT = new Type("TypeField ");
	/**
	 */
	public final static Type PLACEHOLDER = new Type("PlaceHolder ");
	protected JoinField[] joinFields = new JoinField[1];
	boolean accessible = false;

	Persistence persistentObject;
	CollectionAdapter collectionAdapter;
	String columnName;
	Field f;
	final Field[] fds = new Field[1];
	final Object[] value = new Object[1];
	Type type;
	Class relatedType;
	//constraint only for collection
	ConstraintCompare collectionConstraint;
	/**
	 *  Subclasses such as wrapper classes may need this.
	 */
	public AttributeTypeColumn()
	{
	}
	/**
	 * @param  pObj
	 * @param  name
	 * @param  fd
	 * @param  t
	 */
	public AttributeTypeColumn(Persistence pObj, String name, Field fd, Type t)
	{
		this(name, fd, t);
		persistentObject = pObj;
		if(pObj != null)
		{
			setRelatedType(pObj.getClass());
		}
	}
	/**
	 *  Used to create instance links that can not be proxied.
	 *
	 * @param  pObj
	 * @param  fd
	 * @param  t
	 */
	public AttributeTypeColumn(Class pObj, Field fd, Type t)
	{
		if(fd == null)
		{
			throw new IllegalArgumentException("AttributeTypeColumn.<init> At class " + pObj.getName() + " trying to set NULL field. ");
		}
		setRelatedType(pObj);
		type = t;
		f = fd;
		accessible = fd.isAccessible();
	}
	/**
	 * @param  pObj
	 * @param  name
	 * @param  fd
	 * @param  t
	 */
	public AttributeTypeColumn(Class pObj, String name, Field fd, Type t)
	{
		this(name, fd, t);
		setRelatedType(pObj);
	}
	/**
	 *  Most often used for ATTRIBUTE types.
	 *
	 * @param  name
	 * @param  fd
	 * @param  t
	 */
	public AttributeTypeColumn(String name, Field fd, Type t)
	{
		if(fd == null)
		{
			throw new IllegalArgumentException("AttributeTypeColumn.<init> At " + name + " trying to set NULL field. ");
		}
		type = t;
		setColumnName(name);
		f = fd;
		accessible = fd.isAccessible();
	}
	/**
	 *  Convenience method for creating Attribute relations.
	 *
	 * @param  columnName
	 * @param  fd
	 * @return  The AttributeRelation value
	 */
	public static AttributeTypeColumn getAttributeRelation(String columnName, Field fd)
	{
		return new AttributeTypeColumn(columnName, fd, ATTRIBUTE);
	}
	/**
	 *  Convenience method for creating Collection relations.
	 *
	 * @param  c
	 * @param  fd
	 * @return  The CollectionRelation value
	 */
	public static AttributeTypeColumn getCollectionRelation(Class c, Field fd)
	{
		return new AttributeTypeColumn(c, null, fd, COLLECTION);
	}
	/**
	 *  Convenience method for creating Foreign relations.
	 *
	 * @param  c
	 * @param  columnName
	 * @param  fd
	 * @return  The ForeignRelation value
	 */
	public static AttributeTypeColumn getForeignRelation(Class c, String columnName, Field fd)
	{
		if(columnName == null)
		{
			throw new IllegalArgumentException("ColumnName can not be null for a foreign relation");
		}
		return new AttributeTypeColumn(c, columnName, fd, FOREIGN);
	}
	/**
	 *  Convenience method for creating Instance relations.
	 *
	 * @param  c
	 * @param  fd
	 * @return  The InstanceRelation value
	 */
	public static AttributeTypeColumn getInstanceRelation(Class c, Field fd)
	{
		return getInstanceRelation(c, null, fd);
	}
	/**
	 *  Convenience method for creating Instance relations.
	 *
	 * @param  c
	 * @param  columnName
	 * @param  fd
	 * @return  The InstanceRelation value
	 */
	public static AttributeTypeColumn getInstanceRelation(Class c, String columnName, Field fd)
	{
		return new AttributeTypeColumn(c, columnName, fd, INSTANCE);
	}
	/**
	 * @param  columnName java.lang.String
	 * @param  fd java.lang.reflect.Field
	 * @return  com.objectwave.persist.AttributeTypeColumn
	 * @author  Steven Sinclair
	 */
	public static AttributeTypeColumn getTypeAttributeRelation(String columnName, Field fd)
	{
		return new AttributeTypeColumn(columnName, fd, TYPEATT);
	}
	/**
	 *  An easy way change the type to be a primary attribute.
	 */
	public void setAsPrimary()
	{
		type = PRIMARYATT;
	}
	/**
	 *  Sets the ColumnName attribute of the AttributeTypeColumn object
	 *
	 * @param  nm The new ColumnName value
	 */
	public void setColumnName(String nm)
	{
		columnName = nm;
		joinFields[0] = new JoinField(nm, null);
	}
	/**
	 *  All AttributeTypeColumns are required to have a corresponding Field object.
	 *
	 * @param  fd The new Field value
	 */
	public void setField(Field fd)
	{
		if(fd == null)
		{
			throw new IllegalArgumentException("AttributeTypeColumn.setField(): At " + getColumnName() + " trying to set NULL field. ");
		}
		f = fd;
		accessible = fd.isAccessible();
	}
	/**
	 *  This is type object we are going to use to attempt to match a field on one object to a field
	 *  on another object. By default, this type is also going to be instatiated via the default
	 *  constructor when building proxies. This can be overridden, but that is the default behavior.
	 *
	 * @param  c The new RelatedType value
	 */
	public void setRelatedType(Class c)
	{
		if(c != null && c.isInterface())
		{
			BrokerFactory.println("Persistence Warning: The attribute definition is being defined with an Interface as the related type!");
		}
		relatedType = c;
	}
	/**
	 * @param  c The new Type value
	 */
	public void setType(Type c)
	{
		type = c;
	}
	/**
	 *  Convenience method to allow one to update a single attribute on a persistent object.
	 *
	 * @param  obj The new Value value
	 * @param  aValue The new Value value
	 */
	public void setValue(final Persistence obj, final Object aValue)
	{
		if(accessible)
		{
			try
			{
				getField().set(obj, aValue);
				return;
			}
			catch(Exception e)
			{
				MessageLog.debug(this, "Value loader " + aValue.getClass().getClassLoader());
				MessageLog.debug(this, "Field type loader " + getField().getType().getClassLoader());
				MessageLog.debug(this, "Value type: " + aValue.getClass().getName() );
				MessageLog.debug(this, "Field type " + getField().getType().getName());
				MessageLog.debug(this, "Instance loader " + obj.getClass().getClassLoader());
				MessageLog.error(this, "Setting " + aValue + " in " + getField() + " on " + obj, e);
				e.printStackTrace();
			}
		}
		synchronized(this)
		{
			fds[0] = this.getField();
			value[0] = aValue;
			obj.update(false, value, fds);
		}
	}
	/**
	 *  This attribute is only used for the CollectionType.
	 *  With this it is possible to force the result set of the collection
	 *  query to be a certain type.
	 *
	 * @param  adapter com.objectwave.persist.CollectionAdapter An interface that allows building collections
	 */
	public void setCollectionAdpater(CollectionAdapter adapter)
	{
		collectionAdapter = adapter;
	}
	/**
	 *  Sets the Constraint attribute of the AttributeTypeColumn object
	 *
	 * @param  comp The new Constraint value
	 */
	public void setConstraint(ConstraintCompare comp)
	{
		this.collectionConstraint = comp;
	}
	/**
	 *  By default, foreign key links join on the other object PrimaryKeyField.
	 *  This is not always the case. If we don't want to join on the primary key
	 *  field, but set the theOtherField to be the Field object from the other
	 *  object. It would be more ideal to get the AttributeTypeColumn, but that
	 *  can be hard to get.
	 *
	 * @param  theOtherField The new JoinOn value
	 */
	public void setJoinOn(final Field theOtherField)
	{
		joinFields[0].setJoinField(theOtherField);
	}
	/**
	 *Gets the JoinFields attribute of the AttributeTypeColumn object
	 *
	 * @return  The JoinFields value
	 */
	public JoinField[] getJoinFields()
	{
		return joinFields;
	}
	/**
	 *  Gets the ColumnName attribute of the AttributeTypeColumn object
	 *
	 * @return  The ColumnName value
	 */
	public String getColumnName()
	{
		return columnName;
	}
	/**
	 *  Gets the Field attribute of the AttributeTypeColumn object
	 *
	 * @return  The Field value
	 */
	public Field getField()
	{
		return f;
	}
	/**
	 *  A persistentType is the class of the persistent object we wish to build.
	 *  It is used when you have a reference (FOREIGN, COLLECTION, INSTANCE) to another object.
	 *  The difference from relatedType come in the creation of new instances.
	 *  New instances of the are created by asking the persistentObject for it's adapter
	 *  and then asking the adapter for a new instance. This allows one to specifically
	 *  customize a new instance, if customization of some sort is needed.
	 *
	 * @return  The PersistentType value
	 * @see  #getRelatedType()
	 */
	public Persistence getPersistentType()
	{
		return persistentObject;
	}
	/**
	 *  A relatedType is the class of the persistent object we wish to build.
	 *  It is used when you have a reference (FOREIGN, COLLECTION, INSTANCE) to another object.
	 *  New instances of the related object are created via reflection.
	 *
	 * @return  The RelatedType value
	 * @see  #getPersistentType()
	 */
	public Class getRelatedType()
	{
		return relatedType;
	}
	/**
	 *  Collection, Foreign, Instance, Attribute, PrimaryAttribute
	 *
	 * @return  The Type value
	 */
	public Type getType()
	{
		return type;
	}
	/**
	 *  Convenience method to allow one to retrieve a single attribute from a persistent object.
	 *
	 * @param  obj
	 * @param  fields
	 * @param  values
	 * @return  The Value value
	 */
	public final Object getValue(final Persistence obj, final Field[] fields, final Object[] values)
	{
		if(accessible)
		{
			try
			{
				return getField().get(obj);
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}

		fields[0] = this.getField();
		obj.update(true, values, fields);
		return values[0];
	}
	/**
	 *  By default, foreign key links join on the other object PrimaryKeyField.
	 *  This is not always the case. If we don't want to join on the primary key
	 *  field, this will be set to the Field of the object object.
	 *
	 * @return  The JoinOn value
	 */
	public Field getJoinOn()
	{
		return joinFields[0].getJoinField();
	}
	/**
	 *  Convenience method to allow one to retrieve a single attribute from a persistent object.
	 *
	 * @param  obj The instance that holds the value represented by this attribute
	 * @return  The object represented by this field in the Persistent parameter
	 */
	public Object getValue(final Persistence obj)
	{
		if(accessible)
		{
			try
			{
				return getField().get(obj);
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		synchronized(this)
		{
			fds[0] = this.getField();
			obj.update(true, value, fds);
			return value[0];
		}
	}
	/**
	 * @return  The CollectionAdapter value
	 */
	public CollectionAdapter getCollectionAdapter()
	{
		return collectionAdapter;
	}
	/**
	 *  Gets the Constraint attribute of the AttributeTypeColumn object
	 *
	 * @return  The Constraint value
	 */
	public ConstraintCompare getConstraint()
	{
		return this.collectionConstraint;
	}

	/**
	 *Adds a feature to the JoinField attribute of the AttributeTypeColumn object
	 *
	 * @param  joinField The feature to be added to the JoinField attribute
	 */
	public void addJoinField(JoinField joinField)
	{
		if(joinField == null)
		{
			throw new IllegalArgumentException("A field must be provided, in order to add it!");
		}
		//Sometimes the first join field is added a second time ( like from XML )
		if(joinFields[0].getJoinField() == null)
		{
			//Just update the first entry
			joinFields[0].setJoinField(joinField.getJoinField());
			joinFields[0].setJoinColumn(joinField.getJoinColumn());
			return;
		}
		ArrayList list = new ArrayList();
		for(int i = 0; i < joinFields.length; i++)
		{
			list.add(joinFields[i]);
		}
		list.add(joinField);
		joinFields = new JoinField[list.size()];
		list.toArray(joinFields);
	}
	/**
	 * @param  aValue
	 * @return
	 */
	public boolean equals(final AttributeTypeColumn aValue)
	{
		boolean ans = false;
		if(this.getField() == aValue.getField())
		{
			if(this.getColumnName() == aValue.getColumnName())
			{
				ans = true;
			}
		}
		return ans;
	}
	/**
	 * compares
	 *
	 * @param  o
	 * @return
	 */
	public int compareTo(Object o)
	{
		if(o == null)
		{
			return 1;
		}
		if(o instanceof AttributeTypeColumn)
		{
			AttributeTypeColumn other = (AttributeTypeColumn) o;
			if(columnName == null || other.columnName == null)
			{
				if(columnName == null && other.columnName == null)
				{
					return 0;
				}
				else if(f == null)
				{
					return 1;
				}
				else
				{
					return 0;
				}
			}
			else
			{
				return columnName.compareTo(other.columnName);
			}
		}
		return -1;
	}
	/**
	 * @return
	 */
	public String toString()
	{
		String result = super.toString();
		Field f = getField();
		if(f != null)
		{
			result += " Field: " + getField().getName();
		}
		else
		{
			result += " Field: null";
		}

		result += " columnName: " + getColumnName();
		result += " type: " + getType();
		return result;
	}
}

