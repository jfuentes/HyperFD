package com.objectwave.persist;

import java.util.ArrayList;
import java.util.Vector;
/**
 * The API for persistence. Implementations can be flat files, serialized objects, or perhaps
 * even a relational database. Just adhere to this API and the implementation can be plugged
 * into the BrokerFactory.
 * @version 4.0
 * @author Dave Hoag
 */
public interface Broker
{
    public void setBrokerProperty(BrokerPropertyIF b);
	public void beginTransaction() throws QueryException;
	public void commit() throws QueryException;
	public int count(SQLQuery q) throws QueryException;
	public void delete(Persistence obj) throws QueryException;
	public void deleteObjects(ArrayList deleteList) throws QueryException;
	/**
	 * The return type of object allows the support of multiple collection types.
	 */
	public Object find(SQLQuery q) throws QueryException;
	public void deleteAll(SQLQuery q) throws QueryException;
	public Vector findAttributes(SQLQuery q, String [] at) throws QueryException;
	public Persistence findUnique(SQLQuery q) throws QueryException;
	public void rollback() throws QueryException;
	public void save(Persistence obj) throws QueryException;
	public void saveObjects(ArrayList saveList) throws QueryException;
	/** Tell the broker the application is done with it. May not have any behavior */
	public void close();
}
