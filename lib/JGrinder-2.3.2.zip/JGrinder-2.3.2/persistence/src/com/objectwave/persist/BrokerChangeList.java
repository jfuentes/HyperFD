package com.objectwave.persist;
import com.objectwave.persist.broker.*;
import com.objectwave.persist.examples.*;
import com.objectwave.persist.mapping.*;
import com.objectwave.transactionalSupport.UpdateException;

import java.util.ArrayList;
/**
 *  Contain a list of changed objects. There is a unique instance of this object
 *  for every Transaction that is being commited. The Transaction.commit()
 *  method is synchronized. Only one thread will ever have access to a
 *  particular broker change list instance.
 *
 * @author  Dave Hoag
 * @version  $Id: BrokerChangeList.java,v 1.1.1.1 2001/02/13 23:18:40 dhoag Exp
 *      $
 */
class BrokerChangeList
{
	String[] brokers;
	ArrayList[] changeList;
	ArrayList[] deleteList;
	BrokerTransactionLog log;

	int size = 0;

	/**
	 *  Get a list of changed objects.
	 *
	 * @param  log TransactionLog The one only instance that will work with this
	 *      instance of BrokerChangeList.
	 */
	BrokerChangeList(BrokerTransactionLog log)
	{
		brokers = new String[10];
		changeList = new ArrayList[10];
		deleteList = new ArrayList[10];
		this.log = log;
	}
	/**
	 *  The list of broker should usually be very small. Probably one. This should
	 *  cause minimal overhead. If a commit fails, and there are multiple brokers,
	 *  results may be unpredictable.
	 *
	 * @exception  QueryException Description of Exception
	 * @exception  com.objectwave.transactionalSupport.UpdateException Description
	 *      of Exception
	 */
	public synchronized void commitAll() throws QueryException, com.objectwave.transactionalSupport.UpdateException
	{
		for(int i = 0; i < size; ++i)
		{
			if(changeList[i] == null && deleteList[i] == null)
			{
				continue;
			}
			Broker broker = BrokerFactory.getBroker(brokers[i]);
			if(broker == null)
			{
				broker = BrokerFactory.getDefaultBroker();
			}
			broker.beginTransaction();
		}
		doUpdates(true);
		for(int i = 0; i < size; ++i)
		{
			if(changeList[i] == null && deleteList[i] == null)
			{
				continue;
			}
			try
			{
				Broker broker = BrokerFactory.getBroker(brokers[i]);
				if(broker == null)
				{
					broker = BrokerFactory.getDefaultBroker();
				}
				broker.commit();
				//			brokers [i] = "_done";
			}
			catch(RuntimeException ex)
			{
				//Only need to restore if any commits have been done
				restoreData(i);
				//throws UpdateException
				throw ex;
			}
			catch(QueryException ex)
			{
				//Only need to restore if any commits have been done
				restoreData(i);
				//throws UpdateException
				throw ex;
			}

		}
	}
	/**
	 *  Delete this persistent object.
	 *
	 * @param  p Description of Parameter
	 */
	public synchronized void deletePersistence(Persistence p)
	{
		int idx = getBrokerIndex(p);
		if(deleteList[idx] == null)
		{
			deleteList[idx] = new ArrayList();
		}
		deleteList[idx].add(p);
	}
	/**
	 *  Attempt to rollback the changes to each broker. If a broker has sucessfully
	 *  commited (and hence is "done") then there is little we can do about that.
	 *
	 * @exception  QueryException Description of Exception
	 */
	public void rollback() throws QueryException
	{
		for(int i = 0; i < size; ++i)
		{
			if(brokers[i] != null && brokers[i].equals("_done"))
			{
				continue;
			}
			//Sorry. Not much we can do about it.
			Broker broker = BrokerFactory.getBroker(brokers[i]);
			if(broker == null)
			{
				broker = BrokerFactory.getDefaultBroker();
			}
			broker.rollback();
		}
	}
	/**
	 *  Save this persistent object.
	 *
	 * @param  p Description of Parameter
	 */
	public synchronized void savePersistence(Persistence p)
	{
		int idx = getBrokerIndex(p);
		if(changeList[idx] == null)
		{
			changeList[idx] = new ArrayList();
		}
		changeList[idx].add(p);
	}
	/**
	 * @return  Description of the Returned Value
	 */
	public int size()
	{
		return size;
	}
	/**
	 *  Tell all of the brokers to update, insert, or delete the appropriate
	 *  values.
	 *
	 * @param  allowRetry Description of Parameter
	 * @exception  QueryException Description of Exception
	 * @parameter  allowRetry true if this method will allow a recursive attempt to
	 *      'try again' at the transaction.
	 */
	protected void doUpdates(boolean allowRetry) throws QueryException
	{
		for(int i = 0; i < size; ++i)
		{
			Broker broker = BrokerFactory.getBroker(brokers[i]);
			if(broker == null)
			{
				broker = BrokerFactory.getDefaultBroker();
			}
			try
			{
				if(changeList[i] != null)
				{
					broker.saveObjects(changeList[i]);
					//throws QueryException
				}
				if(deleteList[i] != null)
				{
					broker.deleteObjects(deleteList[i]);
					//throws QueryException
				}
			}
			catch(QueryException ex)
			{
				if(allowRetry && ex.isRetryPossible())
				{
					BrokerFactory.println("Attempting retry elements in transaction");
					broker.beginTransaction();
					// Need to tell it start again
					doUpdates(false);
					BrokerFactory.println("Successful retry");
				}
				else
				{
					throw ex;
				}
			}
		}
	}
	/**
	 * @param  p Description of Parameter
	 * @return  The BrokerIndex value
	 */
	int getBrokerIndex(Persistence p)
	{
		if(size == 0)
		{
			size = 1;
		}
		String name = p.getBrokerName();
		if(name == null)
		{
			return 0;
		}
		for(int i = 1; i < size; i++)
		{
			if(name.equals(brokers[i]))
			{
				return i;
			}
		}
		if(size == brokers.length)
		{
			growLists();
		}
		brokers[size] = name;
		return ++size - 1;
	}
	/**
	 *  Grow by increments of 10.
	 */
	void growLists()
	{
		int newLength = brokers.length + 10;
		String[] newBrokers = new String[newLength];
		System.arraycopy(brokers, 0, newBrokers, 0, brokers.length);
		brokers = newBrokers;

		ArrayList[] newArrayList = new ArrayList[newLength];
		System.arraycopy(changeList, 0, newArrayList, 0, changeList.length);
		changeList = newArrayList;

		newArrayList = new ArrayList[newLength];
		System.arraycopy(deleteList, 0, newArrayList, 0, deleteList.length);
		deleteList = newArrayList;
	}
	/**
	 * @param  idx Description of Parameter
	 * @exception  QueryException Description of Exception
	 * @exception  com.objectwave.transactionalSupport.UpdateException Description
	 *      of Exception
	 * @author  Dave Hoag
	 */
	void resave(int idx) throws QueryException, com.objectwave.transactionalSupport.UpdateException
	{
		ArrayList v = changeList[idx];
		if(v == null)
		{
			return;
		}
		for(int i = 0; i < v.size(); i++)
		{
			Persistence p = (Persistence) v.get(i);
			//The following 'restore object' call could end up in a 'delete' invocation
			log.restoreObject(p.getObjectEditor(), false);
			if(p.isRetrievedFromDatabase())
			{
				p.save();
			}
		}
	}
	/**
	 * @param  idx Description of Parameter
	 * @exception  QueryException Description of Exception
	 * @author  Dave Hoag
	 */
	void undelete(int idx) throws QueryException
	{
		ArrayList v = deleteList[idx];
		if(v == null)
		{
			return;
		}
		for(int i = 0; i < v.size(); i++)
		{
			Persistence p = (Persistence) v.get(i);
			p.save();
		}
	}
	/**
	 *  In the event that multpile brokers are involved with the transaction, this
	 *  will attempt to undo the committed changes.
	 *
	 * @param  end Description of Parameter
	 * @exception  QueryException Description of Exception
	 * @exception  UpdateException Description of Exception
	 */
	private final void restoreData(int end) throws QueryException, UpdateException
	{
		//Attempt to undo committed changes.
		for(int j = 0; j < end; ++j)
		{
			undelete(j);
			//Undelete those in index j.
			resave(j);
			//Change any updates
		}
	}
	/**
	 *  Unit tests.
	 *
	 * @author  dhoag
	 * @version  $Id: BrokerChangeList.java,v 1.1.1.1 2001/02/13 23:18:40 dhoag Exp
	 *      $
	 */
	public static class Test extends com.objectwave.test.UnitTestBaseImpl
	{
		BrokerChangeList list;
		ArrayList saveList;
		ArrayList delList;
		boolean breakIt = false;
		/**
		 *  The main program for the Test class
		 *
		 * @param  args The command line arguments
		 */
		public static void main(String[] args)
		{
			com.objectwave.test.TestRunner.run(new Test(), args);
		}
		/**
		 *  The JUnit setup method
		 *
		 * @param  str The new Up value
		 * @param  context The new Up value
		 * @exception  Exception
		 */
		public void setUp(String str, com.objectwave.test.TestContext context) throws Exception
		{
			super.setUp(str, context);
			list = new BrokerChangeList(new BrokerTransactionLog());
			BrokerFactory.addStaticBroker("aFakeBroker", new ObjectPoolBroker(new ObjectPool()));
		}
		/**
		 * @exception  QueryException Description of Exception
		 * @exception  UpdateException Description of Exception
		 */
		public void testCommitAll() throws QueryException, UpdateException
		{
			Broker brok =
				new ObjectPoolBroker(new ObjectPool())
				{
					/**
					 *  Description of the Method
					 *
					 * @exception  QueryException Description of Exception
					 */
					public void commit() throws QueryException
					{
						if(breakIt)
						{
							throw new QueryException("asdf", null);
						}
					}
				};
			BrokerFactory.addStaticBroker("aFakeBroker2", brok);
			saveList = new ArrayList();
			delList = new ArrayList();
			MyExamplePerson pers = new MyExamplePerson();
			pers.setName("me");
			pers.setBrokerName("aFakeBroker");
			list.savePersistence(pers);

			pers = new MyExamplePerson();
			pers.setName("me2");
			pers.setBrokerName("aFakeBroker2");
			list.savePersistence(pers);
			list.deletePersistence(pers);

			list.commitAll();

			testContext.assertEquals(2, saveList.size());
			testContext.assertEquals(saveList.get(1).toString(), "me2");
			testContext.assertEquals(delList.get(0).toString(), "me2");

			breakIt = true;
			try
			{
				delList = new ArrayList();
				saveList = new ArrayList();
				BrokerTransactionLog log = new BrokerTransactionLog();
				list = new BrokerChangeList(log);
				pers = new MyExamplePerson();
				pers.setName("me");
				pers.setBrokerName("aFakeBroker");
				list.savePersistence(pers);

				RDBPersistentAdapter adapt = (RDBPersistentAdapter) pers.getAdapter();
				adapt.markChange(new NullChange(adapt, false, true), log);

				pers = new MyExamplePerson();
				pers.setName("meDel");
				pers.setBrokerName("aFakeBroker");
				list.deletePersistence(pers);

				pers = new MyExamplePerson();
				pers.setName("me2");
				pers.setBrokerName("aFakeBroker2");
				list.savePersistence(pers);

				list.commitAll();
			}
			catch(QueryException ex)
			{
				//The 2 expected saves, plus the one undelete
				testContext.assertEquals(3, saveList.size());
				testContext.assertEquals("meDel", saveList.get(2).toString());
				//The saved object should not be deleted!
//Not quite sure how to test this yet
//				testContext.assertEquals(2, delList.size());
//				testContext.assertEquals("me",delList.get(1).toString());
				return;
			}
			testContext.assertTrue("Exception wasn't thrown as expected ", false);
		}
		/**
		 *  A unit test for JUnit
		 */
		public void testBrokerIdx()
		{
			ExamplePerson pers = new ExamplePerson();
			int idx = list.getBrokerIndex(pers);
			testContext.assertEquals(0, idx);
			pers.setBrokerName("aFakeBroker");
			idx = list.getBrokerIndex(pers);
			testContext.assertEquals(1, idx);

			idx = list.getBrokerIndex(pers);
			testContext.assertEquals(1, idx);

			for(int i = 2; i < 40; i++)
			{
				pers.setBrokerName("aFakeBroker" + i);
				idx = list.getBrokerIndex(pers);
				testContext.assertEquals(i, idx);
			}
			testContext.assertEquals(40, list.size());
		}
		/**
		 *  A unit test for JUnit
		 */
		public void testDelPersistence()
		{
			ExamplePerson pers = new ExamplePerson();

			int idx = list.getBrokerIndex(pers);
			list.deletePersistence(pers);
			pers = new ExamplePerson();
			list.deletePersistence(pers);

			testContext.assertEquals(2, ((ArrayList) list.deleteList[idx]).size());

			pers = new ExamplePerson();
			pers.setBrokerName("aFakeBroker");
			idx = list.getBrokerIndex(pers);
			list.deletePersistence(pers);

			testContext.assertEquals(1, ((ArrayList) list.deleteList[idx]).size());
		}
		/**
		 *  A unit test for JUnit
		 */
		public void testSavePersistence()
		{
			ExamplePerson pers = new ExamplePerson();

			int idx = list.getBrokerIndex(pers);
			list.savePersistence(pers);
			pers = new ExamplePerson();
			list.savePersistence(pers);

			testContext.assertEquals(2, ((ArrayList) list.changeList[idx]).size());

			pers = new ExamplePerson();
			pers.setBrokerName("aFakeBroker");
			idx = list.getBrokerIndex(pers);
			list.savePersistence(pers);

			testContext.assertEquals(1, ((ArrayList) list.changeList[idx]).size());
		}
		/**
		 *  Description of the Class
		 *
		 * @author  dhoag
		 * @version  $Id: BrokerChangeList.java,v 1.1.1.1 2001/02/13 23:18:40 dhoag
		 *      Exp $
		 */
		class MyExamplePerson extends ExamplePerson
		{
			/**
			 *  Description of the Method
			 */
			public void save()
			{
				saveList.add(getName());
			}
			/**
			 *  Description of the Method
			 */
			public void delete()
			{
				delList.add(getName());
			}
		}
	}
}
