package com.objectwave.persist;
import com.objectwave.logging.MessageLog;
import com.objectwave.persist.broker.ObjectPool;
import com.objectwave.persist.broker.ObjectPoolBroker;
import com.objectwave.persist.broker.RDBBroker;
import com.objectwave.persist.properties.BrokerPropertySource;
import com.objectwave.utility.ScalarTypeFactory;
import java.sql.Driver;
import java.util.Hashtable;
/**
 *  Factory may be an incorrect name. More like a BrokerManager. Here we
 *  initialize and contain references to the Persistence framework.
 *
 * @author  dhoag
 * @version  $Id: BrokerFactory.java,v 2.1 2002/02/13 21:36:18 dave_hoag Exp $
 */
public class BrokerFactory
{
	/**
	 */
	public static PersistLogIF logger =
		new PersistLogIF()
		{
			/**
			 * @param  str
			 */
			public void log(String str)
			{
				MessageLog.debug(this, str);
			}
		};
	static Broker brok;
	static BrokerPropertyIF defaultProperties;
	//The following seems odd, but it ensures that the classes will not
	// be garbage collected. If it is, it will lose it's default instance.
	// However, is is up to someone else to make sure that BrokerFactory is not garbage collected.
	private static Class q = RDBBroker.class;
	private static Class p = ObjectPoolBroker.class;
	private static Class r = SQLQuery.class;
	private static Class t = com.objectwave.transactionalSupport.TransactionLog.class;
	private static Class u = ScalarTypeFactory.class;

	private static Hashtable brokerInstances;
	private static Object syncObject;
	/**
	 * @param  b The new DefaultBroker value
	 * @author  Dave Hoag
	 */
	public static void setDefaultBroker(Broker b)
	{
		brok = b;
	}
	/**
	 * @param  prop The new DefaultProperties value
	 */
	public static void setDefaultProperties(BrokerPropertyIF prop)
	{
		defaultProperties = prop;
	}
	/**
	 *  Get any broker that's been registered via addStaticBroker. Check the static
	 *  initializer block of this class to see what types are automatically
	 *  registered.
	 *
	 * @param  name String Some string to identify the broker. (ex.
	 *      "jdbc:odbc:leasing")
	 * @return  The Broker value
	 * @exception  QueryException
	 * @returns  the RDBBroker which matches "name", else null.
	 */
	public static Broker getBroker(String name) throws QueryException
	{
		if(name == null)
		{
			return null;
		}
		BrokerInstance bi = null;
		synchronized(getSyncObject())
		{
			bi = (BrokerInstance) getBrokerInstances().get(name);
			if(bi == null)
			{
				return null;
			}
			if(bi.broker == null)
			{
				//Only initialize one broker at a time.
				synchronized(RDBBroker.class)
				{
					//Another thread may have initialized broker.
					if(bi.broker != null)
					{
						return bi.broker;
					}

					RDBBroker theBroker = new RDBBroker();
					theBroker.getBrokerPropertySource().setConnectUrl(bi.connectUrl);

					try
					{
						Class c = Class.forName(bi.driver);
						theBroker.setDriver((Driver) c.newInstance());
					}
					catch(Exception ex)
					{
						MessageLog.debug(new BrokerFactory(), "Error creating broker", ex);
						throw new QueryException("Failed to create configured broker " + name, ex);
					}

					bi.broker = theBroker;
					((RDBBroker) bi.broker).initialize();
				}
			}
		}
		return bi.broker;
	}
	/**
	 *  Gets the BrokerInstances attribute of the BrokerFactory class
	 *
	 * @return  The BrokerInstances value
	 */
	public static Hashtable getBrokerInstances()
	{
		if(brokerInstances == null)
		{
			synchronized(getSyncObject())
			{
				if(brokerInstances == null)
				{
					brokerInstances = new Hashtable(4);
				}
			}
		}
		return brokerInstances;
	}
	/**
	 *  This will invoke the 'createBroker' method on the instance of RDBBroker (or
	 *  a subclass). The createBroker method will return an instance of the
	 *  appropriate type.
	 *
	 * @return  The DatabaseBroker value
	 */
	public static RDBBroker getDatabaseBroker()
	{
		String db = new BrokerPropertySource("ow").getDatabaseImpl();

		try
		{
			Class c = Class.forName(db);
			RDBBroker fact = (RDBBroker) c.newInstance();
			return fact.defaultBroker();
		}
		catch(Exception ex)
		{
			MessageLog.warn(BrokerFactory.class, "Failed to create broker " + db, ex);
		}
		return RDBBroker.getDefaultBroker();
	}
	/**
	 *  It is intedended that an Broker never be manually instantiated. A single
	 *  instance of Broker will need to be shared among many different aspects of
	 *  the application, therefore an application should only obtain a handle to
	 *  the broker with this factory method.
	 *
	 * @return  The DefaultBroker value
	 * @author  Dave Hoag
	 */
	public static Broker getDefaultBroker()
	{
		return brok;
	}
	/**
	 *  Gets the ObjectPoolBroker attribute of the BrokerFactory class
	 *
	 * @return  The ObjectPoolBroker value
	 */
	public static ObjectPoolBroker getObjectPoolBroker()
	{
		return ObjectPoolBroker.getDefaultBroker();
	}
	/**
	 * @return  The DefaultProperties value
	 */
	public static BrokerPropertyIF getDefaultProperties()
	{
		if(defaultProperties != null)
		{
			return defaultProperties;
		}
		return new DefaultBrokerProperty();
	}
	/**
	 *  Gets the SyncObject attribute of the BrokerFactory class
	 *
	 * @return  The SyncObject value
	 */
	private static Object getSyncObject()
	{
		if(syncObject == null)
		{
			syncObject = new Object();
		}
		return syncObject;
	}

	/**
	 *  This method is for adding a broker to the static list which is not an
	 *  RBDBroker or is a special case thereof which cannot be handled by the
	 *  lazy-initialization system. ex. <pre>
	 *
	 *  String db = System.getProperty("pooledBroker.databaseImpl",
	 *  "com.objectwave.persist.OracleBroker"); try { Class c = Class.forName(db);
	 *  RDBBroker broker = (RDBBroker) c.newInstance();
	 *  broker.setBrokerProperty(props); broker.initialize();
	 *  broker.setUsingObjectPool(true); BrokerFactory.addStaticBroker("pooledBroker",
	 *  broker); } catch (Exception ex) { BrokerFactory.println(ex.toString()); }
	 *  </pre>
	 *
	 * @param  name The feature to be added to the StaticBroker attribute
	 * @param  broker The feature to be added to the StaticBroker attribute
	 */
	public static void addStaticBroker(String name, Broker broker)
	{
		BrokerInstance bi = new BrokerInstance(broker, null, null);
		synchronized(getSyncObject())
		{
			getBrokerInstances().put(name, bi);
		}
	}
	/**
	 *  Add a static broker type to the factory. Also see addStaticBroker(String,
	 *  Driver).
	 *
	 * @param  name The feature to be added to the StaticBroker attribute
	 * @param  connectUrl The feature to be added to the StaticBroker attribute
	 */
	public static void addStaticBroker(String name, String connectUrl)
	{
		addStaticBroker(name, connectUrl, null);
	}
	/**
	 *  Add a static broker type to the factory. The name should be the connect URL
	 *  to use, and the Driver should be the proper driver for the given
	 *  connection. If driver is null, then a default driver of type JdbcOdbcDriver
	 *  is used.
	 *
	 * @param  name The feature to be added to the StaticBroker attribute
	 * @param  connectUrl The feature to be added to the StaticBroker attribute
	 * @param  driver The feature to be added to the StaticBroker attribute
	 */
	public static void addStaticBroker(String name, String connectUrl, String driver)
	{
		if(driver == null)
		{
			driver = "sun.jdbc.odbc.JdbcOdbcDriver";
		}
		BrokerInstance bi = new BrokerInstance(null, "sun.jdbc.odbc.JdbcOdbcDriver", connectUrl);
		synchronized(getSyncObject())
		{
			getBrokerInstances().put(name, bi);
		}
	}
	/**
	 *  Utility method to assist with migration to logger interface.
	 *
	 * @param  str
	 */
	public static void println(String str)
	{
		logger.log(str);
	}
	/**
	 *  Convience method for setting up persistence to use RDBBroker. No object
	 *  pooling. This is probably the most likely means to initialize Persistence.
	 */
	public static void useDatabase()
	{
		useDatabase(false, null);
	}
	/**
	 *  Convience method for setting up persistence to use RDBBroker.
	 *
	 * @param  pool Enable object pooling
	 * @param  p The pool to use for object pooling.
	 */
	public static void useDatabase(boolean pool, ObjectPool p)
	{
		RDBBroker b = getDatabaseBroker();
		setDefaultBroker(b);
		SQLQuery.setDefaultBroker(b);
		b.setObjectPool(p);
		b.setUsingObjectPool(pool);
	}
	/**
	 *  Convience method for setting up persistence to use objectpool broker.
	 *
	 * @param  p
	 */
	public static void useObjectPoolBroker(ObjectPool p)
	{
		ObjectPoolBroker b = getObjectPoolBroker();
		setDefaultBroker(b);
		SQLQuery.setDefaultBroker(b);
		b.setObjectPool(p);
	}
	/**
	 * @author  dhoag
	 * @version  $Id: BrokerFactory.java,v 2.1 2002/02/13 21:36:18 dave_hoag Exp $
	 */
	static class DefaultBrokerProperty implements BrokerPropertyIF
	{
		/**
		 * @param  key
		 * @return  The Property value
		 */
		public String getProperty(String key)
		{
			return System.getProperty(key);
		}
		/**
		 * @param  key
		 * @param  defaultValue
		 * @return  The Property value
		 */
		public String getProperty(String key, String defaultValue)
		{
			return System.getProperty(key, defaultValue);
		}
		/**
		 * @param  key
		 * @param  value
		 */
		public void put(Object key, Object value)
		{
			System.getProperties().put(key, value);
		}
		/**
		 *  Do nothing
		 *
		 * @param  b
		 */
		public void configure(Broker b)
		{
		}
	}

	/**
	 *  Used to hold brokers in the brokerInstances hashtable.
	 *
	 * @author  dhoag
	 * @version  $Id: BrokerFactory.java,v 2.1 2002/02/13 21:36:18 dave_hoag Exp $
	 */
	private static class BrokerInstance
	{
		Broker broker;
		String driver;
		String connectUrl;
		/**
		 *  Constructor for the BrokerInstance object
		 *
		 * @param  b
		 * @param  driverName
		 * @param  url
		 */
		BrokerInstance(Broker b, String driverName, String url)
		{
			broker = b;
			driver = driverName;
			connectUrl = url;
		}
	}
	static
	{
		com.objectwave.transactionalSupport.TransactionLog.addTransactionSupport("RDB", BrokerTransactionLog.class);
		new com.objectwave.persist.collectionAdapters.SupportedCollections();
		// hook into the production database (Informix):
//		addStaticBroker("production", "jdbc:odbc:prod", "sun.jdbc.odbc.JdbcOdbcDriver");
	}
}
