/* Copyright (C) 2001 David Hoag
 * ObjectWave Corporation
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * For a full copy of the license see:
 * http://www.opensource.org/licenses/lgpl-license.html
 */
package com.objectwave.persist;

import com.objectwave.persist.mapping.*;
import com.objectwave.transactionalSupport.ObjectEditingView;
import com.objectwave.transactionalSupport.TransactionLog;
import com.objectwave.transactionalSupport.UpdateException;
import java.util.*;

/**
 *  Provide some database specific transactional stuff. If we have an
 *  RDBTransaction log this log can provide support to saving change objects.
 *  CAUTION : - IF A QUERY IS EXECUTED WITH AN OBJECT THAT WAS ONCE MARKED
 *  DIRTY, THAT OBJECT WILL BE REMOVED FROM THE TRANSACTION LOG. COMMIT CHANGES
 *  BEFORE USING AN OBJECT AS A QUERY!!!!
 *
 * @author  dhoag
 * @version  $Id: BrokerTransactionLog.java,v 2.1 2001/06/15 13:45:32 dave_hoag Exp $
 */
public class BrokerTransactionLog extends TransactionLog
{
	final static boolean warnOfCollectionChanges = false;
	boolean metrics = System.getProperty("ow.persistMetrics", "").equals("true");
	Broker broker = null;

	/**
	 */
	public BrokerTransactionLog()
	{
		try
		{
			initialize(null);
			// with the null parameter, this exception will not occur.
		}
		catch(QueryException ex)
		{
		}
	}
	/**
	 * @param  brokerType
	 * @exception  QueryException
	 */
	public BrokerTransactionLog(String brokerType) throws QueryException
	{
		initialize(brokerType);
	}
	/**
	 *  Sets the Broker attribute of the BrokerTransactionLog object
	 *
	 * @param  brok The new Broker value
	 */
	public void setBroker(Broker brok)
	{
		broker = brok;
	}
	/**
	 *  Select those objects that need to be saved to and delete from the
	 *  relational database. I considered having this object 'delete' any values
	 *  that are dropped from a collection, but that is not necessarily what I want
	 *  to do. It is up to the application developer to mark what objects are to be
	 *  deleted. Side effect of 'commiting' changes into object.
	 *
	 * @param  force
	 * @return  The ModifiedObjects value
	 * @exception  UpdateException
	 */
	protected BrokerChangeList getModifiedObjects(boolean force) throws UpdateException
	{
		BrokerChangeList saveList = new BrokerChangeList(this);
		if(editedObjects == null)
		{
			return saveList;
		}

		for(int i = 0; i < editedObjectsCount; ++i)
		{
			ObjectEditingView view = editedObjects[i];
			//Every change needs to be updated.
			//updateObject(view, force);
			view.commit(this, force);
			//Only RDBPersistent objects need to be saved to the database.
			try
			{
				RDBPersistentAdapter obj = (RDBPersistentAdapter) view;
				if(obj.containsAttributeChanges(this))
				{
					if(obj.isDeleteThis())
					{
						saveList.deletePersistence(obj.getPersistentObject());
					}
					else
					{
						saveList.savePersistence(obj.getPersistentObject());
					}
				}
				else
						if(warnOfCollectionChanges)
				{
					BrokerFactory.println("Collection may have changed!");
				}
			}
			catch(ClassCastException ex)
			{
				//An unlikely event, but possible. Not really an error, just means a custom adapter is in use.
			}
		}
		return saveList;
	}
	/**
	 */
	public void forceCommit()
	{
		try
		{
			commit(true);
		}
		catch(UpdateException ex)
		{
		}
	}
	/**
	 */
	public void rollback()
	{
		try
		{
			broker.rollback();
		}
		catch(QueryException e)
		{
		}
		super.rollback();
	}
	/**
	 *  Called by super class when we are ready to really commit the values. This
	 *  only occurs for top level Transactions. Changes in nested transactions are
	 *  migrated to top level transactions by calls to commit().
	 *
	 * @exception  UpdateException
	 */
	protected void actualCommit() throws UpdateException
	{
		long start = System.currentTimeMillis();
		if(editedObjects != null)
		{
			try
			{
				transactionManager.getLockManager().acquireLocks(editedObjects, editedObjectsCount);
				commit(false);
			}
			catch(UpdateException ex)
			{
				limitedRollback();
				throw ex;
			}
			catch(RuntimeException ex)
			{
				limitedRollback();
				throw ex;
			}
			finally
			{
				if(editedObjects != null)
				{
					transactionManager.getLockManager().releaseLocks(editedObjects, editedObjectsCount);
				}
			}
		}
	}
	/**
	 *  Copy the values from the object editing view into the domain object. Try to
	 *  save all of the persistent objects to the database.
	 *
	 * @param  force
	 * @exception  UpdateException
	 */
	protected void commit(boolean force) throws UpdateException
	{
		BrokerChangeList saveList = null;
		try
		{
			saveList = getModifiedObjects(force);
			if(saveList.size() < 1)
			{
				return;
			}

			saveList.commitAll();
		}
		catch(QueryException ex)
		{
			//fixme - Restore all objects to original state. Fails in the multiple broker situation.
			limitedRollback();
			try
			{
				saveList.rollback();
			}
			catch(QueryException exc)
			{
			}

			BrokerFactory.println(ex.getOriginalException().toString());
			if(ex.getAdditionalInfo() != null)
			{
				BrokerFactory.println(ex.getAdditionalInfo());
			}
			throw new UpdateException(ex);
		}
	}
	/**
	 * @param  brokerType
	 * @exception  QueryException
	 */
	protected void initialize(String brokerType) throws QueryException
	{
		if(brokerType == null)
		{
			broker = BrokerFactory.getDefaultBroker();
		}
		else
		{
			broker = BrokerFactory.getBroker(brokerType);
			if(broker == null)
			{
				broker = BrokerFactory.getDefaultBroker();
			}
		}
	}
	/**
	 *  Copy the values from the ObjectEditor into the Object. Used to 'rollback'
	 *  changes into the object.
	 *
	 * @param  view
	 * @param  force
	 * @exception  UpdateException
	 */
	protected void restoreObject(ObjectEditingView view, boolean force) throws UpdateException
	{
		view.rollback(this, force);
	}
}
