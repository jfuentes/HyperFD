package com.objectwave.persist;
import java.io.Serializable;
/**
 *  This class enables the generic persistence framework to support multiple
 *  collection types.
 *
 * @author  Dave Hoag
 * @version  1.1
 */
public interface CollectionAdapter extends Serializable
{
	/**
	 *  An entry point to tweak the query before issuing the find. This will be a
	 *  noop for most CollectionAdapters.
	 *
	 * @param  q
	 */
	public void preQuery(SQLQuery q);
	/**
	 *  Invoked when a new instance is needed. This could simply return 'this'.
	 *  This is called when creating the SQLQuery that will realize a collection
	 *  attribute. Normally, this method is not invoked, only when a
	 *  CollectionAdapter is associated with an AttributeTypeColumn.
	 *
	 * @return  The NewInstance value
	 */
	public CollectionAdapter getNewInstance();
	/**
	 *  Get the actual collection object.
	 *
	 * @return  Object that is the 'collection'
	 */
	Object getCollectionObject();
	/**
	 *  Add the object to this collection.
	 *
	 * @param  obj The feature to be added to the Element attribute
	 */
	void addElement(Object obj);
	/**
	 *  The number of elements in the collection.
	 *
	 * @return
	 */
	int size();
	/**
	 * @return
	 */
	Object firstElement();
}
