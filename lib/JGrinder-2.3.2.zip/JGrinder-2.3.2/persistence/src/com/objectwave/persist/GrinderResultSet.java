package com.objectwave.persist;
import com.objectwave.persist.broker.*;
import java.sql.ResultSet;

/**
 * Private class for use in this package for returning two elements from a method.
 *
 * @version 2.0
 * @author Dave Hoag
 */
public class GrinderResultSet
{

	java.sql.ResultSet resultSet;
	java.sql.Statement statement;
	RDBConnection connection;
	boolean available;
	boolean dropped ;
	public synchronized void setDropped(boolean value) throws java.sql.SQLException
	{
		dropped = value;
		if(available == true)
		{
//			System.out.println("Closing in drop");
			statement.close();
//			RDBConnection.statementCount--;
//			available = false;
		}
	}
/**
 * GrinderResultSet constructor comment.
 */
public GrinderResultSet(final ResultSet set, final java.sql.Statement stmt, final RDBConnection connection)
{
	available = false;
	setResultSet(set);
	setStatement(stmt);
	setConnection(connection);
}
	public boolean isAvailable(){ return available; }
	public void setAvailable(boolean b)
	{
		available = b;
	}
/**
 * @author Dave Hoag
 */
public synchronized void close() throws java.sql.SQLException
{
//System.out.println("Close set " + resultSet + " " + this);
	try
	{
		resultSet.close();
		resultSet = null;
		if(connection.getLastResultSet() != this)
		{
	//		System.out.println("Closing in close");
			statement.close();
	//		RDBConnection.statementCount--;
		}
		else
		{
	//		System.out.println("Marking available!");
			available = true;
		}
	}
	finally
	{
		if(! connection.isInTransaction())
		{
			connection.freeConnection();
		}
	}
}
/**
 * @author Dave Hoag
 * @return java.sql.ResultSet
 */
public java.sql.ResultSet getResultSet()
{
	return resultSet;
}
/**
 * @author Dave Hoag
 * @return java.sql.Statement
 */
public java.sql.Statement getStatement()
{
	return statement;
}
/**
 * @author Dave Hoag
 * @param newValue java.sql.ResultSet
 */
public void setResultSet(java.sql.ResultSet newValue)
{
	if(resultSet != null) throw new RuntimeException("Result set not null");
	this.resultSet = newValue;

}
/**
 * @author Dave Hoag
 * @param newValue java.sql.Statement
 */
public /*synchronized */void setStatement(java.sql.Statement newValue)
{
	this.statement = newValue;
//	RDBConnection.statementCount++;
}
/**
*/
public void setConnection(RDBConnection connect)
{
	connection = connect;
}
/**
 */
public RDBConnection getConnection()
{
	return connection;
}
}
