package com.objectwave.persist;

import java.lang.reflect.Field;

/**
 * @author  cson
 * @version  $Id: JoinField.java,v 2.1 2001/08/10 20:31:35 dave_hoag Exp $
 */
public class JoinField implements Comparable
{

	private String joinColumn = null;
	private Field joinField = null;

	/**
	 *Constructor for the JoinField object
	 */
	public JoinField()
	{
	}
	/**
	 *Constructor for the JoinField object
	 *
	 * @param  joinColumn
	 * @param  joinField
	 */
	public JoinField(String joinColumn, Field joinField)
	{
		this.joinColumn = joinColumn;
		this.joinField = joinField;
	}

	/**
	 *Sets the JoinColumn attribute of the JoinField object
	 *
	 * @param  joinColumn The new JoinColumn value
	 */
	public void setJoinColumn(String joinColumn)
	{
		this.joinColumn = joinColumn;
	}
	/**
	 *Sets the JoinField attribute of the JoinField object
	 *
	 * @param  joinField The new JoinField value
	 */
	public void setJoinField(Field joinField)
	{
		this.joinField = joinField;
	}

	/**
	 *Gets the JoinColumn attribute of the JoinField object
	 *
	 * @return  The JoinColumn value
	 */
	public String getJoinColumn()
	{
		return joinColumn;
	}
	/**
	 *Gets the JoinField attribute of the JoinField object
	 *
	 * @return  The JoinField value
	 */
	public Field getJoinField()
	{
		return joinField;
	}

	/**
	 * @param  o
	 * @return
	 */
	public boolean equals(Object o)
	{
		if(o != null && o instanceof JoinField)
		{
			JoinField other = (JoinField) o;
			if(joinColumn == null &&
					other.joinColumn == null &&
					joinField == null &&
					other.joinField == null)
			{
				return true;
			}
			else if(joinColumn != null &&
					other.joinColumn != null &&
					joinColumn.equals(other.joinColumn) &&
					joinField != null &&
					other.joinField != null &&
					joinField.equals(other.joinField))
			{
				return true;
			}
		}
		return false;
	}

	/**
	 * @param  o
	 * @return
	 */
	public int compareTo(Object o)
	{
		if(o instanceof JoinField)
		{
			if(equals(o))
			{
				return 0;
			}
			return ((joinColumn == null) ? "" : joinColumn).compareTo(((JoinField) o).joinColumn);
		}
		else
		{
			return 1;
		}
	}

}
