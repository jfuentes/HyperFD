package com.objectwave.persist;
import com.objectwave.persist.*;
import com.objectwave.persist.examples.*;
import com.objectwave.utility.ScalarType;
import com.objectwave.utility.ScalarTypeFactory;
import com.objectwave.utility.ScalarTypeGeneratorIF;

import com.objectwave.utility.StringManipulator;
import java.io.*;
import java.lang.reflect.*;
import java.sql.Timestamp;
import java.util.Date;
import java.util.Vector;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;
/**
 *  This class converts data from one type to another. Used extensively for
 *  persistence manipulation.
 *
 * @author  Dave Hoag
 * @version  $Id: ObjectFormatter.java,v 2.1 2002/03/23 13:42:10 dave_hoag Exp $
 */
public class ObjectFormatter extends com.objectwave.utility.ObjectFormatter
{
	/**
	 * @param  statement
	 * @param  data
	 * @param  idx
	 * @exception  java.sql.SQLException
	 */
	public void bindBlob(java.sql.PreparedStatement statement, byte[] data, int idx) throws java.sql.SQLException
	{
		throw new RuntimeException("Blobs not supported");
	}
	/**
	 *  If we have an Array of a scalar datatype, we may store that in the database
	 *  as a long string. This method will convert the long string into an array of
	 *  the scalar data types. This method will convert the data from the database
	 *  into the correct format for the Object.
	 *
	 * @param  data
	 * @param  cols
	 * @author  Dave Hoag
	 */
	public void convertTypes(final Object[] data, final AttributeTypeColumn[] cols)
	{
		for(int i = 0; i < cols.length; i++)
		{
			data[i] = convertType(cols[i], data[i]);
		}
	}
	/**
	 *  Convert the data represented by 'obj' to the correct data type as specified
	 *  by 'col'.
	 *
	 * @param  col AttributeTypeColumn from a class description.
	 * @param  obj
	 * @return  An instance of the expected type.
	 */
	public Object convertType(final AttributeTypeColumn col, final Object obj)
	{
		final Field f = col.getField();
		final Class c = f.getType();

		return convertType(c, obj);
	}
	/**
	 *  Check to see the the field represented by this AttributeTypeColumn is a
	 *  native array.
	 *
	 * @param  col
	 * @return
	 */
	public boolean needsArrayConversion(final AttributeTypeColumn col)
	{
		final java.lang.reflect.Field f = col.getField();
		final Class c = f.getType();
		//Don't convert byte []s at this point
		return (c.isArray() && c.getComponentType() != byte.class);
		//For now, don't do anything - bytes converted in formatValue
	}
	/**
	 *  If we have an Array of a scalar datatype, we may store that in the database
	 *  as a long string. This method will convert the array into a long string.
	 *  I've used '\n' the new line character to sperate entries. This could cause
	 *  problems but many of the other characters were having troubles getting in
	 *  an out of the datatbase.
	 *
	 * @param  map
	 * @param  cols
	 * @return
	 */
	public boolean convertArrays(final Object[] map, final AttributeTypeColumn[] cols)
	{
		boolean hasArrays = false;
		for(int i = 0; i < cols.length; i++)
		{
			AttributeTypeColumn col = cols[i];
			if(needsArrayConversion(col))
			{
				hasArrays = true;
				if(map[i] != null)
				{
					map[i] = convertArray(map[i]);
				}
			}
		}
		return hasArrays;
	}
	/**
	 *  Unit tests.
	 *
	 * @author  dhoag
	 * @version  $Id: ObjectFormatter.java,v 2.1 2002/03/23 13:42:10 dave_hoag Exp $
	 */
	public static class Test extends com.objectwave.test.UnitTestBaseImpl
	{
		//Used by one of the tests.
		String[] testStringField;
		int[] testField;
		short[] testField2;
		boolean[] testBools;
		byte[] testBytes;
		/**
		 *  The main program for the Test class
		 *
		 * @param  args The command line arguments
		 */
		public static void main(String[] args)
		{
			com.objectwave.test.TestRunner.run(new Test(), args);
		}
		/**
		 *  A unit test for JUnit
		 *
		 * @exception  NoSuchFieldException
		 */
		public void testArrayConversions() throws NoSuchFieldException
		{
			//The data for the tests.
			String oneTest = "1" + Native_Array_Delimiter + "2" + Native_Array_Delimiter + "3";
			String stringTest = "one" + Native_Array_Delimiter + "two" + Native_Array_Delimiter + "three";
			String booleanTest = "true" + Native_Array_Delimiter + "true" + Native_Array_Delimiter + "false";
			int[] oneTestSrc = new int[]{1, 2, 3};
			byte[] bytes = new byte[]{(byte) 1, (byte) 2, (byte) 3};
			byte[] byteTest = bytes;
			short[] oneTestSrc2 = new short[]{(short) 1, (short) 2, (short) 3};
			String[] stringTestSrc = new String[]{"one", "two", "three"};
			boolean[] bools = new boolean[]{true, true, false};

			ObjectFormatter of = new ObjectFormatter();
			//Tests string to array
			int[] result = (int[]) of.convertType(oneTestSrc.getClass(), oneTest);
			for(int i = 0; i < result.length; ++i)
			{
				testContext.assertEquals("Integer conversion failed. ", oneTestSrc[i], result[i]);
			}

			short[] result2 = (short[]) of.convertType(oneTestSrc2.getClass(), oneTest);
			for(int i = 0; i < result2.length; ++i)
			{
				testContext.assertEquals("Integer conversion failed. ", oneTestSrc2[i], result2[i]);
			}

			String[] result3 = (String[]) of.convertType(stringTestSrc.getClass(), stringTest);
			for(int i = 0; i < result3.length; ++i)
			{
				testContext.assertEquals("Integer conversion failed. ", stringTestSrc[i], result3[i]);
			}

			boolean[] result4 = (boolean[]) of.convertType(bools.getClass(), booleanTest);
			for(int i = 0; i < result4.length; ++i)
			{
				testContext.assertTrue("boolean conversion failed. ", bools[i] == result4[i]);
			}

			//Test Array to String.
			Field f = this.getClass().getDeclaredField("testField");
			AttributeTypeColumn col = new AttributeTypeColumn();
			Object[] data = new Object[1];
			AttributeTypeColumn[] cols = new AttributeTypeColumn[]{col};

			data[0] = oneTestSrc;
			col.setField(f);
			of.convertArrays(data, cols);
			testContext.assertEquals("Failed integer conversion.", data[0], oneTest);

			f = this.getClass().getDeclaredField("testField2");
			data[0] = oneTestSrc2;
			col.setField(f);
			of.convertArrays(data, cols);
			testContext.assertEquals("Failed short conversion.", data[0], oneTest);

			f = this.getClass().getDeclaredField("testStringField");
			data[0] = stringTestSrc;
			col.setField(f);
			of.convertArrays(data, cols);
			testContext.assertEquals("Failed short conversion.", data[0], stringTest);

			f = this.getClass().getDeclaredField("testBools");
			data[0] = bools;
			col.setField(f);
			of.convertArrays(data, cols);
			testContext.assertEquals("Failed boolean conversion.", data[0], booleanTest);

			//Bytes should not be converted
			f = this.getClass().getDeclaredField("testBytes");
			data[0] = bytes;
			col.setField(f);
			of.convertArrays(data, cols);
			testContext.assertEquals("Failed byte conversion.", data[0], byteTest);

		}
		/**
		 *  A unit test for JUnit
		 */
		public void testStringConversions()
		{
			ScalarTypeFactory.registerGenerator(new TestSqlScalar());

			Class[] targetClasses = {double.class, Double.class, char.class, Character.class, short.class, Short.class, long.class, Long.class, int.class, Integer.class, boolean.class, Boolean.class, byte.class, Byte.class, float.class, Float.class, TestSqlScalar.class, String.class};
			String[] testData = {"10.2", "10.2", "f", "a", "3", "4", "5", "6", "7", "8", "0", "1", "3", "5", "3.4", "4.3", "one", "one"};
			Object[] expectedResults = {new Double("10.2"), new Double("10.2"), new Character('f'), new Character('a'), new Short("3"), new Short("4"), new Long(5), new Long(6), new Integer(7), new Integer(8), new Boolean(false), new Boolean(true), new Byte("3"), new Byte("5"), new Float("3.4"), new Float("4.3"), new TestSqlScalar("one"), "one"};
			ObjectFormatter of = new ObjectFormatter();
			for(int i = 0; i < targetClasses.length; ++i)
			{
				Object actualResult = of.convertString(targetClasses[i], testData[i]);
				testContext.assertEquals("Target class of " + targetClasses[i] + " failed to convert. " + i, expectedResults[i], actualResult);
			}
		}
		/**
		 *  A unit test for JUnit
		 */
		public void testNullPrimitive()
		{
			Class[] primNums = {byte.class, int.class, float.class, double.class, short.class, long.class};
			ObjectFormatter of = new ObjectFormatter();
			for(int i = 0; i < primNums.length; ++i)
			{
				Number num = (Number) of.convertType(primNums[i], null);
				testContext.assertTrue("Null Primitive failed!", num.intValue() == 0);
			}
			Boolean b = (Boolean) of.convertType(boolean.class, null);
			testContext.assertTrue("Null boolean failed!", b.booleanValue() == false);
		}
		/**
		 *  A unit test for JUnit
		 *
		 * @exception  IOException
		 */
		public void testByteArray() throws IOException
		{
			ObjectFormatter of = new ObjectFormatter();
			byte[] data = new byte[]{(byte) 2, (byte) 0xf2, (byte) 0xa};
			String val = of.formatValue(data);
			testContext.assertEquals("Byte string creation failed ", "'02f20a'", val);

			byte[] convertedData = of.stringToBytes("02f20a");
			for(int i = 0; i < convertedData.length; i++)
			{
				testContext.assertEquals("Byte conversion failed [" + i + "] for " + Integer.toHexString(data[i]), data[i], convertedData[i]);
			}
		}
		/**
		 *  A unit test for JUnit
		 */
		public void testCreateNumber()
		{
			ObjectFormatter of = new ObjectFormatter();
			Double value = new Double(4);
			Number res = of.createNumber(byte.class, value);
			testContext.assertTrue("Byte conversion failed!", res instanceof Byte);
		}
		/**
		 *  A unit test for JUnit
		 *
		 * @exception  IOException
		 */
		public void testSerializable() throws IOException
		{
			ObjectFormatter of = new ObjectFormatter();
			StringBuffer buf = new StringBuffer();
			TestEntity to = new TestEntity();
			to.name = "AName";
			of.formatSerializable(to, buf);
			testContext.assertTrue("No data generated! ", buf.length() > 0);

			StringBuffer buf2 = new StringBuffer();
			of.formatValue(to, buf2);
			testContext.assertEquals(buf.toString(), buf2.toString());

			byte[] theObjectSerialized = of.serializeObject(to);

			TestEntity newOne = (TestEntity) (of.convertType(TestEntity.class, theObjectSerialized));

			testContext.assertEquals("AName", newOne.name);
		}
		//Used by one of the tests.
		class TestSqlScalar implements ScalarType, ScalarTypeGeneratorIF
		{
			String value;
			/**
			 *  Constructor for the TestSqlScalar object
			 */
			public TestSqlScalar()
			{
			}
			/**
			 *  Constructor for the TestSqlScalar object
			 *
			 * @param  str
			 */
			public TestSqlScalar(String str)
			{
				value = str;
			}
			/**
			 * @param  dbString
			 * @return
			 * @exception  java.text.ParseException
			 */
			public ScalarType createInstance(String dbString) throws java.text.ParseException
			{
				TestSqlScalar result = new TestSqlScalar();
				result.value = dbString;
				return result;
			}
			/**
			 * @return
			 */
			public Class typeGenerated()
			{
				return TestSqlScalar.class;
			}
			/**
			 * @return
			 */
			public String toDatabaseString()
			{
				return value;
			}
			/**
			 * @param  obj
			 * @return
			 */
			public boolean equals(Object obj)
			{
				return ((TestSqlScalar) obj).value.equals(value);
			}
		}
	}
}

