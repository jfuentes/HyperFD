package com.objectwave.persist;

import java.lang.*;
/**
 * A simple interface that will be used as the glue to plug in whatever
 * logging mechanism necessary.
 * @version 1.0
 */
public interface PersistLogIF
{
    void log(String str);
}