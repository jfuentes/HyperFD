package com.objectwave.persist;
import com.objectwave.transactionalSupport.TransactionalObjectIF;

import java.lang.reflect.Field;

/**
 * A persistent object can either implement all of the necessary support
 * for persistence, or have an adapter who does it. If an adapter performs
 * the actions, most likely all of the methods in this interface will be
 * delegated to the adapter.
 *
 * @author  Dave Hoag
 * @version  1.5
 * @see  com.objectwave.transactionalSupport.TransactionalObject
 */
public interface Persistence extends TransactionalObjectIF, java.io.Serializable
{
	/**
	 * @exception  QueryException
	 */
	public void delete() throws QueryException;
	/**
	 *Gets the Adapter attribute of the Persistence object
	 *
	 * @return  The Adapter value
	 */
	public Persistence getAdapter();
	/**
	 * Broker names allow an application to have multiple brokers.
	 * Every PersistentObject can be associated with only one broker.
	 *
	 * @return  The BrokerName value
	 */
	String getBrokerName();
	/**
	 *Sets the BrokerName attribute of the Persistence object
	 *
	 * @param  str The new BrokerName value
	 */
	public void setBrokerName(String str);
	/**
	 *Gets the PrimaryKeyField attribute of the Persistence object
	 *
	 * @return  The PrimaryKeyField value
	 */
	public Object getPrimaryKeyField();
	/**
	 *Gets the PrimaryKeyFields attribute of the Persistence object
	 *
	 * @return  The PrimaryKeyFields value
	 */
	public Object[] getPrimaryKeyFields();
	/**
	 * Force this object to be a part of the changedObjects list.
	 *
	 * @exception  QueryException
	 */
	void insert() throws QueryException;
	/**
	 *Gets the RetrievedFromDatabase attribute of the Persistence object
	 *
	 * @return  The RetrievedFromDatabase value
	 */
	public boolean isRetrievedFromDatabase();
	/**
	 * Support explicit locking and unlocking.
	 *
	 * @param  wait true if the caller wants the suspend the thread until
	 *     the object can be locked.
	 * @return  true if and only if the object was successfully locked.
	 */
	boolean lock(boolean wait);
	/**
	 * @exception  QueryException
	 */
	public void save() throws QueryException;
	/**
	 *Sets the PrimaryKeyField attribute of the Persistence object
	 *
	 * @param  val The new PrimaryKeyField value
	 */
	public void setPrimaryKeyField(Object val);
	/**
	 *Sets the RetrievedFromDatabase attribute of the Persistence object
	 *
	 * @param  b The new RetrievedFromDatabase value
	 */
	public void setRetrievedFromDatabase(boolean b);
	/**
	 * Support explicit locking and unlocking.
	 */
	void unlock();
	/**
	 * @return
	 */
	public boolean usesAdapter();
}
