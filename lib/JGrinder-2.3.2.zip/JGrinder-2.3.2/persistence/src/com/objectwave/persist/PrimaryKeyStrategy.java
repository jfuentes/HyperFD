package com.objectwave.persist;
import com.objectwave.persist.broker.RDBBroker;
import java.sql.SQLException;
/**
 *  Implement this interface if the code is to assist with the creation with the
 *  generation of PrimaryKeyValues.
 *
 * @author  dhoag
 * @version  $Id: PrimaryKeyStrategy.java,v 2.0 2001/06/11 16:00:03 dave_hoag Exp $
 */
public interface PrimaryKeyStrategy
{
	/**
	 *  Calls to this method should never return the same value. When this method
	 *  is called, the broker assumes the value returned will create a unique
	 *  primary key value that can identify a unique row in the database.
	 *
	 * @param  broker
	 * @param  pObj
	 * @return
	 * @exception  SQLException
	 * @exception  QueryException
	 */
	public Object nextPrimaryKey(RDBBroker broker, RDBPersistence pObj) throws SQLException, QueryException;
}
