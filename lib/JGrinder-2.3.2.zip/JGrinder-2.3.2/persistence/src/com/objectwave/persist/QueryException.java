package com.objectwave.persist;

/**
 * Little more than an exception wrapper class.
 * addInfo attribute could contain the acutal SQL that caused the exception.
 * originalException attribute is the source exception that was caught that threw
 * this exception.
 *
 * @author Dave Hoag
 * @version 1.3
 */
public class QueryException extends Exception
{
    boolean retryPossible;
	String text;
	String addInfo;
	Exception originalException;
	/**
	 * Create a new query exception to hide the actual problem.
	 * @param text The text to display.
	 * @param e Exception The reason for creating this object.
	 */
	public QueryException(String text, Exception e)
	{
		this.text = text;
		originalException = e;
	}
	/**
	 * Create a new query exception to hide the actual problem.
	 * @param text The text to display.
	 * @param e Exception The reason for creating this object.
	 * @param additionalInfo Not text to normally display, but may provide more information about the problem.
	 */
	public QueryException(String text, Exception e, String additionalInfo)
	{
		this(text,e);
		addInfo = additionalInfo;
	}
	/**
	 * Additional information may be provided to assist with debugging efforts.
	 * It may contain the SQL statement that cause the error.
	 * 
	 * @return String The additional information or null.
	 */
	public String getAdditionalInfo()
	{
		return addInfo;
	}
	/**
	 * If an exception occurs within JavaGrinder it will eventually be wrapped
	 * by an instance of this class. To get the causing exception, use this method.
	 * Not every QueryException will have an original exception.
	 * @return Exception The cause of your problems.
	 */
	public Exception getOriginalException()
	{
		return originalException;
	}
    /**
     */
    public void printStackTrace(java.io.PrintWriter stream)
    {
        if(getOriginalException() != null)
        {
            stream.println("Delegating stack trace to the causing exception.");
            getOriginalException().printStackTrace(stream);
        }
        else
        {
            super.printStackTrace(stream);
        }
    }
    /**
     */
    public void printStackTrace(java.io.PrintStream stream)
    {
        if(getOriginalException() != null)
        {
            stream.println("Delegating stack trace to the causing exception.");
            getOriginalException().printStackTrace(stream);
        }
        else
        {
            super.printStackTrace(stream);
        }
    }
    /**
     */
    public void printStackTrace()
    {
        if(getOriginalException() != null)
        {
            System.out.println("Delegating stack trace to the causing exception.");
            getOriginalException().printStackTrace();
        }
        else
        {
            super.printStackTrace();
        }
    }
	/**
	 * Display a nice version of this exception.
	 */
	public String toString()
	{
		if(text == null) 
		{
			String result = "QueryException";
			if(getOriginalException() != null)
			{
				result += ':' + getOriginalException().toString();
			}
			return result;
		}
		return text;
	}
    /**
     */
    public void setRetryPossible(boolean b)
    {
        retryPossible = b;
    }
    /**
     */
    public boolean isRetryPossible()
    {
        return retryPossible;
    }
}
