package com.objectwave.persist;
import com.objectwave.exception.NotFoundException;
import java.lang.reflect.Field;
import java.util.Hashtable;
import java.util.Vector;
/**
 *  In order be used with in the RDB supporting framework, all of the following
 *  methods must be implemented. Fortunately, most of the work has been done in
 *  the RDBPersistentAdapter class, and very little is actually needed to be
 *  done by the programmer. The reason that there are some many methods in this
 *  class is that it provides a great amount of flexibility in creating the
 *  persistence layer. The default behavior will be sufficient for most,
 *  however, it may be necessary to change any of the following methods.
 *
 * @author  dhoag
 * @version  $Id: RDBPersistence.java,v 2.2 2002/02/07 02:44:05 dave_hoag Exp $
 */
public interface RDBPersistence extends Persistence
{
	/**
	 * @param  name
	 * @param  q
	 */
	public void addCollectionQuery(String name, SQLQuery q);
	/**
	 * @return
	 */
	public boolean containsAnyChanges();
	/**
	 * @param  joinObj
	 * @return
	 */
	public AttributeTypeColumn foreignKeyBackRef(RDBPersistence joinObj);
	/**
	 * @return  The AttributeDescriptions value
	 */
	AttributeTypeColumn[] getAttributeDescriptions();

	/**
	 * @return  boolean true if the broker should manage the creation and
	 *  assignment of the primary key values for persistent objects using this
	 *  adapter.
	 * @author  Steven Sinclair
	 */
	boolean getBrokerGeneratedPrimaryKeys();
	/**
	 * @return  The ClassDescription value
	 */
	public Vector getClassDescription();
	/**
	 * @return  The CollectionDescriptions value
	 */
	public AttributeTypeColumn[] getCollectionDescriptions();
	/**
	 * @return  The CollectionQueries value
	 */
	public Hashtable getCollectionQueries();
	/**
	 * @param  pRef
	 * @return  The CollectionTypes value
	 */
	public AttributeTypeColumn[] getCollectionTypes(RDBPersistence pRef);
	/**
	 * @return  TransactionalObject
	 * @author  Dave Hoag
	 */
	com.objectwave.transactionalSupport.TransactionalObjectIF getDomainObject();
	/**
	 * @return  The ForeignKeyDescriptions value
	 */
	AttributeTypeColumn[] getForeignKeyDescriptions();
	/**
	 * @return  The PrimaryKeyDescriptions value
	 */
	AttributeTypeColumn[] getPrimaryKeyDescriptions();
	/**
	 * @param  refObj
	 * @return  The ForeignKeyTypes value
	 */
	public AttributeTypeColumn[] getForeignKeyTypes(RDBPersistence refObj);

	/**
	 * @param  refObj
	 * @param  classValue
	 * @return  The Instance value
	 * @exception  InstantiationException
	 * @exception  IllegalAccessException
	 */
	public Persistence getInstance(RDBPersistence refObj, String classValue) throws InstantiationException, IllegalAccessException;
	/**
	 * @return  The InstanceLinkDescriptions value
	 */
	public AttributeTypeColumn[] getInstanceLinkDescriptions();
	/**
	 * @param  pRef
	 * @return  The InstanceLinkTypes value
	 */
	public AttributeTypeColumn[] getInstanceLinkTypes(RDBPersistence pRef);
	/**
	 * @return  The PersistentObject value
	 */
	public Persistence getPersistentObject();
	/**
	 * @return  The PrimaryAttributeDescription value
	 */
	AttributeTypeColumn getPrimaryAttributeDescription();
	/**
	 * @return  The PrimaryKeyColumn value
	 */
	public String getPrimaryKeyColumn();
	/**
	 * @return  The PrimaryKeyField value
	 */
	public Object getPrimaryKeyField();
	/**
	 * @return  The PrimaryKeyField values
	 */
	public Object[] getPrimaryKeyFields();
	/**
	 * @return  The RecordOffset value
	 */
	public int getRecordOffset();
	/**
	 * @param  refObj
	 * @return  The TableName value
	 */
	public String getTableName(Object refObj);
	/**
	 * @param  joinObj
	 * @return
	 */
	public AttributeTypeColumn instanceLinkJoinColumn(RDBPersistence joinObj);
	/**
	 * @param  joinObj
	 * @param  specifiedField
	 * @return
	 */
	public AttributeTypeColumn foreignKeyJoinColumn(RDBPersistence joinObj, Field specifiedField);
	/**
	 * @return  The DeleteThis value
	 */
	public boolean isDeleteThis();
	/**
	 * @return  The Proxy value
	 */
	public boolean isProxy();
	/**
	 * @exception  QueryException
	 */
	public void markForDelete() throws QueryException;
	/**
	 * @param  t The new CollectionQueries value
	 */
	public void setCollectionQueries(Hashtable t);
	/**
	 * @param  i The new PrimaryKeyField value
	 */
	public void setPrimaryKeyField(Object i);
	/**
	 * @param  b The new Proxy value
	 */
	public void setProxy(boolean b);
	/**
	 * @param  i The new RecordOffset value
	 */
	public void setRecordOffset(int i);
	/**
	 * @return
	 */
	public boolean skipScalarCheck();
	/**
	 * @param  b The new SkipScalarCheck value
	 */
	public void setSkipScalarCheck(boolean b);
	/**
	 * From the provided path, find the Attribute type column
	 * it represents. Imagine an employee having a person object.
	 * Employee has a salary attribute and person has a name attribute.
	 * Valid paths for the employee adapter would be 'salary', 'person.name',
	 * or 'person'.
	 *
	 * @param  path
	 * @return
	 * @exception  NotFoundException
	 */
	public AttributeTypeColumn findColumnMap(final String path) throws NotFoundException;
}
