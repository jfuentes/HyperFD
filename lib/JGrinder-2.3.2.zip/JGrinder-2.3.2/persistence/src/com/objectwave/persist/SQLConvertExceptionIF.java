package com.objectwave.persist;

/**
 * Instances of this class will convert generic SQL exceptions to specific exceptions.
 */
public interface SQLConvertExceptionIF
{
    /**
     * Convert the SQLException into a specific query exception
     */
    QueryException convert(java.sql.SQLException ex, String additionalInfo);
    /**
     * Convert the generic QueryException into a specific query exception
     */
    QueryException convert(QueryException ex);
}