/* Copyright (C) 2001 David Hoag
 * ObjectWave Corporation
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * For a full copy of the license see:
 * http://www.opensource.org/licenses/lgpl-license.html
 */
package com.objectwave.persist;
import com.objectwave.logging.MessageLog;
import com.objectwave.persist.constraints.*;
import com.objectwave.persist.examples.*;
import com.objectwave.persist.sqlConstruction.SQLSelect;
import com.objectwave.transactionalSupport.*;
import com.objectwave.utility.ClassTree;
import com.objectwave.utility.NonUniqueHashtable;
import com.objectwave.utility.StringCalculator;
import java.io.IOException;
import java.io.Serializable;
import java.lang.reflect.Field;
import java.text.ParseException;
import java.util.HashMap;
import java.util.Stack;
import java.util.Vector;
/**
 *  Used to define dynamic queries at an object level. This is intended to allow
 *  a developer to never include SQL code in their development efforts. For
 *  example: <p>
 *
 *  SQLQuery query = new SQLQuery(somePersistentObject); <br>
 *  somePersistentObject.setAttributeValue("one"); <br>
 *  query.find(); <br>
 *  This should return a vector containing instances of SomePersistentObject.
 *  The query would be constrained by those cases that AttributeValue = "one";
 *
 * @author  Dave Hoag
 * @version  $Id: SQLQuery.java,v 2.7 2002/08/24 13:08:07 dave_hoag Exp $
 * @see  com.objectwave.persist.Persistence
 * @see  com.objectwave.persist.Broker
 */
public class SQLQuery extends ObjectEditor implements Serializable
{
	//The class tree allows generic collection adapters to be defined.
	final static ClassTree collectionAdapters = new ClassTree(true, false);
	final static Class vectorClass = Vector.class;

	protected static Broker defaultBroker;
	protected HashMap constraints;
	protected transient Broker brok;
	protected Persistence subject;
	protected boolean queryLike = false;
	protected boolean distinct = false;
	protected boolean attributeSearch = false;
	protected Vector subQuery = new Vector(3);
	protected CollectionAdapter collectionAdapter;
	protected Vector orderByList;
	protected Persistence constraint = null;
	protected int objectLimit = -1;
	/**
	 * When using this constructor, before this query would be valid you MUST
	 * call the setSubject method.
	 * @see #setSubject
	 */
	public SQLQuery() { }
	/**
	 *  Create a query object that will be used to locate persistent objects.
	 *
	 * @param  obj An object implmenting Persistence interface.
	 */
	public SQLQuery(final Persistence obj)
	{
		super(obj);
		setSubject(obj);
	}
	/**
	 *  When a query is executed, it needs to be executed against a specific
	 *  broker. It is possible for the persistent subject to specify the broker
	 *  but it many cases the subject will not identify a specific broker. In
	 *  those cases, the default broker (set here) will be broker processing
	 *  the query.
	 *
	 * @param  b The new DefaultBroker value
	 */
	public static void setDefaultBroker( final Broker b)
	{
		defaultBroker = b;
	}
	/**
	 *  A SQLQuery object can be pegged to a specific broker. That broker is known
	 *  as the default broker.
	 *
	 * @return  An implementation of the Broker interface.
	 */
	public static Broker getDefaultBroker()
	{
		return defaultBroker;
	}
	/**
	 *  To support different collection types, multiple collection adapters must be
	 *  registered.
	 *
	 * @param  adapter It is assumed that this class implements the
	 *      CollectionAdapter interface.
	 * @param  collectionClass The 'type' that is built by this collection adapter.
	 * @exception  IllegalArgumentException If the adapter parameter does not
	 *      implement the CollectionAdapter interface.
	 * @fixme  Expand to support different types for different collection contents.
	 */
	public static void registerCollectionAdapter( final Class collectionClass, final Class adapter) throws IllegalArgumentException
	{
		if(!com.objectwave.persist.CollectionAdapter.class.isAssignableFrom(adapter))
		{
			throw new IllegalArgumentException("The adapter must implement the CollectionAdapter interface.");
		}
		collectionAdapters.addObject(collectionClass, adapter);
	}
	/**
	 * The basis of a JGringer query is the concept of Query by Example. In
	 * other words, "I want all objects that look like this one". Since this
	 * is our fundamental query capability, we always need a 'subject' of a
	 * query. This method allows the subject to be set and become our 'example'
	 * for the query.
	 *
	 * @param  obj The example object we are using as the basis of the query
	 */
	public void setSubject(final Persistence obj)
	{
		subject = obj;
		if(obj.isRetrievedFromDatabase())
		{
			MessageLog.warn(this, "Using persistent object as a query, may adversly effect results.");
		}
		else
		{
			setAsTransient(true);
			ObjectEditingView oldEdit = obj.getObjectEditor();
			TransactionLog log = TransactionLog.getCurrentInstance();
			if(log != null)
			{
				try
				{
					oldEdit.commit(log, true);
					oldEdit.clearChanges(log);
				}
				catch(UpdateException ue)
				{
					MessageLog.error(this, "The impossible has happen, force should have prevented this exception!", ue);
				}
			}
			obj.setAsTransient(true);
			obj.setObjectEditor(this);
		}
	}
	/**
	 *  Limit the number of objects that can be created through this query.
	 *
	 * @param  num The limit on the number of objects to create.
	 */
	public void setObjectLimit( final int num)
	{
		objectLimit = num;
	}
	/**
	 *  If we set any field on this object that also happens to be a persistent
	 *  object, wrap it with a SQLQuery.
	 *
	 * @param  adapt
	 * @param  val
	 * @param  originalVal
	 */
	public void set( final Field adapt, final Object val, final Object originalVal)
	{
		if(val instanceof Persistence)
		{
			Persistence p = (Persistence) val;
			if(!p.isRetrievedFromDatabase())
			{
				SQLQuery q = new SQLQuery(p);
				if(constraints != null)
				{
					q.constraints = (HashMap) constraints.clone();
				}
				q.setAsLike(isLike());
				subQuery.addElement(q);
			}
		}
		super.set(adapt, val, originalVal);
	}
	/**
	 *  Should we default the comparison of values (when using query by example) to
	 *  be a 'LIKE' comparison.
	 *
	 * @param  value boolean indicating if this should be a "like" query
	 */
	public void setAsLike( final boolean value)
	{
		queryLike = value;
		for(int i = 0; i < subQuery.size(); i++)
		{
			((SQLQuery) subQuery.elementAt(i)).setAsLike(value);
		}
	}
	/**
	 *  Set broker for which this query is to use.
	 *
	 * @param  b The new Broker value
	 */
	public void setBroker( final Broker b)
	{
		brok = b;
	}
	/**
	 *  This method may be to powerfull for its own good. It allows the developer
	 *  to force the result set to be a certain type.
	 *
	 * @param  adapter The new CollectionAdapter value
	 */
	public void setCollectionAdapter( final CollectionAdapter adapter)
	{
		collectionAdapter = adapter;
	}
	/**
	 * @param  p The new Constraint value
	 * @fixme  What does this method do?
	 */
	public void setConstraint( final Persistence p)
	{
		constraint = p;
	}
	/**
	 *  Attempt to simplify the creation of constraints. Building constraints
	 * is a multiple step process, this is an attempt to simplify the creation
	 * of simple constraints. Complex constraints are not yet supported.
	 *
	 * @param  constraints A simple string like "name = 'Dave' && orderSize < 10"
	 * @exception  ParseException The provided string is not valid
	 */
	public void setConstraintString( final String constraints) throws ParseException
	{
		StringCalculator calculator = new StringCalculator();
		Vector symbols = calculator.createSymbols(constraints, true);
		//the following can be usefull for debugging
		//calculator.dumpSymbols( symbols );
		if(symbols.size() < 3)
		{
			throw new ParseException("Sorry, must specify something like \"fielda = 'bValue'\" !", 0);
		}

		symbols = calculator.convertToReversePolish(symbols);
		String anyField;
		Stack stack = new Stack();

		populateStack(symbols, 0, stack);
		if(stack.size() != 1)
		{
			throw new ParseException("Failed to build constraint from string: stack size of " + stack.size(), 0);
		}
		Constraint constraint = (Constraint) stack.pop();
		addConstraint(constraint);
	}
	/**
	 * Should only distinct rows be found.
	 *
	 * @param  b The new Distinct value
	 */
	public void setDistinct( final boolean b)
	{
		distinct = b;
	}
	/**
	 *  Convenience method for setting field constraints.
	 *
	 * @param  search The persistent object that has the field?
	 * @param  fieldPath Field of the 'search' param?
	 * @param  value The value to use in the comparison.
	 * @param  compareConstraintType A simple comparison type '=', ' <=', etc....
	 */
	public void setFieldConstraint(Persistence search, String fieldPath, String value, String compareConstraintType)
	{
		if(search == null)
		{
			search = getSubject();
		}
		ConstraintCompare comp = new ConstraintCompare();
		comp.setComparison(compareConstraintType);
		comp.setCompValue(value);
		comp.setPersistence(search);
		comp.setField(fieldPath);
		addConstraint(comp);
	}
	/**
	 * @param  p The new SubSelect value
	 * @param  fieldPath The new SubSelect value
	 * @param  subSelectFieldPath The new SubSelect value
	 * @param  subSelectQuery The new SubSelect value
	 * @param  isNot The new SubSelect value
	 */
	public void setSubSelect(Persistence p, String fieldPath, String subSelectFieldPath, SQLQuery subSelectQuery, boolean isNot)
	{
		ConstraintSubSelect c = (ConstraintSubSelect) ConstraintFactory.createConstraint("subSelect");
		c.setPersistence(p);
		c.setField(fieldPath);
		c.setSubSelectField(subSelectFieldPath);
		c.setSubSelectQuery(subSelectQuery);
		c.setNot(isNot);
		addConstraint(c);
	}
	/**
	 *  Determine that all elements of the result set must have a value in the
	 *  given field (indicated by fieldName) which occurs as an element "anyOf".
	 *
	 * @param  p The new IsanyOf value
	 * @param  fieldName The new IsanyOf value
	 * @param  anyOf The new IsanyOf value
	 */
	public void setIsanyOf(Persistence p, String fieldName, Vector anyOf)
	{
		ConstraintAnyOf c = (ConstraintAnyOf) ConstraintFactory.createConstraint("anyof");
		c.setField(fieldName);
		c.setAnyOf(anyOf);
		c.setPersistence(p);
		addConstraint(c);
	}
	/**
	 *  We can provide our own objects for the comparison. If the parameter p is
	 *  null, we will default it to be the subject of this query. Find all of the
	 *  objects where the field specified is not null.
	 *
	 * @param  p The new IsNotNull value
	 * @param  fieldName The new IsNotNull value
	 */
	public void setIsNotNull(Persistence p, String fieldName)
	{
		if(p == null)
		{
			p = getSubject();
		}
		ConstraintIsNull c = (ConstraintIsNull) ConstraintFactory.createConstraint("isnull");
		c.setNot(true);
		c.setField(fieldName);
		c.setPersistence(p);
		addConstraint(c);
	}
	/**
	 *  We can provide our own objects for the comparison. If the parameter p is
	 *  null, we will default it to be the subject of this query. Find all of the
	 *  objects where the field specified is null.
	 *
	 * @param  p The new IsNull value
	 * @param  fieldName The new IsNull value
	 */
	public void setIsNull(Persistence p, final String fieldName)
	{
		if(p == null)
		{
			p = getSubject();
		}
		ConstraintIsNull c = (ConstraintIsNull) ConstraintFactory.createConstraint("isnull");
		c.setField(fieldName);
		c.setPersistence(p);
		addConstraint(c);
	}
	/**
	 *  Similar to setIsAnyOf, but the "inverse" of the results
	 *
	 * @param  p The new NotAnyOf value
	 * @param  fieldName The new NotAnyOf value
	 * @param  anyOf The new NotAnyOf value
	 */
	public void setNotAnyOf(Persistence p, String fieldName, Vector anyOf)
	{
		if(p == null)
		{
			p = getSubject();
		}
		ConstraintAnyOf c = (ConstraintAnyOf) ConstraintFactory.createConstraint("anyof");
		c.setField(fieldName);
		c.setAnyOf(anyOf);
		c.setPersistence(p);
		c.setNot(true);
		addConstraint(c);
	}
	/**
	 *  Field paths that are used to order the result set.
	 *
	 * @param  v Vector of Strings.
	 * @see  #getOrderByList()
	 */
	public void setOrderByList(Vector v)
	{
		orderByList = v;
	}
	/**
	 *  Gets the JoinConstraint attribute of the SQLQuery object
	 *
	 * @return  The JoinConstraint value
	 */
	public Persistence getJoinConstraint()
	{
		return constraint;
	}
	/**
	 *  Gets the AttributeSearch attribute of the SQLQuery object
	 *
	 * @return  The AttributeSearch value
	 */
	public boolean isAttributeSearch()
	{
		return attributeSearch;
	}
	/**
	 *  Gets the Distinct attribute of the SQLQuery object
	 *
	 * @return  The Distinct value
	 */
	public boolean isDistinct()
	{
		return distinct;
	}
	/**
	 * @return  int The number of objects this query will legally be allowed to
	 *      return.
	 */
	public int getObjectLimit()
	{
		return objectLimit;
	}
	/**
	 *  If the broker is explicitly set, use that broker. Next check the query
	 *  object's BrokerName. Finally, try using the default broker associated for
	 *  all SQLQueries. This must ALWAYS return some broker or the query will fail
	 *  with a null pointer exception.
	 *
	 * @return  An implementation of the Broker interface.
	 */
	public Broker getBroker()
	{
		if(brok != null)
		{
			return brok;
		}
		Persistence p = getSubject();
		String brokerName = p.getBrokerName();
		if(brokerName != null)
		{
			try
			{
				Broker b = BrokerFactory.getBroker(brokerName);
				if(b != null)
				{
					return b;
				}
			}
			catch(QueryException ex)
			{
			}
		}
		return getDefaultBroker();
	}
	/**
	 *  Used when building result sets. This will usually be null.
	 *
	 * @return  The collection adapter that will build the result set values.
	 */
	public CollectionAdapter getCollectionAdapter()
	{
		return collectionAdapter;
	}
	/**
	 *  How do we deal with multiple constraints on a given field? Answer: we
	 *  don't.
	 *
	 * @param  field The name of a constrained field.
	 * @return  Constraint for the given field.
	 */
	public Constraint getConstraintFor(String field)
	{
		if(constraints == null)
		{
			return null;
		}
		return (Constraint) constraints.get(field);
	}

	/**
	 *  How do we deal with multiple constraints on a given field? Answer: we
	 *  don't.
	 *
	 * @param  field The name of a constrained field.
	 * @return  Constraint for the given field.
	 */
	public java.util.List getChildConstraintFor(String field)
	{
		if(constraints == null)
		{
			return null;
		}
		java.util.ArrayList list = new java.util.ArrayList();
		java.util.Iterator it = constraints.keySet().iterator();
		while(it.hasNext())
		{
			String name = (String) it.next();
			int index = name.indexOf(".");
			if(index > -1 && field.equals(name.substring(0, index)))
			{
				Constraint constraint = (Constraint) constraints.get(name);
				constraint.setField(name.substring(index + 1));
				list.add(constraint);
			}
		}
		return list;
	}
	/**
	 *  The main subject of this query. This query will always return a vector of
	 * the subject objects (or subclasses...).
	 *
	 * @return  The Subject value
	 */
	public Persistence getSubject()
	{
		return subject;
	}
	/**
	 *  Should we default the comparison of values (when using query by example) to
	 * be a 'LIKE' comparison.
	 *
	 * @return  The Like value
	 */
	public boolean isLike()
	{
		return queryLike;
	}
	/**
	 *  Each string in the vector is a path to the field we wish to use. Each path
	 * begins with from the subject of this query. ex. Assume the subect is an
	 * instance of an Order class. Assume the order class contains an amount and a
	 * reference to a class called OrderId. Assume OrderId has a field called id.
	 * Assume a query is created that is looking for a Orders and their respective
	 * OrderId. Valid paths include: amount orderId.id orderId <==This one uses
	 * the foreign key as the order by element The order that the elements appear
	 * in the list is the order they will appear in the order by clause.
	 *
	 * @return  The OrderByList value
	 */
	public Vector getOrderByList()
	{
		return orderByList;
	}
	/**
	 *  Add a constraint to the query. A constraint is some restriction on the
	 * field values. Typical usage may constrain where a value is < another value.
	 *
	 * @param  constraint The constraint object representing the restricted values.
	 */
	public void addConstraint(final Constraint constraint)
	{
		if( constraint.getField() == null || constraint.getField().trim().equals("") )
		{
			throw new IllegalArgumentException( "The contraint field can not be blank!" );
		}
		if(constraints == null)
		{
			constraints = new HashMap();
		}
		final Persistence constSubject = constraint.getPersistence();
		if(constSubject == null)
		{
			String field = constraint.getField();
			if(field.indexOf(".") < 0)
			{
				constraint.setPersistence(getSubject());
			}
			else
			{
				try
				{
					traversePersistence(getSubject(), field);
				}
				catch(ParseException pe)
				{
					MessageLog.debug(this, "Can not add constraint", pe);
					throw new IllegalArgumentException("The field on the constraint is not a legal value.");
				}
			}
			constraints.put(constraint.getField(), constraint);
		}
		else
		if(constSubject == getSubject())
		{
			constraints.put(constraint.getField(), constraint);
		}
		else
		{
			int size = subQuery.size();
			for(int i = 0; i < size; ++i)
			{
				((SQLQuery) subQuery.elementAt(i)).addConstraint(constraint);
			}
		}
	}

	/**
	 *  Return a collection of persistent objects of the type of this current
	 *  query's subject.
	 *
	 * @return  A Vector of persistent objects.
	 * @exception  QueryException
	 */
	public int count() throws QueryException
	{
		attributeSearch = false;
		return getBroker().count(this);
	}
	/**
	 *  Determine if there is a constraint assigned for the provided field name.
	 *
	 * @param  field
	 * @return  boolean true if a field constraint is defined.
	 * @see  #addConstraint(Constraint)
	 */
	public boolean fieldIsConstrained(String field)
	{
		if(constraints == null)
		{
			return false;
		}
		return constraints.containsKey(field);
	}
	/**
	 *  Return a collection of persistent objects of the type of this current
	 *  query's subject. The return type of Object allows any collection type.
	 *  NOTE: This may have a side effect of modifying the state of this object.
	 *  The collectionAdapter field will be set to null.
	 *
	 * @return  A Vector of persistent objects.
	 * @exception  QueryException
	 */
	public Vector find() throws QueryException
	{
		return (Vector) findCollection(null);
	}
	/**
	 *  Return a collection of persistent objects of the type of this current
	 *  query's subject. The return type of Object allows any collection type.
	 *  NOTE: This may have a side effect of modifying the state of this object.
	 *  The collectionAdapter field may be set to null.
	 *
	 * @return  A Collection of persistent objects.
	 * @exception  QueryException
	 */
	public Object findCollection() throws QueryException
	{
		if(collectionAdapter != null)
		{
			return findCollection(collectionAdapter.getClass());
		}
		else
		{
			return findCollection(null);
		}
	}
	/**
	 *  Return a vector of Object []. Each Object [] will contain the values for
	 *  the attribute list.
	 *
	 * @param  attributes A list of the attributes that are to be retrieved.
	 * @return  A Vector of Object [].
	 * @exception  QueryException
	 */
	public Vector findAttributes(String[] attributes) throws QueryException
	{
		attributeSearch = true;
		return getBroker().findAttributes(this, attributes);
	}
	/**
	 *  Return a collection of persistent objects of the type of this current
	 *  query's subject. The return type of Object allows any collection type.
	 *
	 * @param  clazz The class of object we want as the result set value
	 * @return  A Vector of persistent objects.
	 * @exception  QueryException
	 */
	public Object findCollection(java.lang.Class clazz) throws QueryException
	{
		attributeSearch = false;
		if(clazz != null && collectionAdapter == null)
		{
			Vector v = collectionAdapters.getObjects(clazz);
			if(v.size() != 0)
			{
				try
				{
					Class adapterClass = (Class) v.lastElement();
					//The last element is the most exact match we find.
					collectionAdapter = (CollectionAdapter) adapterClass.newInstance();
				}
				catch(Exception ex)
				{
					throw new QueryException("Failed to create the desired collection", ex);
				}
			}
			else
					if(clazz != vectorClass)
			{
				MessageLog.warn(this, "Failed to create the desired collection. Could not find the request collection adapter for: " + clazz);
				collectionAdapter = null;
			}
			else
			{
				collectionAdapter = null;
			}
		}
		else
				if(clazz == null)
		{
			//Force result to be a vector
			collectionAdapter = null;
		}
		if(collectionAdapter != null)
		{
			collectionAdapter.preQuery(this);
		}
		return getBroker().find(this);
	}
	/**
	 * @param  obj is an object that can join with the subject of this query.
	 * @return
	 * @exception  QueryException
	 */
	public Vector findIn(Persistence obj) throws QueryException
	{
		constraint = obj;
		distinct = true;
		return find();
	}
	/**
	 *  Find the one and only one persistent object that matches our Query
	 *  conditions. NULL is a valid return type.
	 *
	 * @return  The object that matches the search criteria.
	 * @exception  QueryException One of the following occured:
	 *      <li> More than one object is found</li>
	 *      <li> A database specific exception occurred</li>
	 */
	public Persistence findUnique() throws QueryException
	{
		return getBroker().findUnique(this);
	}
	/**
	 *  Add a new element to our list of order by clauses.
	 *
	 * @param  pathToField The feature to be added to the OrderByField attribute
	 * @see  #getOrderByList()
	 */
	public void addOrderByField(final String pathToField)
	{
		addOrderByField(pathToField, false);
	}
	/**
	 *  Add a new element to our list of order by clauses.
	 *
	 * @param  descend If true, sort the results in descending order.
	 * @param  pathToField The feature to be added to the OrderByField attribute
	 * @see  #getOrderByList()
	 */
	public void addOrderByField(String pathToField, boolean descend)
	{
		if(getOrderByList() == null)
		{
			setOrderByList(new Vector(5));
		}

		if(descend)
		{
			pathToField = '!' + pathToField;
		}
		getOrderByList().addElement(pathToField);
	}
	/**
	 *  Delete all records that match the search criteria. This is a very powerfull
	 *  method, use sparingly.
	 *
	 * @exception  QueryException
	 */
	public void deleteAll() throws QueryException
	{
		getBroker().deleteAll(this);
	}
	/**
	 *  Examine the symbols and build constraints from the information. The
	 *  supplied stack will contain one and only one constraint object when this
	 *  method returns. This method can be used as a part of a recursive algorithm
	 *  to handle parens "( )". This method will terminate when a closing paren ")"
	 *  is encountered, therefore all values in the list of symbols may not be
	 *  processed.
	 *
	 * @param  symbols The reverse polish notation of all the symbols in the
	 *      constraint string.
	 * @param  idx The current index of the element to process within the symbols
	 *      vector
	 * @param  currentStack The holder of the created Constraint objects.
	 * @return  The last processed symbol within the vector of symbols
	 * @exception  ParseException Something wasn't right about the constraint
	 *      string
	 */
	protected int populateStack(Vector symbols, int idx, Stack currentStack) throws ParseException
	{
		if(idx < symbols.size())
		{

			StringCalculator.CalcItem calcItem = (StringCalculator.CalcItem) symbols.get(idx);
			int type = calcItem.type;
			if((type & calcItem.TYPE_BRACKET) != 0)
			{
				String bracket = calcItem.valueStr();
				if(bracket.equals("("))
				{
					idx = processBracket(calcItem, symbols, idx, currentStack);
				}
				else
				{
					if(currentStack.size() != 1)
					{
						throw new ParseException("Integrity of constraint is suspect: Should only be 1 entry at this point", 0);
					}
					return idx;
				}
			}
			else
					if(calcItem.isOperator())
			{
				processOperator(calcItem, symbols, idx, currentStack);
			}
			else
			{
				currentStack.push(calcItem.valueStr());
			}
			idx = populateStack(symbols, idx + 1, currentStack);
		}
		return idx;
	}
	/**
	 *  The constraint string has found an operation (like '=' or '&&') and it
	 *  needs to build the appropriate Constraint object.
	 *
	 * @param  calcItem An item found within the constratint string
	 * @param  symbols The reverse polish notation of all the symbols in the
	 *      constraint string.
	 * @param  idx The current index of the current operation within the symbols
	 * @param  currentStack The holder of the created Constraint objects.
	 * @exception  ParseException The boolean expression did not use the correct
	 *      symbols
	 * @assumptions  The currentStack contains at least two values consisting of
	 *      the left and right of the operator
	 */
	protected void processOperator(StringCalculator.CalcItem calcItem, Vector symbols, int idx, Stack currentStack) throws ParseException
	{
		Object value = currentStack.pop();
		Object field = currentStack.pop();
		String operator = calcItem.valueStr();
		if(field instanceof Constraint)
		{
			//operator must be either && or ||
			int opType = " && || ".indexOf(operator);
			//the && symbol
			if(opType == 1)
			{
				CrossField cross = new CrossField(true, (Constraint) field, (Constraint) value);
				cross.setField(((Constraint) field).getField());
				currentStack.push(cross);
			}
			else
			//the || symbol
					if(opType == 4)
			{
				CrossField cross = new CrossField(false, (Constraint) field, (Constraint) value);
				cross.setField(((Constraint) field).getField());
				currentStack.push(cross);
			}
			else
			{
				throw new ParseException("Must be boolean operators (&& / ||) between constraints", calcItem.pos);
			}
		}
		else
		{
			ConstraintCompare regularConstraint = new ConstraintCompare();
			regularConstraint.setField(field.toString());

			String strValue = stripTicks(value.toString());
			regularConstraint.setCompValue(strValue);
			regularConstraint.setComparison(operator);
			currentStack.push(regularConstraint);
		}
	}
	/**
	 *  The constraint string uses \' (ticks) to denote string boundaries. Since
	 *  these ticks should not be considered a part of the value, we attempt to
	 *  strip them here.
	 *
	 * @param  aValue Like "'aValue'"
	 * @return  Ticks removed like "aValue"
	 */
	protected String stripTicks(String aValue)
	{
		if(aValue.length() > 2 && aValue.charAt(0) == '\'')
		{
			if(aValue.charAt(aValue.length() - 1) == '\'')
			{
				return aValue.substring(1, aValue.length() - 1);
			}
		}
		return aValue;
	}
	/**
	 *  The setConstraintString has detected and opening '('. This method uses
	 *  recursion to process the contents of the "( )" brackets as a single
	 *  standalone element.
	 *
	 * @param  calcItem An item found within the constratint string
	 * @param  symbols The reverse polish notation of all the symbols in the
	 *      constraint string.
	 * @param  idx The current index of the "(" within the symbols vector
	 * @param  currentStack The holder of the created Constraint objects.
	 * @return  The last processed symbol within the vector of symbols
	 * @exception  ParseException Something wasn't right within the brackets.
	 */
	protected int processBracket(StringCalculator.CalcItem calcItem, Vector symbols, int idx, Stack currentStack) throws ParseException
	{
		Stack newStack = new Stack();
		idx = populateStack(symbols, idx + 1, newStack);
		currentStack.push(newStack.pop());
		return idx;
	}

	/**
	 * @param  p
	 * @param  field
	 * @exception  ParseException
	 */
	private void traversePersistence(final Persistence p, final String field) throws ParseException
	{
		if(p == null || field == null)
		{
			return;
		}
		int index = field.indexOf(".");
		if(index < 0)
		{
			return;
		}

		String childPersistenceName = field.substring(0, index);
		String suffix = field.substring(index + 1);

		try
		{
			com.objectwave.utility.ReflectiveHelper rh = new com.objectwave.utility.ReflectiveHelper();
			Field f = p.getClass().getDeclaredField(childPersistenceName);
			f.setAccessible(true);
			Object o = rh.getValue(f, p);
			if(o == null)
			{
				o = f.getType().newInstance();
				rh.setValue(f, o, p);
				traversePersistence((Persistence) o, suffix);
			}
		}
		catch(Exception e)
		{
			MessageLog.debug(this, "The path '" + field + "'to a field in '" + p.getClass().getName() + "' proved to be invalid", e);
			throw new ParseException("The field " + childPersistenceName + " could not be found in " + p.getClass().getName(), 0);
		}

	}
	/**
	 * Try to provide some useful debugging information.
	 */
	public String toString()
	{
		String result = super.toString();
		String subjClass;
		if( getSubject() != null)
		{
			subjClass = getSubject().getClass().getName();
		}
		else
		{
			subjClass = "null";
		}
		result += '[' + subjClass + ']';
		return result;
	}
	/**
	 *  Unit test
	 *
	 * @author  dhoag
	 * @version  $Id: SQLQuery.java,v 2.7 2002/08/24 13:08:07 dave_hoag Exp $
	 */
	public static class Test extends com.objectwave.test.UnitTestBaseImpl
	{
		/**
		 *  The main program for the Test class
		 *
		 * @param  args The command line arguments
		 */
		public static void main(String[] args)
		{
			com.objectwave.test.TestRunner.run(new Test(), args);
		}
		/**
		 *  A unit test for JUnit
		 */
		public void testConstraint()
		{
			SQLQuery query = new SQLQuery(new TestPerson());
			testContext.assertTrue("Constraint set incorrectly", !query.fieldIsConstrained("phone"));
			query.setIsNotNull(null, "phone");
			testContext.assertTrue("Constraint failed to be set", query.fieldIsConstrained("phone"));
		}
		/**
		 *  A unit test for JUnit
		 *
		 * @exception  Exception
		 */
		public void testSimplifiedConstraintString() throws Exception
		{
			SQLQuery query = new SQLQuery(new TestPerson());
			query.setConstraintString("phone = '123.321.3322'");
			testContext.assertTrue("Constraint failed to be set", query.fieldIsConstrained("phone"));
			Constraint constraint = query.getConstraintFor("phone");
			testContext.assertEquals("Constraint value check", "= '123.321.3322'", constraint.constructQueryString());
		}
		/**
		 *  A unit test for JUnit
		 *
		 * @exception  Exception
		 */
		public void testBooleanConstraintString() throws Exception
		{
			SQLQuery query = new SQLQuery(new TestPerson());
			query.setConstraintString("phone = '123.321.3322' || annualIncome > 10100.50 ");
			testContext.assertTrue("No Constraints were created", query.constraints != null);
			testContext.assertTrue("No Constraints were entered ", !query.constraints.isEmpty());
			Object[] keys = query.constraints.values().toArray();
			testContext.assertTrue("Constraint failed to be set at field", query.fieldIsConstrained("phone"));
			Constraint constraint = query.getConstraintFor("phone");
			constraint.setColumnName("A.unknown");
			testContext.assertEquals("Constraint value check", "(A.phone = '123.321.3322' OR A.annualIncome > 10100.5)", constraint.constructQueryString());
		}
	}
}
