package com.objectwave.persist;

public class Type
{
	String text;
	Type(String niceText){ text = niceText; }
	public String toString(){ return text; }
}