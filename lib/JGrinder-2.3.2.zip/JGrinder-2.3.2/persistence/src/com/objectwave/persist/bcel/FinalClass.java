package com.objectwave.persist.bcel;

import org.apache.bcel.Constants;
import org.apache.bcel.generic.ClassGen;
import org.apache.bcel.generic.ObjectType;
import org.apache.bcel.generic.ArrayType;
import org.apache.bcel.generic.FieldGen;
import org.apache.bcel.generic.LocalVariableGen;
import org.apache.bcel.generic.MethodGen;
import org.apache.bcel.generic.ConstantPoolGen;
import org.apache.bcel.generic.InstructionList;
import org.apache.bcel.generic.InstructionConstants;
import org.apache.bcel.generic.InstructionFactory;
import org.apache.bcel.generic.InstructionHandle;
import org.apache.bcel.generic.Type;
import org.apache.bcel.generic.GOTO;
import org.apache.bcel.generic.GETFIELD;
import org.apache.bcel.generic.LDC;
import org.apache.bcel.generic.GETSTATIC;
import org.apache.bcel.generic.PUTSTATIC;
import org.apache.bcel.generic.NEW;
import org.apache.bcel.generic.CHECKCAST;
import org.apache.bcel.generic.INVOKEVIRTUAL;
import org.apache.bcel.generic.INVOKEINTERFACE;
import org.apache.bcel.generic.INVOKESPECIAL;
import org.apache.bcel.generic.INVOKESTATIC;
import org.apache.bcel.generic.Type;
import org.apache.bcel.generic.ReturnInstruction;
import org.apache.bcel.classfile.JavaClass;
import org.apache.bcel.classfile.ConstantPool;
import org.apache.bcel.classfile.Constant;
import org.apache.bcel.classfile.ConstantUtf8;
import org.apache.bcel.classfile.ClassParser;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import com.objectwave.logging.MessageLog;
/**
 * This class will create the glue linking the persistence support to 
 * any random domain object.
 *
 * @author dave_hoag
 * @version $Id: FinalClass.java,v 1.7 2002/08/26 23:33:07 dave_hoag Exp $
 */
public class FinalClass
{
	Class subject;
	ClassGen newClass;
	String superClass;
	ConstantPoolGen constantPool;
	int editorRef;
	ArrayList persistentFields = new ArrayList();

	/**
	 * Constructor for the FinalClass object
	 *
	 * @param subject
	 * @param superClassName
	 */
	public FinalClass( final Class subject, final String superClassName )
	{
		this.subject = subject;
		superClass = superClassName;
		validateSubject();
	}
	/**
	 * Gets the persistentClassName attribute of the FinalClass object
	 *
	 * @param domainObject
	 * @return The persistentClassName value
	 */
	protected final String getPersistentClassName( final Class domainObject )
	{
		return domainObject.getName() + "Persistence";
	}
	/**
	 * Gets the superClass attribute of the FinalClass object
	 *
	 * @return The superClass value
	 */
	protected String getSuperClass()
	{
		return superClass;
	}
	/**
	 * Gets the returnInstruction attribute of the FinalClass object
	 *
	 * @param paramType
	 * @return The returnInstruction value
	 */
	public ReturnInstruction getReturnInstruction( Class paramType )
	{
		if( paramType.isPrimitive() )
		{
			if( paramType == Void.TYPE )
			{
				return InstructionConstants.RETURN;
			}
			else if( paramType == Double.TYPE )
			{
				return InstructionConstants.DRETURN;
			}
			else if( paramType == Float.TYPE )
			{
				return InstructionConstants.FRETURN;
			}
			else if( paramType == Long.TYPE )
			{
				return InstructionConstants.LRETURN;
			}
			else
			{
				return InstructionConstants.IRETURN;
			}
		}
		else
		{
			return InstructionConstants.ARETURN;
		}
	}
	/**
	 * Gets the paramType attribute of the FinalClass object
	 *
	 * @param paramType
	 * @return The paramType value
	 */
	public Type getParamType( Class paramType )
	{
		if( paramType.isPrimitive() )
		{
			if( paramType == Boolean.TYPE )
			{
				return Type.BOOLEAN;
			}
			else if( paramType == Character.TYPE )
			{
				return Type.CHAR;
			}
			else if( paramType == Double.TYPE )
			{
				return Type.DOUBLE;
			}
			else if( paramType == Float.TYPE )
			{
				return Type.FLOAT;
			}
			else if( paramType == Integer.TYPE )
			{
				return Type.INT;
			}
			else if( paramType == Long.TYPE )
			{
				return Type.LONG;
			}
			else if( paramType == Short.TYPE )
			{
				return Type.SHORT;
			}
			else if( paramType == Byte.TYPE )
			{
				return Type.BYTE;
			}
			else if( paramType == Void.TYPE )
			{
				return Type.VOID;
			}
			else
			{
				throw new IllegalArgumentException( "unknown primitive: " + paramType );
			}
		}
		else if( paramType.isArray() )
		{
			return new ArrayType( getParamType( paramType.getComponentType() ), 1 );
		}
		else
		{
			return new ObjectType( paramType.getName() );
		}
	}
	/**
	 */
	protected void validateSubject()
	{
		if( getSuperClass() == null )
		{
			throw new IllegalArgumentException( "The superclass can not be null" );
		}
		if( subject.isArray() )
		{
			throw new IllegalArgumentException( "You can not directly persist an array" );
		}
		if( subject.isPrimitive() )
		{
			throw new IllegalArgumentException( "You can not directly persist a primitive" );
		}
	}
	/**
	 * Return a the newly defined class.
	 *
	 * @return
	 */
	public ClassGen parse()
	{
		newClass = declareClass();
		constantPool = newClass.getConstantPool();
		addEditorReference( constantPool );
		addFields( newClass, constantPool );
		addDefaultMethods( newClass, constantPool );
		return newClass;
	}
	/**
	 * @param cg
	 * @param gen
	 */
	protected void addDefaultMethods( final ClassGen cg, final ConstantPoolGen gen )
	{
		cg.addEmptyConstructor( Constants.ACC_PUBLIC );
		addStaticMethod( cg, gen );
		addSetupMethod( cg, gen );
		addFactoryMethod( cg, gen );
	}
	/**
	 * @param cpGen
	 */
	protected void addEditorReference( final ConstantPoolGen cpGen )
	{
		editorRef = cpGen.addFieldref( getSuperClass(), "editor", new ObjectType( "com.objectwave.transactionalSupport.ObjectEditingView" ).getSignature() );
	}
	/**
	 * @param cg
	 * @param cpGen
	 * @param field
	 */
	protected void addField( final ClassGen cg, final ConstantPoolGen cpGen, final Field field )
	{
		persistentFields.add( field );
		ObjectType type = new ObjectType( "java.lang.reflect.Field" );
		int access = Constants.ACC_STATIC | Constants.ACC_PUBLIC;
		FieldGen fg = new FieldGen( access, type, "_" + field.getName(), cpGen );
		cg.addField( fg.getField() );

		//Hide the parent version of the field
		Type copyType = getParamType( field.getType() );
		access = Constants.ACC_PUBLIC;
		FieldGen copyField = new FieldGen( access, copyType, field.getName(), cpGen );
		cg.addField( copyField.getField() );

		addAccessorMutator( cg, cpGen, field, fg );
	}
	/**
	 * @param cg
	 * @param cpGen
	 * @param field
	 * @param fg
	 */
	protected void addAccessorMutator( final ClassGen cg, final ConstantPoolGen cpGen, final Field field, final FieldGen fg )
	{
		addAccessor( cg, cpGen, field, fg );
		addMutator( cg, cpGen, field, fg );
	}
	/**
	 */
	protected void addFactoryMethod(final ClassGen cg, final ConstantPoolGen cpGen )
	{
		String className = getPersistentClassName( subject );
		String subjectName = subject.getName();

		Type returnType = new ObjectType( subjectName );
		Type[] args = new Type[0];
		String[] argNames = new String[0];

		InstructionList il = new InstructionList();
		int objectRef = cpGen.addClass( className );
		il.append( new NEW( objectRef ) );
		il.append( InstructionConstants.DUP );
		int methRef = cpGen.addMethodref( className, "<init>", "()V" );
		il.append( new INVOKESPECIAL(methRef) );
		il.append( InstructionConstants.ARETURN );

		MethodGen mg = new MethodGen( Constants.ACC_PUBLIC, returnType, args, argNames, "newInstance", className, il, cpGen );

		mg.setMaxStack();
		mg.setMaxLocals();
		cg.addMethod( mg.getMethod() );
		il.dispose();
	}
	/**
	 * @param cg
	 * @param cpGen
	 */
	protected void addSetupMethod( final ClassGen cg, final ConstantPoolGen cpGen )
	{
		int idx = subject.getName().lastIndexOf( '.' );
		String name = subject.getName().substring( idx + 1 );
		int xmlRef = cpGen.addString( name + ".xml" );
		String className = getPersistentClassName( subject );

		Type returnType = Type.VOID;
		Type[] args = new Type[0];
		String[] argNames = new String[0];

		InstructionList il = new InstructionList();
		il.append( InstructionConstants.ALOAD_0 );
		il.append( InstructionConstants.ALOAD_0 );
		il.append( new LDC( xmlRef ) );

		int methRef = cpGen.addMethodref( className, "initializeObjectEditor", "(Ljava/lang/String;)Lcom/objectwave/transactionalSupport/ObjectEditingView;" );
		il.append( new INVOKEVIRTUAL( methRef ) );
		methRef = cpGen.addMethodref( className, "setObjectEditor", "(Lcom/objectwave/transactionalSupport/ObjectEditingView;)V" );
		il.append( new INVOKEVIRTUAL( methRef ) );
		il.append( InstructionConstants.RETURN );

		MethodGen mg = new MethodGen( Constants.ACC_PUBLIC, returnType, args, argNames,
				"setup", className, il, cpGen );
		mg.addException( "java.lang.Exception" );

		mg.setMaxStack();
		mg.setMaxLocals();

		cg.addMethod( mg.getMethod() );
		il.dispose();
	}
	/**
	 * Only do anything if the class is different from the current
	 * @return int - The InstructionHandle of the initial LDC instruction
	 */
	protected InstructionHandle callClassForName( final Field aField, final Class [] classHolder, final ConstantPoolGen cpGen , InstructionList il, final int classForNameRef )
	{
		final Class fieldClass = aField.getDeclaringClass();
		if( classHolder[0] != fieldClass )
		{
			classHolder[0] = fieldClass;
			int currentClassRef = cpGen.addString( fieldClass.getName() );
			InstructionHandle try_start = il.append( new LDC( currentClassRef ) );
			il.append( new INVOKESTATIC( classForNameRef ) );
			il.append( InstructionConstants.ASTORE_0 );

			return try_start;
		}
		//Nothing Done
		return null;
	}
	/**
	 * _aField = clazz.getDeclaredField( 
	 */
	protected void assignStaticField( Field aField, ConstantPoolGen cpGen , InstructionList il )
	{
		il.append( InstructionConstants.ALOAD_0 );
		int fieldName = cpGen.addString( aField.getName() );
		il.append( new LDC( fieldName ) );
		int getDeclaredField = cpGen.addMethodref( "java.lang.Class", "getDeclaredField", "(Ljava/lang/String;)Ljava/lang/reflect/Field;" );
		il.append( new INVOKEVIRTUAL( getDeclaredField ) );

		Type fieldType = getParamType( aField.getType() );
		int staticRef = cpGen.lookupFieldref( getPersistentClassName( subject) , "_" + aField.getName(), new ObjectType("java.lang.reflect.Field").getSignature() );

		il.append( new PUTSTATIC( staticRef ) );
		il.append( new GETSTATIC( staticRef ) );

		int setAccessible = cpGen.addMethodref( "java.lang.reflect.Field", "setAccessible", "(Z)V" );
		//Push 'true' onto stack
		il.append( InstructionConstants.ICONST_1 );
		il.append( new INVOKEVIRTUAL( setAccessible ) );
	}
	/**
	 * @param cg
	 * @param cpGen
	 */
	protected void addStaticMethod( final ClassGen cg, final ConstantPoolGen cpGen )
	{
		//Got to have at least one persistent field to worry about this method
		if( persistentFields.size() > 0)
		{
			int idx = subject.getName().lastIndexOf( '.' );
			String name = subject.getName().substring( idx + 1 );
			String className = getPersistentClassName( subject );

			String paramSignature = "(Ljava/lang/String;)Ljava/lang/Class;";
			int classForNameRef = cpGen.addMethodref( "java.lang.Class", "forName", paramSignature );

			Type[] args = new Type[0];
			String[] argNames = new String[0];

			Field persistentField = (Field)persistentFields.get(0);
			final Class [] classHolder = new Class[1];

			final InstructionList il = new InstructionList();
			InstructionHandle try_start = callClassForName( persistentField, classHolder, cpGen, il, classForNameRef );
			assignStaticField( persistentField, cpGen, il );
			for(int i = 1; i < persistentFields.size(); i++)
			{
				persistentField = (Field)persistentFields.get(i);
				callClassForName( persistentField, classHolder, cpGen, il, classForNameRef );
				assignStaticField( persistentField, cpGen, il );
			}

			GOTO g = new GOTO( null );
			//Jump over the error handling code
			InstructionHandle try_catch = il.append( g );
			//The error handling code
			InstructionHandle handler = il.append( InstructionConstants.ASTORE_0 );
			il.append( InstructionConstants.ALOAD_0 );
			int methRef = cpGen.addMethodref( "java.lang.Throwable", "printStackTrace", "()V" );
			il.append( new INVOKEVIRTUAL( methRef ) );
			//The final code outside of the try catch
			InstructionHandle ih = il.append( InstructionConstants.RETURN );
			g.setTarget( ih );

			MethodGen mg = new MethodGen( Constants.ACC_STATIC, Type.VOID, args, argNames,
					"<clinit>", className, il, cpGen );
			mg.addLocalVariable( "clazz", new ObjectType( "java.lang.Class"), 0, null, null );
			mg.addExceptionHandler( try_start, try_catch, handler, new ObjectType( "java.lang.Throwable") );
			

			mg.setMaxStack();
			mg.setMaxLocals();

			cg.addMethod( mg.getMethod() );
			il.dispose();
		}
	}
	/**
	 * @param cg
	 * @param cpGen
	 * @param field
	 * @param fg
	 */
	protected void addMutator( final ClassGen cg, final ConstantPoolGen cpGen, final Field field, final FieldGen fg )
	{
		Type fieldType = getParamType( field.getType() );
		int staticRef = cpGen.addFieldref( cg.getClassName(), fg.getName(), fg.getSignature() );
		int fieldRef = cpGen.addFieldref( field.getDeclaringClass().getName(), field.getName(), fieldType.getSignature() );
		String className = getPersistentClassName( subject );
		char[] chars = field.getName().toCharArray();
		chars[0] = Character.toUpperCase( chars[0] );
		String varName = String.valueOf( chars );
		InstructionList il = new InstructionList();
		//get method
		Type returnType = Type.VOID;
		Type[] args = new Type[]{fieldType};
		String[] argNames = new String[]{"value"};

		il.append( InstructionConstants.ALOAD_0 );
		il.append( new GETFIELD( editorRef ) );
		il.append( new GETSTATIC( staticRef ) );
		if( field.getType().isPrimitive() )
		{
			il.append( InstructionConstants.ILOAD_1 );
		}
		else
		{
			il.append( InstructionConstants.ALOAD_1 );
		}
		il.append( InstructionConstants.ALOAD_0 );
		il.append( new GETFIELD( fieldRef ) );
		int interfaceRef = 0;
		String paramSignature;
		if( field.getType().isPrimitive() )
		{
			paramSignature = Type.getMethodSignature( Type.VOID, new Type [] { new ObjectType("java.lang.reflect.Field"), fieldType, fieldType } );
		}
		else
		{
			paramSignature = Type.getMethodSignature( Type.VOID, new Type [] { new ObjectType("java.lang.reflect.Field"), new ObjectType("java.lang.Object"), new ObjectType("java.lang.Object") } );
		}
		interfaceRef = cpGen.addInterfaceMethodref( "com.objectwave.transactionalSupport.ObjectEditingView", "set", paramSignature );
		il.append( new INVOKEINTERFACE( interfaceRef, 4 ) );
		il.append( InstructionConstants.RETURN );

		String methodName = "set" + varName;
		MethodGen mg = new MethodGen( Constants.ACC_PUBLIC, returnType, args, argNames,
				methodName, className, il, cpGen );

		mg.setMaxStack();
		mg.setMaxLocals();

		cg.addMethod( mg.getMethod() );

		il.dispose();
	}
	/**
	 * @param cg
	 * @param cpGen
	 * @param field
	 * @param fg
	 */
	protected void addAccessor( final ClassGen cg, final ConstantPoolGen cpGen, final Field field, final FieldGen fg )
	{
		Type fieldType = getParamType( field.getType() );
		int staticRef = cpGen.addFieldref( cg.getClassName(), fg.getName(), fg.getSignature() );
		int fieldRef = cpGen.addFieldref( field.getDeclaringClass().getName(), field.getName(), fieldType.getSignature() );
		String className = getPersistentClassName( subject );
		char[] chars = field.getName().toCharArray();
		chars[0] = Character.toUpperCase( chars[0] );
		String varName = String.valueOf( chars );
		InstructionList il = new InstructionList();
		//get method
		Type returnType = fieldType;
		Type[] args = new Type[0];
		String[] argNames = new String[0];

		il.append( InstructionConstants.ALOAD_0 );
		il.append( new GETFIELD( editorRef ) );
		il.append( new GETSTATIC( staticRef ) );
		il.append( InstructionConstants.ALOAD_0 );
		il.append( new GETFIELD( fieldRef ) );
		int interfaceRef = 0;
		String paramSignature;
		if( field.getType().isPrimitive() )
		{
			paramSignature = Type.getMethodSignature( returnType, new Type [] { new ObjectType("java.lang.reflect.Field"), fieldType } );
		}
		else
		{
			paramSignature = Type.getMethodSignature( new ObjectType("java.lang.Object"), new Type [] { new ObjectType("java.lang.reflect.Field"), new ObjectType("java.lang.Object") } );
		}
		interfaceRef = cpGen.addInterfaceMethodref( "com.objectwave.transactionalSupport.ObjectEditingView", "get", paramSignature );
		il.append( new INVOKEINTERFACE( interfaceRef, 3 ) );
		if( !field.getType().isPrimitive() )
		{
			int classRef = cpGen.addClass( field.getType().getName() );
			il.append( new CHECKCAST( classRef ) );
		}
		il.append( getReturnInstruction( field.getType() ) );

		String methodName = "get" + varName;
		MethodGen mg = new MethodGen( Constants.ACC_PUBLIC, returnType, args, argNames,
				methodName, className, il, cpGen );

		mg.setMaxStack();
		mg.setMaxLocals();

		cg.addMethod( mg.getMethod() );

		il.dispose();
	}
	/**
	 * @param cg
	 * @param gen
	 */
	protected void addFields( final ClassGen cg, final ConstantPoolGen gen )
	{
		Field[] fields = subject.getDeclaredFields();
		Class current = subject;
		Class objectClass = Object.class;
		while( fields != null )
		{
			for( int i = 0; i < fields.length; i++ )
			{
				int mods = fields[i].getModifiers();
				//Take all non-static,non-transient,public or protected fields
				if( ( Modifier.isPublic( mods ) || Modifier.isProtected( mods ) ) &&
						( !( Modifier.isStatic( mods ) || Modifier.isTransient( mods ) ) ) )
				{
					MessageLog.debug(this,  "adding  field " + fields[i] );
					addField( cg, gen, fields[i] );
				}
			}
			//Check superclass
			current = subject.getSuperclass();
			if( current == objectClass )
			{
				fields = null;
			}
			else
			{
				fields = current.getDeclaredFields();
			}
		}
	}
	/**
	 * @return
	 */
	protected ClassGen declareClass()
	{
		String name = getPersistentClassName( subject );
		String fileName = "<generated>";
		String[] interfaceNames = new String[0];

		ClassGen cg = new ClassGen( name,
				getSuperClass(), fileName,
				Constants.ACC_PUBLIC | Constants.ACC_SUPER, interfaceNames );
		return cg;
	}
	/**
	 * The main program for the FinalClass class
	 *
	 * @param args The command line arguments
	 */
	public static void main( String[] args )
	{
		try
		{
			FinalClass it = new FinalClass( com.objectwave.persist.examples.InvertPerson.class, "com.objectwave.persist.examples.InvertPersonPersistenceBase" );
			ClassGen gen = it.parse();
			java.io.File file = new java.io.File( "Test.class" );
			gen.getJavaClass().dump( file );
			MyLoader loader = new MyLoader();
			loader.defineClass(it.getPersistentClassName( it.subject ), gen.getJavaClass() );

			Class.forName( it.getPersistentClassName( it.subject ), true, loader );
		}
		catch( Throwable t )
		{
			t.printStackTrace();
		}
	}
}
