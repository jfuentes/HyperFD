package com.objectwave.persist.bcel;

import com.objectwave.persist.invert.ClassCreator;
import com.objectwave.logging.MessageLog;
import org.apache.bcel.Constants;
import org.apache.bcel.generic.ClassGen;
import org.apache.bcel.generic.MethodGen;
import org.apache.bcel.generic.ConstantPoolGen;
import org.apache.bcel.generic.InstructionList;
import org.apache.bcel.generic.InstructionFactory;
import org.apache.bcel.generic.Type;
import org.apache.bcel.generic.GETFIELD;
import org.apache.bcel.generic.NEW;
import org.apache.bcel.generic.CHECKCAST;
import org.apache.bcel.generic.INVOKEVIRTUAL;
import org.apache.bcel.generic.INVOKESPECIAL;
import org.apache.bcel.generic.InstructionConstants;
import org.apache.bcel.classfile.JavaClass;
import org.apache.bcel.classfile.ConstantPool;
import org.apache.bcel.classfile.Constant;
import org.apache.bcel.classfile.ConstantUtf8;
import org.apache.bcel.classfile.ClassParser;
import java.io.*;
import java.util.HashMap;

/**
 * @author dave_hoag
 * @version $Id: Generator.java,v 1.8 2002/08/26 23:33:08 dave_hoag Exp $
 */
public class Generator implements ClassCreator
{
	static MyLoader defaultLoader = new MyLoader();
	static HashMap loaderMap = new HashMap();
	/**
	 * Create a new MyLoader instance for each different parent loader we discover.
	 *
	 * @param clazz
	 * @return The loaderInstance value
	 */
	public static synchronized MyLoader getLoaderInstance( Class clazz )
	{
		if( clazz.getClassLoader() != null )
		{
			MyLoader result = ( MyLoader ) loaderMap.get( clazz.getClassLoader() );
			if( result == null )
			{
				result = new MyLoader( clazz.getClassLoader() );
				loaderMap.put( clazz.getClassLoader(), result );
			}
			return result;
		}
		return defaultLoader;
	}
	/**
	 * Gets the commonBaseClassName attribute of the Generator object
	 *
	 * @param domainObject
	 * @return The commonBaseClassName value
	 */
	protected final String getCommonBaseClassName( final Class domainObject )
	{
		return domainObject.getName() + "PersistenceBaseDef";
	}
	/**
	 * @param domainObject
	 * @return
	 * @exception ClassNotFoundException
	 */
	public Class createPersistentClass( final Class domainObject ) throws ClassNotFoundException
	{
		try
		{
			createBaseFromTemplate( domainObject ) ;
			return createFinalClass( domainObject ) ;
		}
		catch(Exception ex )
		{
			throw new ClassNotFoundException( "Could not generate persistence support for " + domainObject );
		}
		
	}
	/**
	 * Generate the persistent class definition for our domain object
	 */
	protected Class createFinalClass( final Class domainObject ) throws Exception
	{
		String superClass = getCommonBaseClassName( domainObject );
		FinalClass persistentClass = new FinalClass( domainObject, superClass );
		String className = persistentClass.getPersistentClassName( domainObject);
		MyLoader loader = getLoaderInstance( domainObject );
		try
		{
			Class result = Class.forName( className, false, loader);
			return result;
		}
		catch( ClassNotFoundException ex )
		{
			MessageLog.debug(this, "Failed to locate existing persistent class, generating new base class: " + className );
		}

		ClassGen classGen = persistentClass.parse();

		Class result = loader.defineClass( className, classGen.getJavaClass() );
		return result;
	}
	/**
	 * The class name has changed, we need to tweak the constant pool to contain the new
	 * class name.
	 *
	 * @param cp
	 * @param newName
	 * @param newSuperClass
	 */
	protected void updateConstantPool( ConstantPool cp, String newName, String newSuperClass )
	{
		Constant[] constants = cp.getConstantPool();
		for( int i = 0; i < constants.length; i++ )
		{
			if( constants[i] instanceof ConstantUtf8 )
			{
				ConstantUtf8 stringConstant = ( ConstantUtf8 ) constants[i];
				String value = stringConstant.getBytes();
//				System.out.println( value );
				int idx;
				//This class
				if( ( idx = value.indexOf( "/PersistenceBase" ) ) > 0 )
				{
					String newValue = newName.replace( '.', '/' );
					if( value.startsWith( "L" ) )
					{
						newValue = "L" + newValue + ";";
					}
//					System.out.println( value + " -> " + newValue );
					stringConstant.setBytes( newValue );
				}
				if( ( idx = value.indexOf( ".PersistenceBase" ) ) > 0 )
				{
					String newValue = newName;
					if( value.startsWith( "L" ) )
					{
						newValue = "L" + newValue + ";";
					}
//					System.out.println( value + " -> " + newValue );
					stringConstant.setBytes( newValue );
				}
				//Super class
				if( ( idx = value.indexOf( "/DomainObject" ) ) > 0 )
				{
					String newValue = newSuperClass.replace( '.', '/' );
//					System.out.println( value + " -> " + newValue );
					stringConstant.setBytes( newValue );
				}
			}
		}
	}
	/**
	 * @param domainObject
	 * @exception Exception
	 */
	protected void createBaseFromTemplate( final Class domainObject ) throws Exception
	{
		MyLoader loader = getLoaderInstance( domainObject );
		String name = getCommonBaseClassName( domainObject );
		try
		{
			Class result = Class.forName( name, false, loader);
			return;
		}
		catch( ClassNotFoundException ex )
		{
			MessageLog.debug(this, "Failed to locate existing base class, generating new base class: " + domainObject.getName() );
		}
		InputStream stream = getClass().getResourceAsStream( "/com/objectwave/persist/bcel/PersistenceBase.class" );
		ClassParser parser = new ClassParser( stream, "<generated>" );
		JavaClass clazz = parser.parse();
		ClassGen classGen = new ClassGen( clazz );
		classGen.setSuperclassName( domainObject.getName() );
		classGen.setClassName( name );
		classGen.update();

		updateConstantPool( classGen.getConstantPool().getConstantPool(), name, domainObject.getName() );
//		java.io.File base = new java.io.File( "Base.class" );
//		classGen.getJavaClass().dump( base );
		loader.defineClass( name, classGen.getJavaClass() );
		Class baseClass = Class.forName( name, true, loader );
		if( baseClass == null )
		{
			throw new IllegalStateException( "There should be no problems defining this class." );
		}
	}
	public static class Test extends com.objectwave.test.UnitTestBaseImpl
	{
		public static void main( String[] args )
		{
			com.objectwave.test.TestRunner.run( new Test(), args );
		}
		public void testCreateBase() throws Exception
		{
			Class domainObject = com.objectwave.persist.examples.InvertPerson.class;
			new Generator().createBaseFromTemplate( domainObject );
			Class c = Class.forName( "com.objectwave.persist.examples.InvertPersonPersistenceBaseDef", true, getLoaderInstance( domainObject ) );
			testContext.assertTrue( c != null );
		}
	}
}
