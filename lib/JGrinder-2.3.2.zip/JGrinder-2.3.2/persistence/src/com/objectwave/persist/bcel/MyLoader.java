package com.objectwave.persist.bcel;

import org.apache.bcel.classfile.JavaClass;
import com.objectwave.logging.MessageLog;

/**
 * @author dave_hoag
 * @version $Id: MyLoader.java,v 1.3 2002/08/23 02:44:53 dave_hoag Exp $
 */
public class MyLoader extends ClassLoader
{
	/**
	 * Constructor for the MyLoader object
	 */
	public MyLoader()
	{
		this( ClassLoader.getSystemClassLoader() );
	}
	/**
	 * Constructor for the MyLoader object
	 *
	 * @param loader
	 */
	public MyLoader( ClassLoader loader )
	{
		super( loader );
	}
	/**
	 * @param name
	 * @return
	 * @exception ClassNotFoundException
	 */
	public Class findClass( String name ) throws ClassNotFoundException
	{
		System.out.println( "Looking for class " + name );
		return super.findClass( name );
	}
	/**
	 * @param name
	 * @param javaClass
	 * @return
	 */
	public Class defineClass( String name, JavaClass javaClass )
	{
		Class c = null;
		try
		{
			// dump the .class to a byte array, so we can immediately instantiate:
			java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
			javaClass.dump( bos );
			byte[] bytes = bos.toByteArray();

			// load the class from the byte array:
			c = defineClass( name, bytes, 0, bytes.length );
		}
		catch( Exception e )
		{
			// this shouldn't actually happen:
			MessageLog.error( this, "Failed to define class " + name, e );
			throw new RuntimeException( "Failed to define class - system in unknown state" );
		}

		return c;
	}
}
