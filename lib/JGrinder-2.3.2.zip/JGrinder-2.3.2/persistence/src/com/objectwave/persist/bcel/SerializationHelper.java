package com.objectwave.persist.bcel;
import com.objectwave.persist.invert.PersistenceFactory;
import com.objectwave.logging.MessageLog;
import java.io.*;
/**
 * @author dave_hoag
 * @version $Id: Generator.java,v 1.7 2002/08/23 18:05:16 dave_hoag Exp $
 */
public class SerializationHelper implements Serializable
{
	String domainClassName;
	public SerializationHelper( String name )
	{
		domainClassName = name;
	}
	/**
	 * @param in
	 * @exception java.io.IOException
	 * @exception ClassNotFoundException
	 */
	private void readObject( final java.io.ObjectInputStream in ) throws java.io.IOException, ClassNotFoundException
	{
		in.defaultReadObject();
		try
		{
			Class c = Class.forName( domainClassName );
			new PersistenceFactory().getPersistentClass( c );
			System.out.println( "Got here at least");
		}
		catch( Exception ex )
		{
			MessageLog.debug( this, "Exception recovering serialized instance", ex );
			throw new IOException( "Can't recover instance due to initialization problem" );
		}
	}
	public static void main( String [] args)
	{
		try
		{
			if( args.length == 0 )
			{
				System.out.println("Usage [read|write] classname");
			}
			else
			{
				if( args[0].equals("read") )
				{
					FileInputStream fin =new FileInputStream("test.ser");
					ObjectInputStream ois = new ObjectInputStream( fin);
					Object obj= ois.readObject();
					ois.close();
					fin.close();
					System.out.println( obj );
				}
				else
				{
					FileOutputStream fos = new FileOutputStream( "test.ser" );
					ObjectOutputStream oos = new ObjectOutputStream( fos );
					Class c= Class.forName( args[1] );
					Object obj = new PersistenceFactory().newInstance( c );
					oos.writeObject( obj );
					oos.close();
					fos.close();
				}
			}
		}
		catch( Throwable t)
		{
			t.printStackTrace();
		}
	}
}
