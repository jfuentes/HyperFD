/*
 *  Copyright (C) 2002 David Hoag
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *  For a full copy of the license see:
 *  http://www.opensource.org/licenses/lgpl-license.html
 */
package com.objectwave.persist.bcel.examples;

import com.objectwave.persist.*;
import com.objectwave.persist.broker.*;
import com.objectwave.persist.collectionAdapters.SupportedCollections;

import com.objectwave.persist.examples.*;
import com.objectwave.persist.invert.*;
import com.objectwave.test.*;
import com.objectwave.transactionalSupport.*;
import java.util.*;
/**
 * A class to exercise some of the basic capabilities of the BCEL libraries.
 * @author dave_hoag
 * @version $Id: BcelTest.java,v 1.2 2002/08/24 16:34:00 dave_hoag Exp $
 */
public class BcelTest extends UnitTestBaseImpl
{
	FileBroker broker;
	/**
	 * The JUnit setup method
	 *
	 * @param name The new up value
	 * @param context The new up value
	 */
	public void setUp( String name, TestContext context )
	{
		broker = new FileBroker();
		BrokerFactory.setDefaultBroker( broker );
		SQLQuery.setDefaultBroker( broker );
	}
	/**
	 * The main program for the BcelTest class
	 *
	 * @param args The command line arguments
	 */
	public static void main( String[] args )
	{
		new SupportedCollections();
		TestRunner.run( new BcelTest(), args );
	}
	/**
	 * The teardown method for JUnit
	 *
	 * @param context
	 * @exception Exception
	 */
	public void tearDown( TestContext context ) throws Exception
	{
		broker.close();
		super.tearDown( context );
		removeFile( "person.dbf" );
		removeFile( "employee.dbf" );
	}
	/**
	 * A unit test for JUnit
	 *
	 * @exception Exception
	 */
	public void testSaveAndFind() throws Exception
	{
		Session session = Session.createAndJoin( "ONE" );
		session.startTransaction( "RDB" );
		Person person = ( Person )new PersistenceFactory().newInstance( Person.class );
		person.setName( "Dave" );
		session.commit();
		person = ( Person )new PersistenceFactory().newInstance( Person.class );
		SQLQuery query = new SQLQuery( ( Persistence )person );
		ArrayList list = ( ArrayList )query.findCollection( ArrayList.class );
		testContext.assertEquals( "Incorrect number of records", 1, list.size() );
	}
	/**
	 * To avoid casting all of the time, you could create type specific
	 * factories. This does, however, require you to create a newInstance
	 * method in your domain object. Also note, while the PersistenceFactory
	 * requires some exception handling, the factory approach does not.
	 *
	 * @see com.objectwave.persist.examples.Person#newInstance
	 */
	public void testFactory() throws Exception
	{
		Person personFactory;
		try
		{
			personFactory = ( Person )new PersistenceFactory().newInstance( Person.class );
		}
		catch( Exception t) { throw t; }
		Person newOne = personFactory.newInstance();
		Person newTwo = personFactory.newInstance();
		testContext.assertTrue( "Should be difference instances", newOne != newTwo );
		testContext.assertTrue( "Should be persistence instances", newOne instanceof Persistence );
	}
}
