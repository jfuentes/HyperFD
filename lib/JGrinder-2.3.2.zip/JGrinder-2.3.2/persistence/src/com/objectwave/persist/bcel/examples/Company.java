package com.objectwave.persist.bcel.examples;

public class Company
{
	//Must be protected for this to work
	protected Employee [] employees;
	protected Employee ceo;
	//This variable is not persistent - hence the 'transient' attribute
	protected transient int currentHeadCount;

	public Employee getCeo() { return ceo; }
	public void setCeo( Employee value)
	{
		ceo = value;
	}
	public Employee [] getEmployees(){ return employees; }
	public void setEmployees( Employee [] args)
	{
		employees = args;
	}
	//At least a protected empty constructor is required.
	protected Company()
	{
	}
}
