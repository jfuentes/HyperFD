package com.objectwave.persist.bcel.examples;
import java.util.ArrayList;

public class Employee
{
	//Must be protected for this to work
	protected int employeeId;
	protected Person person;
	protected Employee boss;
	protected ArrayList workers;
	protected Company company;
	protected String title;
	protected String emailAddress;
	
	//Private and package-private variables are ignored by the persistence support
	String mightAsWellNotExist;
	private String neverSaved;

	public Employee getBoss() { return boss; }
	public void setBoss( Employee value)
	{
		boss = value;
	}
	public Company getCompany() { return company; }
	public void setCompany( Company comp)
	{
		company = comp;
	}
	public String getTitle(){ return title; }
	public void setTitle( String value ){ title = value; }
	public String getEmailAddress(){ return emailAddress; }
	public void setEmailAddress( String value ) { emailAddress = value; }
	public ArrayList getWorkers(){ return workers; }
	public void setWorkers( ArrayList args)
	{
		workers = args;
	}

	private void setPerson( Person per)
	{
		person = per;
	}
	protected Person getPerson()
	{
		return person;
	}
	//The methods should be empty of non standard behavior
	protected int getEmployeeId()
	{
		return employeeId;
	}
	//The methods should be empty of non standard behavior
	protected void setEmployeeId( int value )
	{
		employeeId = value;
	}
	//At least a protected empty constructor is required.
	protected Employee()
	{
	}
	public void generateId()
	{
		int id = new java.util.Random().nextInt();
		//You MUST MUST MUST use accessors to manipulate local variables
		setEmployeeId( id );
	}
}
