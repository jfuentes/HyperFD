/*
 *  Copyright (C) 2002 David Hoag
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *  For a full copy of the license see:
 *  http://www.opensource.org/licenses/lgpl-license.html
 */
package com.objectwave.persist.bcel.examples;

import com.objectwave.persist.*;
import com.objectwave.persist.broker.HypersonicBroker;
import com.objectwave.persist.invert.PersistenceFactory;
import com.objectwave.persist.sqlConstruction.*;
import com.objectwave.test.*;
import java.sql.*;
import java.util.ArrayList;
/**
 * Exercise many aspects of the transparent persistence solution.
 *
 * @author dave_hoag
 * @version $Id: ExtensiveTest.java,v 1.2 2002/08/24 15:05:03 dave_hoag Exp $
 */
public class ExtensiveTest extends UnitTestBaseImpl
{
	PersistenceFactory factory = new PersistenceFactory();
	HypersonicBroker broker;
	private final static String CONNECT_URL = "jdbc:hsqldb:.";
	private final static String USERNAME = "sa";
	private final static String PASSWORD = "";

	private final static String SQL_SEQUENCE = "CREATE TABLE sequence( nextval int PRIMARY KEY)";
	private final static String SQL_SEQUENCE_INIT = "INSERT INTO sequence(nextval) VALUES(1)";
	private final static String SQL_SEQUENCE_DROP = "DROP TABLE sequence";

	private final static String SQL_CREATE_PERSON =
			"CREATE TABLE person(\n" +
			" databaseIdentifier int NOT NULL,\n" +
			" name VARCHAR(40) NULL,\n" +
			" employeeIdentifier int,\n" +
			" age int,\n" +
			" PRIMARY KEY ( databaseIdentifier ) \n" +
			")";
	private final static String SQL_DROP_PERSON = "DROP TABLE person";

	private final static String SQL_CREATE_EMPLOYEE =
			"CREATE TABLE employee(\n" +
			" databaseIdentifier int NOT NULL,\n" +
			" emailAddress VARCHAR(40) NULL,\n" +
			" title VARCHAR(40) NULL,\n" +
			" bossIdentifier int,\n" +
			" companyIdentifier int,\n" +
			" PRIMARY KEY ( databaseIdentifier ) \n" +
			")";
	private final static String SQL_DROP_EMPLOYEE = "DROP TABLE EMPLOYEE";

	private final static String SQL_CREATE_COMPANY =
			"CREATE TABLE company(\n" +
			" databaseIdentifier int NOT NULL,\n" +
			" ceoIdentifier int,\n" +
			" PRIMARY KEY ( databaseIdentifier ) \n" +
			")";
	private final static String SQL_DROP_COMPANY = "DROP TABLE company";

	/**
	 * The JUnit setup method
	 *
	 * @param str The new Up value
	 * @param context The new Up value
	 * @exception Exception
	 */
	public void setUp( String str, com.objectwave.test.TestContext context ) throws Exception
	{
		com.objectwave.transactionalSupport.TransactionLog.Test.reset();
		System.setProperty( "ow.persistVerbose", "true" );
		System.setProperty( "ow.persistConnectionVerbose", "true" );
		System.setProperty( "ow.persistUser", USERNAME );
		System.setProperty( "ow.persistPassword", PASSWORD );
		System.setProperty( "ow.persistDriver", "org.hsqldb.jdbcDriver" );
		System.setProperty( "ow.databaseImpl", "com.objectwave.persist.broker.HypersonicBroker" );
		System.setProperty( "ow.connectUrl", CONNECT_URL );
		System.setProperty( "ow.useConnectionPool", "true" );
		BrokerFactory.useDatabase();
		HypersonicBroker myBroker = new HypersonicBroker();
		myBroker.initialize();

		BrokerFactory.setDefaultBroker( myBroker );
		SQLQuery.setDefaultBroker( myBroker );
		buildDatabase( myBroker );
		broker = myBroker;
		super.setUp( str, context );
	}

	/**
	 * The teardown method for JUnit
	 *
	 * @param context
	 */
	public void tearDown( com.objectwave.test.TestContext context )
	{
		try
		{
			dropDatabase( ( HypersonicBroker ) broker );
		}
		catch( Exception ex )
		{
			System.out.println( "Failed to tear down test. Oh well" );
			ex.printStackTrace();
		}
	}
	/**
	 * @param broker
	 * @exception Exception
	 */
	protected void dropDatabase( HypersonicBroker broker ) throws Exception
	{
		broker.getConnection().execSql( SQL_SEQUENCE_DROP );
		broker.getConnection().execSql( SQL_DROP_PERSON );
		broker.getConnection().execSql( SQL_DROP_EMPLOYEE );
		broker.getConnection().execSql( SQL_DROP_COMPANY );
	}
	/**
	 * @param broker
	 * @exception Exception
	 */
	protected void buildDatabase( HypersonicBroker broker ) throws Exception
	{
		broker.getConnection().execSql( SQL_SEQUENCE );
		broker.getConnection().execSql( SQL_SEQUENCE_INIT );
		broker.getConnection().execSql( SQL_CREATE_PERSON );
		broker.getConnection().execSql( SQL_CREATE_EMPLOYEE );
		broker.getConnection().execSql( SQL_CREATE_COMPANY );
	}
	/**
	 * Popuplate the database with a small company. NOTE: I'm not updating
	 * the actual collections - just updating the data in the database.
	 * You wouldn't want to use any of these instances in an application
	 * since the collections would not reflect the contents of the DB.
	 */
	protected Employee setupSmallCompany() throws Exception
	{
		Company company = (Company)factory.newInstance( Company.class );
		broker.save( (Persistence)company );

		Employee employee = (Employee)factory.newInstance( Employee.class );
		employee.setTitle( "boss" );
		employee.setCompany( company );
		broker.save( (Persistence)employee );

		company.setCeo( employee );
		broker.save( (Persistence)company );

		Employee worker = (Employee)factory.newInstance( Employee.class );
		worker.setTitle( "worker" );
		worker.setBoss( employee );
		worker.setCompany( company );
		broker.save( (Persistence)worker );

		worker = (Employee)factory.newInstance( Employee.class );
		worker.setTitle( "worker2" );
		worker.setBoss( employee );
		worker.setCompany( company );
		broker.save( (Persistence)worker );

		worker = (Employee)factory.newInstance( Employee.class );
		worker.setTitle( "worker3" );
		worker.setBoss( employee );
		worker.setCompany( company );
		broker.save( (Persistence)worker );

		//Using the boss found in the database we'll get a valid instance
		Employee search = (Employee)factory.newInstance( Employee.class );
		SQLQuery query = new SQLQuery( (Persistence)search );
		search.setTitle( "boss" );
		return (Employee)query.findUnique();
	}
	/**
	 * A unit test for JUnit
	 *
	 * @exception Exception
	 */
	public Employee testCollectionProxy() throws Exception
	{

		Employee resultBoss = setupSmallCompany();
		System.out.println( "Getting the workers" );
		ArrayList v = resultBoss.getWorkers();
		testContext.assertTrue( "Should have at least some workers!", v != null );

		testContext.assertEquals( "Three workers should be found!", 3, v.size() );
		Employee worker1 = ( Employee ) v.get( 0 );
		testContext.assertEquals( "Worker data incorrect", worker1.getTitle(), "worker" );
		testContext.assertTrue( "Back link not correct ", worker1.getBoss() == resultBoss );

		return resultBoss;
	}
	/**
	 */
	public void testNativeArray() throws Exception
	{
		Employee resultBoss = setupSmallCompany();
		System.out.println( "Getting the Company " );
		Company company = resultBoss.getCompany();
		testContext.assertTrue( "Company should exist!", company != null );
		Employee ceo = company.getCeo();
		testContext.assertTrue( "Employee should be same instance", ceo == resultBoss );
		Employee [] all = company.getEmployees();
		testContext.assertEquals( "Incorrect # of employees in company", 4, all.length );
	}
	/**
	 * The main program for the ExtensiveTest class
	 *
	 * @param args The command line arguments
	 */
	public static void main( String[] args )
	{
		com.objectwave.test.TestRunner.run( new ExtensiveTest(), args );
	}
}
