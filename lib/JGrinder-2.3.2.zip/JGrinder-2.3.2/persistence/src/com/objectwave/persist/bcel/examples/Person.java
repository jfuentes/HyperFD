package com.objectwave.persist.bcel.examples;

public class Person 
{
	protected String name;
	protected short age;
	protected Employee employee;

	public void setEmployee( Employee emp )
	{
		employee = emp;
	}
	public Employee getEmployee()
	{
		return employee;
	}
	public void setName( String per)
	{
		name = per;
	}
	public String getName()
	{
		return name;
	}
	public short getAge()
	{
		return age;
	}
	public void setAge( short value )
	{
		age = value;
	}
	public void generateAge()
	{
		int id = new java.util.Random().nextInt( 100 );
		//You MUST MUST MUST use accessors to manipulate local variables
		setAge( (short)id );
	}
	/**
	 * While not required, adding a method like this to your class can
	 * help simplify the coding. This will allow you to create type
	 * specific factories when creating new instances. 
	 * @see com.objectwave.persist.bcel.examples.BcelTest
	 */
	public Person newInstance()
	{
		return new Person();
	}
}
