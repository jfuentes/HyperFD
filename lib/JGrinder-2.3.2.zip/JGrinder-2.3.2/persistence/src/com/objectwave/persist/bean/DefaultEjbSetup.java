/*
 *  Copyright (C) 2001 David Hoag
 *  ObjectWave Corporation
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *  For a full copy of the license see:
 *  http://www.opensource.org/licenses/lgpl-license.html
 */
package com.objectwave.persist.bean;
import com.objectwave.configuration.bean.SetupEjbConfigurationService;
import com.objectwave.persist.BrokerFactory;
import com.objectwave.persist.SQLQuery;
import com.objectwave.persist.broker.RDBBroker;
import com.objectwave.persist.properties.BrokerPropertySource;
import com.objectwave.transactionalSupport.TransactionLog;
import com.objectwave.transactionalSupport.xa.EjbTransactionManager;
import javax.naming.NamingException;
/**
 *  Do the necessary setup for JGrinder to work in an Ejb environment, assuming
 *  all of the defaults.
 *
 * @author  dhoag
 * @version  $Id: DefaultEjbSetup.java,v 2.3 2001/10/04 19:42:17 dave_hoag Exp $
 */
public class DefaultEjbSetup
{
	static boolean initialized;
	/**
	 *  Constructor for the DefaultEjbSetup object
	 */
	public DefaultEjbSetup()
	{
	}
	/**
	 *  After calling this method, JGrinder Persistence will be integrated into the
	 *  Ejb environment. When this is done, JGrinder still generates the SQL and
	 *  supports the JGrinder proxy realization an query language, but transaction
	 *  management is done by the container.
	 *
	 * @param  brokerClassName String A name of an RDBBroker class.
	 * @exception  ClassNotFoundException The name provided in the parameter could
	 *      not be found.
	 * @exception  IllegalAccessException Our code can not reflectively create an
	 *      instance
	 * @exception  InstantiationException This method got an exception attempting
	 *      to create an instance of the brokerClassName
	 * @exception  ClassCastException The broker name provided is not an RDBBroker
	 * @exception  NamingException The Ejb TransactionManager could not be found by
	 *      jgrinder's EjbTransactionManager at java:/TransactionManager
	 */
	public synchronized void initializeRDBBroker(final String brokerClassName) throws ClassNotFoundException, IllegalAccessException, InstantiationException, ClassCastException, NamingException
	{
		initializeRDBBroker(brokerClassName, false);
	}
	/**
	 *  After calling this method, JGrinder Persistence will be integrated into the
	 *  Ejb environment. When this is done, JGrinder still generates the SQL and
	 *  supports the JGrinder proxy realization an query language, but transaction
	 *  management is done by the container.
	 *
	 * @param  brokerClassName String A name of an RDBBroker class.
	 * @param  override Force a reinitialization
	 * @exception  ClassNotFoundException The name provided in the parameter could
	 *      not be found.
	 * @exception  IllegalAccessException Our code can not reflectively create an
	 *      instance
	 * @exception  InstantiationException This method got an exception attempting
	 *      to create an instance of the brokerClassName
	 * @exception  ClassCastException The broker name provided is not an RDBBroker
	 * @exception  NamingException The Ejb TransactionManager could not be found by
	 *      jgrinder's EjbTransactionManager at java:/TransactionManager
	 */
	public synchronized void initializeRDBBroker(final String brokerClassName, boolean override) throws ClassNotFoundException, IllegalAccessException, InstantiationException, ClassCastException, NamingException
	{
		if(initialized && !override)
		{
			return;
		}
		Class c = Class.forName(brokerClassName);
		RDBBroker broker = (RDBBroker) c.newInstance();

		//get properties from java:comp/
		new SetupEjbConfigurationService();

		BrokerPropertySource source = broker.getBrokerPropertySource();
		source.setConnectionFactoryName("com.objectwave.persist.broker.EjbConnectionSource");
		//source.setConnectUrl("java:/DefaultDS");

		broker.initialize();
		BrokerFactory.setDefaultBroker(broker);
		SQLQuery.setDefaultBroker(broker);

		EjbTransactionManager ejbTrans = new EjbTransactionManager();
		ejbTrans.initializeTransactionManager();

		TransactionLog.setTransactionManager(ejbTrans);
		initialized = true;
	}

}
