package com.objectwave.persist.bean;
import com.objectwave.persist.QueryException;
import com.objectwave.persist.examples.ExampleEmployee;

import java.rmi.*;
import javax.ejb.*;
/**
 * @author  dhoag
 * @version  $Id: JGrinderQuery.java,v 2.0 2001/06/11 16:00:03 dave_hoag Exp $
 */
public interface JGrinderQuery extends EJBObject
{
	/**
	 *  Gets the Employee attribute of the JGrinderQuery object
	 *
	 * @return  The Employee value
	 * @exception  RemoteException
	 */
	public com.objectwave.persist.examples.ExampleEmployee getEmployee() throws RemoteException;
	/**
	 * @param  q
	 * @return
	 * @exception  QueryException
	 * @exception  RemoteException
	 */
	public java.lang.Object find(com.objectwave.persist.SQLQuery q) throws QueryException, RemoteException;
	/**
	 * @param  q
	 * @param  at
	 * @return
	 * @exception  QueryException
	 * @exception  RemoteException
	 */
	public java.util.Vector findAttributes(com.objectwave.persist.SQLQuery q, java.lang.String[] at) throws QueryException, RemoteException;
	/**
	 * @param  q
	 * @return
	 * @exception  QueryException
	 * @exception  RemoteException
	 */
	public com.objectwave.persist.Persistence findUnique(com.objectwave.persist.SQLQuery q) throws QueryException, RemoteException;
	/**
	 *  A unit test for JUnit
	 *
	 * @return
	 * @exception  RemoteException
	 */
	public com.objectwave.persist.SQLQuery testIt() throws RemoteException;
	/**
	 * @param  q
	 * @return
	 * @exception  QueryException
	 * @exception  RemoteException
	 */
	public int count(com.objectwave.persist.SQLQuery q) throws QueryException, RemoteException;
}
