package com.objectwave.persist.bean;
import com.objectwave.logging.MessageLog;
import com.objectwave.persist.BrokerFactory;
import com.objectwave.persist.Persistence;
import com.objectwave.persist.QueryException;
import com.objectwave.persist.SQLQuery;
import com.objectwave.persist.broker.FileBroker;
import com.objectwave.persist.examples.ExampleEmployee;

import java.rmi.*;
import java.util.ArrayList;
import java.util.Vector;
import javax.ejb.*;
/**
 * @author  dhoag
 * @version  $Id: JGrinderQueryBean.java,v 2.0 2001/06/11 16:00:03 dave_hoag Exp $
 */
public class JGrinderQueryBean implements SessionBean
{
	private SessionContext sessionContext;
	/**
	 *  Sets the SessionContext attribute of the JGrinderQueryBean object
	 *
	 * @param  context The new SessionContext value
	 */
	public void setSessionContext(SessionContext context)
	{
		sessionContext = context;
	}
	/**
	 *  Gets the Employee attribute of the JGrinderQueryBean object
	 *
	 * @return  The Employee value
	 */
	public ExampleEmployee getEmployee()
	{
		try
		{
			return readObject();
		}
		catch(Throwable t)
		{
			MessageLog.error(this, "", t);
		}
		return null;
	}
	/**
	 */
	public void ejbCreate()
	{
		FileBroker fBroker = new FileBroker();
		BrokerFactory.setDefaultBroker(fBroker);
		SQLQuery.setDefaultBroker(fBroker);
	}
	/**
	 */
	public void ejbRemove()
	{
	}
	/**
	 */
	public void ejbActivate()
	{
	}
	/**
	 */
	public void ejbPassivate()
	{
	}
	/**
	 * @param  q
	 * @return
	 * @exception  QueryException
	 */
	public Object find(SQLQuery q) throws QueryException
	{
		MessageLog.debug(this, "Find query");
		return q.findCollection();
	}
	/**
	 * @param  q
	 * @param  at
	 * @return
	 * @exception  QueryException
	 */
	public Vector findAttributes(SQLQuery q, String[] at) throws QueryException
	{
		MessageLog.debug(this, "FindAttributes query");
		return q.findAttributes(at);
	}
	/**
	 * @param  q
	 * @return
	 * @exception  QueryException
	 */
	public Persistence findUnique(SQLQuery q) throws QueryException
	{
		MessageLog.debug(this, "FindUnique query");
		return q.findUnique();
	}
	/**
	 * @return
	 */
	public SQLQuery testIt()
	{
		System.out.println("Doing the testIt ");
		ExampleEmployee search = new ExampleEmployee();
		SQLQuery query = new SQLQuery(search);
		System.out.println("Empty one");
		if(true)
		{
			return new SQLQuery();
		}
		return query;
	}
	/**
	 * @return
	 * @exception  QueryException
	 */
	public ExampleEmployee readObject() throws QueryException
	{
		System.out.println(System.getProperties().get("user.dir"));
		ExampleEmployee search = new ExampleEmployee();
		SQLQuery query = new SQLQuery(search);
		ArrayList list = (ArrayList) query.findCollection(ArrayList.class);
		ExampleEmployee employee = (ExampleEmployee) list.get(0);
		return employee;
	}
	/**
	 * @param  q
	 * @return
	 * @exception  QueryException
	 */
	public int count(SQLQuery q) throws QueryException
	{
		return q.count();
	}
}
