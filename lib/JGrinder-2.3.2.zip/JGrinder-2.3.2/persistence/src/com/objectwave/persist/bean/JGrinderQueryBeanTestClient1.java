package com.objectwave.persist.bean;
import com.objectwave.persist.BrokerFactory;
import com.objectwave.persist.SQLQuery;
import com.objectwave.persist.broker.FileBroker;
import com.objectwave.persist.broker.RemoteBeanBroker;
import com.objectwave.persist.examples.ExampleEmployee;
import java.util.ArrayList;
import java.util.Hashtable;

import javax.naming.*;
import javax.rmi.PortableRemoteObject;

/**
 * @author  dhoag
 * @version  $Id: JGrinderQueryBeanTestClient1.java,v 2.0 2001/06/11 16:00:03 dave_hoag Exp $
 */
public class JGrinderQueryBeanTestClient1
{
	private final static String ERROR_NULL_REMOTE = "Remote interface reference is null.  It must be created by calling one of the Home interface methods first.";
	private final static int MAX_OUTPUT_LINE_LENGTH = 50;
	private boolean logging = true;
	private JGrinderQueryHome jGrinderQueryHome = null;
	private JGrinderQuery jGrinderQuery = null;

	/**
	 *  Construct the EJB test client
	 */
	public JGrinderQueryBeanTestClient1()
	{
		long startTime = 0;
		if(logging)
		{
			log("Initializing bean access.");
			startTime = System.currentTimeMillis();
		}

		try
		{
			Object ref = getRemoteReference();

			//cast to Home interface
			jGrinderQueryHome = (JGrinderQueryHome) PortableRemoteObject.narrow(ref, JGrinderQueryHome.class);
			if(logging)
			{
				long endTime = System.currentTimeMillis();
				log("Succeeded initializing bean access.");
				log("Execution time: " + (endTime - startTime) + " ms.");
			}
		}
		catch(NamingException ex)
		{
			if(ex.getRootCause() != null)
			{
				ex.getRootCause().printStackTrace();
			}
			else
			{
				ex.printStackTrace();
			}
		}
		catch(Exception e)
		{
			if(logging)
			{
				log("Failed initializing bean access.");
			}
			e.printStackTrace();
		}
	}
	/**
	 *  Main method
	 *
	 * @param  args The command line arguments
	 */
	public static void main(String[] args)
	{
		JGrinderQueryBeanTestClient1 client = new JGrinderQueryBeanTestClient1();
		JGrinderQuery query = client.create();
		RemoteBeanBroker fBroker = new RemoteBeanBroker();
		BrokerFactory.setDefaultBroker(fBroker);
		SQLQuery.setDefaultBroker(fBroker);

		// Use the client object to call one of the Home interface wrappers
		// above, to create a Remote interface reference to the bean.
		// If the return value is of the Remote interface type, you can use it
		// to access the remote interface methods.  You can also just use the
		// client object to call the Remote interface wrappers.
		ExampleEmployee emp = client.getEmployee();
		System.out.println(emp.getTitle());

		ExampleEmployee search = new ExampleEmployee();

		try
		{
			SQLQuery qu = query.testIt();
			System.out.println(" Got query " + qu);

			SQLQuery q = new SQLQuery(search);
			search.setObjectIdentifier(emp.getObjectIdentifier());
			ExampleEmployee employee = (ExampleEmployee) query.findUnique(q);
			System.out.println("Query across ejb " + emp.getTitle());

			search.setObjectIdentifier(null);
			ArrayList list = (ArrayList) q.findCollection(ArrayList.class);
			for(int i = 0; i < list.size(); i++)
			{
				ExampleEmployee empList = (ExampleEmployee) list.get(i);
				System.out.println("Employee[" + i + "] " + empList.getTitle());
			}

		}
		catch(Throwable t)
		{
			t.printStackTrace();
		}
	}

	//----------------------------------------------------------------------------
	// Methods that use Remote interface methods to access data through the bean
	//----------------------------------------------------------------------------

	/**
	 *  Gets the Employee attribute of the JGrinderQueryBeanTestClient1 object
	 *
	 * @return  The Employee value
	 */
	public ExampleEmployee getEmployee()
	{
		ExampleEmployee returnValue = null;
		if(jGrinderQuery == null)
		{
			System.out.println("Error in getEmployee(): " + ERROR_NULL_REMOTE);
			return returnValue;
		}
		long startTime = 0;
		if(logging)
		{
			log("Calling getEmployee()");
			startTime = System.currentTimeMillis();
		}

		try
		{
			returnValue = jGrinderQuery.getEmployee();
			if(logging)
			{
				long endTime = System.currentTimeMillis();
				log("Succeeded: getEmployee()");
				log("Execution time: " + (endTime - startTime) + " ms.");
			}
		}
		catch(Exception e)
		{
			if(logging)
			{
				log("Failed: getEmployee()");
			}
			e.printStackTrace();
		}

		if(logging)
		{
			log("Return value from getEmployee(): " + returnValue + ".");
		}
		return returnValue;
	}

	//----------------------------------------------------------------------------
	// Methods that use Home interface methods to generate a Remote interface reference
	//----------------------------------------------------------------------------

	/**
	 * @return
	 */
	public JGrinderQuery create()
	{
		long startTime = 0;
		if(logging)
		{
			log("Calling create()");
			startTime = System.currentTimeMillis();
		}
		try
		{
			jGrinderQuery = jGrinderQueryHome.create();
			if(logging)
			{
				long endTime = System.currentTimeMillis();
				log("Succeeded: create()");
				log("Execution time: " + (endTime - startTime) + " ms.");
			}
		}
		catch(Exception e)
		{
			if(logging)
			{
				log("Failed: create()");
			}
			e.printStackTrace();
		}

		if(logging)
		{
			log("Return value from create(): " + jGrinderQuery + ".");
		}
		return jGrinderQuery;
	}
	/**
	 * @return  The RemoteReference value
	 * @exception  NamingException
	 */
	protected Object getRemoteReference() throws NamingException
	{
                /* - Use VisualAge Name Service
		String providerUrl = System.getProperty("java.naming.provider.url", "IIOP://localhost/");
		String provider = System.getProperty("java.naming.factory.initial", "com.ibm.ejs.ns.jndi.CNInitialContextFactory");
		Hashtable table = new Hashtable();
		table.put("java.naming.provider.url", providerUrl);
		table.put("java.naming.factory.initial", provider);
		//get naming context
		Context ctx = new InitialContext(table);
		*/
		Context ctx = new InitialContext();
		return ctx.lookup("JGrinderQuery");
	}

	//----------------------------------------------------------------------------
	// Utility Methods
	//----------------------------------------------------------------------------

	/**
	 * @param  message
	 */
	private void log(String message)
	{
		if(message.length() > MAX_OUTPUT_LINE_LENGTH)
		{
			System.out.println("-- " + message.substring(0, MAX_OUTPUT_LINE_LENGTH) + " ...");
		}
		else
		{
			System.out.println("-- " + message);
		}
	}
}
