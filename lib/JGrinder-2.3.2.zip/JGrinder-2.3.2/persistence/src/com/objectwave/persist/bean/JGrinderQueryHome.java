package com.objectwave.persist.bean;

import java.rmi.*;
import javax.ejb.*;

/**
 * @author  dhoag
 * @version  $Id: JGrinderQueryHome.java,v 2.0 2001/06/11 16:00:03 dave_hoag Exp $
 */
public interface JGrinderQueryHome extends EJBHome
{
	/**
	 * @return
	 * @exception  RemoteException
	 * @exception  CreateException
	 */
	public JGrinderQuery create() throws RemoteException, CreateException;
}
