package com.objectwave.persist.bean;
import com.objectwave.persist.BrokerFactory;
import com.objectwave.persist.QueryException;
import com.objectwave.persist.SQLQuery;
import com.objectwave.persist.broker.FileBroker;
import com.objectwave.persist.examples.*;
import com.objectwave.persist.mapping.RDBPersistentAdapter;
import java.io.*;
import java.util.*;
/**
 * @author  dhoag
 * @version  $Id: SerIt.java,v 2.1 2002/03/23 13:42:10 dave_hoag Exp $
 */
public class SerIt
{
	ExampleEmployee employee;
	byte[] serializedBytes;
	/**
	 *  Constructor for the SerIt object
	 */
	public SerIt()
	{
	}
	/**
	 *  The main program for the SerIt class
	 *
	 * @param  args The command line arguments
	 */
	public static void main(String[] args)
	{
		FileBroker fBroker = new FileBroker();
		BrokerFactory.setDefaultBroker(fBroker);
		SQLQuery.setDefaultBroker(fBroker);

		SerIt serIt = new SerIt();
		try
		{
			if(args.length > 0)
			{
				serIt.writeObject(args);
			}
			else
			{
				serIt.readObject();
				serIt.serializeIt();
				ExampleEmployee newView = serIt.deserialize();
				System.out.println("Old " + serIt.employee + " new " + newView);
				System.out.println("Person is " + newView.getPerson());
				newView.save();
			}

		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		System.out.println("Complete");
	}
	/**
	 * @param  args
	 * @exception  QueryException
	 */
	public void writeObject(String[] args) throws QueryException
	{
		ExampleEmployee emp = new ExampleEmployee();
		emp.setTitle(args[0]);
		emp.save();
		ExamplePerson pers = new ExamplePerson();
		pers.setName("Dave");
		pers.setEmployee(emp);
		pers.save();
	}
	/**
	 * @return
	 * @exception  QueryException
	 */
	public int readObject() throws QueryException
	{
		ExampleEmployee search = new ExampleEmployee();
		SQLQuery query = new SQLQuery(search);
		ArrayList list = (ArrayList) query.findCollection(ArrayList.class);
		employee = (ExampleEmployee) list.get(0);
		return list.size();
	}
	/**
	 * @return
	 * @exception  Exception
	 */
	public ExampleEmployee deserialize() throws Exception
	{
		ByteArrayInputStream bin = new ByteArrayInputStream(serializedBytes);
		ObjectInputStream ois = new ObjectInputStream(bin);
		Object obj = ois.readObject();
		ois.close();
		bin.close();
		return (ExampleEmployee) obj;
	}
	/**
	 * @exception  Exception
	 */
	public void serializeIt() throws Exception
	{
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		ObjectOutputStream oos = new ObjectOutputStream(bos);
		oos.writeObject(employee);
		oos.flush();
		serializedBytes = bos.toByteArray();
		oos.close();
		bos.close();
	}
	/**
	 * @author  dhoag
	 * @version  $Id: SerIt.java,v 2.1 2002/03/23 13:42:10 dave_hoag Exp $
	 */
	public static class Test extends com.objectwave.test.UnitTestBaseImpl
	{
		FileBroker fBroker;
		/**
		 *  The main program for the Test class
		 *
		 * @param  args The command line arguments
		 */
		public static void main(String[] args)
		{
			com.objectwave.test.TestRunner.run(new Test(), args);
		}
		/**
		 *  The JUnit setup method
		 *
		 * @param  testName The new Up value
		 * @param  context The new Up value
		 */
		public void setUp(String testName, com.objectwave.test.TestContext context)
		{
			fBroker = new FileBroker();
			BrokerFactory.setDefaultBroker(fBroker);
			SQLQuery.setDefaultBroker(fBroker);
		}
		/**
		 *  The teardown method for JUnit
		 *
		 * @param  context
		 */
		public void tearDown(com.objectwave.test.TestContext context)
		{
			fBroker.close();
			removeFile("person.dbf");
			removeFile("employee.dbf");
		}
		/**
		 *  A unit test for JUnit
		 *
		 * @exception  Exception
		 */
		public void testBasics() throws Exception
		{
			SerIt serIt = new SerIt();
			serIt.writeObject(new String[]{"title"});
			serIt.readObject();
			testContext.assertEquals("Person proxy must realize on original!", "Dave", serIt.employee.getPerson().getName());
			serIt.employee.save();
		}
		/**
		 *  A unit test for JUnit
		 *
		 * @exception  Exception
		 */
		public void testDomainSerialize() throws Exception
		{
			SerIt serIt = new SerIt();
			serIt.writeObject(new String[]{"title"});
			serIt.readObject();
			testContext.assertEquals("Person proxy must realize on original!", "Dave", serIt.employee.getPerson().getName());

			serIt.serializeIt();
			ExampleEmployee newView = serIt.deserialize();
			testContext.assertTrue("Instances must be different after serialization", serIt.employee != newView);
			testContext.assertEquals("Person proxy must realize!", "Dave", newView.getPerson().getName());
			newView.getPerson().setEmployee(null);
			newView.getPerson().save();
			newView.setPerson(null);
			newView.setTitle("aNewTitle");
			newView.save();
			//Must be as good as the original
			int size = serIt.readObject();
			//Read in the newly saved object
			testContext.assertEquals("Expected only one entry in the employee table", 1, size);
			testContext.assertEquals("PrimaryKey Value should not change!", newView.getObjectIdentifier(), serIt.employee.getObjectIdentifier());
			testContext.assertEquals("Title was not changed!", "aNewTitle", serIt.employee.getTitle());
			testContext.assertTrue("Person found when it shouldn't be!", newView.getPerson() == null);
			testContext.assertTrue("Person was erased, but yet it remains!", serIt.employee.getPerson() == null);
		}
	}
}
