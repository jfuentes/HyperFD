/* Copyright (C) 2001 David Hoag
 * ObjectWave Corporation
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * For a full copy of the license see:
 * http://www.opensource.org/licenses/lgpl-license.html
 */
package com.objectwave.persist.broker;
import com.objectwave.logging.MessageLog;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.SQLWarning;
/**
 *  Some basic methods that our connection factories may use.
 *
 * @author  dhoag
 * @version  $Id: AbstractConnectionFactory.java,v 2.1 2001/06/13 23:40:07 dave_hoag Exp $
 */
public abstract class AbstractConnectionFactory
{
	/**
	 *  Constructor for the AbstractConnectionFactory object
	 */
	public AbstractConnectionFactory()
	{
	}
	/**
	 * @param  jgrinderConnection
	 * @param  connection
	 */
	public void freeNormalConnection(final RDBConnection jgrinderConnection, java.sql.Connection connection)
	{
		jgrinderConnection.setThread(null);
		if(jgrinderConnection.verbose)
		{
			MessageLog.debug(this, String.valueOf(System.currentTimeMillis()) + " Freeing " + this + " Thread: " + Thread.currentThread());
		}
		jgrinderConnection.getPool().notifyConnection();
	}
	/**
	 * @param  warn
	 * @return
	 * @exception  SQLException
	 */
	protected final boolean checkForWarning(SQLWarning warn) throws SQLException
	{
		boolean rc = false;

		// If a SQLWarning object was given, display the
		// warning messages.  Note that there could be
		// multiple warnings chained together

		if(warn != null)
		{
			MessageLog.warn(this, "\n *** Warning ***\n" + " Thread: " + Thread.currentThread());
			rc = true;
			while(warn != null)
			{
				MessageLog.warn(this, "SQLState: " + warn.getSQLState());
				MessageLog.warn(this, "Message:  " + warn.getMessage());
				MessageLog.warn(this, "Vendor:   " + warn.getErrorCode());
				MessageLog.warn(this, "");
				warn = warn.getNextWarning();
			}
		}
		return rc;
	}
	/**
	 *  Display some log information about the connection.
	 *
	 * @param  databaseMetaData
	 * @exception  SQLException
	 */
	protected final void logConnectionStatus(final DatabaseMetaData databaseMetaData) throws SQLException
	{
		boolean supportsTransaction = databaseMetaData.supportsTransactions();
		int maxStatements = databaseMetaData.getMaxStatements();

		MessageLog.info(this, "\nConnected to " + databaseMetaData.getURL());
		MessageLog.info(this, "Driver	   " + databaseMetaData.getDriverName());
		MessageLog.info(this, "Version	  " + databaseMetaData.getDriverVersion());
		MessageLog.info(this, "Supports Transactions " + supportsTransaction);
		MessageLog.info(this, "Max Statements " + maxStatements);
		MessageLog.info(this, "");
	}
}
