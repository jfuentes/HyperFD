package com.objectwave.persist.broker;
import com.objectwave.persist.*;
import com.objectwave.persist.mapping.*;
import com.objectwave.persist.sqlConstruction.*;

import java.sql.*;
/**
 *  Used for connecting to MS Access database.
 *
 * @author  Dave Hoag
 * @version  $Id: AccessBroker.java,v 2.3 2002/02/13 21:36:18 dave_hoag Exp $
 */
public class AccessBroker extends RDBBroker
{
	/**
	 *  Most systems will have only one database broker. This method is used to
	 *  support systems of that type.
	 *
	 * @return  The DefaultBroker value
	 */
	public static RDBBroker getDefaultBroker()
	{
		if(broker == null)
		{
			broker = new AccessBroker();
			broker.initialize();
		}
		return broker;
	}
	/**
	 * Install our custom object formatter
	 */
	public void initialize()
	{
		super.initialize();
		//A Special ObjectFormatter is needed to customize the format of data for Access.
		statementFactory.setObjectFormatter(new AccessObjectFormatter());
	}
	/**
	 *  Builds and executes an update statement.
	 *
	 * @param  pObj
	 * @exception  QueryException
	 * @exception  SQLException
	 */
	public void update(final RDBPersistence pObj) throws QueryException, SQLException
	{
		SQLUpdate sql = statementFactory.newUpdate();
		try
		{
			sqlModifyEngine.buildUpdateStatement(sql, pObj, pObj.getPersistentObject());
			if(getBrokerPropertySource().getUsePreparedStatements())
			{
				getConnection().preparedUpdateSql(sql, (Persistence) pObj.getDomainObject());
			}
			else
			{
				getConnection().updateExecSql(sql);
				//Specifically for AccessDatabases
				//For some reason beyond me updates are not committing immediately.
				getConnection().updateExecSql(sql);
			}
		}
		finally
		{
			statementFactory.returnUpdate(sql);
		}
	}
	/**
	 *  Don't include the primary key field as a value in the insert statement.
	 *
	 * @param  sql
	 * @param  obj
	 */
	public void update(final SQLInsert sql, final RDBPersistence obj)
	{
		//Since the broker isn't generating the pkey, we need to include columns
		if(!obj.getBrokerGeneratedPrimaryKeys())
		{
			AttributeTypeColumn[] atc = obj.getPrimaryKeyDescriptions();
			for(int i = 0; i < atc.length; ++i)
			{
				sql.addColumnValue(atc[i].getColumnName(), atc[i].getValue(obj.getPersistentObject()));
			}
		}
	}
	/**
	 *  Implemented as an instance method to support method overriding.
	 *
	 * @return  com.objectwave.persist.RDBBroker or a subclass.
	 * @author  Dave Hoag
	 */
	public RDBBroker defaultBroker()
	{
		return AccessBroker.getDefaultBroker();
	}
	/**
	 *  Determine the primary key for the provided persistent object. This assumes
	 *  the primary key has not yet been determined and that the pObj happens to
	 *  match the highest value the table.
	 *
	 * @param  pObj
	 * @exception  SQLException
	 * @exception  QueryException
	 */
	protected void determinePrimaryKey(final RDBPersistence pObj) throws SQLException, QueryException
	{
		// The following will query to determine value just inserted.
		int idx = ((Integer) nextPrimaryKey(pObj)).intValue() - 1;
		final AttributeTypeColumn column = pObj.getPrimaryAttributeDescription();
		final Object value = SQLObject.getDefaultFormatter().convertType(column, String.valueOf(idx));
		pObj.setPrimaryKeyField(value);
	}
	/**
	 *  Override the default behavior since we can not determine pkey prior to
	 *  insert.
	 *
	 * @param  pObj
	 * @exception  SQLException
	 * @exception  QueryException
	 */
	protected void generateInsertValues(final RDBPersistence pObj) throws SQLException, QueryException
	{
		//change to a no-op
	}
	/**
	 *  Access the NEXTVAL function of each table to determine the next primary key
	 *  for the table named tableName. Do a query to determine the highest known
	 *  pkey. This is a VERY unsafe solution and should only be used on databases
	 *  that don't support other ways of determining pkey.
	 *
	 * @param  pObj
	 * @return  Next available primary key field.
	 * @exception  SQLException
	 * @exception  QueryException
	 */
	protected Object nextPrimaryKey(RDBPersistence pObj) throws SQLException, QueryException
	{
		String tableName = pObj.getTableName(null);

		/*
		 *  ACCESS
		 */
		//With MSAccess, this non multithread approach will have to be sufficient.
		//For now, this is all I need.
		boolean exclusiveTableLock = false;
		//not needed with current approach
		SQLSelect sqlA = new SQLSelect(tableName, exclusiveTableLock);
		String colName = pObj.getPrimaryKeyColumn();
		sqlA.addColumnList("max(" + colName + ')');
		int i = getConnection().nextPrimaryKey(sqlA);
		return new Integer(i + 1);
	}
}

