/*
 *  Copyright (C) 2001 David Hoag
 *  ObjectWave Corporation
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *  For a full copy of the license see:
 *  http://www.opensource.org/licenses/lgpl-license.html
 */
package com.objectwave.persist.broker;

import com.objectwave.persist.ObjectFormatter;
import java.sql.Timestamp;
import java.util.Date;
/**
 * Customize the formatting of dates for MS Access.
 *
 * @author  dhoag
 * @version  $Id: AccessObjectFormatter.java,v 1.1 2001/11/08 20:36:31 dave_hoag Exp $
 */
public class AccessObjectFormatter extends ObjectFormatter
{
	/**
	 *  Constructor for the AccessObjectFormatter object
	 */
	public AccessObjectFormatter()
	{
	}
	/**
	 *  Format for Access based dates.
	 * <p />
	 * Timestamps look like 2001-11-02 10:56:46.923, but for
	 * access we need to remove everything after the final .
	 * so you keep 2001-11-02 10:56:46
	 *
	 * @param  value Date object to format.
	 * @param  buf StringBuffer upon which to write the data.
	 */
	protected void formatDate(final Date value, final StringBuffer buf)
	{
		String timeStamp = new Timestamp(value.getTime()).toString();
		int idx = timeStamp.lastIndexOf('.');
		//include the period
		timeStamp = timeStamp.substring(0, idx);
		buf.append('#');
		buf.append(' ');
		buf.append(timeStamp);
		buf.append(' ');
		buf.append('#');
	}
	/**
	 * @author  dhoag
	 * @version  $Id: AccessObjectFormatter.java,v 1.1 2001/11/08 20:36:31 dave_hoag Exp $
	 */
	public static class Test extends com.objectwave.test.UnitTestBaseImpl
	{
		/**
		 *The main program for the Test class
		 *
		 * @param  args The command line arguments
		 */
		public static void main(String[] args)
		{
			com.objectwave.test.TestRunner.run(new Test(), args);
		}
		/**
		 *A unit test for JUnit
		 *
		 * @exception  Exception
		 */
		public void testDateFormat() throws Exception
		{
			Date date = java.text.DateFormat.getDateInstance().parse("October 9, 1999");
			StringBuffer buffer = new StringBuffer();
			new AccessObjectFormatter().formatDate(date, buffer);
			testContext.assertEquals("# 1999-10-09 00:00:00 #", buffer.toString());
		}
	}
}
