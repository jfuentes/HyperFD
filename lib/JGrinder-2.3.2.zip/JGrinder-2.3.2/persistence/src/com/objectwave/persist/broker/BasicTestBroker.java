/*
 *  Copyright (C) 2001 David Hoag
 *  ObjectWave Corporation
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *  For a full copy of the license see:
 *  http://www.opensource.org/licenses/lgpl-license.html
 */
package com.objectwave.persist.broker;
import com.objectwave.logging.MessageLog;
import com.objectwave.persist.*;
import com.objectwave.persist.constraints.*;
import com.objectwave.persist.examples.*;
import com.objectwave.persist.properties.*;
import com.objectwave.test.*;
import java.io.*;
import java.util.*;
/**
 *  Generic test suite to exercise a broker instance. If no brokerImpl is
 *  specified or manually set, it defaults to using the FileBroker.
 *
 * @author  dhoag
 * @version  $Id: BasicTestBroker.java,v 1.6 2003/12/01 16:52:20 dave_hoag Exp $
 */
public class BasicTestBroker extends UnitTestBaseImpl
{
	static FileBroker defaultBroker = new FileBroker();
	/**
	 */
	public Broker broker;
	/**
	 *  Constructor for the BasicTestBroker object
	 */
	public BasicTestBroker()
	{
	}
	/**
	 *  The main program for the Test class
	 *
	 * @param  args The command line arguments
	 */
	public static void main(String[] args)
	{
		com.objectwave.test.TestRunner.run(new BasicTestBroker(), args);
	}
	/**
	 *  The JUnit setup method
	 *
	 * @param  str The new Up value
	 * @param  context The new Up value
	 * @exception  Exception
	 */
	public void setUp(String str, com.objectwave.test.TestContext context) throws Exception
	{
		super.setUp(str, context);
		com.objectwave.transactionalSupport.TransactionLog.Test.reset();

		Class c2 = BrokerFactory.class;
		//Load the BrokerFactory
		String brokerName = System.getProperty("testBrokerImpl", null);
		if(brokerName != null)
		{
			try
			{
				Class c = Class.forName(brokerName);
				broker = (Broker) c.newInstance();

				if(broker instanceof RDBBroker)
				{
					RDBBroker rdbBroker = (RDBBroker) broker;
					rdbBroker.initialize();
					MessageLog.info(this, String.valueOf( rdbBroker.getBrokerPropertySource().getPrimaryKeyStrategy() ) );
				}
			}
			catch(Throwable t)
			{
				System.out.println(t);
			}
		}
		//Oh well, use the file broker

		if(broker == null)
		{
			broker = new FileBroker();
		}
//           broker = defaultBroker;
		//Makes proxies work!
		System.out.println("Using default broker of " + broker);
		BrokerFactory.setDefaultBroker(broker);
		SQLQuery.setDefaultBroker(broker);
	}
	/**
	 *  The teardown method for JUnit
	 *
	 * @param  context Description of Parameter
	 */
	public void tearDown(com.objectwave.test.TestContext context)
	{
//if(true) return;
		try
		{
			ExampleEmployee emp1 = new ExampleEmployee();
			ExamplePerson person = new ExamplePerson();
			ExampleCompany comp = new ExampleCompany();
			SQLQuery quer = new SQLQuery(emp1);
			SQLQuery pers = new SQLQuery(person);
			SQLQuery company = new SQLQuery(comp);
			try
			{
				quer.deleteAll();
				pers.deleteAll();
				company.deleteAll();
			}
			catch(Exception ex)
			{
				ex.printStackTrace();
				System.err.println("May have failed to clean database " + ex);
			}
			broker.close();

		}
		catch(Throwable t)
		{
			System.out.println("Failed to remove old db file " + t);
		}
		//Don't really care
	}
	/**
	 *  A unit test for JUnit
	 */
	public void testTargetFileName()
	{
		String source = "example";
		FileBroker fb = new FileBroker();
		fb.targetDirectory = null;
		String result = fb.getTargetFileName(source);
		testContext.assertEquals("Failed to generate default file name", "example.dbf", result);
		fb.targetDirectory = "one";
		result = fb.getTargetFileName(source);
		testContext.assertEquals("Failed to generate file name", "one" + File.separatorChar + "example.dbf", result);
		fb.targetDirectory = "two/";
		result = fb.getTargetFileName(source);
		testContext.assertEquals("Failed to generate file name", "two/example.dbf", result);
		fb.targetDirectory = "two\\";
		result = fb.getTargetFileName(source);
		testContext.assertEquals("Failed to generate file name", "two\\example.dbf", result);
	}
	/**
	 *  A unit test for JUnit
	 *
	 * @exception  QueryException Description of Exception
	 */
	public void testConstrainingInstance() throws QueryException
	{
		ExampleEmployee emp1 = new ExampleEmployee();
		emp1.setTitle("nothing");
		broker.save(emp1);

		ExampleEmployee employee = new ExampleEmployee();
		employee.setTitle("myTitle");
		broker.save(employee);

		ExampleEmployee emp2 = new ExampleEmployee();
		emp2.setTitle("nothing");
		broker.save(emp2);

		ExamplePerson person = new ExamplePerson();
		person.setName("Dave Hoag");
		person.setEmployee(employee);
		employee.setPerson(person);
		broker.save(person);

		ExampleEmployee search = new ExampleEmployee();
		SQLQuery query = new SQLQuery(search);
		search.setPerson(person);
		Vector v = query.find();
		testContext.assertEquals("The saved employee was not found!", 1, v.size());

		ExampleEmployee resultEmployee = (ExampleEmployee) v.get(0);
		ExamplePerson resultPerson = resultEmployee.getPerson();

		testContext.assertTrue("Instance object not found!", resultPerson != null);

		testContext.assertEquals("Pkeys don't match on FK object", person.getObjectIdentifier(), resultPerson.getObjectIdentifier());
		testContext.assertEquals("Data in Instance Object doesn't match!", resultPerson.getName(), person.getName());
		testContext.assertTrue("The objects are not the EXACT same references", resultEmployee.getPerson() == person);
	}

	/**
	 *A unit test for JUnit
	 *
	 * @exception  QueryException
	 */
	public void testCrossFieldConstraint() throws QueryException
	{
		ExampleEmployee employee = new ExampleEmployee();
		employee.setTitle("myTitle");
		broker.save(employee);

		ExamplePerson p = new ExamplePerson();
		p.setName("John Smith");
		broker.save(p);

		ExamplePerson pers1 = new ExamplePerson();
		pers1.setName("Steve Sinclair");
		broker.save(pers1);

		ExamplePerson person = new ExamplePerson();
		person.setName("Dave Hoag");
		person.setEmployee(employee);
		broker.save(person);

		ExamplePerson search = new ExamplePerson();
		SQLQuery query = new SQLQuery(search);

		ConstraintCompare one = new ConstraintCompare();
		one.setComparison("=");
		one.setCompValue("Dave Hoag");
		one.setField("name");
		ConstraintCompare two = new ConstraintCompare();
		two.setComparison("LIKE");
		two.setCompValue("Steve%");
		two.setField("name");

		//create the outer 'or' constraint
		CrossField outerConst = new CrossField(false, one, two);
		outerConst.setField("name");
		query.addConstraint(outerConst);

		Vector v = query.find();
		testContext.assertEquals("The correct number of saved people were not found!", 2, v.size());

		ExamplePerson resultPerson = (ExamplePerson) v.get(0);
	}
	/**
	 *  A unit test for JUnit
	 *
	 * @exception  QueryException Description of Exception
	 */
	public void testConstrainingFk() throws QueryException
	{
		ExampleEmployee employee = new ExampleEmployee();
		employee.setTitle("myTitle");
		broker.save(employee);

		ExamplePerson pers1 = new ExamplePerson();
		pers1.setName("Steve Sinclair");
		broker.save(pers1);

		ExamplePerson person = new ExamplePerson();
		person.setName("Dave Hoag");
		person.setEmployee(employee);
		broker.save(person);

		ExamplePerson search = new ExamplePerson();
		SQLQuery query = new SQLQuery(search);
		search.setEmployee(employee);
		Vector v = query.find();
		testContext.assertEquals("The saved person (or to many persons) not found!", 1, v.size());

		ExamplePerson resultPerson = (ExamplePerson) v.get(0);
		ExampleEmployee resultEmployee = resultPerson.getEmployee();

		testContext.assertEquals("Pkeys don't match on FK object", employee.getObjectIdentifier(), resultEmployee.getObjectIdentifier());
		testContext.assertTrue("The exact employee instances are not the same! ", resultEmployee == employee);
	}
	/**
	 *  A unit test for JUnit
	 *
	 * @exception  QueryException
	 * @exception  Exception
	 */
	public void testDualInsert() throws QueryException, Exception
	{
		com.objectwave.transactionalSupport.TransactionLog log = com.objectwave.transactionalSupport.TransactionLog.startRootTransaction("RDB", "MYCONTEXT");

		ExampleEmployee employee = new ExampleEmployee();
		employee.setTitle("myTitle2");
		ExamplePerson person = new ExamplePerson();
		person.setName("Dave Hoag2");
		person.setEmployee(employee);
		employee.setPerson(person);

		ExampleCompany company = new ExampleCompany();
		company.setCeo(employee);
		employee.setCompany(company);

		log.commit();

		ExamplePerson search = new ExamplePerson();
		SQLQuery query = new SQLQuery(search);
		Vector v = query.find();
		testContext.assertEquals("The saved person (or to many persons) not found!", 1, v.size());

		ExamplePerson per = (ExamplePerson) v.get(0);
		testContext.assertEquals("The employee did not have correct title", "myTitle2", per.getEmployee().getTitle());

		ExampleEmployee search2 = new ExampleEmployee();
		query = new SQLQuery(search2);
		v = query.find();
		testContext.assertEquals("The saved employee( or to many employees) not found!", 1, v.size());
		ExampleEmployee emp = (ExampleEmployee) v.get(0);
		testContext.assertEquals("The person did not have correct name", "Dave Hoag2", emp.getPerson().getName());
		testContext.assertTrue("The company did not exist!", emp.getCompany() != null);

		ExampleCompany search3 = new ExampleCompany();
		query = new SQLQuery(search3);
		v = query.find();
		testContext.assertEquals("The saved company( or to many employees) not found!", 1, v.size());
		ExampleCompany comp = (ExampleCompany) v.get(0);
		testContext.assertTrue("The employee ceo did not exist!", comp.getCeo() != null);
		testContext.assertEquals("The employee did not have correct title", "myTitle2", comp.getCeo().getTitle());
	}
	/**
	 *  A unit test for JUnit
	 *
	 * @exception  QueryException Description of Exception
	 */
	public void testInstanceProxy() throws QueryException
	{
		ExampleEmployee employee = new ExampleEmployee();
		employee.setTitle("myTitle");
		broker.save(employee);

		ExamplePerson person = new ExamplePerson();
		person.setName("Dave Hoag");
		person.setEmployee(employee);
		broker.save(person);

		ExamplePerson secondPerson = new ExamplePerson();
		secondPerson.setName("Should not be found");
		broker.save(secondPerson);

		employee.setPerson(person);

		ExampleEmployee search = new ExampleEmployee();
		SQLQuery query = new SQLQuery(search);
		Vector v = query.find();
		testContext.assertEquals("The saved employee was not found!", 1, v.size());

		ExampleEmployee resultEmployee = (ExampleEmployee) v.get(0);
		ExamplePerson resultPerson = resultEmployee.getPerson();

		testContext.assertTrue("Instance object not found!", resultPerson != null);

		testContext.assertEquals("Pkeys don't match on FK object", person.getObjectIdentifier(), resultPerson.getObjectIdentifier());
		testContext.assertEquals("Data in Instance Object doesn't match!", resultPerson.getName(), person.getName());

		ExampleEmployee emp2 = new ExampleEmployee();
		emp2.setTitle("NoEmployee");
		broker.save(emp2);

		search = new ExampleEmployee();
		query = new SQLQuery(search);
		search.setTitle("NoEmployee");
		v = query.find();
		testContext.assertEquals("The correct employee was not found!", 1, v.size());
		resultEmployee = (ExampleEmployee) v.get(0);

		testContext.assertTrue("No person should be found!", resultEmployee.getPerson() == null);

	}

	/**
	 *  A unit test for JUnit
	 *
	 * @exception  QueryException Description of Exception
	 */
	public void testFkProxy() throws QueryException
	{
		ExampleEmployee employee = new ExampleEmployee();
		employee.setTitle("myTitle");
		broker.save(employee);

		ExamplePerson person = new ExamplePerson();
		person.setName("Dave Hoag");
		person.setEmployee(employee);
		broker.save(person);

		ExamplePerson search = new ExamplePerson();
		SQLQuery query = new SQLQuery(search);
		Vector v = query.find();
		testContext.assertEquals("The saved person was not found!", 1, v.size());

		ExamplePerson resultPerson = (ExamplePerson) v.get(0);
		ExampleEmployee resultEmployee = resultPerson.getEmployee();

		testContext.assertEquals("Pkeys don't match on FK object", employee.getObjectIdentifier(), resultEmployee.getObjectIdentifier());
	}
	/**
	 *  A unit test for JUnit
	 *
	 * @exception  QueryException Description of Exception
	 */
	public void testListFind() throws QueryException
	{
		ExampleEmployee employee = new ExampleEmployee();
		employee.setTitle("myTitle");
		broker.save(employee);

		ExampleEmployee emp2 = new ExampleEmployee();
		emp2.setTitle("myTitle2");
		broker.save(emp2);

		ExampleEmployee search = new ExampleEmployee();
		SQLQuery query = new SQLQuery(search);
		Vector v = query.find();
		testContext.assertEquals("The two saved objects were not found!", 2, v.size());

		broker.save(employee);
		query.addOrderByField("title");
		v = query.find();
		testContext.assertEquals("Element count corrupt after resave first object. ", 2, v.size());

		ExampleEmployee empResult = (ExampleEmployee) v.get(0);
		testContext.assertTrue("Data not marked from database!", empResult.isRetrievedFromDatabase());
		testContext.assertEquals("Incorrect data in the resulting objects", employee.getTitle(), empResult.getTitle());

		empResult = (ExampleEmployee) v.get(1);
		testContext.assertTrue("Second data element not marked from database!", empResult.isRetrievedFromDatabase());
		testContext.assertEquals("Incorrect data in the resulting objects", emp2.getTitle(), empResult.getTitle());

		empResult.save();
		//A resave that should result in an update
		v = query.find();
		testContext.assertEquals("After saving a returned result, element count in DB incorrect!", 2, v.size());

	}
	/**
	 *  A unit test for JUnit
	 *
	 * @exception  QueryException Description of Exception
	 */
	public void testSimpleFind() throws QueryException
	{
		ExampleEmployee employee = new ExampleEmployee();
		employee.setTitle("myTitle");
		broker.save(employee);

		ExampleEmployee emp2 = new ExampleEmployee();
		emp2.setTitle("myTitle2");
		broker.save(emp2);

		broker.save(employee);

		ExampleEmployee search = new ExampleEmployee();
		SQLQuery query = new SQLQuery(search);
		search.setPrimaryKeyField(employee.getPrimaryKeyField());
		ExampleEmployee result = (ExampleEmployee) query.findUnique();
		testContext.assertTrue("No employee found!", result != null);
		testContext.assertTrue("Employee found, but not with correct primary key", employee.getObjectIdentifier().equals(result.getObjectIdentifier()));
		testContext.assertEquals("Title Value corrupted!", employee.getTitle(), result.getTitle());
		testContext.assertEquals("Email address Value corrupted!", employee.getEmailAddress(), result.getEmailAddress());

		broker.save(result);
		employee = (ExampleEmployee) query.findUnique();
		testContext.assertTrue("Employee found, but not with correct primary key after update", employee.getObjectIdentifier().equals(result.getObjectIdentifier()));

		search.setPrimaryKeyField(emp2.getPrimaryKeyField());
		result = (ExampleEmployee) query.findUnique();
		testContext.assertTrue("Employee found, but not with correct primary key", emp2.getObjectIdentifier().equals(result.getObjectIdentifier()));

		broker.save(emp2);
		broker.save(result);
		broker.save(employee);
		result = (ExampleEmployee) query.findUnique();
		//find the second one
		testContext.assertTrue("Employee found, but not with correct primary key", emp2.getObjectIdentifier().equals(result.getObjectIdentifier()));
	}
	/**
	 *  A unit test for JUnit
	 *
	 * @exception  QueryException Description of Exception
	 */
	public void testDelete() throws QueryException
	{
		ExampleEmployee employee = new ExampleEmployee();
		employee.setTitle("myTitle");
		broker.save(employee);
		testContext.assertTrue("Employee not marked as saved!", employee.isRetrievedFromDatabase());
		testContext.assertTrue("PKey was not set! ", employee.getObjectIdentifier() != null);

		broker.delete(employee);
		testContext.assertTrue("Retrieved from database not cleared after delete! ", !employee.isRetrievedFromDatabase());

		ExampleEmployee search = new ExampleEmployee();
		SQLQuery query = new SQLQuery(search);
		search.setTitle("myTitle");
		Vector v = query.find();
		testContext.assertEquals("The single object was not removed.", 0, v.size());

		employee = new ExampleEmployee();
		employee.setTitle("myTitle");
		broker.save(employee);

		employee = new ExampleEmployee();
		employee.setTitle("title2");
		broker.save(employee);

		search = new ExampleEmployee();
		query = new SQLQuery(search);
		search.setTitle("myTitle");
		v = query.find();
		testContext.assertEquals("Failed to find the correct object.", 1, v.size());
		employee = (ExampleEmployee) v.firstElement();
		testContext.assertEquals("Incorrect object returned by query", "myTitle", employee.getTitle());
		broker.delete(employee);

		search = new ExampleEmployee();
		query = new SQLQuery(search);
		search.setTitle("myTitle");
		v = query.find();
		testContext.assertEquals("The myTitle object still exists, even though it was deleted.", 0, v.size());

		search = new ExampleEmployee();
		query = new SQLQuery(search);
		v = query.find();
		testContext.assertEquals("Remaining object not located!", 1, v.size());
		employee = (ExampleEmployee) v.firstElement();
		testContext.assertEquals("Remaining object has the wrong title", "title2", employee.getTitle());
	}
	/**
	 *  A unit test for JUnit
	 *
	 * @exception  QueryException Description of Exception
	 */
	public void testSimpleSaveList() throws QueryException
	{
		ArrayList objsToSave = new ArrayList();
		ExampleEmployee employee = new ExampleEmployee();
		employee.setTitle("myTitle");
		objsToSave.add(employee);
		ExampleEmployee emp2 = new ExampleEmployee();
		emp2.setTitle("myTitle2");
		objsToSave.add(emp2);

		broker.beginTransaction();
		broker.saveObjects(objsToSave);
		broker.commit();
		testContext.assertTrue("PKey on second save was not set! ", emp2.getObjectIdentifier() != null);
		testContext.assertTrue("Employees should have unique primary key fields. ", !employee.getObjectIdentifier().equals(emp2.getObjectIdentifier()));

		Object origKey = employee.getObjectIdentifier();
		broker.beginTransaction();
		broker.saveObjects(objsToSave);
		broker.commit();
		testContext.assertTrue("Updates should not change pkeys. ", origKey.equals(employee.getObjectIdentifier()));

		ExampleEmployee search = new ExampleEmployee();
		SQLQuery query = new SQLQuery(search);
		//query.registerCollectionAdapter(ArrayList.class, com.objectwave.persist.collectionAdapters.ArrayListCollectionAdapter.class);
		ArrayList v = (ArrayList) query.findCollection(ArrayList.class);
		testContext.assertEquals("Correct number of objects not found!", 2, v.size());
	}
	/**
	 *  A unit test for JUnit
	 *
	 * @exception  QueryException
	 */
	public void testResave() throws QueryException
	{
		ExampleEmployee employee = new ExampleEmployee();
		employee.setTitle("myTitle");
		broker.save(employee);

		ExamplePerson person = new ExamplePerson();
		person.setName("Dave Hoag");
		person.setEmployee(employee);
		broker.save(person);

		ExamplePerson person2 = new ExamplePerson();
		person2.setName("Jim Smith");
		broker.save(person2);

		person.setEmployee(null);
		broker.save(person);

		person2.setEmployee(employee);
		broker.save(person2);

		ExamplePerson persons = new ExamplePerson();
		SQLQuery query = new SQLQuery(persons);
		ArrayList list = (ArrayList) query.findCollection(ArrayList.class);
		testContext.assertEquals("Found incorrect number of objects", 2, list.size());
		person2 = (ExamplePerson) list.get(0);
		if(person2.getName().equals("Dave Hoag"))
		{
			person = person2;
			person2 = (ExamplePerson) list.get(1);
		}
		else
		{
			person = (ExamplePerson) list.get(1);
		}
		testContext.assertTrue("Employee was cleared, but it remains!", person.getEmployee() == null);
		testContext.assertTrue("Exmployee expected!", person2.getEmployee() != null);
	}
	/**
	 *  A unit test for JUnit
	 *
	 * @exception  QueryException Description of Exception
	 */
	public void testSimpleSave() throws QueryException
	{

		ExampleEmployee employee = new ExampleEmployee();
		employee.setTitle("myTitle");
		testContext.assertTrue("Employee started with a pkey? ", employee.getObjectIdentifier() == null);
		broker.save(employee);
		testContext.assertTrue("Employee not marked as saved!", employee.isRetrievedFromDatabase());
		testContext.assertTrue("PKey was not set! ", employee.getObjectIdentifier() != null);
		ExampleEmployee emp2 = new ExampleEmployee();
		emp2.setTitle("myTitle2");
		broker.save(emp2);
		testContext.assertTrue("PKey on second save was not set! ", emp2.getObjectIdentifier() != null);
		testContext.assertTrue("Employees should have unique primary key fields. ", !employee.getObjectIdentifier().equals(emp2.getObjectIdentifier()));

		Object origKey = employee.getObjectIdentifier();
		broker.save(employee);
		broker.save(employee);
		broker.save(employee);
		testContext.assertTrue("Updates should not change pkeys. ", origKey.equals(employee.getObjectIdentifier()));

		long start = System.currentTimeMillis();
		/*
		 *  Don't need to perf test.
		 *  for(int i = 0; i < 2000; ++i)
		 *  {
		 *  broker.save(employee);
		 *  }
		 *  System.out.println("Update MPS " + ( 1000 * 1000) / (System.currentTimeMillis() - start));
		 *  start = System.currentTimeMillis();
		 *  for(int i = 0; i < 1000; ++i)
		 *  {
		 *  employee = new ExampleEmployee();
		 *  employee.setTitle("myTitle");
		 *  broker.save(employee);
		 *  }
		 *  System.out.println("Insert MPS " + ( 1000 * 1000) / (System.currentTimeMillis() - start));
		 */
	}
	/**
	 *  A unit test for JUnit
	 *
	 * @exception  QueryException Description of Exception
	 */
	public void testCollectionProxy() throws QueryException
	{
		ExampleEmployee employee = new ExampleEmployee();
		employee.setTitle("boss");
		broker.save(employee);
		employee.setWorkers(new Vector());

		ExampleEmployee worker = new ExampleEmployee();
		worker.setTitle("worker");
		worker.setBoss(employee);
		broker.save(worker);
		employee.getWorkers().add(worker);

		worker = new ExampleEmployee();
		worker.setTitle("worker2");
		worker.setBoss(employee);
		broker.save(worker);
		employee.getWorkers().add(worker);

		worker = new ExampleEmployee();
		worker.setTitle("worker3");
		worker.setBoss(employee);
		broker.save(worker);
		employee.getWorkers().add(worker);

		ExampleEmployee search = new ExampleEmployee();
		SQLQuery query = new SQLQuery(search);
		search.setTitle("boss");
		ExampleEmployee resultBoss = (ExampleEmployee) query.findUnique();
		System.out.println("Getting the workers");
		Vector v = resultBoss.getWorkers();

		testContext.assertEquals("Three workers should be found!", 3, v.size());
		ExampleEmployee worker1 = (ExampleEmployee) v.get(0);
		testContext.assertEquals("Worker data incorrect", worker1.getTitle(), "worker");
		testContext.assertTrue("Back link not correct ", worker1.getBoss() == resultBoss);
	}
	public void testInitConfiguration()
	{
		if(broker instanceof RDBBroker)
		{
			RDBBroker rdbBroker = (RDBBroker)broker;
			BrokerPropertyDetail detail = rdbBroker.getBrokerPropertySource().getPropertyDetail();
			detail.setUsePreparedStatements(true);
			rdbBroker.initConfiguration();
			testContext.assertTrue( "Value changed when no system property!", detail.getUsePreparedStatements() );
		}
	}
}
