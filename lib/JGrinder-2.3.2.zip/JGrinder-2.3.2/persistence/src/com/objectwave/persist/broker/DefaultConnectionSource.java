/* Copyright (C) 2001 David Hoag
 * ObjectWave Corporation
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * For a full copy of the license see:
 * http://www.opensource.org/licenses/lgpl-license.html
 */
package com.objectwave.persist.broker;
import com.objectwave.logging.MessageLog;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.SQLWarning;
/**
 *  Create new instances for the provided jgrinderConnection if a connection
 *  does not already exist.
 *
 * @author  dhoag
 * @version  $Id: DefaultConnectionSource.java,v 2.1 2001/06/13 23:40:07 dave_hoag Exp $
 */
public class DefaultConnectionSource extends AbstractConnectionFactory implements SqlConnectionFactory
{

	/**
	 *  Constructor for the DefaultConnectionSource object
	 */
	public DefaultConnectionSource()
	{
	}
	/**
	 * @param  jgrinderConnection
	 * @return
	 * @exception  SQLException
	 */
	public Connection connect(final RDBConnection jgrinderConnection) throws SQLException
	{
		Connection connection = null;
		boolean verbose = jgrinderConnection.verbose;
		String userName = jgrinderConnection.userName;
		String password = jgrinderConnection.password;
		String connectUrl = jgrinderConnection.connectUrl;
		if(verbose)
		{
			MessageLog.info(this, "Establishing RDB connection to \"" + connectUrl + "\" : " + this.hashCode());
			MessageLog.info(this, "\tUsing username \"" + userName + "\"");
			MessageLog.info(this, "\tUsing password \"" + password + "\"");
		}
		long time = System.currentTimeMillis();
		try
		{
			connection = DriverManager.getConnection(connectUrl, userName, password);
		}
		catch(SQLException ex)
		{
			if(jgrinderConnection.tryAgain(ex.getErrorCode()))
			{
				connection = DriverManager.getConnection(connectUrl, userName, password);
			}
			else
			{
				throw ex;
			}
		}
		if(jgrinderConnection.metrics)
		{
			jgrinderConnection.pool.incrementSqlTime(System.currentTimeMillis() - time);
		}
		if(connection == null)
		{
			throw new SQLException("Failed to establish a connection ");
		}

		//Results in odd exceptions
		//connection.setTransactionIsolation(connection.TRANSACTION_SERIALIZABLE);

		// If we were unable to connect, an exception
		// would have been thrown.  So, if we get here,
		// we are successfully connected to the URL

		// Check for, and display and warnings generated
		// by the connect.
		if(verbose)
		{
			checkForWarning(connection.getWarnings());
		}

		// Get the DatabaseMetaData object and display
		// some information about the connection

		DatabaseMetaData databaseMetaData = connection.getMetaData();
		jgrinderConnection.supportsTransaction = databaseMetaData.supportsTransactions();
		logConnectionStatus(databaseMetaData);

		if(jgrinderConnection.supportsTransaction)
		{
			connection.setAutoCommit(false);
		}
		try
		{
			Class c = Class.forName("com.objectwave.event.StatusManager");
			com.objectwave.event.StatusManager.getDefaultManager().fireStatusEvent(this, "Connected to Database.");
		}
		catch(ClassNotFoundException e)
		{
		}
		jgrinderConnection.alterVendorConnection(connection);
		return connection;
	}
	/**
	 * @param  jgrinderConnection
	 * @return
	 * @exception  SQLException
	 */
	public Connection checkConnection(RDBConnection jgrinderConnection) throws SQLException
	{
		if(jgrinderConnection.connection == null)
		{
			jgrinderConnection.connection = connect(jgrinderConnection);
		}

		return jgrinderConnection.connection;
	}
	/**
	 * @param  jgrinderConnection
	 * @param  connection
	 */
	public void freeConnection(RDBConnection jgrinderConnection, Connection connection)
	{
		super.freeNormalConnection(jgrinderConnection, connection);
	}
}
