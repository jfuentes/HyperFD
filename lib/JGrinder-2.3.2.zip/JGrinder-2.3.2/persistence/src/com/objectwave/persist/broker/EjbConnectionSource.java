/*
 *  Copyright (C) 2001 David Hoag
 *  ObjectWave Corporation
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *  For a full copy of the license see:
 *  http://www.opensource.org/licenses/lgpl-license.html
 */
package com.objectwave.persist.broker;
import com.objectwave.logging.MessageLog;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.SQLException;
import java.sql.SQLWarning;
import javax.ejb.EJBException;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;
/**
 *  The connectUrl will be the DataSource JNDI name.
 *
 * @author  dhoag
 * @version  $Id: EjbConnectionSource.java,v 2.2 2001/10/04 19:42:17 dave_hoag Exp $
 */
public class EjbConnectionSource extends AbstractConnectionFactory implements SqlConnectionFactory
{
	/**
	 */
	public final static String DEFAULT_DATASOURCE = "java:/DefaultDS";
	/**
	 *  Constructor for the EjbConnectionSource object
	 */
	public EjbConnectionSource()
	{
	}

	/**
	 *  Lookup the DataSource from the JNDI location. From the DataSource, create a
	 *  new connection object.
	 *
	 * @param  jgrinderConnection
	 * @return  The EjbConnection value
	 * @exception  Exception
	 */
	public Connection getEjbConnection(final RDBConnection jgrinderConnection) throws Exception
	{
		jgrinderConnection.needsExplicitBegin = false;
		String connectUrl = jgrinderConnection.connectUrl;
		//Disable the connection.commit call
		jgrinderConnection.manageTransaction = false;
		String lookupName = connectUrl;
		if(connectUrl == null || connectUrl.trim().equals(""))
		{
			lookupName = DEFAULT_DATASOURCE;
		}
		DataSource dataSource = null;
		if(dataSource == null)
		{
			try
			{
				Context jndi = new InitialContext();
				Object obj = jndi.lookup(lookupName);
				dataSource = (DataSource) obj;
			}
			catch(NamingException e)
			{
				throw new EJBException("EJB base class could not get JNDI context: " + e);
			}
		}

		Connection con = dataSource.getConnection();
		return con;
	}
	/**
	 * @param  jgrinderConnection
	 * @return
	 * @exception  SQLException
	 */
	public Connection checkConnection(final RDBConnection jgrinderConnection) throws SQLException
	{
		try
		{
			Connection connection = null;
			if(jgrinderConnection.getConnection() == null)
			{
				connection = getEjbConnection(jgrinderConnection);
				DatabaseMetaData databaseMetaData = connection.getMetaData();
				jgrinderConnection.supportsTransaction = true;
				logConnectionStatus(databaseMetaData);
				jgrinderConnection.connection = connection;
			}
			else
			{
				connection = jgrinderConnection.getConnection();
			}

			return connection;
		}
		catch(SQLException ex)
		{
			throw ex;
		}
		catch(Exception ex)
		{
			MessageLog.debug(this, "Failed to get Ejb connection", ex);
			throw new SQLException("Failed to get Ejb connection: " + ex);
		}
	}
	/**
	 * @param  jgrinderConnection
	 * @param  connection
	 */
	public void freeConnection(final RDBConnection jgrinderConnection, final Connection connection)
	{
		try
		{
			//Statement objects are closed when the 'connection' is closed
			jgrinderConnection.lastResultSet = null;
			connection.close();
		}
		catch(SQLException ex)
		{
			MessageLog.warn(this, "Failed to close java.sql.Connection", ex);
		}
		jgrinderConnection.connection = null;
		freeNormalConnection(jgrinderConnection, connection);
	}
}
