/*
 *  Copyright (C) 2001 David Hoag
 *  ObjectWave Corporation
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *  For a full copy of the license see:
 *  http://www.opensource.org/licenses/lgpl-license.html
 */
package com.objectwave.persist.broker;
import com.objectwave.logging.MessageLog;
import com.objectwave.persist.*;
import com.objectwave.persist.collectionAdapters.ArrayListCollectionAdapter;
import com.objectwave.persist.examples.*;
import com.objectwave.persist.file.*;
import com.objectwave.persist.properties.FilePropertySource;
import java.io.*;
import java.util.*;
/**
 *  A broker that will write persistent objects out to files. Requires that the
 *  persistent objects use the RDBPersistence as their interface.
 *
 * @author  Dave Hoag
 * @version  $Id: FileBroker.java,v 2.6 2001/11/02 16:07:56 dave_hoag Exp $
 * @todo  - Lots of room for optimization, this is just a first cut.
 */
public class FileBroker extends AbstractBroker
{
	static ObjectBuilder builder;
	static SaveObjectsStrategy saveObjectsStrategy = new SaveObjectsStrategy();
	/**
	 *  Description of the Field
	 */
	protected HashMap dbFiles;
	boolean verbose;
	FilePropertySource filePropertySource;
	String targetDirectory;
	/**
	 *  Initialize the local variables.
	 */
	public FileBroker()
	{
		initialize();
	}
	/**
	 *  A utility method that simplifies code. Users of this broker are expected to
	 *  use an RDBPersistence implementation.
	 *
	 * @param  object Description of Parameter
	 * @return  The RDBAdapter value
	 */
	public final static RDBPersistence getRDBAdapter(final Persistence object)
	{
		if(object.usesAdapter())
		{
			return (RDBPersistence) object.getAdapter();
		}
		else
		{
			return (RDBPersistence) object;
		}
	}
	/**
	 * @param  file Description of Parameter
	 * @param  p Description of Parameter
	 * @return  Description of the Returned Value
	 * @exception  QueryException Description of Exception
	 * @exception  IOException Description of Exception
	 * @exception  InstantiationException Description of Exception
	 * @exception  IllegalAccessException Description of Exception
	 */
	private final static Persistence findByPrimaryKey(DbFile file, final Persistence p) throws QueryException, IOException, InstantiationException, IllegalAccessException
	{
		Iterator iterator = file.iterator();
		while(iterator.hasNext())
		{
			RecordHeader header = (RecordHeader) iterator.next();
			if(header.getPrimaryKey().equals(DbFile.buildPrimaryKeyString(p).toString()))
			{
				Persistence obj = builder.buildObject(p, header.getData(file.getSourceFile()), header.getPrimaryKey());
				obj.setRetrievedFromDatabase(true);
				return obj;
			}
		}
		return null;
	}

	/**
	 * @param  fileName The name of the file to create.
	 * @return  The File value
	 * @exception  IOException Description of Exception
	 */
	protected synchronized DbFile getFile(final String fileName) throws IOException
	{
		DbFile result = (DbFile) dbFiles.get(fileName);
		if(result == null)
		{
			result = new DbFile(fileName);
			dbFiles.put(fileName, result);
		}
		while(result.isInUse())
		{
			try
			{
				wait();
			}
			catch(InterruptedException ex)
			{
			}
		}
		result.setInUse(true);
		//For now, do the locking at the same time we get the reference
		result.lock();
		return result;
	}
	/**
	 * @param  fileName A file name independent of extensions or pathing
	 * @return  The TargetFileName value
	 */
	protected String getTargetFileName(final String fileName)
	{
		StringBuffer result = new StringBuffer();
		if(targetDirectory != null)
		{
			result.append(targetDirectory);
			boolean hasSlash = targetDirectory.endsWith("/") || targetDirectory.endsWith("\\");
			if(!hasSlash)
			{
				result.append(File.separatorChar);
			}
		}
		result.append(fileName);
		result.append(".dbf");
		return result.toString();
	}
	/**
	 *  Maps the getFile exceptions to a QueryException
	 *
	 * @param  fileName Description of Parameter
	 * @return  The Connection value
	 * @exception  QueryException Description of Exception
	 */
	private final DbFile getConnection(final String fileName) throws QueryException
	{
		try
		{
			return getFile(fileName);
		}
		catch(IOException ex)
		{
			ex.printStackTrace();
			throw new QueryException("Exception occured obtaining the DbFile lock: " + ex, ex);
		}
	}
	/**
	 *  Establish the property settings for this object.
	 */
	public void initialize()
	{
		filePropertySource = new FilePropertySource();
		verbose = filePropertySource.getVerbose();
		dbFiles = new HashMap();
		targetDirectory = filePropertySource.getDataDirectory();
	}
	/**
	 *  Do transactions make sense?
	 *
	 * @exception  QueryException Description of Exception
	 */
	public void beginTransaction() throws QueryException
	{
	}
	/**
	 *  Description of the Method
	 *
	 * @exception  QueryException Description of Exception
	 */
	public void commit() throws QueryException
	{
	}
	/**
	 *  Remove the provided object from the persistence mechanism.
	 *
	 * @param  obj A class to be deleted.
	 * @exception  QueryException Description of Exception
	 */
	public void delete(final Persistence obj) throws QueryException
	{
		if((!obj.isRetrievedFromDatabase()) || obj.isTransient())
		{
			return;
		}
		RDBPersistence pObj = getRDBAdapter(obj);
		String theFileName = getTargetFileName(pObj.getTableName(null));

		DbFile file = getConnection(theFileName);
		try
		{
			file.delete(obj);
			obj.setRetrievedFromDatabase(false);
		}
		finally
		{
			releaseConnection(file);
		}
	}
	/**
	 *  Shutdown gracefully.
	 */
	public void close()
	{
		try
		{
			Set fileNames = dbFiles.keySet();
			Iterator files = fileNames.iterator();
			while(files.hasNext())
			{
				String fileName = (String) files.next();
				DbFile connection = getFile(fileName);
				connection.close();
			}
		}
		catch(IOException ex)
		{
		}
	}
	/**
	 *  The return type of object allows the support of multiple collection types.
	 *
	 * @param  query Description of Parameter
	 * @return  Description of the Returned Value
	 * @exception  QueryException Description of Exception
	 */
	public Object find(final SQLQuery query) throws QueryException
	{
		Persistence pers = query.getSubject();
		RDBPersistence pObj = getRDBAdapter(pers);
		String theFileName = getTargetFileName(pObj.getTableName(null));

		DbFile dbConnection = getConnection(theFileName);
		try
		{
			Object list = actualFind(dbConnection, query, pers);
			return list;
		}
		catch(InstantiationException ex)
		{
			throw new QueryException("Failed to instantiate object. ", ex);
		}
		catch(IllegalAccessException ex)
		{
			throw new QueryException("Failed to set object values. ", ex);
		}
		catch(IOException ex)
		{
			throw new QueryException("IOException when finding object(s). ", ex);
		}
		finally
		{
			releaseConnection(dbConnection);
		}
	}
	/**
	 *  Description of the Method
	 *
	 * @param  q Description of Parameter
	 * @exception  QueryException Description of Exception
	 */
	public void deleteAll(final SQLQuery q) throws QueryException
	{
		ArrayList list = (ArrayList) q.findCollection(ArrayList.class);
		for(int i = 0; i < list.size(); i++)
		{
			Persistence pers = (Persistence) list.get(i);
			delete(pers);
		}
	}
	/**
	 * @param  q Description of Parameter
	 * @param  at Description of Parameter
	 * @return  Description of the Returned Value
	 * @exception  QueryException Description of Exception
	 */
	public Vector findAttributes(final SQLQuery q, final String[] at) throws QueryException
	{
		return null;
	}
	/**
	 * @param  query Description of Parameter
	 * @return  Description of the Returned Value
	 * @exception  QueryException Description of Exception
	 */
	public Persistence findUnique(final SQLQuery query) throws QueryException
	{
		Persistence pers = query.getSubject();
		RDBPersistence pObj = getRDBAdapter(pers);
		String theFileName = getTargetFileName(pObj.getTableName(null));
		if(verbose)
		{
			System.out.println("Finding unique from " + theFileName);
		}
		DbFile dbConnection = getConnection(theFileName);
		try
		{
			Persistence result = null;
			if(pers.getPrimaryKeyField() != null && (!pers.getPrimaryKeyField().toString().equals("0")) && (!query.isLike()))
			{
				if(verbose)
				{
					System.out.println("Doing a find by primary key");
				}
				result = findByPrimaryKey(dbConnection, pers);
				if(result != null)
				{
					FileQuery fq = new FileQuery(query, dbConnection, builder);
					if(!fq.checkAttributeValues(query.isLike(), getRDBAdapter(result), getRDBAdapter(result)))
					{
						result = null;
						//The other attributes did not check out
					}
				}
			}
			else
			{
				query.setCollectionAdapter(new ArrayListCollectionAdapter());
				ArrayList listResult = (ArrayList) actualFind(dbConnection, query, pers);
				if(!listResult.isEmpty())
				{
					if(listResult.size() > 1)
					{
						throw new QueryException("Find Unique found more than 1 object!", null);
					}
					result = (Persistence) listResult.get(0);
				}
			}
			return result;
		}
		catch(InstantiationException ex)
		{
			throw new QueryException("Failed to instantiate object. ", ex);
		}
		catch(IllegalAccessException ex)
		{
			throw new QueryException("Failed to set object values. ", ex);
		}
		catch(IOException ex)
		{
			throw new QueryException("IOException when finding object(s). ", ex);
		}
		finally
		{
			releaseConnection(dbConnection);
		}
	}
	/**
	 * @exception  QueryException Description of Exception
	 */
	public void rollback() throws QueryException
	{
	}
	/**
	 *  Write the change to the persistence store.
	 *
	 * @param  obj Description of Parameter
	 * @exception  QueryException Description of Exception
	 */
	public void save(final Persistence obj) throws QueryException
	{
		long time = System.currentTimeMillis();
		if(!obj.isTransient())
		{
			RDBPersistence pObj = getRDBAdapter(obj);
			String theFileName = getTargetFileName(pObj.getTableName(null));
			byte[] data = builder.getSaveData(pObj);

			DbFile file = getConnection(theFileName);
			try
			{

				if(!obj.isRetrievedFromDatabase() && pObj.getBrokerGeneratedPrimaryKeys())
				{
					AttributeTypeColumn column = pObj.getPrimaryAttributeDescription();
					Object value = ObjectBuilder.defaultFormatter.convertType(column, String.valueOf(file.getNextIdx()));
					pObj.setPrimaryKeyField(value);
				}

				file.save(obj, data);
			}
			catch(QueryException qe)
			{
				throw qe;
			}
			catch(RuntimeException te)
			{
				MessageLog.debug(this, "Runtime " + te + " when saving object: " + obj);
				throw te;
			}
			finally
			{
				releaseConnection(file);
			}
			pObj.setRetrievedFromDatabase(true);
		}
	}
	/**
	 *  Save all of the objects provided and be sure to take into account
	 *  bidirectional relationships.
	 *
	 * @param  saveList Description of Parameter
	 * @exception  QueryException Description of Exception
	 */
	public void saveObjects(final ArrayList saveList) throws QueryException
	{
		saveObjectsStrategy.saveObjects(saveList);
	}
	/**
	 *  Make the 'dbConnection' available to other processes.
	 *
	 * @param  dbConnection Description of Parameter
	 * @exception  IOException Description of Exception
	 */
	protected synchronized void release(final DbFile dbConnection) throws IOException
	{
		dbConnection.setInUse(false);
		//For now, do the locking at the same time we get the reference
		dbConnection.releaseLock();
		notify();
	}
	/**
	 * @param  file Description of Parameter
	 * @param  query Description of Parameter
	 * @param  p Description of Parameter
	 * @return  Description of the Returned Value
	 * @exception  IOException Description of Exception
	 * @exception  InstantiationException Description of Exception
	 * @exception  IllegalAccessException Description of Exception
	 */
	protected Object actualFind(final DbFile file, final SQLQuery query, final Persistence p) throws IOException, InstantiationException, IllegalAccessException
	{
		//force it for now
//		query.setCollectionAdapter( new ArrayListCollectionAdapter() );

		FileQuery fQuery = new FileQuery(query, file, builder);
		Object result = fQuery.find();
		return result;
	}
	/**
	 *  Catch and throw any IOExceptions
	 *
	 * @param  file Description of Parameter
	 */
	private final void releaseConnection(final DbFile file)
	{
		try
		{
			release(file);
		}
		catch(IOException ex)
		{
			System.err.println(" Exception releasing the DbFile lock. " + ex);
			throw new Error("Exception releasing the DbFile lock. " + ex + "\nSystem in a VERY bad state. Manually release the lock using the com.objectwave.utility.FileLock utiliy.");
		}
	}
	/**
	 *  Unit tests.
	 *
	 * @author  dhoag
	 * @version  $Id: FileBroker.java,v 2.6 2001/11/02 16:07:56 dave_hoag Exp $
	 */
	public static class Test extends BasicTestBroker
	{
		/**
		 *  The main program for the Test class
		 *
		 * @param  args The command line arguments
		 */
		public static void main(String[] args)
		{
			com.objectwave.test.TestRunner.run(new Test(), args);
		}
		/**
		 *  The JUnit setup method
		 *
		 * @param  str The new Up value
		 * @param  context The new Up value
		 * @exception  Exception
		 */
		public void setUp(String str, com.objectwave.test.TestContext context) throws Exception
		{
			broker = new FileBroker();
			super.setUp(str, context);
		}

		/**
		 *The teardown method for JUnit
		 *
		 * @param  context
		 */
		public void tearDown(com.objectwave.test.TestContext context)
		{
			super.tearDown(context);
			String fName = defaultBroker.getTargetFileName("employee");
			removeFile(fName);
			fName = defaultBroker.getTargetFileName("person");
			removeFile(fName);
			fName = defaultBroker.getTargetFileName("company");
			removeFile(fName);
		}
		/**
		 *  A unit test for JUnit
		 */
		public void testTargetFileName()
		{
			String source = "example";
			FileBroker fb = new FileBroker();
			fb.targetDirectory = null;
			String result = fb.getTargetFileName(source);
			testContext.assertEquals("Failed to generate default file name", "example.dbf", result);
			fb.targetDirectory = "one";
			result = fb.getTargetFileName(source);
			testContext.assertEquals("Failed to generate file name", "one" + File.separatorChar + "example.dbf", result);
			fb.targetDirectory = "two/";
			result = fb.getTargetFileName(source);
			testContext.assertEquals("Failed to generate file name", "two/example.dbf", result);
			fb.targetDirectory = "two\\";
			result = fb.getTargetFileName(source);
			testContext.assertEquals("Failed to generate file name", "two\\example.dbf", result);
		}
	}

	static
	{
		try
		{
			builder = ObjectBuilder.getInstance();
		}
		catch(Throwable t)
		{
			System.out.println("Exception loading FileBroker class. " + t);
		}
	}
}
