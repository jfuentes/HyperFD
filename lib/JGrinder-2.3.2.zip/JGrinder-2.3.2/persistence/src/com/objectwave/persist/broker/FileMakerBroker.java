package com.objectwave.persist.broker;

import com.objectwave.persist.*;
import com.objectwave.persist.mapping.*;
import com.objectwave.persist.sqlConstruction.*;
import java.sql.*;
/**
 *  This will be the place for FileMaker specific implementation issues. Special
 *  Considerations
 *  <li> The type of Date will be like {5/31/2001} </li>
 *  <li> The type of Time will be like {17:30} </li>
 *
 * @author  Zhou Cai
 * @version  $Id: FileMakerBroker.java,v 2.2 2002/02/13 21:36:18 dave_hoag Exp $
 */

public class FileMakerBroker extends RDBBroker
{

	/**
	 *  Most systems will have only one database broker. This method is used to
	 *  support systems of that type.
	 *
	 * @return  The DefaultBroker value
	 */
	public static RDBBroker getDefaultBroker()
	{
		if(broker == null)
		{
			broker = new FileMakerBroker();
			broker.initialize();
		}
		return broker;
	}

	/**
	 *  Nevel use connection pool
	 *
	 * @return  RDBConnection A connection to the database.
	 */
	public RDBConnection getConnection()
	{
		String connectUrl = getBrokerPropertySource().getConnectUrl();
		String userPassword = getBrokerPropertySource().getPersistPassword();
		String userName = getBrokerPropertySource().getPersistUser();
		RDBConnection con = (RDBConnection) threadLocal.get();
		if(con == null)
		{
			con = newRDBConnection(connectionPool, connectUrl, userName, userPassword);
			if(pool != null)
			{
				con.setObjectPoolBroker(new ObjectPoolBroker(pool, true));
			}
			con.setBrokerProperty(props);
			connectionPool.addConnection(con);
			threadLocal.set(con);
		}
		return con;
	}
	/**
	 */
	public void initialize()
	{
		super.initialize();
		//A Special ObjectFormatter is needed to customize the format of data for Oracle.
		statementFactory.setObjectFormatter(new FileMakerObjectFormatter());
	}
	/**
	 *  Implemented as an instance method to support method overriding.
	 *
	 * @return  com.objectwave.persist.RDBBroker or a subclass.
	 */
	public RDBBroker defaultBroker()
	{
		return FileMakerBroker.getDefaultBroker();
	}

	/**
	 *  Determine the primary key for the provided persistent object. This assumes
	 *  the primary key has not yet been determined and that the pObj happens to
	 *  match the highest value the table.
	 *
	 * @param  pObj
	 * @exception  SQLException
	 * @exception  QueryException
	 */
	protected void determinePrimaryKey(final RDBPersistence pObj) throws SQLException, QueryException
	{
		/*
		 *  I don't want to use this method because it is too slow to get the next primary
		 *  value from FileMaker Pro Database.
		 *  I define the databaseIdentifer as an auto number in the FileMakePro
		 */
		final Object value = null;
		pObj.setPrimaryKeyField(value);
	}

	/**
	 *  Same as the last method. I don't want to implement it.
	 *
	 * @param  pObj
	 * @return  Next available primary key field.
	 * @exception  SQLException
	 * @exception  QueryException
	 */
	protected Object nextPrimaryKey(RDBPersistence pObj) throws SQLException, QueryException
	{
		return null;
	}

}
