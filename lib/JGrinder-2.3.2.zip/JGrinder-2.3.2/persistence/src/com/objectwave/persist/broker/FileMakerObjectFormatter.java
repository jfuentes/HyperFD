package com.objectwave.persist.broker;
import com.objectwave.logging.MessageLog;
import com.objectwave.utility.ScalarType;
import java.io.IOException;
import java.sql.Time;
import java.text.SimpleDateFormat;

import java.util.Date;

/**
 *  This class converts data from Java type to FileMakerPro type.
 *
 * @author  Zhou Cai
 * @version  $Id; $
 */

public class FileMakerObjectFormatter extends com.objectwave.persist.ObjectFormatter
{

	/**
	 *  Constructor for the FileMakerObjectFormatter object
	 */
	public FileMakerObjectFormatter()
	{
	}

	/**
	 *  format the Date
	 *
	 * @param  value
	 * @param  buf
	 */
	protected void formatDate(final Date value, final StringBuffer buf)
	{
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		String strDate = dateFormat.format(value);
		MessageLog.debug(this, "Date=" + strDate);
		buf.append('{').append(strDate).append('}');
	}

	/**
	 *  format the Time
	 *
	 * @param  value
	 * @param  buf
	 */
	protected void formatTime(final Time value, final StringBuffer buf)
	{
		SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm");
		String strTime = dateFormat.format(value);
		MessageLog.debug(this, "Time=" + strTime);
		buf.append('{').append(strTime).append('}');
	}

	/**
	 *  Override the super's method
	 *
	 * @param  value
	 * @param  buf
	 * @exception  IOException
	 */
	public void formatValue(final Object value, final StringBuffer buf) throws IOException
	{
		if(value == null)
		{
			super.formatValue(value, buf);
		}
		else if(value instanceof Time)
		{
			formatTime((Time) value, buf);
		}
		else if(value instanceof Date)
		{
			formatDate((Date) value, buf);
		}
		else
		{
			// SPS - DEBUG if statement, REMOVE ME
			if(value instanceof java.io.Serializable &&
					!(
					(value instanceof String) ||
					(value instanceof Number) ||
					(value instanceof Boolean)
					)
					)
			{
				System.out.println("DEBUG: maybe serializing class " + value.getClass() + "( " + value + ")");
			}

			super.formatValue(value, buf);
		}
	}
}
