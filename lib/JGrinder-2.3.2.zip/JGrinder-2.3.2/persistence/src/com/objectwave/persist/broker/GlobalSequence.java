package com.objectwave.persist.broker;
import com.objectwave.persist.*;

import com.objectwave.persist.PrimaryKeyStrategy;
import com.objectwave.persist.sqlConstruction.SQLSelect;
import java.sql.SQLException;
/**
 *  Use a sequence called GLOBAL_UID_SEQ to generate primary key values.
 *
 * @author  dhoag
 * @version  $Id: GlobalSequence.java,v 2.1 2002/03/09 15:23:03 dave_hoag Exp $
 */
public class GlobalSequence implements PrimaryKeyStrategy
{
	//The sequence number from the database * 100
	protected int pkeyPool;
	//Start at -1 to be initialized
	protected int currentPkey = -1;
	String sequenceTableName = "DUAL";
	String sequenceColumnName = "GLOBAL_UID_SEQ.NEXTVAL";
	/**
	 *  Constructor for the GlobalSequence object
	 */
	public GlobalSequence()
	{
	}
	/**
	 * When using Oracle, the default of DUAL works just fine - this may be
	 * true with other databases, but I have no idea.
	 * @param  aValue The new SequenceTableName value
	 */
	public void setSequenceTableName(String aValue)
	{
		sequenceTableName = aValue;
	}
	/**
	 * When using oracle, the default sequence will be just fine, but you
	 * may have reasons of your own to change it.
	 * @param  aValue The new SequenceColumnName value
	 */
	public void setSequenceColumnName(String aValue)
	{
		sequenceColumnName = aValue;
	}
	/**
	 * When using Oracle, the default of DUAL works just fine - this may be
	 * true with other databases, but I have no idea.
	 * @return  The SequenceTableName value
	 */
	public String getSequenceTableName()
	{
		return sequenceTableName;
	}
	/**
	 * @return  The SequenceColumnName value
	 */
	public String getSequenceColumnName()
	{
		return sequenceColumnName;
	}
	/**
	 * @param  broker
	 * @param  pObj
	 * @return
	 * @exception  SQLException
	 * @exception  QueryException
	 */
	public Object nextPrimaryKey(final RDBBroker broker, final RDBPersistence pObj) throws SQLException, QueryException
	{
		if(pkeyPool < 0)
		{
			/*
			 * Arbitrarily selected my own global sequence
			 */
			SQLSelect sql = new SQLSelect(getSequenceTableName());
			sql.addColumnList(getSequenceColumnName());
			pkeyPool = broker.getConnection().nextPrimaryKey(sql);
		}
		int pkey = pkeyPool * 100 + currentPkey++;
		if(currentPkey == 100)
		{
			pkeyPool = -1;
			//Ivalidate the pool value.
			currentPkey = 0;
			/*
			 * Arbitrarily selected my own global sequence
			 */
			SQLSelect sql = new SQLSelect(getSequenceTableName());
			sql.addColumnList(getSequenceColumnName());
			//set pkeyPool to next element in pkey pool.
			pkeyPool = broker.getConnection().nextPrimaryKey(sql);
		}
		return new Integer(pkey);
	}
}
