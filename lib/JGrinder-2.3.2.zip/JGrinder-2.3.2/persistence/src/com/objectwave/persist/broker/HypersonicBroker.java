package com.objectwave.persist.broker;
import com.objectwave.persist.*;
import com.objectwave.persist.examples.*;
import com.objectwave.persist.sqlConstruction.*;
import java.sql.*;
/**
 *  HypersonicBroker - works with Hypersonic database <a
 *  href="http://hsql.oron.ch/">http://hsql.oron.ch/ <a><br>
 *  The following two SQL statements must be run to generate primary keys. <p>
 *
 *  CREATE TABLE sequence(nextval INTEGER PRIMARY KEY) <br>
 *  INSERT INTO sequence(nextval) VALUES (1000)
 *
 * @author  Chi Son
 * @version  $Id: HypersonicBroker.java,v 2.4 2002/03/23 13:42:10 dave_hoag Exp $
 */
public class HypersonicBroker extends RDBBroker
{
	final static int poolSize = 100;
	int[] pkeyPool = null;
	int currentPkey = 0;
	/**
	 *  Most systems will have only one database broker. This method is used to
	 *  support systems of that type.
	 *
	 * @return  The DefaultBroker value
	 */
	public static RDBBroker getDefaultBroker()
	{
		if(broker == null)
		{
			broker = new HypersonicBroker();
			broker.initialize();
		}
		return broker;
	}

	/**
	 *  Get the fully qualified class name of the preferred database driver.
	 *
	 * @return  java.lang.String
	 * @author  Chi Son
	 */
	protected String getDefaultDriverName()
	{
		return "org.hsqldb.jdbcDriver";
	}
	/**
	 *  Implemented as an instance method to support method overriding.
	 *
	 * @return  com.objectwave.persist.RDBBroker or a subclass.
	 * @author  Dave Hoag
	 */
	public RDBBroker defaultBroker()
	{
		return HypersonicBroker.getDefaultBroker();
	}
	/**
	 * @param  pObj
	 * @return  Next available primary key field.
	 * @exception  SQLException Description of Exception
	 * @exception  QueryException Description of Exception
	 * @author  Chi Son
	 */
	protected Object nextPrimaryKey(final RDBPersistence pObj) throws SQLException, QueryException
	{
		if(pkeyPool == null || currentPkey == poolSize)
		{
			pkeyPool = nextPrimaryKeys(poolSize);
			currentPkey = 0;
		}
		return new Integer(pkeyPool[currentPkey++]);
	}
	/**
	 *  Gets a bunch of primary keys and updates the primary key table at set
	 *  intervals
	 *
	 * @param  count Description of Parameter
	 * @return  Next set of primary keys as an array of int
	 * @exception  SQLException Description of Exception
	 * @exception  QueryException Description of Exception
	 * @author  Chi Son
	 */
	protected int[] nextPrimaryKeys(int count) throws SQLException, QueryException
	{
		int[] list = new int[count];
		SQLSelect sql = new SQLSelect("SEQUENCE");
		sql.addColumnList("NEXTVAL");

		int resultA = getConnection().nextPrimaryKey(sql);

		SQLUpdate sqlUpdate = new SQLUpdate("SEQUENCE");
		sqlUpdate.addColumnValue("NEXTVAL", new Integer(resultA + count));
		getConnection().updateExecSql(sqlUpdate);

		for(int i = 0; i < count; i++)
		{
			list[i] = resultA + i;
		}
		return list;
	}
	/**
	 * @param  ex Description of Parameter
	 * @param  additionalInfo Description of Parameter
	 * @return  Description of the Returned Value
	 */
	protected QueryException convertException(SQLException ex, String additionalInfo)
	{
		final QueryException result = super.convertException(ex, additionalInfo);
		//Attempt to resolve various dying connection problems
		switch (ex.getErrorCode())
		{
			case 17002:
			// Io exception: Broken Pipe
			case 17410:
			{
				//'No more data to read from socket' exception

				result.setRetryPossible(true);
			}
		}
		return result;
	}

	/**
	 * @author  cson
	 * @version  $Id: HypersonicBroker.java,v 2.4 2002/03/23 13:42:10 dave_hoag Exp $
	 */
	public static class Test extends BasicTestBroker
	{

		private final static String CONNECT_URL = "jdbc:hsqldb:.";
		private final static String USERNAME = "sa";
		private final static String PASSWORD = "";

		private final static String SQL_SEQUENCE = "CREATE TABLE sequence( nextval int PRIMARY KEY)";
		private final static String SQL_SEQUENCE_INIT = "INSERT INTO sequence(nextval) VALUES(1)";
		private final static String SQL_SEQUENCE_DROP = "DROP TABLE sequence";

		private final static String SQL_CREATE_PERSON =
				"CREATE TABLE person(\n" +
				" databaseIdentifier int NOT NULL,\n" +
				" name VARCHAR(40) NULL,\n" +
				" employeeIdentifier int,\n" +
				" PRIMARY KEY ( databaseIdentifier ) \n" +
				")";
		private final static String SQL_DROP_PERSON = "DROP TABLE person";

		private final static String SQL_CREATE_EMPLOYEE =
				"CREATE TABLE employee(\n" +
				" databaseIdentifier int NOT NULL,\n" +
				" emailAddress VARCHAR(40) NULL,\n" +
				" title VARCHAR(40) NULL,\n" +
				" bossIdentifier int,\n" +
				" companyIdentifier int,\n" +
				" PRIMARY KEY ( databaseIdentifier ) \n" +
				")";
		private final static String SQL_DROP_EMPLOYEE = "DROP TABLE EMPLOYEE";

		private final static String SQL_CREATE_COMPANY =
				"CREATE TABLE company(\n" +
				" databaseIdentifier int NOT NULL,\n" +
				" ceoIdentifier int,\n" +
				" PRIMARY KEY ( databaseIdentifier ) \n" +
				")";
		private final static String SQL_DROP_COMPANY = "DROP TABLE company";
		/**
		 *The main program for the RDBTest class
		 *
		 * @param  args The command line arguments
		 */
		public static void main(String[] args)
		{
			com.objectwave.test.TestRunner.run(new Test(), args);
		}

		/**
		 *The JUnit setup method
		 *
		 * @param  str The new Up value
		 * @param  context The new Up value
		 * @exception  Exception
		 */
		public void setUp(String str, com.objectwave.test.TestContext context) throws Exception
		{
			System.setProperty("ow.persistVerbose", "true");
			System.setProperty("ow.persistConnectionVerbose", "true");
			System.setProperty("ow.persistUser", USERNAME);
			System.setProperty("ow.persistPassword", PASSWORD);
			System.setProperty("ow.persistDriver", "org.hsqldb.jdbcDriver");
			System.setProperty("ow.databaseImpl", "com.objectwave.persist.broker.HypersonicBroker");
			System.setProperty("ow.connectUrl", CONNECT_URL);
			System.setProperty("ow.useConnectionPool", "true");
			BrokerFactory.useDatabase();
			HypersonicBroker myBroker = new com.objectwave.persist.broker.HypersonicBroker();
			myBroker.initialize();

			BrokerFactory.setDefaultBroker(myBroker);
			SQLQuery.setDefaultBroker(myBroker);
			buildDatabase(myBroker);
			super.broker = myBroker;
			super.setUp(str, context);
		}

		/**
		 *The teardown method for JUnit
		 *
		 * @param  context
		 */
		public void tearDown(com.objectwave.test.TestContext context)
		{
			try
			{
				dropDatabase((HypersonicBroker) broker);
			}
			catch(Exception ex)
			{
				System.out.println("Failed to tear down test. Oh well");
				ex.printStackTrace();
			}
		}
		/**
		 * @param  broker
		 * @exception  Exception
		 */
		protected void dropDatabase(HypersonicBroker broker) throws Exception
		{
			broker.getConnection().execSql(SQL_SEQUENCE_DROP);
			broker.getConnection().execSql(SQL_DROP_PERSON);
			broker.getConnection().execSql(SQL_DROP_EMPLOYEE);
			broker.getConnection().execSql(SQL_DROP_COMPANY);
		}
		/**
		 * @param  broker
		 * @exception  Exception
		 */
		protected void buildDatabase(HypersonicBroker broker) throws Exception
		{
			broker.getConnection().execSql(SQL_SEQUENCE);
			broker.getConnection().execSql(SQL_SEQUENCE_INIT);
			broker.getConnection().execSql(SQL_CREATE_PERSON);
			broker.getConnection().execSql(SQL_CREATE_EMPLOYEE);
			broker.getConnection().execSql(SQL_CREATE_COMPANY);
		}
		/**
		 *A unit test for JUnit
		 *
		 * @exception  QueryException
		 */
		public void testCollectionProxy() throws QueryException
		{
			try
			{
				super.testCollectionProxy();
			}
			catch(Throwable t)
			{

				ExampleEmployee search = new ExampleEmployee();
				SQLQuery query = new SQLQuery(search);
				search.setTitle("boss");
				ExampleEmployee resultBoss = (ExampleEmployee) query.findUnique();
				search = new ExampleEmployee();
				query = new SQLQuery(search);
				search.setBoss(resultBoss);
				System.out.println("***********");
				java.util.Vector v = query.find();
				testContext.assertTrue("Fail", false);
			}
		}
	}
}
