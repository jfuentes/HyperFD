package com.objectwave.persist.broker;
import java.util.*;
import com.objectwave.persist.*;
/**
 * This class will not do anything. This allows an application to be built including hooks for
 * persistence, but with virtually no overhead. When necessary, switch to an appropriate broker.
 *
 * @version 1.0
 */
public class NullBroker extends AbstractBroker
{
    public Persistence findUnique(SQLQuery query)
    {
        return null;
    }
    public Object find(SQLQuery query)
    {
        return new Vector();
    }
    public Vector findAttributes(SQLQuery query, String [] args)
    {
        return null;
    }
    public void deleteAll(SQLQuery query){};
    public void save(Persistence pers){};
    public void delete(Persistence pers){};
    public void rollback(){};
    public void commit(){};
    public void saveObjects(ArrayList list){};
    public void beginTransaction(){};
}
