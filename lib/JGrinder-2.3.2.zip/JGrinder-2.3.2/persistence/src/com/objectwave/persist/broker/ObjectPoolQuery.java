package com.objectwave.persist.broker;
import com.objectwave.persist.Persistence;
import com.objectwave.persist.SQLQuery;
import java.util.Iterator;
/**
 *  Used to search an object pool. Works exactly like a relational database
 *  would.
 *
 * @author  Dave Hoag
 * @version  $Id: ObjectPoolQuery.java,v 2.0 2001/06/11 16:00:03 dave_hoag Exp $
 */
public class ObjectPoolQuery extends ObjectQuerySupport
{
	ObjectPool m_pool;
	/**
	 *  Without this instance being initialized with a pool and a query, nothing
	 *  good can be done with this class.
	 */
	public ObjectPoolQuery()
	{
	}
	/**
	 * @param  q The object specifying the query
	 * @param  p The pool to search upon
	 */
	public ObjectPoolQuery(final SQLQuery q, final ObjectPool p)
	{
		initialize(q, p);
	}
	/**
	 * @param  q
	 * @param  p
	 */
	public void initialize(final SQLQuery q, final ObjectPool p)
	{
		setSqlQuery(q);
		m_pool = p;
	}
	/**
	 * @return
	 */
	public Object clone()
	{
		ObjectPoolQuery pq = (ObjectPoolQuery) super.clone();
		pq.m_pool = m_pool;
		return pq;
	}
	/**
	 *  Query the object pool for all objects that are of the expected type.
	 *
	 * @param  expectedType The type of object specified in the query.
	 * @return  The ListOfObjects value
	 */
	protected Iterator getListOfObjects(final Persistence expectedType)
	{
		final Iterator e = m_pool.elements(expectedType.getClass());
		return e;
	}
}
