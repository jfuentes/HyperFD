/*
 *  Copyright (C) 2001 David Hoag
 *  ObjectWave Corporation
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *  For a full copy of the license see:
 *  http://www.opensource.org/licenses/lgpl-license.html
 */
package com.objectwave.persist.broker;

import com.objectwave.logging.MessageLog;
import com.objectwave.persist.*;
import com.objectwave.persist.collectionAdapters.*;
import com.objectwave.persist.constraints.Constraint;
import com.objectwave.persist.sqlConstruction.*;
import com.objectwave.utility.Sorter;
import com.objectwave.utility.StringManipulator;
import java.io.IOException;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.Vector;
/**
 *  A generic class that can assist with the query of objects in a way similar
 *  to relational databases.
 *
 * @author  dhoag
 * @version  $Id: ObjectQuerySupport.java,v 2.5 2002/03/09 17:13:47 dave_hoag Exp $
 */
public abstract class ObjectQuerySupport implements Cloneable
{
	protected ObjectFormatter defaultFormatter;
	SQLQuery m_query;
	/**
	 *  The query subject
	 */
	RDBPersistence m_subject;
	transient Object[] queryAttributeData = null;
	transient Persistence[] queryForeignData = null;
	transient Persistence[] instanceDataElements = null;
	/**
	 */
	public ObjectQuerySupport()
	{
		initialize();
	}
	/**
	 *  Without this instance being initialized with a query, nothing good can be
	 *  done with this class.
	 *
	 * @param  q The new SqlQuery value
	 */
	public void setSqlQuery(final SQLQuery q)
	{
		m_query = q;
	}
	/**
	 *  Set the subject attribute for this query and initializes the reusable query
	 *  attribute data.
	 *
	 * @param  pObj The new Subject value
	 */
	void setSubject(final RDBPersistence pObj)
	{
		m_subject = pObj;
		queryAttributeData = getAttributeData(pObj);
	}
	/**
	 *  Get the AttributeData from the persistent adapter
	 *
	 * @param  adapter
	 * @return  The data from the persistent object.
	 * @adapter  RDBPeristence The object that knows about the attribute
	 *      descriptions.
	 */
	public Object[] getAttributeData(final RDBPersistence adapter)
	{
		final Persistence p = adapter.getPersistentObject();
		final AttributeTypeColumn[] cols = adapter.getAttributeDescriptions();
		final Object[] map = new Object[cols.length];
		for(int i = 0; i < cols.length; ++i)
		{
			map[i] = cols[i].getValue(p);
		}
		return map;
	}
	/**
	 *  Get the collection adapter specified in the query. If none is specified
	 *  default to a VectorCollectionAdapter.
	 *
	 * @param  query
	 * @return  The CollectionAdapter value
	 */
	protected CollectionAdapter getCollectionAdapter(final SQLQuery query)
	{
		CollectionAdapter ca = query.getCollectionAdapter();
		if(ca == null)
		{
			ca = new VectorCollectionAdapter();
			ca.preQuery(query);
		}
		return ca;
	}
	/**
	 *  Query the object pool for all objects that are of the expected type.
	 *
	 * @param  expectedType The type of object specified in the query.
	 * @return  The ListOfObjects value
	 */
	protected abstract Iterator getListOfObjects(final Persistence expectedType);
	/**
	 *  To prevent problems with cyclical references we keep a list of every object
	 *  visited.
	 *
	 * @param  visited ArrayList The list of visited objects.
	 * @param  poolElement
	 * @param  wildCard
	 * @param  subject
	 * @return  The Match value
	 * @todo  Rewrite needed
	 */
	protected boolean isMatch(final boolean wildCard, final RDBPersistence subject, final Persistence poolElement, final ArrayList visited)
	{
		if(visited.contains(poolElement))
		{
			//If this is true, then other factors will determine if this is match
			return true;
		}
		visited.add(poolElement);
		final RDBPersistence pObj = getAdapterFor(poolElement);

		//The first res value of false will stop all other elements from executing
		boolean res = !pObj.isDeleteThis();
		res = res && checkConstrainedColumns(poolElement, pObj);
		try
		{
			res = res && checkAttributeValues(wildCard, subject, pObj);
		}
		catch(IOException ex)
		{
			MessageLog.warn(this, "Could not evaluate a persistent object for comparison.", ex);
			res = false;
		}
		//If the subject is from the database, no need to check fk and instance values
		if(res && pObj.isRetrievedFromDatabase() && !subject.isRetrievedFromDatabase())
		{
			res = res && checkForeignValues(subject, pObj, visited);
			res = res && checkInstanceValues(subject, pObj, visited);
		}
		return res;
	}
	/**
	 *  Create a new ObjectPoolQuery using the subject of searchObject and check to
	 *  see if it matches listElement.
	 *
	 * @param  searchObject Foreign key or instance link data that was found in the
	 *      original query object.
	 * @param  listElement The fk or instance link data from an object found in the
	 *      object pool.
	 * @param  visited ArrayList The list of persistent objects to which we have
	 *      visited
	 * @return  true if query matches the data, otherwise false.
	 */
	protected boolean isMatch(final RDBPersistence searchObject, final RDBPersistence listElement, final ArrayList visited)
	{
		//need a copy
		ObjectQuerySupport pq = (ObjectQuerySupport) clone();
		pq.setSubject(searchObject);
		return pq.isMatch(m_query.isLike(), searchObject, listElement.getPersistentObject(), visited);
	}
	/**
	 *  Determine if the primary keys from querySubject and the poolElement have
	 *  the same values.
	 *
	 * @param  wildCardMatch true if the querySubject specified a primaryKey as a
	 *      wild card
	 * @param  querySubject
	 * @param  poolElement
	 * @return  The PrimaryKeyMatch value
	 * @exception  IOException
	 */
	protected boolean isPrimaryKeyMatch(final boolean wildCardMatch, final RDBPersistence querySubject, final RDBPersistence poolElement) throws IOException
	{
		AttributeTypeColumn[] atc1 = querySubject.getPrimaryKeyDescriptions();
		AttributeTypeColumn[] atc2 = poolElement.getPrimaryKeyDescriptions();
		if(atc1.length == atc2.length)
		{
			for(int i = 0; i < atc1.length; i++)
			{
				if(atc1[i].getField().equals(atc2[i].getField()))
				{
					final Object pkey1 = atc1[i].getValue(querySubject.getPersistentObject());
					final Object pkey2 = atc2[i].getValue(poolElement.getPersistentObject());
					if(!isConsideredEqual(wildCardMatch, pkey1, pkey2))
					{
						return false;
					}
				}
				else
				{
					return false;
				}
			}
		}
		else
		{
			return false;
		}
		return true;
		//return isConsideredEqual(wildCardMatch, poolElement.getPrimaryKeyField(), querySubject.getPrimaryKeyField());
	}
	/**
	 *  If the query object is null or a default value, then this will return true.
	 *
	 * @param  poolObject Real data from a persistent object.
	 * @param  queryObject User specified data found in a query. May contain wild
	 *      cards.
	 * @param  wildCardMatch
	 * @return  The ConsideredEqual value
	 * @exception  IOException
	 */
	protected boolean isConsideredEqual(final boolean wildCardMatch, final Object poolObject, final Object queryObject) throws IOException
	{
		if(queryObject == null)
		{
			return true;
		}
		//The easy validation
		if(poolObject == queryObject)
		{
			return true;
		}

		if(SqlQueryBuilder.defaultValue(queryObject))
		{
			return true;
		}

		if(poolObject == null)
		{
			return false;
		}

		final String realData = defaultFormatter.formatValue(poolObject).trim();
		final String queryData = defaultFormatter.formatValue(queryObject).trim();
		if(wildCardMatch)
		{
			//queryData is a pattern, not actual data
			return StringManipulator.matchesPattern(realData, queryData);
		}
		else
		{
			return realData.equals(queryData);
		}
	}
	/**
	 *  Get the col value from the list element. If it exists, check to see if it
	 *  is a proxy. If so, realize the proxy. Once the final list element reference
	 *  value exists, get the adapter and return that result.
	 *
	 * @param  col AttributeTypeColumn The 'field' that should reference a
	 *      persistent object.
	 * @param  listElement The persistent object having the refence to another
	 *      persistent object.
	 * @return  null if element does not exist
	 */
	protected RDBPersistence getReferenceAdapter(final Persistence listElement, final AttributeTypeColumn col)
	{
		Persistence fkDataObject = (Persistence) col.getValue(listElement);
		RDBPersistence pObjFkData = null;
		if(fkDataObject != null)
		{
			pObjFkData = getAdapterFor(fkDataObject);
			//Realize the proxy if needed
			if(pObjFkData.isProxy())
			{
				pObjFkData = null;
				MessageLog.debug(this, "Forcing proxy realization " + fkDataObject.getClass().getName() + " during query.");
				fkDataObject = (Persistence) listElement.getObjectEditor().get(col.getField(), fkDataObject);
				if(fkDataObject != null)
				{
					pObjFkData = getAdapterFor(fkDataObject);
				}
			}
		}
		return pObjFkData;
	}
	/**
	 * @param  subject
	 * @param  visited
	 * @param  pObjFkData
	 * @param  listElementAdapter
	 * @param  pQueryReference
	 * @return  The PersistentReferenceValid value
	 */
	protected boolean isPersistentReferenceValid(final RDBPersistence subject, final RDBPersistence pQueryReference, final RDBPersistence pObjFkData, final RDBPersistence listElementAdapter, final ArrayList visited)
	{
		if(pObjFkData == null)
		{
			return false;
		}
		if(pQueryReference.isRetrievedFromDatabase())
		{
			Object searchValue = pQueryReference.getPrimaryKeyField();
			Object listValue = pObjFkData.getPrimaryKeyField();
			if(!searchValue.equals(listValue))
			{
				return false;
			}
		}
		else
		{
			// Data not retrieved from database.
			if(!isMatch(pQueryReference, pObjFkData, visited))
			{
				return false;
			}
		}
		return true;
	}
	/**
	 *  To process the result set, get the RDB specific information on the
	 *  persistent object 'p'.
	 *
	 * @param  p A persistent object that may use an adapter to describe its
	 *      relationships.
	 * @return  The implementation of the RDBPersistence interface.
	 */
	final RDBPersistence getAdapterFor(final Persistence p)
	{
		if(p.usesAdapter())
		{
			return (RDBPersistence) p.getAdapter();
		}
		else
		{
			return (RDBPersistence) p;
		}
	}
	/**
	 */
	public void initialize()
	{
		defaultFormatter = new ObjectFormatter();
	}
	/**
	 *  Execute the query.
	 *
	 * @return
	 */
	public Object find()
	{
		final Persistence subj = initializeSubject(m_query);
		final CollectionAdapter ca = getCollectionAdapter(m_query);

		final Iterator e = getListOfObjects(subj);
		while(e.hasNext())
		{
			//For each element in the pool
			final Persistence poolElement = (Persistence) e.next();
			//check to see if its a match
			if(isMatch(m_query.isLike(), m_subject, poolElement, new ArrayList()))
			{
				ca.addElement(poolElement);
			}
		}
		final Object result = ca.getCollectionObject();
		return sortResult(result, m_query.getOrderByList());
	}
	/**
	 *  Create an almost copy. The transient data is not copied.
	 *
	 * @return
	 */
	public Object clone()
	{
		ObjectQuerySupport result = null;
		try
		{
			result = (ObjectQuerySupport) super.clone();
		}
		catch(CloneNotSupportedException ex)
		{
			MessageLog.debug(this, "Did not expect this error", ex);
		}
		if(result == null)
		{
			try
			{
				result = (ObjectQuerySupport) this.getClass().newInstance();
			}
			catch(Exception ex)
			{
				MessageLog.error(this, "Just can't get a break. Giving up.", ex);
			}
		}
		//tranisent data is nulled out
		result.queryAttributeData = null;
		result.queryForeignData = null;
		result.instanceDataElements = null;
		result.m_query = m_query;
		result.m_subject = m_subject;
		return result;
	}
	/**
	 *  If the subject is retrieved from the database, only check the primary key
	 *  in the query. Assumes queryAttributeData has been setup via the setSubject
	 *  method call.
	 *
	 * @param  pObj An element from the object pool
	 * @param  wildCard
	 * @param  subject
	 * @return
	 * @exception  IOException
	 * @todo  Rewrite needed
	 */
	public boolean checkAttributeValues(final boolean wildCard, final RDBPersistence subject, final RDBPersistence pObj) throws IOException
	{
		if(subject.isRetrievedFromDatabase())
		{
			//then only check pkey
			return isPrimaryKeyMatch(wildCard, subject, pObj);
		}
		//if the pkey field is specified, and it's not a default value
		if(subject.getPrimaryKeyField() != null && !"0".equals(subject.getPrimaryKeyField().toString()))
		{
			//check for a match. If match fails, we know enough to exit
			if(!isPrimaryKeyMatch(wildCard, subject, pObj))
			{
				return false;
			}
		}
		//Get the attribute data from the Object Pool Element
		final Object[] map = getAttributeData(pObj);

		//check all attributes, if any don't match, exit
		for(int i = 0; i < queryAttributeData.length; i++)
		{
			if(!isConsideredEqual(wildCard, map[i], queryAttributeData[i]))
			{
				return false;
			}
		}
		return true;
	}
	/**
	 *  Set the subject of this ObjectPoolQuery to be the subject found in the
	 *  query parameter.
	 *
	 * @param  query The original query that resulted in this object being created.
	 * @return  The query subject
	 */
	protected Persistence initializeSubject(final SQLQuery query)
	{
		Persistence subj = query.getSubject();
		setSubject(getAdapterFor(subj));
		return subj;
	}
	/**
	 *  If there the query specifies a sort order, apply that now.
	 *
	 * @param  originalResult
	 * @param  orderByList
	 * @return
	 */
	protected Object sortResult(final Object originalResult, final Vector orderByList)
	{
		if(orderByList != null && orderByList.size() > 0)
		{
			if(originalResult instanceof Vector)
			{
				int size = orderByList.size();
				for(int i = size - 1; i > -1; i--)
				{
					sortOnField((Vector) originalResult, (String) orderByList.get(i));
				}
			}
		}
		return originalResult;
	}
	/**
	 * @param  poolElement
	 * @param  pObj
	 * @return
	 */
	protected boolean checkConstrainedColumns(final Persistence poolElement, final RDBPersistence pObj)
	{
		final AttributeTypeColumn[] cols = pObj.getAttributeDescriptions();

		for(int i = 0; i < cols.length; ++i)
		{
			String columnName = cols[i].getColumnName();
			Object columnValue = cols[i].getValue(poolElement);

			if(!satisfyingConstraint(poolElement, columnName, columnValue, queryAttributeData[i]))
			{
				// There is a constraint on this object & it failed the check.
				// We therefore return false, no matter what else may be true.
				return false;
			}
		}
		return true;
	}
	/**
	 *  Check to see if any constraints have been established for this query. If
	 *  constraints exist, make sure that the value satisfies the constraint
	 *  parameters.
	 *
	 * @param  columnName
	 * @param  value The value from the found object in the list of candidates for
	 *      query matches.
	 * @param  queryValue
	 * @param  poolElement
	 * @return  true If the contraint is satisfied or does not exist
	 */
	protected boolean satisfyingConstraint(final Persistence poolElement, final String columnName, final Object value, final Object queryValue)
	{
		com.objectwave.persist.constraints.Constraint c = m_query.getConstraintFor(columnName);
		if(c != null)
		{
			// Check the constraint on this column.
			// call Constraint.checkConstraint(dataValue, queryValue)
			//
			if(!c.checkConstraint(m_query, poolElement, value, queryValue))
			{
				// There is a constraint on this object & it failed the check.
				// We therefore return false, no matter what else may be true.
				//
				return false;
			}
		}
		return true;
	}
	/**
	 * @param  visited ArrayList The list of visited persistent objects.
	 * @param  subject
	 * @param  listElementAdapter
	 * @return
	 */
	protected boolean checkForeignValues(final RDBPersistence subject, final RDBPersistence listElementAdapter, final ArrayList visited)
	{
		final Persistence subjectP = subject.getPersistentObject();
		final AttributeTypeColumn[] subjCols = subject.getForeignKeyTypes(null);
		if(queryForeignData == null)
		{
			queryForeignData = initDataElements(subjCols, subjectP);
		}

		final AttributeTypeColumn[] cols = listElementAdapter.getForeignKeyTypes(null);
		final Persistence listElement = listElementAdapter.getPersistentObject();

		//For all the fk data in the search object
		for(int i = 0; i < queryForeignData.length; i++)
		{
			if(queryForeignData[i] != null)
			{
				//Get the foreign key data from the list
				RDBPersistence pObjFkData = getReferenceAdapter(listElement, cols[i]);
				//Get the adapter for our fk reference
				RDBPersistence pQueryReference = getAdapterFor(queryForeignData[i]);
				boolean validRef = isPersistentReferenceValid(subject, pQueryReference, pObjFkData, listElementAdapter, visited);
				if(!validRef)
				{
					return false;
				}
			}
		}
		// For loop
		return true;
	}
	/**
	 *  Use the AttributeTypeColumns to extract the data from the persistent
	 *  subject.
	 *
	 * @param  subjCols AttributeTypeColumn [] The attribute type columns that
	 *      identify the instance relations.
	 * @param  subject Persistence The persistent object
	 * @return
	 */
	protected Persistence[] initDataElements(final AttributeTypeColumn[] subjCols, final Persistence subject)
	{
		Persistence[] dataElements = new Persistence[subjCols.length];
		for(int i = 0; i < subjCols.length; ++i)
		{
			dataElements[i] = (Persistence) subjCols[i].getValue(subject);
		}
		return dataElements;
	}
	/**
	 * @param  visited The list objects that have been visited by this query.
	 * @param  subject
	 * @param  listElementAdapter
	 * @return
	 */
	protected boolean checkInstanceValues(final RDBPersistence subject, final RDBPersistence listElementAdapter, final ArrayList visited)
	{
		final Persistence subjectP = subject.getPersistentObject();
		final AttributeTypeColumn[] subjCols = subject.getInstanceLinkTypes(null);

		if(instanceDataElements == null)
		{
			instanceDataElements = initDataElements(subjCols, subjectP);
		}

		final AttributeTypeColumn[] cols = listElementAdapter.getInstanceLinkTypes(null);
		final Persistence listElement = listElementAdapter.getPersistentObject();

		for(int i = 0; i < instanceDataElements.length; i++)
		{
			if(instanceDataElements[i] != null)
			{
				final RDBPersistence pObjIlData = getReferenceAdapter(listElement, cols[i]);
				if(pObjIlData == null)
				{
					return false;
				}
				Persistence ilDataObject = pObjIlData.getPersistentObject();

				RDBPersistence pIlData = getAdapterFor(instanceDataElements[i]);

				AttributeTypeColumn dataJoinIdx = pIlData.instanceLinkJoinColumn(subject);

				if((pIlData.isRetrievedFromDatabase()) && (cols[i].getColumnName() != null) && dataJoinIdx == null)
				{
					Object searchValue = pIlData.getPrimaryKeyField();
					Object listValue = pObjIlData.getPrimaryKeyField();
					if(!searchValue.equals(listValue))
					{
						return false;
					}
				}
				else
						if(!isMatch(pIlData, pObjIlData, visited))
				{
					return false;
				}

			}
			// End ifData
		}
		// For loop
		return true;
	}
	/**
	 *  Modify the vector parameter to be sorted based upon the field.
	 *
	 * @param  collection Vector A result from a query.
	 * @param  fieldName The name of a field on each object in the collection.
	 * @todo  Handle numeric sorces and fieldNames that are paths
	 * @todo  Optimize
	 */
	protected void sortOnField(Vector collection, String fieldName)
	{
		try
		{
			AttributeTypeColumn field = null;
			String[] values = new String[collection.size()];
			Object[] sortedCollection = new Object[collection.size()];
			for(int i = 0; i < values.length; i++)
			{
				Persistence collectionElement = (Persistence)collection.get(i);
				if(field == null)
				{
					field = getFieldForName( collectionElement, fieldName );
				}
				values[i] = String.valueOf( field.getValue( collectionElement ) );
				sortedCollection[i] = collectionElement;
			}
			Sorter.quickSort(values, sortedCollection);
			collection.removeAllElements();
			for(int i = 0; i < values.length; i++)
			{
				collection.add(sortedCollection[i]);
			}
		}
		catch(NoSuchFieldException ex)
		{
			MessageLog.error( this, "Skipping sort of collection result set. Sort Field: '" + fieldName + '\'', ex);
		}
		catch(IllegalArgumentException ex)
		{
			MessageLog.error(this, "Skipping sort of collection result set. Sort Field: '" + fieldName + '\'', ex);
		}
	}
	/**
	 * Find the Field object represented by the provided field name
	 * @param persistentObject The object that should contain the provided field
	 * @param fieldName The name of a persistent field on the provided object
	 */
	protected AttributeTypeColumn getFieldForName( final Persistence persistentObject, final String fieldName ) throws NoSuchFieldException
	{
		RDBPersistence theAdapter = (RDBPersistence)persistentObject.getAdapter();
		AttributeTypeColumn [] pkeyCols = theAdapter.getPrimaryKeyDescriptions();
		AttributeTypeColumn [] cols = theAdapter.getAttributeDescriptions();
		for (int i = 0; i < pkeyCols.length; i++)
		{
			final AttributeTypeColumn col = pkeyCols[i];
			if( col.getField() != null )
			{
				if( col.getField().getName().equals( fieldName ) )
				{
					return col;
				}
			}
		}
		for (int i = 0; i < cols.length; i++)
		{
			final AttributeTypeColumn col = cols[i];
			if( col.getField() != null )
			{
				if( col.getField().getName().equals( fieldName ) )
				{
					return col;
				}
			}
		}
		throw new NoSuchFieldException("The field " + fieldName + " is not a persistent field on the persistent class: " + persistentObject.getClass().getName() );
	}
	/**
	 * @author  dhoag
	 * @version  $Id: ObjectQuerySupport.java,v 2.5 2002/03/09 17:13:47 dave_hoag Exp $
	 */
	public static class Test extends com.objectwave.test.UnitTestBaseImpl
	{
		/**
		 *  The main program for the Test class
		 *
		 * @param  args The command line arguments
		 */
		public static void main(String[] args)
		{
			com.objectwave.test.TestRunner.run(new Test(), args);
		}
		/**
		 *  A unit test for JUnit
		 */
		public void testIsMatch()
		{
			com.objectwave.persist.examples.TestEntity te = new com.objectwave.persist.examples.TestEntity();
			com.objectwave.persist.examples.TestEntity foundObject = new com.objectwave.persist.examples.TestEntity();
			foundObject.annualIncome = 30.0;
			ObjectQuerySupport fq = new EmptyObjectQuerySupport();
			fq.setSqlQuery(new SQLQuery(te));
			RDBPersistence queryObject = (RDBPersistence) te.getAdapter();
			RDBPersistence listElement = (RDBPersistence) foundObject.getAdapter();

			ArrayList matches = new ArrayList();
			testContext.assertTrue("Failed to match on double value and default search value", fq.isMatch(queryObject, listElement, matches));
			testContext.assertTrue("Failed to match with alternate IsMatch call", fq.isMatch(false, queryObject, foundObject, matches));
		}
		/**
		 *  A unit test for JUnit
		 *
		 * @exception  Exception
		 */
		public void testPrimaryKeyMatch() throws Exception
		{
			com.objectwave.persist.examples.TestEntity te = new com.objectwave.persist.examples.TestEntity();
			com.objectwave.persist.examples.TestEntity foundObject = new com.objectwave.persist.examples.TestEntity();

			ObjectQuerySupport fq = new EmptyObjectQuerySupport();
			fq.setSqlQuery(new SQLQuery(te));

			te.setPrimaryKeyField(new Integer(100));
			foundObject.setPrimaryKeyField(new Integer(101));

			RDBPersistence queryObject = (RDBPersistence) te.getAdapter();
			RDBPersistence listElement = (RDBPersistence) foundObject.getAdapter();

			testContext.assertTrue("Found match even with different PK values", !fq.isPrimaryKeyMatch(false, queryObject, listElement));
			foundObject.setPrimaryKeyField(new Integer(100));
			testContext.assertTrue("Failed to find match on PK values", fq.isPrimaryKeyMatch(false, queryObject, listElement));
		}
		class EmptyObjectQuerySupport extends ObjectQuerySupport
		{
			/**
			 *  Gets the ListOfObjects attribute of the EmptyObjectQuerySupport object
			 *
			 * @param  expectedType
			 * @return  The ListOfObjects value
			 */
			protected Iterator getListOfObjects(final Persistence expectedType)
			{
				return null;
			}
		}
	}
}
