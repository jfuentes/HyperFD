package com.objectwave.persist.broker;
import com.objectwave.persist.*;
import com.objectwave.persist.examples.*;
import com.objectwave.persist.mapping.*;
import com.objectwave.persist.properties.BrokerPropertySource;
import com.objectwave.persist.sqlConstruction.*;
import java.sql.*;
/**
 *  This will be the place for Oracle specific implementation issues. Special
 *  Considerations
 *  <li> The oracle type of VARCHAR will not contain empty strings. If a field
 *  contains an empty string, this will be returned from the database as 'null'.
 *  </li>
 *
 * @author  Dave Hoag
 * @version  $Id: OracleBroker.java,v 2.3 2002/03/23 13:42:10 dave_hoag Exp $
 */
public class OracleBroker extends RDBBroker
{
	final static boolean useCachePkey = true;
	// = System.getProperty("ow.cachePkey") != null;
	int pkeyPool = -1;
	int currentPkey = 0;
	Boolean cachedResult;
	/**
	 *  Most systems will have only one database broker. This method is used to
	 *  support systems of that type.
	 *
	 * @return  The DefaultBroker value
	 */
	public static RDBBroker getDefaultBroker()
	{
		if(broker == null)
		{
			broker = new OracleBroker();
			broker.initialize();
		}
		return broker;
	}
	/**
	 * @return  The SmartBatchEnabled value
	 */
	protected final boolean isSmartBatchEnabled()
	{
		if(cachedResult == null)
		{
			String str = props.getProperty("ow.smartBatch", "false");
			cachedResult = new Boolean(str.equals("true"));
		}
		return cachedResult.booleanValue();
	}
	/**
	 *  Get the fully qualified class name of the preferred database driver.
	 *
	 * @return  java.lang.String
	 * @author  Dave Hoag
	 */
	protected String getDefaultDriverName()
	{
		return "oracle.jdbc.driver.OracleDriver";
	}
	/**
	 *  Gets the DefaultPrimaryKeyStrategy attribute of the OracleBroker object
	 *
	 * @return  The DefaultPrimaryKeyStrategy value
	 */
	protected PrimaryKeyStrategy getDefaultPrimaryKeyStrategy()
	{
		return new GlobalSequence();
	}
	/**
	 */
	public void initialize()
	{
		super.initialize();
		//A Special ObjectFormatter is needed to customize the format of data for Oracle.
		statementFactory.setObjectFormatter(new OracleObjectFormatter());
	}
	/**
	 *  Implemented as an instance method to support method overriding.
	 *
	 * @return  com.objectwave.persist.RDBBroker or a subclass.
	 * @author  Dave Hoag
	 */
	public RDBBroker defaultBroker()
	{
		return OracleBroker.getDefaultBroker();
	}
	/**
	 * @param  connectionPool Description of Parameter
	 * @param  connectUrl Description of Parameter
	 * @param  userName Description of Parameter
	 * @param  userPassword Description of Parameter
	 * @return  Description of the Returned Value
	 */
	protected RDBConnection newRDBConnection(final RDBConnectionPool connectionPool, final String connectUrl, final String userName, final String userPassword)
	{
		return new OracleConnection(connectionPool, connectUrl, userName, userPassword);
	}
	/**
	 * @param  ex Description of Parameter
	 * @param  additionalInfo Description of Parameter
	 * @return  Description of the Returned Value
	 */
	protected QueryException convertException(SQLException ex, String additionalInfo)
	{
		final QueryException result = super.convertException(ex, additionalInfo);
		//Attempt to resolve various dying connection problems
		switch (ex.getErrorCode())
		{
			case 17002:
			// Io exception: Broken Pipe
			case 17410:
			{
				//'No more data to read from socket' exception

				result.setRetryPossible(true);
			}
		}
		return result;
	}
	/**
	 *  Unit tests.
	 *
	 * @author  dhoag
	 * @version  $Id: OracleBroker.java,v 2.3 2002/03/23 13:42:10 dave_hoag Exp $
	 */
	public static class Test extends com.objectwave.test.UnitTestBaseImpl
	{
		/**
		 *  The main program for the Test class
		 *
		 * @param  args The command line arguments
		 */
		public static void main(String[] args)
		{
			com.objectwave.test.TestRunner.run(new Test(), args);
		}
		/**
		 *  A unit test for JUnit
		 */
		public void testGetPkeyStrategy()
		{
			OracleBroker broker = new OracleBroker();
			//Force it to use a unique source
			BrokerPropertySource source = new BrokerPropertySource("UniqueCategory");
			broker.setBrokerPropertySource(source);
			broker.initialize();
			PrimaryKeyStrategy strat = broker.getBrokerPropertySource().getPrimaryKeyStrategy();
			testContext.assertTrue("Didn't get default instance!", strat instanceof GlobalSequence);
			PrimaryKeyStrategy strat2 = broker.getBrokerPropertySource().getPrimaryKeyStrategy();
			testContext.assertTrue("Should be identical instance!", strat == strat2);
		}
		/**
		 *  A unit test for JUnit
		 */
		public void testCustomSerialize()
		{
			System.getProperties().put("ow.databaseImpl", "com.objectwave.persist.broker.OracleBroker");
			//Clear out any old instances.
			BrokerFactory.setDefaultBroker(null);
			RDBBroker.broker = null;
			OracleBroker.broker = null;
			testContext.assertTrue("Failed to get the expected broker instance.", BrokerFactory.getDatabaseBroker() instanceof OracleBroker);
			OracleBroker ob = (OracleBroker) BrokerFactory.getDatabaseBroker();
			SQLInsert sqlObj = ob.statementFactory.newInsert();

			StringBuffer buf = new StringBuffer();
			TestEntity to = new TestEntity();

			sqlObj.formatValue(to, buf);

			testContext.assertTrue("Failed to strip 0x !", !buf.toString().startsWith("0x"));
		}
	}
}
