/* Copyright (C) 2001 David Hoag
 * ObjectWave Corporation
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * For a full copy of the license see:
 * http://www.opensource.org/licenses/lgpl-license.html
 */
package com.objectwave.persist.broker;
import com.objectwave.logging.MessageLog;
import com.objectwave.persist.BrokerPropertyIF;

import java.sql.*;
/**
 *  This class allows for specific customization of the connection between the
 *  OracleBroker and the OracleDatabase.
 *
 * @author  Dave Hoag
 * @version  $Id: OracleConnection.java,v 2.1 2001/06/13 23:39:30 dave_hoag Exp $
 */
public class OracleConnection extends RDBConnection
{
	static String useBatch = System.getProperty("ow.prepBatch");
	static boolean sqlTrace = System.getProperty("ow.sqlTrace", "false").equalsIgnoreCase("true");
	/**
	 *  Most of the work is done by the super class implementation. Change the
	 *  value of needsExplicitBegin to false. Oracle does not need this.
	 *
	 * @param  pool com.objectwave.persist.RDBConnectionPool
	 * @param  connectUrl java.lang.String
	 * @param  userName java.lang.String
	 * @param  password java.lang.String
	 */
	OracleConnection(final RDBConnectionPool pool, final String connectUrl, final String userName, final String password)
	{
		super(pool, connectUrl, userName, password);
		needsExplicitBegin = false;
	}
	/**
	 * @param  b The new BrokerProperty value
	 */
	public void setBrokerProperty(BrokerPropertyIF b)
	{
		if(System.getProperty("ow.prepBatch") == null)
		{
			//Don't override the system settings

			useBatch = b.getProperty("ow.prepBatch");
		}
		sqlTrace = b.getProperty("ow.sqlTrace", "false").equalsIgnoreCase("true");
		super.setBrokerProperty(b);
	}
	/**
	 *  Method assumes a check to see if useBatch was null before this method was
	 *  invoked. If useBatch is null, this method should not be used.
	 *
	 * @return  int value of the useBatch property
	 */
	protected int getBatchSize()
	{
		try
		{
			int batchNum = new Integer(useBatch).intValue();
			//	((oracle.jdbc.driver.OraclePreparedStatement)stmt).setExecuteBatch(batchNum);
			return batchNum;
		}
		//If an exception is thrown, stop trying.
		catch(Exception ex)
		{
			if(verbose)
			{
				System.out.println("Exception using bacth statements.\n--" + ex);
			}
			useBatch = null;
		}
		return -1;
	}
	/**
	 *  Establish the connection to the database.
	 *
	 * @param  con
	 * @exception  SQLException
	 */
	public void alterVendorConnection(final java.sql.Connection con) throws SQLException
	{
		//We must have connected!
		if(sqlTrace)
		{
			execSql("ALTER SESSION SET SQL_TRACE=TRUE");
		}
		if(con instanceof oracle.jdbc.driver.OracleConnection)
		{
			if(useBatch != null)
			{
				int batchSize = getBatchSize();
				if(batchSize > 0)
				{
					((oracle.jdbc.driver.OracleConnection) con).setDefaultExecuteBatch(batchSize);
					MessageLog.debug(this, "Oracle Connection using batch size: " + batchSize);
				}
			}
		}
	}
	/**
	 * @param  errorCode
	 * @return
	 */
	protected boolean tryAgain(int errorCode)
	{
		switch (errorCode)
		{
			case 18:
			//Maximum Sessions Exceeded
			case 19:
			//All licenses exceeded
			case 20:
			//Max processes exceeded
			case 52:
			//Max enqueue resources exceeded
			case 53:
			//Max enqueues exceeded
			case 54:
			//Resource busy and acquire with nowait specified
			case 55:
			//Max number of DML locks exceeded
			case 703:
			//Max number of dictionary cache instance locks exceeded
			case 1033:
			//Oracle startup or shutdown in progress
			case 1098:
				//Program interface error during long insert
				try
				{
					Thread.currentThread().sleep(500);
				}
				catch(InterruptedException ex)
				{
					MessageLog.debug(this, "OracleConnection>>tryAgain Sleep interrupted! a problem?");
				}
				return true;
			case 28:
			//These errors require that the connection be closed and reopen.
			case 30:
			//The code will NOT try again and will instread rethrow the exception
			case 603:
			case 17002:
			case 17410:
			{
				clearConnection();
			}
		}
		return false;
	}

}
