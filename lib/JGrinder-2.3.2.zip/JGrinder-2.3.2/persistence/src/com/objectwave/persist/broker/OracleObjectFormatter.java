package com.objectwave.persist.broker;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Date;
/**
 *  Override the one change necessary for Oracle.
 *
 * @author  Dave Hoag
 * @version  $Id: OracleObjectFormatter.java,v 2.1 2002/01/21 22:34:50 dave_hoag Exp $
 */
public class OracleObjectFormatter extends com.objectwave.persist.ObjectFormatter
{
	/**
	 * @param  statement
	 * @param  data
	 * @param  idx
	 * @exception  java.sql.SQLException
	 */

	final static SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("dd-MMM-yyyy");
	/**
	 * @param  statement
	 * @param  data
	 * @param  idx
	 * @exception  java.sql.SQLException
	 */
	public void bindBlob(java.sql.PreparedStatement statement, byte[] data, int idx) throws java.sql.SQLException
	{
		oracle.jdbc.driver.OracleConnection con = (oracle.jdbc.driver.OracleConnection) statement.getConnection();
		java.sql.Blob blob = new oracle.sql.BLOB(con, data);
		statement.setBlob(idx, blob);
	}
	/**
	 *  To facilitate overriding of this method, the formatting is broken out.
	 *
	 * @param  buf StringBuffer upon which to write the data.
	 * @param  value Serializable object to convert to a string value.
	 */
	public void formatSerializable(final java.io.Serializable value, final StringBuffer buf)
	{
		try
		{
			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			ObjectOutputStream os = new ObjectOutputStream(bos);
			os.writeObject(value);
			byte[] theObjectSerialized = bos.toByteArray();
			buf.append('\'');
			bytesToString(theObjectSerialized, buf);
			buf.append('\'');
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}

	/**
	 * @param  value Date object to format.
	 * @param  buf StringBuffer upon which to write the data.
	 */
	protected void formatDate(final Date value, final StringBuffer buf)
	{
		buf.append(DATE_FORMAT.format(value));
	}
}

