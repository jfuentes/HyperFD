package com.objectwave.persist.broker;
import java.util.Vector;
import com.objectwave.persist.*;
/**
 *  Manage multiple connections.
 *
 * @author  dhoag
 * @version  $Id: RDBConnectionPool.java,v 2.1 2002/03/23 13:42:10 dave_hoag Exp $
 */
public class RDBConnectionPool
{
	RDBConnection[] connections;
	Vector list;
	boolean initialized = false;
	long sqlTime;
	/**
	 *  the index to a silly algorithm to provide more balance to the connection
	 *  usage.
	 */
	int balanceIdx = 0;
	static boolean metrics = System.getProperty("ow.persistMetrics") != null;
	/**
	 */
	public RDBConnectionPool()
	{
	}
	/**
	 * @param  b The new BrokerProperty value
	 */
	public void setBrokerProperty(BrokerPropertyIF b)
	{
		metrics = b.getProperty("ow.persistConnectionMetrics") != null;
	}
	/**
	 * @param  conns com.objectwave.persist.RDBConnection[]
	 * @author  Dave Hoag
	 */
	public void setConnections(RDBConnection[] conns)
	{
		connections = conns;
		initialized = true;
	}
	/**
	 *  RDBConnectionPool constructor comment. All connections created by this
	 *  connection pool will have the following parameters. This method MUST be
	 *  called prior to getConnections being called.
	 *
	 * @param  connectUrl Description of Parameter
	 * @param  userName Description of Parameter
	 * @param  password Description of Parameter
	 * @param  connectionCount Description of Parameter
	 * @deprecated
	 */
	public void initialize(String connectUrl, String userName, String password, final int connectionCount)
	{
		connections = new RDBConnection[connectionCount];
		for(int i = 0; i < connectionCount; i++)
		{
			connections[i] = new RDBConnection(this, connectUrl, userName, password);
		}
		initialized = true;
	}
	/**
	 *  Gets the SqlTime attribute of the RDBConnectionPool object
	 *
	 * @return  The SqlTime value
	 */
	protected long getSqlTime()
	{
		return sqlTime;
	}
	/**
	 *  Every thread will attempt to get a connection to the database. This is the
	 *  point at which we handle synchronization issues. Once a thread has a
	 *  connection, it will hold onto the connection as long as necessary. No other
	 *  threads will be allowed to have that connection until it is set free.
	 *
	 * @return  The Connection value
	 * @fixme  - Thread death? Preemptive dropping of connection? More threads than
	 *      connections?
	 * @author  Dave Hoag
	 */
	protected synchronized RDBConnection getConnection()
	{
		if(!initialized)
		{
			throw new RuntimeException("Connection pool is not initialized!");
		}
		RDBConnection available = null;
		final Thread current = Thread.currentThread();

		while(true)
		{
			//A linear search has proven to be very fast for small collection sizes.
			for(int i = 0; i < connections.length; i++)
			{
				if(connections[i].getThread() == current)
				{
					return connections[i];
				}
				if(available == null && connections[i].getThread() == null)
				{
					available = connections[i];
					//An attempt to more evenly use the connections.
//Don't bother balancing, yet...
					/*
					 * balanceIdx = (balanceIdx + 1) % connections.length;
					 * connections[i] = connections[ balanceIdx ];
					 * connections[ balanceIdx ] = available;
					 */
				}
			}
			if(available != null)
			{
				available.setThread(current);
				return available;
			}
			waitForConnection();
		}
	}
	/**
	 *  Used for metric information
	 *
	 * @param  l Description of Parameter
	 */
	protected synchronized void incrementSqlTime(long l)
	{
		sqlTime += l;
	}
	/**
	 *  Description of the Method
	 */
	protected void resetSqlTime()
	{
		sqlTime = 0;
	}
	/**
	 *  The other way the pool works is maintains the list of connections.
	 *
	 * @param  con The feature to be added to the Connection attribute
	 */
	protected void addConnection(RDBConnection con)
	{
		if(list == null)
		{
			list = new Vector();
		}
		list.add(con);
	}
	/**
	 * @author  Dave Hoag
	 */
	protected final synchronized void notifyConnection()
	{
		notify();
	}
	/**
	 * @author  Dave Hoag
	 */
	protected final synchronized void waitForConnection()
	{
		if(metrics)
		{
			RDBBroker.println("Waiting for connection");
		}
		try
		{
			wait();
		}
		catch(InterruptedException ex)
		{
		}
	}
	/**
	 * @return  The Connections value
	 */
	RDBConnection[] getConnections()
	{
		if(connections == null && list != null)
		{
			//dynamicly growing list of connections

			RDBConnection[] values = new RDBConnection[list.size()];
			list.copyInto(values);
			return values;
		}
		return connections;
	}
	/**
	 *  Unit tests.
	 *
	 * @author  dhoag
	 * @version  $Id: RDBConnectionPool.java,v 2.1 2002/03/23 13:42:10 dave_hoag Exp $
	 */
	public static class Test extends com.objectwave.test.UnitTestBaseImpl
	{
		//Get me around weird java behavior.
		/**
		 *  Description of the Method
		 *
		 * @param  str Description of Parameter
		 * @param  b Description of Parameter
		 */
		public void assertTrue(String str, boolean b)
		{
			testContext.assertTrue(str, b);
		}
		/**
		 *  Description of the Method
		 */
		public void pauseThread()
		{
			try
			{
				Thread.currentThread().sleep(100);
			}
			catch(Throwable t)
			{
			}
		}
		/**
		 *  A unit test for JUnit
		 */
		public void testGetConnection()
		{
			RDBConnectionPool pool = new RDBConnectionPool();
			pool.initialize("connect", "user", "pass", 2);
			testContext.assertEquals("Invalid number of connections ", pool.getConnections().length, 2);
			MyRunnable one = new MyRunnable(pool);
			MyRunnable two = new MyRunnable(pool);
			MyRunnable three = new MyRunnable(pool);
			try
			{
				testContext.getNewThread(one).start();
				testContext.getNewThread(two).start();
				pauseThread();
				testContext.getNewThread(three).start();
				pauseThread();
				testContext.assertTrue("No connection obtained!", one.connect != null);
				testContext.assertTrue("Second connection never obtained!", two.connect != null);
				testContext.assertTrue("Connection erroneously obtained!", three.connect == null);
				one.release();
				pauseThread();
				testContext.assertTrue("Third connection not obtained!", three.connect != null);
				two.release();
				three.release();
			}
			finally
			{
				one.release();
				two.release();
				three.release();
			}
		}
		/**
		 *  The main program for the Test class
		 *
		 * @param  args The command line arguments
		 */
		public static void main(String[] args)
		{
			com.objectwave.test.TestRunner.run(new Test(), args);
		}
		//use to manipulate access to the connections.
		class MyRunnable implements Runnable
		{
			RDBConnectionPool pool;
			RDBConnection connect = null;
			/**
			 *  Constructor for the MyRunnable object
			 *
			 * @param  p Description of Parameter
			 */
			MyRunnable(RDBConnectionPool p)
			{
				pool = p;
			}
			/**
			 *  Main processing method for the MyRunnable object
			 */
			public void run()
			{
				connect = pool.getConnection();
				pause();
				testContext.assertTrue("Connects should be the same!", connect == pool.getConnection());
				connect.freeConnection();
			}
			/**
			 *  Description of the Method
			 */
			public synchronized void release()
			{
				notifyAll();
			}
			/**
			 *  Description of the Method
			 */
			synchronized void pause()
			{
				try
				{
					wait();
				}
				catch(Throwable t)
				{
				}
			}
		}
	}

}
