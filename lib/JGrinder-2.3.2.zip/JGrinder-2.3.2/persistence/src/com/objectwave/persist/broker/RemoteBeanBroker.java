package com.objectwave.persist.broker;
import com.objectwave.logging.MessageLog;
import com.objectwave.persist.*;
import com.objectwave.persist.Broker;
import com.objectwave.persist.Persistence;
import com.objectwave.persist.SQLQuery;
import com.objectwave.persist.bean.JGrinderQuery;

import com.objectwave.persist.bean.JGrinderQueryHome;
import com.objectwave.persist.examples.ExampleEmployee;
import java.util.ArrayList;
import java.util.Vector;
import javax.naming.*;
import javax.rmi.PortableRemoteObject;

/**
 * @author  dhoag
 * @version  $Id: RemoteBeanBroker.java,v 2.0 2001/06/11 16:00:04 dave_hoag Exp $
 */
public class RemoteBeanBroker implements Broker
{
	private final static String ERROR_NULL_REMOTE = "Remote interface reference is null.  It must be created by calling one of the Home interface methods first.";
	private final static int MAX_OUTPUT_LINE_LENGTH = 50;
	private boolean logging = true;
	private JGrinderQueryHome jGrinderQueryHome = null;
	private JGrinderQuery jGrinderQuery = null;
	/**
	 *  Construct the EJB test client
	 */
	public RemoteBeanBroker()
	{
		initialize();
	}
	/**
	 *  Main method
	 *
	 * @param  args The command line arguments
	 */

	public static void main(String[] args)
	{
		RemoteBeanBroker client = new RemoteBeanBroker();
		// Use the client object to call one of the Home interface wrappers
		// above, to create a Remote interface reference to the bean.
		// If the return value is of the Remote interface type, you can use it
		// to access the remote interface methods.  You can also just use the
		// client object to call the Remote interface wrappers.
	}

	/**
	 *  Sets the BrokerProperty attribute of the RemoteBeanBroker object
	 *
	 * @param  b The new BrokerProperty value
	 */
	public void setBrokerProperty(BrokerPropertyIF b)
	{
	}

	/**
	 */
	public void initialize()
	{
		long startTime = 0;
		if(logging)
		{
			MessageLog.debug(this, "Initializing bean access.");
			startTime = System.currentTimeMillis();
		}

		try
		{
			//get naming context
			Context ctx = new InitialContext();

			//look up jndi name
			Object ref = ctx.lookup("JGrinderQuery");

			//cast to Home interface
			jGrinderQueryHome = (JGrinderQueryHome) PortableRemoteObject.narrow(ref, JGrinderQueryHome.class);
			if(logging)
			{
				long endTime = System.currentTimeMillis();
				MessageLog.debug(this, "Succeeded initializing bean access.");
				MessageLog.debug(this, "Execution time: " + (endTime - startTime) + " ms.");
			}
			create();
		}
		catch(Exception e)
		{
			if(logging)
			{
				MessageLog.debug(this, "Failed initializing bean access.");
			}
			e.printStackTrace();
		}
	}

	//----------------------------------------------------------------------------
	// Methods that use Home interface methods to generate a Remote interface reference
	//----------------------------------------------------------------------------

	/**
	 * @return
	 */
	public JGrinderQuery create()
	{
		long startTime = 0;
		if(logging)
		{
			MessageLog.debug(this, "Calling create()");
			startTime = System.currentTimeMillis();
		}
		try
		{
			jGrinderQuery = jGrinderQueryHome.create();
			if(logging)
			{
				long endTime = System.currentTimeMillis();
				MessageLog.debug(this, "Succeeded: create()");
				MessageLog.debug(this, "Execution time: " + (endTime - startTime) + " ms.");
			}
		}
		catch(Exception e)
		{
			if(logging)
			{
				MessageLog.debug(this, "Failed: create()");
			}
			e.printStackTrace();
		}

		if(logging)
		{
			MessageLog.debug(this, "Return value from create(): " + jGrinderQuery + ".");
		}
		return jGrinderQuery;
	}

	//----------------------------------------------------------------------------
	// Methods that use Remote interface methods to access data through the bean
	//----------------------------------------------------------------------------

	/**
	 * @param  q
	 * @return
	 */
	public Object find(SQLQuery q)
	{
		Object returnValue = null;
		if(jGrinderQuery == null)
		{
			System.out.println("Error in find(): " + ERROR_NULL_REMOTE);
			return returnValue;
		}
		long startTime = 0;
		if(logging)
		{
			MessageLog.debug(this, "Calling find(" + q + ")");
			startTime = System.currentTimeMillis();
		}

		try
		{
			returnValue = jGrinderQuery.find(q);
			if(logging)
			{
				long endTime = System.currentTimeMillis();
				MessageLog.debug(this, "Succeeded: find(" + q + ")");
				MessageLog.debug(this, "Execution time: " + (endTime - startTime) + " ms.");
			}
		}
		catch(Exception e)
		{
			if(logging)
			{
				MessageLog.debug(this, "Failed: find(" + q + ")");
			}
			e.printStackTrace();
		}

		if(logging)
		{
			MessageLog.debug(this, "Return value from find(" + q + "): " + returnValue + ".");
		}
		return returnValue;
	}

	/**
	 * @param  q
	 * @param  at
	 * @return
	 */
	public Vector findAttributes(SQLQuery q, String[] at)
	{
		Vector returnValue = null;
		if(jGrinderQuery == null)
		{
			System.out.println("Error in findAttributes(): " + ERROR_NULL_REMOTE);
			return returnValue;
		}
		long startTime = 0;
		if(logging)
		{
			MessageLog.debug(this, "Calling findAttributes(" + q + ", " + at + ")");
			startTime = System.currentTimeMillis();
		}

		try
		{
			returnValue = jGrinderQuery.findAttributes(q, at);
			if(logging)
			{
				long endTime = System.currentTimeMillis();
				MessageLog.debug(this, "Succeeded: findAttributes(" + q + ", " + at + ")");
				MessageLog.debug(this, "Execution time: " + (endTime - startTime) + " ms.");
			}
		}
		catch(Exception e)
		{
			if(logging)
			{
				MessageLog.debug(this, "Failed: findAttributes(" + q + ", " + at + ")");
			}
			e.printStackTrace();
		}

		if(logging)
		{
			MessageLog.debug(this, "Return value from findAttributes(" + q + ", " + at + "): " + returnValue + ".");
		}
		return returnValue;
	}

	/**
	 * @param  q
	 * @return
	 */
	public Persistence findUnique(SQLQuery q)
	{
		Persistence returnValue = null;
		if(jGrinderQuery == null)
		{
			System.out.println("Error in findUnique(): " + ERROR_NULL_REMOTE);
			return returnValue;
		}
		long startTime = 0;
		if(logging)
		{
			MessageLog.debug(this, "Calling findUnique(" + q + ")");
			startTime = System.currentTimeMillis();
		}

		try
		{
			returnValue = jGrinderQuery.findUnique(q);
			if(logging)
			{
				long endTime = System.currentTimeMillis();
				MessageLog.debug(this, "Succeeded: findUnique(" + q + ")");
				MessageLog.debug(this, "Execution time: " + (endTime - startTime) + " ms.");
			}
		}
		catch(Exception e)
		{
			if(logging)
			{
				MessageLog.debug(this, "Failed: findUnique(" + q + ")");
			}
			e.printStackTrace();
		}

		if(logging)
		{
			MessageLog.debug(this, "Return value from findUnique(" + q + "): " + returnValue + ".");
		}
		return returnValue;
	}
	/**
	 * @param  q
	 * @return
	 * @exception  QueryException
	 */
	public int count(SQLQuery q) throws QueryException
	{
		int returnValue = 0;
		if(jGrinderQuery == null)
		{
			System.out.println("Error in findUnique(): " + ERROR_NULL_REMOTE);
			return returnValue;
		}
		long startTime = 0;
		if(logging)
		{
			MessageLog.debug(this, "Calling findUnique(" + q + ")");
			startTime = System.currentTimeMillis();
		}

		try
		{
			returnValue = jGrinderQuery.count(q);
			if(logging)
			{
				long endTime = System.currentTimeMillis();
				MessageLog.debug(this, "Succeeded: findUnique(" + q + ")");
				MessageLog.debug(this, "Execution time: " + (endTime - startTime) + " ms.");
			}
		}
		catch(Exception e)
		{
			if(logging)
			{
				MessageLog.debug(this, "Failed: findUnique(" + q + ")");
			}
			e.printStackTrace();
		}

		if(logging)
		{
			MessageLog.debug(this, "Return value from findUnique(" + q + "): " + returnValue + ".");
		}
		return returnValue;
	}
	/**
	 * @exception  QueryException
	 */
	public void beginTransaction() throws QueryException
	{
	}
	/**
	 * @exception  QueryException
	 */
	public void commit() throws QueryException
	{
	}
	/**
	 * @param  obj
	 * @exception  QueryException
	 */
	public void delete(Persistence obj) throws QueryException
	{
	}
	/**
	 * @param  deleteList
	 * @exception  QueryException
	 */
	public void deleteObjects(ArrayList deleteList) throws QueryException
	{
	}
	/**
	 *  The return type of object allows the support of multiple collection types.
	 *
	 * @param  q
	 * @exception  QueryException
	 */
	public void deleteAll(SQLQuery q) throws QueryException
	{
	}
	/**
	 * @exception  QueryException
	 */
	public void rollback() throws QueryException
	{
	}
	/**
	 * @param  obj
	 * @exception  QueryException
	 */
	public void save(Persistence obj) throws QueryException
	{
	}
	/**
	 * @param  saveList
	 * @exception  QueryException
	 */
	public void saveObjects(ArrayList saveList) throws QueryException
	{
	}
	/**
	 *  Tell the broker the application is done with it. May not have any behavior
	 */
	public void close()
	{
	}

}
