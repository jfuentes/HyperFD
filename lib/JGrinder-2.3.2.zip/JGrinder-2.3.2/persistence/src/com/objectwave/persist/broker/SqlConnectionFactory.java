/* Copyright (C) 2001 David Hoag
 * ObjectWave Corporation
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * For a full copy of the license see:
 * http://www.opensource.org/licenses/lgpl-license.html
 */
package com.objectwave.persist.broker;
import java.sql.Connection;
import java.sql.SQLException;
/**
 *  A connection factory will retrieve or create the necessary
 *  java.sql.Connection for communication with the database.
 *
 * @author  dhoag
 * @version  $Id: SqlConnectionFactory.java,v 2.1 2001/06/13 23:40:07 dave_hoag Exp $
 */
public interface SqlConnectionFactory
{
	/**
	 *  Create or retrieve the connection to use for accessing the database.
	 *
	 * @param  jgrinderConnection
	 * @return
	 * @exception  SQLException
	 */
	public Connection checkConnection(RDBConnection jgrinderConnection) throws SQLException;
	/**
	 *  Release the connection back into the wild.
	 *
	 * @param  jgrinderConnection
	 * @param  connection
	 */
	public void freeConnection(final RDBConnection jgrinderConnection, java.sql.Connection connection);
}
