package com.objectwave.persist.broker;
import com.objectwave.persist.*;

import com.objectwave.persist.PrimaryKeyStrategy;
import java.sql.SQLException;
import java.util.List;
import com.objectwave.logging.MessageLog;
/**
 *  Use a sequence called GLOBAL_UID_SEQ to generate primary key values.
 *  This is different from GlobalSequence in that it uses the SQL92 standard
 *  for sequences. GlobalSequence is specific to Oracle.
 *
 * @author  David Hoag
 * @version  $Id: StandardSqlSequence.java,v 1.2 2002/08/26 20:14:06 dave_hoag Exp $
 */
public class StandardSqlSequence implements PrimaryKeyStrategy
{
	//The sequence number from the database * 100
	protected int pkeyPool;
	//Start at -1 to be initialized
	protected int currentPkey = -1;
	String sequenceName = "GLOBAL_UID_SEQ";
	/**
	 *  Constructor for the StandardSqlSequence object
	 */
	public StandardSqlSequence()
	{
	}
	/**
	 * @param  aValue The new SequenceName value
	 */
	public void setSequenceName(String aValue)
	{
		sequenceName = aValue;
	}
	/**
	 * @return  The SequenceColumnName value
	 */
	public String getSequenceName()
	{
		return sequenceName;
	}
	/**
	 * This will provide the next sequence number. 
	 *
	 * @param  broker
	 * @param  pObj
	 * @return
	 * @exception  SQLException
	 * @exception  QueryException
	 */
	public Object nextPrimaryKey(final RDBBroker broker, final RDBPersistence pObj) throws SQLException, QueryException
	{
		if(pkeyPool < 0)
		{
			//Attempt to get the value not within synchronized code
			//Worst case is that a sequence number is never used 
			pkeyPool = getSequenceValue( broker );
		}
		final int pkey = getNextVal( broker );
		return new Integer(pkey);
	}
	/**
	 * Provide the next unique primary key value. 
	 * To optimize performance we actully multiply the sequence by 100.
	 * In essence, every sequence number represents a possible 100 primary
	 * key values.
	 *
	 * @param  broker The instance requesting the primary key value 
	 * @return int A unique primary key value
	 */
	protected synchronized int getNextVal(final RDBBroker broker) throws SQLException, QueryException
	{
		//While we hope to never enter this method with a negative value
		//the current synchronization could allow it to happen
		if(pkeyPool < 0)
		{
			pkeyPool = getSequenceValue( broker );
		}
		int pkey = pkeyPool * 100 + currentPkey++;
		if(currentPkey == 100)
		{
			pkeyPool = -1;
			currentPkey = 0;
		}
		return pkey;
	}
	/**
	 * Use select NEXTVAL( sequenceName ) to get the next sequence value
	 * @param  broker The instance requesting the primary key value 
	 */
	protected int getSequenceValue(final RDBBroker broker) throws SQLException, QueryException
	{
		String sql = "select NEXTVAL( '" + getSequenceName() + "' )";
		List result = broker.getConnection().executeQuery(sql, 1);
		if( result.size() != 1 )
		{
			MessageLog.debug(this, "Failed to get sequence value - unexpected number of results!");
			throw new QueryException( "Failed to get sequence value - unexpected number of results!", null);
		}
		String [] value = (String[]) result.get(0);
		return Integer.parseInt( value[0] );
	}
}
