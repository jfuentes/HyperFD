package com.objectwave.persist.collectionAdapters;

import java.util.HashMap;
import java.util.Iterator;
import com.objectwave.persist.CollectionAdapter;
import com.objectwave.persist.SQLQuery;
/**
 * Collection Adapters were introduced to support multiple collection
 * types within the JavaGrinder Framework.
 * @version 1.0
 */
public class HashMapCollectionAdapter implements CollectionAdapter
{
	HashMap dataObject = new HashMap();
	public Object firstElement()
	{
		Iterator i = dataObject.values().iterator();
		if(i.hasNext())
		{
			return i.next();
		}
		return null;
	}
    /**
     * An entry point to tweak the query before issuing the find.
     * This will be a noop for most CollectionAdapters.
     */
    public void preQuery(SQLQuery q){}
	/**
	 * Get the actual collection object.
	 * @return java.util.Vector
	 */
	public Object getCollectionObject()
	{
		return dataObject;
	}
	/**
	 * Add the object to this collection.
     * Override this method if you define your own collection adapter.
	 */
    public void addElement(Object obj)
    {
    	dataObject.put(obj.toString(), obj);
    }
    /**
     * The number of elements in the collection.
     */
    public int size()
    {
    	return dataObject.size();
    }
    /**
     */
	public CollectionAdapter getNewInstance()
	{
		return new HashMapCollectionAdapter();
	}

}
