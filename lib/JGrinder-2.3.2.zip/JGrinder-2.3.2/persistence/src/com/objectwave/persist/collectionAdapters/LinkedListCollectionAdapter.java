package com.objectwave.persist.collectionAdapters;

import java.util.LinkedList;
import com.objectwave.persist.CollectionAdapter;
import com.objectwave.persist.SQLQuery;
/**
 * Collection Adapters were introduced to support multiple collection
 * types within the JavaGrinder Framework.
 * @version 1.0
 */
public class LinkedListCollectionAdapter implements CollectionAdapter
{
	LinkedList dataObject = new LinkedList();
    /**
     */
	public Object firstElement()
	{
		return dataObject.getFirst();
    }
    /**
     * An entry point to tweak the query before issuing the find.
     * This will be a noop for most CollectionAdapters.
     */
    public void preQuery(SQLQuery q){}
	/**
	 * Get the actual collection object.
	 * @return java.util.Vector
	 */
	public Object getCollectionObject()
	{
		return dataObject;
	}
	/**
	 * Add the object to this collection.
	 */
    public void addElement(Object obj)
    {
    	dataObject.add( obj);
    }
    /**
     * The number of elements in the collection.
     */
    public int size()
    {
    	return dataObject.size();
    }
    /**
     */
	public CollectionAdapter getNewInstance()
	{
		return new LinkedListCollectionAdapter();
	}

}
