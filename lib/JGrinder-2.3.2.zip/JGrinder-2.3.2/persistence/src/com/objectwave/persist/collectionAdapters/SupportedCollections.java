package com.objectwave.persist.collectionAdapters;

import com.objectwave.persist.SQLQuery;
import java.util.Properties;
import java.util.Enumeration;

/**
 * This class is nothing more than a place holder to initialize predefined supported
 * collections.
 * The registered collections are the default collection adpaters for the registered
 * class type. This can be overridden by explicitly setting the collection adapter
 * on the SQLQuery object.
 *
 * @version 1.2
 * @author Dave Hoag
 */
public class SupportedCollections
{
	/**
	 * The default behavior is to initialize the collections with defaults.
	 */
	public SupportedCollections()
	{
		this(true);
	}
	/**
	 * The default behavior is to initialize the collections with defaults.
	 */
	public SupportedCollections(Properties props)
	{
		this(true, props);
	}
	/**
	 * The default behavior is to initialize the collections with defaults.
	 */
	public SupportedCollections(boolean useDefaults)
	{
		this(useDefaults, null);
	}
	/**
	 * If using the defaults, first set up those collection adapters;
	 * If props is not null, then add those to the list of CollectionAdapters.
	 */
	public SupportedCollections(boolean useDefaults, Properties props)
	{
		if(useDefaults)
			initializeDefaults();
		if(props != null)
			initialize(props);
	}
/**
 * 
 * @author Dave Hoag
 * 
 * @param collectionClassName java.lang.String 
 * @param adapterClassName java.lang.String The class must implement the CollectionAdapter interface in Persist.
 * @see com.objectwave.persist.CollectionAdapter
 */
public void addCollection(String collectionClassName, String adapterClassName) throws ClassNotFoundException
{
	Class collectionClass = Class.forName(collectionClassName);
	Class adapterClass = Class.forName(adapterClassName);
	SQLQuery.registerCollectionAdapter(collectionClass, adapterClass);
}
	/**
	 * Register the collection classes in the properties parameter.
	 * 'collectionClassName=adapterClassName'
	 * 'java.util.Hashtable=com.objectwave.persist.collectionAdapters.HashtableCollectionAdapter'
	 * @param NameValue pairs that provide the collection class name and the collection adapter class name.
	 * @see com.objectwave.persist.CollectionAdapter
	 */
	public void initialize(Properties props)
	{
		Enumeration e = props.propertyNames();
		String collectionClassName = null;
		while(e.hasMoreElements())
		{
		try { 
				collectionClassName = (String)e.nextElement();
				String adapterClassName = props.getProperty(collectionClassName);
				addCollection(collectionClassName, adapterClassName);
			} catch (Exception ex)
				{
					com.objectwave.persist.BrokerFactory.println("Did not register collection " + collectionClassName);
					com.objectwave.persist.BrokerFactory.println('\t' + e.toString());
				}
		}
	}
	/**
	 * JavaGrinder predefined support collections.
	 * NOTE: Vector is not in this list, since that is the SQLQuery default collection type.
	 */
	public void initializeDefaults()
	{
		Properties props = new Properties();
		props.put("java.util.Hashtable", "com.objectwave.persist.collectionAdapters.HashtableCollectionAdapter");
		props.put("java.util.ArrayList", "com.objectwave.persist.collectionAdapters.ArrayListCollectionAdapter");
		props.put("java.util.LinkedList", "com.objectwave.persist.collectionAdapters.LinkedListCollectionAdapter");
		props.put("java.util.HashMap", "com.objectwave.persist.collectionAdapters.HashMapCollectionAdapter");
//		props.put("java.util.Vector", "com.objectwave.persist.collectionAdapters.VectorCollectionAdapter");
		initialize(props);
	}
}
