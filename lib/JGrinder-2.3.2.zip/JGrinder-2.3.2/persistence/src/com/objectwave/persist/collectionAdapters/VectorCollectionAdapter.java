package com.objectwave.persist.collectionAdapters;
import com.objectwave.persist.CollectionAdapter;
import com.objectwave.persist.SQLQuery;
import java.util.ArrayList;

import java.util.Vector;
/**
 *  Collection Adapters were introduced to support multiple collection types
 *  within the JavaGrinder Framework.
 *
 * @author  dhoag
 * @version  $Id: VectorCollectionAdapter.java,v 2.0 2001/06/11 16:00:04 dave_hoag Exp $
 */
public class VectorCollectionAdapter implements CollectionAdapter
{
	ArrayList dataObject = new ArrayList();
	Vector specifiedResult = null;
	/**
	 *  Sets the DataObject attribute of the VectorCollectionAdapter object
	 *
	 * @param  v The new DataObject value
	 */
	public void setDataObject(Vector v)
	{
		specifiedResult = v;
	}
	/**
	 *  Get the actual collection object.
	 *
	 * @return  java.util.Vector
	 */
	public Object getCollectionObject()
	{
		if(specifiedResult != null)
		{
			return specifiedResult;
		}
		Vector result = new Vector();
		result.addAll(dataObject);
		return result;
	}
	/**
	 * @return  The NewInstance value
	 */
	public CollectionAdapter getNewInstance()
	{
		return new VectorCollectionAdapter();
	}
	/**
	 * @return
	 */
	public Object firstElement()
	{
		Object result = null;
		if(specifiedResult != null)
		{
			result = specifiedResult.firstElement();
		}
		else
		{
			if(dataObject.size() > 0)
			{
				result = dataObject.get(0);
			}
		}
		return result;
	}
	/**
	 *  An entry point to tweak the query before issuing the find. This will be a
	 *  noop for most CollectionAdapters.
	 *
	 * @param  q
	 */
	public void preQuery(SQLQuery q)
	{
	}
	/**
	 *  Add the object to this collection.
	 *
	 * @param  obj The feature to be added to the Element attribute
	 */
	public void addElement(Object obj)
	{
		if(specifiedResult != null)
		{
			specifiedResult.add(obj);
		}
		else
		{
			dataObject.add(obj);
		}
	}
	/**
	 *  The number of elements in the collection.
	 *
	 * @return
	 */
	public int size()
	{
		if(specifiedResult != null)
		{
			return specifiedResult.size();
		}
		return dataObject.size();
	}
}
