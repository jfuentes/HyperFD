/*
 *  Copyright (C) 2001 David Hoag
 *  ObjectWave Corporation
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *  For a full copy of the license see:
 *  http://www.opensource.org/licenses/lgpl-license.html
 */
package com.objectwave.persist.constraints;
import com.objectwave.event.StatusManager;
import com.objectwave.logging.MessageLog;
import com.objectwave.persist.*;
import com.objectwave.utility.StringManipulator;
import java.io.IOException;
import java.io.Serializable;
import java.lang.reflect.Field;

import java.text.ParseException;
import java.util.*;
/**
 *  Abstract class for all query constraints. Remember, after creating one of
 *  these guys, you should add a line to the ConstraintFactory's static{} block.
 *
 * @author  Steven Sinclair
 * @version  $Id: Constraint.java,v 2.1 2002/02/08 22:41:28 dave_hoag Exp $
 */
public abstract class Constraint implements Cloneable, Serializable
{
	protected static ObjectFormatter defaultObjectFormatter;

	private static java.text.DateFormat dateTimeFormat = new java.text.SimpleDateFormat("MM-dd-yyyy hh:mm:ss");
	private static java.text.DateFormat dateFormat = new java.text.SimpleDateFormat("yyyy/MM/dd");
	protected String columnName;
	//Allow the brokers to change the instance of the object formatter
	protected transient ObjectFormatter objectFormatter;
	/**
	 *  This is a required field. This is the name of the field on the persistent
	 *  object. It will be mapped to a database column.
	 */
	private String field = "";
	private boolean not = false;
	/**
	 *  This is a required field. With out this, the actual database column can not
	 *  be determined.
	 */
	private Persistence p;
	/**
	 */
	public Constraint()
	{
	}
	/**
	 *  This is a handy method for formatting output and validating input for
	 *  specific fields. baseObj would presumably be getPersistence().
	 *
	 * @param  field
	 * @param  baseObj
	 * @return
	 * @exception  NoSuchFieldException
	 */
	protected static Class classOfField(String field, Object baseObj)
			 throws NoSuchFieldException
	{
		//int,double,boolean,String,Date,DateWithoutTime
		if(field == null || baseObj == null)
		{
			return null;
		}
		Vector segments = StringManipulator.stringToVector(field, '\\', '.');
		Class c = baseObj.getClass();
		for(Enumeration e = segments.elements(); e.hasMoreElements(); )
		{
			boolean foundField = false;
			//each enumeration needs to find the field
			final String fieldName = (String) e.nextElement();
			while(c != Object.class)
			{
				try
				{
					c = c.getDeclaredField(fieldName).getType();
					foundField = true;
					break;
					//Success, move on to next segment
				}
				catch(NoSuchFieldException ex)
				{
					c = c.getSuperclass();
				}
			}
			if(!foundField)
			{
				throw new NoSuchFieldException("No field " + field + " in class " + baseObj.getClass());
			}
		}
		return c;
	}
	/**
	 *  Provide a generic method for converting a string to a SQL-type string:
	 *
	 * @param  str
	 * @return
	 */
	protected static String sqlString(String str)
	{
		StringBuffer ret = new StringBuffer(str.length() + 2);
		ret.append('\'');
		for(int i = 0; i < str.length(); ++i)
		{
			switch (str.charAt(i))
			{
				case '\'':
					ret.append("\\\'");
					break;
				case '\"':
					ret.append("\\\"");
					break;
				case '\r':
				case '\n':
					ret.append("\\n");
					break;
				default:
					ret.append(str.charAt(i));
			}
		}
		ret.append('\'');
		return ret.toString();
	}
	/**
	 * @param  value The new ObjectFormatter value
	 */
	public void setObjectFormatter(final ObjectFormatter value)
	{
		objectFormatter = value;
	}
	/**
	 *  Sets the Field attribute of the Constraint object
	 *
	 * @param  field The new Field value
	 */
	public void setField(String field)
	{
		this.field = field;
	}
	/**
	 *  Sets the Not attribute of the Constraint object
	 *
	 * @param  not The new Not value
	 */
	public void setNot(boolean not)
	{
		this.not = not;
	}
	/**
	 *  Sets the Persistence attribute of the Constraint object
	 *
	 * @param  p The new Persistence value
	 */
	public void setPersistence(Persistence p)
	{
		this.p = p;
	}
	/**
	 * @param  colName The new ColumnName value
	 */
	public void setColumnName(final String colName)
	{
		columnName = colName;
	}
	/**
	 * @return  The ObjectFormatter value
	 */
	public ObjectFormatter getObjectFormatter()
	{
		if(objectFormatter == null)
		{
			return defaultObjectFormatter;
		}
		return objectFormatter;
	}
	/**
	 *  A given constraint instance will be associated with a field. Since most
	 *  constraints can be preceeded by "not", it has been defined here, in the
	 *  base class.
	 *
	 * @return  The Field value
	 */
	public String getField()
	{
		return field;
	}
	/**
	 *  Gets the Not attribute of the Constraint object
	 *
	 * @return  The Not value
	 */
	public boolean getNot()
	{
		return not;
	}
	/**
	 *  The field is specified as a field on a given persistent object. This is the
	 *  persistent object with that field.
	 *
	 * @return  The Persistence value
	 */
	public Persistence getPersistence()
	{
		return p;
	}
	/**
	 *  Gets the StaticList attribute of the Constraint object
	 *
	 * @return  The StaticList value
	 */
	public abstract Enumeration getStaticList();
	/**
	 *  This is a unique, readable string identifying the constraint type (ex,
	 *  anyof, null)
	 *
	 * @return  The Type value
	 */
	public abstract String getType();
	/**
	 * @return  true If the constraint object should use the comparison value from
	 *      the persistent object.
	 */
	public boolean isComparisonValueFromPersistentObject()
	{
		return false;
	}
	/**
	 * @return  The UsingColumnName value
	 */
	public boolean isUsingColumnName()
	{
		return false;
	}
	/**
	 * @return  The ColumnName value
	 */
	public String getColumnName()
	{
		return columnName;
	}
	/**
	 *  Check to see if a given object passes this constraint.
	 *
	 * @param  dataField
	 * @param  queryField
	 * @return  <b><i>boolean:</i> </b> true iif the object <b>dataField</b> is
	 *      acceptable by the rules of this constraint instance.
	 */
	public abstract boolean checkConstraint(Object dataField, Object queryField);
	/**
	 * @param  query
	 * @param  poolElement
	 * @param  dataField
	 * @param  queryField
	 * @return
	 */
	public boolean checkConstraint(SQLQuery query, Persistence poolElement, Object dataField, Object queryField)
	{
		return checkConstraint(dataField, queryField);
	}
	/**
	 *  Publicize the clone method.
	 *
	 * @return
	 * @exception  CloneNotSupportedException
	 */
	public Object clone() throws CloneNotSupportedException
	{
		return super.clone();
	}
	/**
	 *  Return the string which will appear in the query string. That is, what
	 *  should follow the field specification? (ex, "NOT IN ('cat','dog')"). If
	 *  this constraint is simply an operator, and the original comparison value
	 *  should go on the RHS, then the last character should be a '*'. Ex, If the
	 *  field is "quote.status", and the field' value has been specified to be
	 *  "Q%", then returning "MATCHES*" will produce "quote.status MATCHES Q%". Ex,
	 *  Using the above example, returning "NOT IN ('cat','dog')" will produce
	 *  "quote.status NOT IN ('cat','dog')". Note that the returned string is never
	 *  padded with spaces. Note that this method will return null if the string
	 *  cannot be constructed for some reason (an messafe will already have been
	 *  presented to the user. Perhaps I should delegate that responsability to the
	 *  calling method... hmmm....)
	 *
	 * @return
	 */
	public abstract String constructQueryString();
	/**
	 *  A rudimentary but effective equals() method for subclasses of Constraint.
	 *
	 * @param  obj
	 * @return
	 */
	public boolean equals(Object obj)
	{
		return this.getClass().isInstance(obj)
				 ? constructQueryString().equals(((Constraint) obj).constructQueryString())
				 : false;
	}
	/**
	 * @param  field
	 * @return
	 */
	public boolean findField(String field)
	{
		for(Enumeration e = getStaticList(); e.hasMoreElements(); )
		{
			if(field.equals(e.nextElement()))
			{
				return true;
			}
		}
		return false;
	}
	/**
	 *  Parse the string. Probably a string encoded via the toString() call, this
	 *  method attempts to build the object's state from the information in string
	 *  "str".
	 *
	 * @param  str
	 * @exception  ParseException
	 */
	public abstract void fromString(String str) throws ParseException;
	/**
	 *  Each type of constraint will have a specific set of fields associated with
	 *  it. This is to allow the user to select them via Gui.
	 *
	 * @param  field
	 */
	public abstract void staticListInsert(String field);
	/**
	 *  Stringify the object. Object serialization may be a better approach. Oh
	 *  well. Encode the class's type and state in a readable string.
	 *
	 * @return
	 */
	public abstract String stringify();
	/**
	 *  toString returns the stringified object.
	 *
	 * @return
	 */
	public String toString()
	{
		return stringify();
	}
	/**
	 *  This is to abstract the need to get input in the correct format for a given
	 *  field object, based on the class of the field indicated by getField() and
	 *  getPersistence(). If either are null, or if the string getField() doesn't
	 *  indicate a path to a real field, starting at the class of object
	 *  getPersistence(), then a NoSuchFieldException is thrown. Otherwise, the
	 *  method returns if 'input' is a recognizable format for the class indicated
	 *  by getField(). If the input string is a bad format, then a ParseException
	 *  is thrown. If the class indicated by getField() is not one of int, long,
	 *  float, double, boolean, Integer, Long, Float, Double, Boolean, String,
	 *  Date, or DateWithoutTime, then a just the input is returned. The returned
	 *  is as a SQL-argument style version of the input.
	 *
	 * @param  input
	 * @return
	 * @exception  NoSuchFieldException
	 * @exception  ParseException
	 * @exception  NumberFormatException
	 */
	protected String formatString(final String input) throws NoSuchFieldException, ParseException, NumberFormatException
	{
		if(getField() == null || getPersistence() == null)
		{
			throw new NoSuchFieldException("The base object or the field string was null.");
		}
		Class c = classOfField(getField(), getPersistence());

		if(Persistence.class.isAssignableFrom(c))
		{
			RDBPersistence persist = (RDBPersistence) getPersistence().getAdapter();
			c = persist.getPrimaryAttributeDescription().getField().getType();
		}

		try
		{
			Object typedObject = getObjectFormatter().convertString(c, input);
			return getObjectFormatter().formatValue(typedObject);
		}
		catch(IOException ex)
		{
			MessageLog.debug(this, "Translating IOException", ex);
			throw new ParseException("Failed to format '" + input + "' into a " + c, 0);
		}
	}
	/**
	 * @param  str java.lang.String
	 * @param  classOfStr java.lang.Class
	 * @return  java.lang.Object
	 */
	protected Object stringToObject(final String str, final Class classOfStr)
	{
		return getObjectFormatter().convertString(classOfStr, str);
	}
	static
	{
		try
		{
			defaultObjectFormatter = new ObjectFormatter();
		}
		catch(Throwable t)
		{
			//We never expect any exceptions, but if one occurs, this will help debugging.

			System.out.println("Unable to use the constraint class. The ObjectFormatter could not be instantiated. " + t);
		}
	}
}
