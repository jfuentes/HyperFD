/*
 *  Copyright (C) 2001 David Hoag
 *  ObjectWave Corporation
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *  For a full copy of the license see:
 *  http://www.opensource.org/licenses/lgpl-license.html
 */
package com.objectwave.persist.constraints;
import com.objectwave.logging.MessageLog;
import com.objectwave.persist.*;
import com.objectwave.persist.examples.*;
import com.objectwave.utility.StringManipulator;
import com.objectwave.utility.StringifyIF;
import java.text.ParseException;
import java.util.*;
/**
 *  Define & manage the "any of" and "not any of" constraints.
 *
 * @author  Steven Sinclair
 * @version  $Id: ConstraintAnyOf.java,v 2.2 2002/03/23 13:42:10 dave_hoag Exp $
 */
public class ConstraintAnyOf extends Constraint
{
	static Vector fields = new Vector();

	Vector anyOf = new Vector(0);
	/**
	 * @return  The Fields value
	 */
	public static Vector getFields()
	{
		return fields;
	}
	/**
	 * @param  anyOf The new AnyOf value
	 */
	public void setAnyOf(Vector anyOf)
	{
		this.anyOf = anyOf;
	}
	/**
	 * @return  The AnyOf value
	 */
	public Vector getAnyOf()
	{
		return anyOf;
	}
	/**
	 * @return  The StaticList value
	 */
	public Enumeration getStaticList()
	{
		return fields.elements();
	}
	/**
	 * @return  The Type value
	 */
	public String getType()
	{
		return "anyof";
	}

	/**
	 *  Check if the dataField is in the list of previously defined fields.
	 *
	 * @param  dataField The data from an object in the 'pool'.
	 * @param  queryField The data from the Query object. Not used in an anyOf
	 *      comparison.
	 * @return  boolean The result of the constraint comparison
	 */
	public boolean checkConstraint(Object dataField, Object queryField)
	{
		if(dataField == null)
		{
			return true;
		}
		if(getAnyOf() == null || getAnyOf().size() == 0)
		{
			return getNot();
		}
		Class fieldClass = dataField.getClass();
		Enumeration e = getAnyOf().elements();
		while(e.hasMoreElements())
		{
			String str = (String) e.nextElement();
			Object obj = stringToObject(str, fieldClass);
			if(obj == null)
			{
				// the anyOf element didn't parse properly: ignore.

				System.out.println("The \"any of\" constraint value \"" + str + "\" couldn't be parsed into");
				System.out.println("an object of type " + fieldClass);
				continue;
			}
			if(obj.equals(dataField))
			{
				return !getNot();
			}
		}
		return getNot();
	}
	/**
	 *  Create as string representing an anOf constraint.
	 *
	 * @return  String The in or not in portion of a where clause.
	 */
	public String constructQueryString()
	{
		StringBuffer buf = new StringBuffer();
		if(getNot())
		{
			buf.append("NOT IN ");
		}
		else
		{
			buf.append("IN ");
		}

		if(createAnyOfString(buf))
		{
			return buf.toString();
		}
		else
		{
			return null;
		}
	}
	/**
	 * @param  str Description of Parameter
	 * @exception  ParseException Description of Exception
	 */
	public void fromString(String str) throws ParseException
	{
		Vector portions = StringManipulator.stringToVector(str, '\\', ':');
		if(portions.size() != 4)
		{
			throw new ParseException("Expected exactly 3 colon-separated substrings.", 0);
		}
		if(!((String) portions.firstElement()).equals(getType()))
		{
			throw new ParseException("First substring must be \"" + getType() + "\".", 0);
		}

		setNot("true".equals((String) portions.elementAt(1)));
		setField((String) portions.elementAt(2));
		anyOf = StringManipulator.stringToVector((String) portions.elementAt(3), '\\', '|');
	}
	/**
	 * @param  field Description of Parameter
	 */
	public void staticListInsert(String field)
	{
		fields.addElement(field);
	}
	/**
	 * @return  a readable string revealing the contents
	 */
	public String stringify()
	{
		Vector v = new Vector(4);
		v.addElement(getType());
		v.addElement("" + getNot());
		v.addElement(getField());
		v.addElement(StringManipulator.vectorToString(anyOf, '\\', '|'));
		return StringManipulator.vectorToString(v, '\\', ':');
	}
	/**
	 * @param  buf The string buffer being assembled.
	 * @return  true if we are to send the buffer on, false if there were no
	 *      values.
	 * @author  Dave Hoag
	 */
	protected boolean createAnyOfString(final StringBuffer buf)
	{
		// Format the "any of" arguments to the type of id used.
		//
		buf.append('(');
		boolean formatOk = false;
		try
		{
			int size = getAnyOf().size();
			for(int i = 0; i < size; ++i)
			{
				String str = formatString((String) getAnyOf().elementAt(i));
				buf.append(str);
				if(i + 1 < size)
				{
					buf.append(',');
				}
			}
			formatOk = true;
			buf.append(')');
		}
		catch(NoSuchFieldException ex)
		{
			MessageLog.debug(this, "Failed to create sql query string", ex);
		}
		catch(java.text.ParseException ex)
		{
			MessageLog.debug(this, "Failed to create sql query string", ex);
		}
		catch(NumberFormatException ex)
		{
			MessageLog.debug(this, "Failed to create sql query string", ex);
		}

		return formatOk;
	}
	/**
	 *  Unit test of some simple AnyOf values.
	 *
	 * @author  dhoag
	 * @version  $Id: ConstraintAnyOf.java,v 2.2 2002/03/23 13:42:10 dave_hoag Exp $
	 */
	public static class Test extends com.objectwave.test.UnitTestBaseImpl
	{
		short sh;
		/**
		 *  The main program for the Test class
		 *
		 * @param  args The command line arguments
		 */
		public static void main(String[] args)
		{
			com.objectwave.test.TestRunner.run(new Test(), args);
		}
		/**
		 *  A unit test for JUnit
		 */
		public void testConstructQueryString()
		{
			Vector v = new Vector();
			v.addElement("1");
			v.addElement("2");
			ConstraintAnyOf c = new ConstraintAnyOf();
			c.setAnyOf(v);
			c.setPersistence(new ExampleEmployee());
			c.setField("emailAddress");
			testContext.assertEquals("IN ('1','2')", c.constructQueryString());
			c.setNot(true);
			testContext.assertEquals("NOT IN ('1','2')", c.constructQueryString());
		}
		/**
		 *  A unit test for JUnit
		 *
		 * @exception  Throwable Description of Exception
		 */
		public void testCheckConstraint() throws Throwable
		{
			Vector v = new Vector();
			v.addElement("1");
			v.addElement("2");
			ConstraintAnyOf c = new ConstraintAnyOf();
			c.setField("side");
			c.setAnyOf(v);
			java.lang.reflect.Field f = Test.class.getDeclaredField("sh");
			sh = 1;
			Object obj = f.get(this);
			testContext.assertTrue("AnyOf value not found in list", c.checkConstraint(obj, new Short((short) 0)));
			sh = 4;
			obj = f.get(this);
			testContext.assertTrue("Any of value incorrectly found in list", !c.checkConstraint(obj, new Short((short) 0)));
		}

	}

	static
	{
		ConstraintGuiSelection.getInstance().mapClassNameToGuiClass(ConstraintAnyOf.class.getName(), "com.objectwave.persist.constraints.gui.AnyOfGui");
	}
}
