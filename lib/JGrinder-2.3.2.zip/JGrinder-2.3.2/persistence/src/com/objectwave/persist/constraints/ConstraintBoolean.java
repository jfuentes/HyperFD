package com.objectwave.persist.constraints;

import java.text.ParseException;
import java.util.*;
import com.objectwave.persist.*;
import com.objectwave.persist.examples.*;
/**
 * Use this to create multiple constraints on a single field.
 *
 * @author Dave Hoag
 * @version $Id: ConstraintBoolean.java,v 2.0 2001/06/11 16:00:04 dave_hoag Exp $
 */
public class ConstraintBoolean extends Constraint
{
	static Vector fields = new Vector();
    boolean isAnd;
    Constraint left, right;
    /**
     * @param and true if this is an and and false if this is an or
     */
    public ConstraintBoolean(boolean and, Constraint first, Constraint second)
    {
        isAnd = and;
        left = first;
        right = second;
    }
	/**
	* @return boolean
	* @param fieldObj java.lang.Object
	* @param queryObj java.lang.Object
	*/
	public boolean checkConstraint(final Object fieldObj, final Object queryObj)
	{
        if(isAnd)
        {
            return left.checkConstraint(fieldObj, queryObj) && right.checkConstraint(fieldObj, queryObj);
        }
        return left.checkConstraint(fieldObj, queryObj) || right.checkConstraint(fieldObj, queryObj);
	}
	/**
	 */
	public String constructQueryString()
	{
        String andString = " OR ";
        if(isAnd)
        {
            andString = " AND ";
        }
        if(getColumnName() == null) throw new IllegalStateException("Attempted to create a query constraint without knowning the column name.");
        return "(" + getColumnName() + ' ' + left.constructQueryString() + andString + getColumnName() + ' '+ right.constructQueryString() + ")";
	}
	/**
	 */
	public void fromString(String str) throws ParseException
	{
        throw new RuntimeException("Not implemented");
	}
	public static Vector getFields() { return fields; }
	/**
	 */
	public Enumeration getStaticList() { return fields.elements(); }
	/**
	 */
	public String getType() { return "boolean"; }
	/**
	 */
	public void staticListInsert(String field)
	{
		fields.addElement(field);
	}
	/**
	 */
	public String stringify()
	{
        String andString = " AND ";
        if( ! isAnd)
        {
            andString = " OR ";
        }
        return getField() +  " ( " + left + andString  + right + ")";
	}
	/**
	 * Unit test of some simple Between values.
	 */
	public static class Test extends com.objectwave.test.UnitTestBaseImpl
	{
        public void testOr()
        {
            ConstraintCompare first = new ConstraintCompare();
            first.setCompValue("10");
            first.setComparison("<");
            first.setPersistence(new ExampleEmployee());
            first.setField("objectIdentifier");

            ConstraintCompare second = new ConstraintCompare();
            second.setCompValue("30");
            second.setComparison(">");
            second.setPersistence(new ExampleEmployee());
            second.setField("objectIdentifier");
            ConstraintBoolean bet = new ConstraintBoolean(false, first, second);
            bet.setColumnName("A.one");

            testContext.assertEquals("(A.one < 10 OR A.one > 30)", bet.constructQueryString());
        }
        public void testAnd()
        {
            ConstraintCompare first = new ConstraintCompare();
            first.setCompValue("dave34");
            first.setComparison("<");
            first.setPersistence(new ExampleEmployee());
            first.setField("emailAddress");
            ConstraintCompare second = new ConstraintCompare();
            second.setCompValue("dave");
            second.setComparison(">");
            second.setPersistence(new ExampleEmployee());
            second.setField("emailAddress");
            ConstraintBoolean bet = new ConstraintBoolean(true, first, second);
            bet.setColumnName("A.one");
            testContext.assertEquals("(A.one < 'dave34' AND A.one > 'dave')", bet.constructQueryString());
        }
        public static void main(String [] args)
        {
			com.objectwave.test.TestRunner.run(new Test(), args);
		}

	}
    /**
     */
    public boolean isUsingColumnName()
    {
        return true;
    }
}
