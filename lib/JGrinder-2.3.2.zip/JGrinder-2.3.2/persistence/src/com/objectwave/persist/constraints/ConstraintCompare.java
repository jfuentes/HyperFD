/*
 *  Copyright (C) 2001 David Hoag
 *  ObjectWave Corporation
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *  For a full copy of the license see:
 *  http://www.opensource.org/licenses/lgpl-license.html
 */
package com.objectwave.persist.constraints;

import com.objectwave.logging.MessageLog;
import com.objectwave.persist.*;
import com.objectwave.persist.util.*;
import com.objectwave.utility.StringManipulator;
import java.io.IOException;
import java.text.ParseException;
import java.util.*;
/**
 *  The constraint object to handle the following comparison capabilities.
 *  "LIKE", "MATCHES", "=", "!=", "<", ">=", ">", "<=" .
 *
 * @author  Steven Sinclair
 * @version  $Id: ConstraintCompare.java,v 2.1 2002/02/08 22:41:28 dave_hoag Exp $
 */
public class ConstraintCompare extends Constraint
{
	/**
	 *  Description of the Field
	 */
	public final static int likeIndex = 0;
	/**
	 *  Description of the Field
	 */
	public final static int matchesIndex = 1;
	/**
	 *  Description of the Field
	 */
	public final static int equalsIndex = 2;
	/**
	 *  Description of the Field
	 */
	public final static int notEqualsIndex = 3;
	/**
	 *  Description of the Field
	 */
	public final static int lessThanIndex = 4;
	/**
	 *  Description of the Field
	 */
	public final static int greaterOrEqualIndex = 5;
	/**
	 *  Description of the Field
	 */
	public final static int greaterThanIndex = 6;
	/**
	 *  Description of the Field
	 */
	public final static int lessOrEqualIndex = 7;
	// The ordering of the arithmetic operators is important.
	// (The inverse of the evenly-indexed operators is at index+1)
	//
	static String comparisons[] = {"LIKE", "MATCHES", "=", "!=", "<", ">=", ">", "<="};
	static Vector fields = new Vector();
	private int comparison = equalsIndex;
	private String comparisonValue = "";
	/**
	 * @return  The Comparisons value
	 */
	public static String[] getComparisons()
	{
		return comparisons;
	}
	/**
	 * @return  The Fields value
	 */
	public static Vector getFields()
	{
		return fields;
	}
	/**
	 * @param  index The new Comparison value
	 */
	public void setComparison(int index)
	{
		comparison = index;
	}
	/**
	 * @param  comp The new Comparison value
	 */
	public void setComparison(String comp)
	{
		comparison = equalsIndex;
		for(int i = 0; i < comparisons.length; ++i)
		{
			if(comparisons[i].equalsIgnoreCase(comp))
			{
				comparison = i;
				break;
			}
		}
	}
	/**
	 *  Sets the CompValue attribute of the ConstraintCompare object
	 *
	 * @param  val The new CompValue value
	 */
	public void setCompValue(String val)
	{
		comparisonValue = val;
	}
	/**
	 * @return  The Comparison value
	 */
	public String getComparison()
	{
		return comparisons[comparison];
	}
	/**
	 * @return  The ComparisonIndex value
	 */
	public int getComparisonIndex()
	{
		return comparison;
	}
	/**
	 * @return  The CompValue value
	 */
	public String getCompValue()
	{
		return comparisonValue;
	}
	/**
	 * @return  The StaticList value
	 */
	public Enumeration getStaticList()
	{
		return fields.elements();
	}
	/**
	 * @return  The Type value
	 */
	public String getType()
	{
		return "compare";
	}
	/**
	 * @return  true If the constraint object should use the comparison value from
	 *      the persistent object.
	 */
	public boolean isComparisonValueFromPersistentObject()
	{
		String comp = getCompValue();
		return (comp == null || comp.trim().length() == 0);
	}
	/**
	 * @param  fieldObj java.lang.Object The value being compared.
	 * @param  queryObj java.lang.Object
	 * @return  boolean True if the constraing matches.
	 */
	public boolean checkConstraint(Object fieldObj, Object queryObj)
	{
		if(fieldObj == null)
		{
			return true;
		}

		Object rhs = queryObj;
		if(getCompValue() != null)
		{

			rhs = stringToObject(getCompValue(), fieldObj.getClass());
		}
		if(rhs == null)
		{
			return true;
		}

		String comp = getComparison();

		if(comp == null)
		{
			return true;
		}

		if((comp.equalsIgnoreCase("LIKE") || comp.equalsIgnoreCase("MATCHES"))
				 && (fieldObj instanceof String && !(rhs instanceof String)))
		{
			//If we have a LIKE comparison & both fields are not strings, exit with false
			return false;
		}
		boolean value = false;

		if(Number.class.isInstance(rhs) || Boolean.class.isInstance(rhs))
		{
			double fVal = 0;
			double rVal = 0;

			if(rhs instanceof Number)
			{
				fVal = ((Number) fieldObj).doubleValue();
				rVal = ((Number) rhs).doubleValue();
			}

			else
			{
				fVal = ((Boolean) fieldObj).booleanValue() ? 1 : 0;
				rVal = ((Boolean) rhs).booleanValue() ? 1 : 0;
			}
			if(comp.equals("="))
			{
				value = (fVal == rVal);
			}
			else if(comp.equals("<"))
			{
				value = (fVal < rVal);
			}
			else if(comp.equals(">"))
			{
				value = (fVal > rVal);
			}
			else if(comp.equals("<="))
			{
				value = (fVal <= rVal);
			}
			else if(comp.equals(">="))
			{
				value = (fVal >= rVal);
			}
		}
		else
				if(rhs instanceof String && fieldObj instanceof String)
		{
			value = stringCompare((String) fieldObj, (String) rhs, comp);
		}
		else
				if(rhs instanceof Date && fieldObj instanceof Date)
		{
			value = dateCompare((Date) fieldObj, (Date) rhs, comp);
		}
		else if(DateWithoutTime.class.isInstance(rhs))
		{
			DateWithoutTime fDate = (DateWithoutTime) fieldObj;
			DateWithoutTime rDate = (DateWithoutTime) rhs;
			boolean equal = fDate.equals(rDate);
			if(comp.equals("="))
			{
				value = equal;
			}
			else if(comp.equals("<"))
			{
				value = fDate.before(rDate);
			}
			else if(comp.equals(">"))
			{
				value = rDate.after(rDate);
			}
			else if(comp.equals("<="))
			{
				value = equal || fDate.before(rDate);
			}
			else if(comp.equals(">="))
			{
				value = equal || fDate.after(rDate);
			}
		}
		return getNot() ? !value : value;
	}
	/**
	 * @return  Description of the Returned Value
	 */
	public String constructQueryString()
	{
		String compValue = null;
		try
		{
			compValue = sqlCompValue();
		}
		catch(Exception ex)
		{
			MessageLog.debug(this, "Failed to use ConstraintCompare to generate a sql statement", ex);
			throw new RuntimeException("Failed to succeed at consruting the query string " + ex);
		}

		int opIdx = getComparisonIndex();
		String operator = getComparison();
		if(getNot())
		{
			// Use the opposite operator.
			//
			if(opIdx == likeIndex || opIdx == matchesIndex)
			{
				operator = "NOT " + operator;
			}
			else
			{
				//This relies upon the ordering of the comparisons attribute.
				operator = comparisons[opIdx + ((opIdx % 2 == 0) ? 1 : -1)];
			}
		}
		return operator + " " + compValue;
	}
	/**
	 * @param  str Description of Parameter
	 * @exception  ParseException Description of Exception
	 */
	public void fromString(String str) throws ParseException
	{
		Vector portions = StringManipulator.stringToVector(str, '\\', ':');
		if(portions.size() != 5)
		{
			throw new ParseException("Expected exactly 5 colon-separated substrings.", 0);
		}
		if(!((String) portions.firstElement()).equals(getType()))
		{
			throw new ParseException("First substring must be \"" + getType() + "\".", 0);
		}
		setNot("true".equals((String) portions.elementAt(1)));
		setField((String) portions.elementAt(2));
		String compStr = (String) portions.elementAt(3);
		comparison = -1;
		for(int i = 0; i < comparisons.length; ++i)
		{
			if(comparisons[i].equalsIgnoreCase(compStr))
			{
				comparison = i;
				break;
			}
		}
		if(comparison < 0)
		{
			throw new ParseException("Unknown comparison string \"" + compStr + "\"", 0);
		}
		setCompValue((String) portions.elementAt(4));
	}
	/**
	 * @param  field Description of Parameter
	 */
	public void staticListInsert(String field)
	{
		fields.addElement(field);
	}
	/**
	 *  A nice display version of the object.
	 *
	 * @return  Description of the Returned Value
	 */
	public String stringify()
	{
		Vector v = new Vector(5);
		v.addElement(getType());
		v.addElement("" + getNot());
		v.addElement(getField());
		v.addElement(getComparison());
		v.addElement(getCompValue());

		return StringManipulator.vectorToString(v, '\\', ':');
	}
	/**
	 *  Compare the two dates with the specified comparison operation.
	 *
	 * @param  fDate The left hand argument to the comparison
	 * @param  rDate The right hand argument to the comparison
	 * @param  comp The comparison type. ex. '=', ' <=', etc...
	 * @return  boolean The result of the comparison.
	 */
	protected boolean dateCompare(final Date fDate, final Date rDate, final String comp)
	{
		boolean value = false;
		boolean equal = fDate.equals(rDate);
		if(comp.equals("="))
		{
			value = equal;
		}
		else if(comp.equals("<"))
		{
			value = fDate.before(rDate);
		}
		else if(comp.equals(">"))
		{
			value = rDate.after(rDate);
		}
		else if(comp.equals("<="))
		{
			value = equal || fDate.before(rDate);
		}
		else if(comp.equals(">="))
		{
			value = equal || fDate.after(rDate);
		}
		return value;
	}
	/**
	 *  Compare the two strings with the specified comparison operation. NOTE:
	 *  instanceof is a faster comparison that isInstance
	 *
	 * @param  fStr The left hand argument to the comparison
	 * @param  rStr The right hand argument to the comparison
	 * @param  comp The comparison type. ex. '=', ' <=', etc...
	 * @return  boolean The result of the comparison.
	 */
	protected boolean stringCompare(final String fStr, final String rStr, final String comp)
	{
		boolean value = false;
		int compVal = fStr.compareTo(rStr);
		if(comp.equals("="))
		{
			value = (compVal == 0);
		}
		else if(comp.equals("<"))
		{
			value = (compVal == -1);
		}
		else if(comp.equals(">"))
		{
			value = (compVal == 1);
		}
		else if(comp.equals("<="))
		{
			value = (compVal <= 0);
		}
		else if(comp.equals(">="))
		{
			value = (compVal >= 0);
		}
		else if(comp.equalsIgnoreCase("LIKE"))
		{
			value = StringManipulator.matchesPattern(fStr, rStr, '%', '_');
		}
		else if(comp.equalsIgnoreCase("MATCHES"))
		{
			value = StringManipulator.matchesPattern(fStr, rStr, '*', '?');
		}
		return value;
	}
	/**
	 * @return  Description of the Returned Value
	 * @exception  NoSuchFieldException Description of Exception
	 * @exception  NumberFormatException Description of Exception
	 * @exception  java.text.ParseException Description of Exception
	 * @exception  IOException
	 */
	protected String sqlCompValue() throws NoSuchFieldException, NumberFormatException, java.text.ParseException, IOException
	{
		Class fieldClass = classOfField(getField(), getPersistence());
		if(!fieldClass.equals(String.class) &&
				(getComparisonIndex() == likeIndex ||
				getComparisonIndex() == matchesIndex))
		{
			// 'LIKE' and 'MATCHES' comparison are only valid for
			// string fields.
			//
			MessageLog.debug(this, "LIKE and MATCHES comparisons only valid for string-typed fields.");
			throw new IllegalArgumentException("LIKE and MATCHES comparisons only valid for string-typed fields.");
		}
		String comp = getCompValue();
		if(comp != null && comp.trim().length() > 0)
		{
			return formatString(comp);
		}
		return null;
	}
	/**
	 *  Description of the Class
	 *
	 * @author  dhoag
	 * @version  $Id: ConstraintCompare.java,v 2.1 2002/02/08 22:41:28 dave_hoag Exp $
	 */
	private static class GBC extends java.awt.GridBagConstraints
	{
	}
	static
	{
		ConstraintGuiSelection.getInstance().mapClassNameToGuiClass(ConstraintCompare.class.getName(), "com.objectwave.persist.constraints.gui.CompareGui");
	}
}

