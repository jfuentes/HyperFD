package com.objectwave.persist.constraints;

import java.util.Hashtable;
import java.util.Enumeration;

/**
 *  A factory for the generation and management of Constraint objects.
 */
public class ConstraintFactory
{
	private static Hashtable constraints = new Hashtable(4);

	static
	{
		addConstraint("anyof",   ConstraintAnyOf.class);
		addConstraint("isnull",  ConstraintIsNull.class);
		addConstraint("compare", ConstraintCompare.class);
		addConstraint("between", ConstraintBetween.class);
		addConstraint("subSelect", ConstraintSubSelect.class);
	}

	private static Hashtable staticConstraints;

	public static void addConstraint(String type, Class constraintClass)
	{
		constraints.put(type, constraintClass);
	}
	public static Constraint createConstraint(String type)
	{
		Class c = (Class)constraints.get(type);
		if (c == null)
			return null;
		try { return (Constraint)c.newInstance(); }
		catch (Exception ex) 
		{ 
			System.out.println("Creation error: " + ex);
			return null; 
		}
	}
	public static Enumeration getClasses() { return constraints.elements(); }
	public static int getSize() { return constraints.size(); }
	public static Constraint getStaticInstance(String type)
	{
		if (staticConstraints == null)
			staticConstraints = new Hashtable(getSize());
		Constraint staticInstance = (Constraint)staticConstraints.get(type);
		if (staticInstance == null)
		{
			staticInstance = createConstraint(type);
			staticConstraints.put(type, staticInstance);
		}
		return staticInstance;
	}
	public static Enumeration getTypes()  { return constraints.keys(); }
}
