package com.objectwave.persist.constraints;

/**
 */
public interface ConstraintGuiIF
{
	public void displayObject();
	public void populateObject();
	public void initialize(Constraint c);
}
