package com.objectwave.persist.constraints;

import java.util.*;
/**
 * A 'map' of Constraint classes to GUI objects.
 */
public class ConstraintGuiSelection
{
	Hashtable cache;
	Hashtable actualInstances;
	protected static ConstraintGuiSelection instance;
	/**
	 */
	public static ConstraintGuiSelection getInstance()
	{
		if(instance == null)
		{
			instance = new ConstraintGuiSelection();
		}
		return instance;
	}
	/**
	 */
	public void displayObject(Constraint aConstraint) throws ClassNotFoundException, IllegalAccessException, InstantiationException
	{
		((ConstraintGuiIF)getComponent(aConstraint)).displayObject();
	}
	/**
	 */
	public void populateObject(Constraint aConstraint) throws ClassNotFoundException, IllegalAccessException, InstantiationException
	{
		((ConstraintGuiIF)getComponent(aConstraint)).populateObject();
	}
	/**
	 */
	public ConstraintGuiSelection()
	{
		cache = new Hashtable();
		actualInstances = new Hashtable();
	}
	/**
	 */
	public ConstraintGuiIF getComponent(Constraint aConstraintObject) throws ClassNotFoundException, IllegalAccessException, InstantiationException
	{
		ConstraintGuiIF actualInstance = (ConstraintGuiIF)actualInstances.get(aConstraintObject);
		if(actualInstance ==  null)
		{
			Object classOrName = cache.get(aConstraintObject.getClass().getName());
			if(classOrName instanceof String)
			{
				classOrName = Class.forName((String)classOrName);
				cache.put(aConstraintObject.getClass().getName(), classOrName);
			}
			actualInstance = (ConstraintGuiIF)((Class)classOrName).newInstance();
			actualInstance.initialize(aConstraintObject);
			actualInstances.put(aConstraintObject, actualInstance);
		}
		return actualInstance;
	}
	/**
	 */
	public void mapClassNameToGuiClass(String sourceClassName, String guiClassName)
	{
		cache.put(sourceClassName, guiClassName);
	}

}
