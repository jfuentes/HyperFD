package com.objectwave.persist.constraints;

import java.text.ParseException;
import java.util.*;
import com.objectwave.utility.StringManipulator;
import com.objectwave.utility.StringifyIF;
import com.objectwave.persist.*;

/**
 * @author Steven Sinclair
 */
public class ConstraintIsNull extends Constraint
{
	static Vector fields = new Vector();
	/**
	 * Associate instances of this class with the named gui.
	 * Using this approach eliminates a compile time dependency upon the IsNullGui.
	 * @author Dave Hoag
	 */
	static 
	{
		ConstraintGuiSelection.getInstance().mapClassNameToGuiClass(ConstraintIsNull.class.getName(), "com.objectwave.persist.constraints.gui.IsNullGui");
	}

	/**
	* This method was created in VisualAge.
	* @return boolean
	* @param fieldObject java.lang.Object
	* @param queryObject java.lang.Object
	*/
	public boolean checkConstraint(Object fieldObject, Object queryObject)
	{
		return fieldObject==null ? !getNot() : getNot();
	}
	/**
	 */
	public String constructQueryString()
	{
		return "IS " + (getNot() ? "NOT ":"") + "NULL";
	}
	/**
	 */
	public void fromString(String str) throws ParseException
	{
		Vector portions = StringManipulator.stringToVector(str,'\\',':');
		if (portions.size() != 3)
		{
			throw new ParseException("Expected exactly 2 colon-separated substrings.", 0);
		}
		if ( !((String)portions.firstElement()).equals(getType()))
		{
			throw new ParseException("First substring must be \""+getType()+"\".", 0);
		}
		setNot("true".equals((String)portions.elementAt(1)));
		setField((String)portions.elementAt(2));
	}
	/**
	 */
	public static Vector getFields()
	{
		return fields;
	}
	/**
	 */
	public Enumeration getStaticList() 
	{
		return fields.elements();
	}
	/**
	 */
	public String getType() 
	{
		return "isnull";
	}
	/**
	 */
	public void staticListInsert(String field)
	{
		fields.addElement(field);
	}
	/**
	 */
	public String stringify()
	{
		Vector v = new Vector(3);
		v.addElement(getType());
		v.addElement(""+getNot());
		v.addElement(getField());
		return StringManipulator.vectorToString(v, '\\', ':');
	}
}