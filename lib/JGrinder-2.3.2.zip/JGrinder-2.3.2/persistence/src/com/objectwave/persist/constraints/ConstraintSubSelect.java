package com.objectwave.persist.constraints;

import java.text.ParseException;
import java.util.*;
import com.objectwave.utility.StringManipulator;
import com.objectwave.utility.StringifyIF;
import com.objectwave.persist.*;
import com.objectwave.persist.broker.*;
import com.objectwave.persist.sqlConstruction.SQLSelect;

/**
 * Define & manage the "any of" and "not any of" constraints.
 * @author Steven Sinclair
 * @version 1.1
 */
public class ConstraintSubSelect extends Constraint
{
	static Vector fields = new Vector();

    SQLQuery subSelectQuery = null;

	String subSelectField = null;

    /**
    * Check if the dataField is in the list of previously defined fields.
    *
    * @return boolean The result of the constraint comparison
    * @param dataField The data from an object in the 'pool'.
    * @param queryField The data from the Query object. Not used in an anyOf comparison.
    */
    public boolean checkConstraint(Object dataField, Object queryField)
    {
	    if (dataField == null)
		    return true;
	    if (getSubSelectQuery() == null)
		    return getNot();
		throw new RuntimeException("checkConstraint method not supported for constaint type ConstraintSubSelect");
    }
    /**
     * Create as string representing an anOf constraint.
     *
     * @return String The in or not in portion of a where clause.
     */
	public String constructQueryString()
	{
	    StringBuffer buf = new StringBuffer();
	    if(getNot())
	        buf.append("NOT IN (");
	    else
	        buf.append("IN (");

		buf.append(getQueryStatement());
		buf.append(") ");
		System.out.println("XXXXX - subSelect: \"" + buf + "\"");
		return buf.toString();
	}
	/**
	 *
	 * @param buf The string buffer being assembled.
	 * @return true if we are to send the buffer on, false if there were no values.
	 */
	protected String getQueryStatement()
	{
		try
		{
			if (!(getSubSelectQuery().getBroker() instanceof RDBBroker))
			{
				throw new RuntimeException("The ConstraintSubSelect constraint is only applicable to queries using an RDBBroker broker.");
			}
			RDBBroker broker = (RDBBroker)getSubSelectQuery().getBroker();
			SQLSelect sqlSelect = broker.createAttributeSelect(getSubSelectQuery(), new String[] { getSubSelectField() }, null);
			return sqlSelect.getSqlStatement().toString();
		}
		catch (QueryException ex)
		{
			throw new RuntimeException("SubSelect query build exception: " + ex);
		}
	}
	/**
	 */
	public void fromString(String str) throws ParseException
	{
		throw new RuntimeException("fromString() method not supported for constraint type ConstraintSubSelect.");
	}
	/**
	 */
	public static Vector getFields() { return fields; }
	/**
	 */
	public Enumeration getStaticList()
	{
		return fields.elements();
	}
	/**
	 */
	public String getType()
	{
	    return "subSelect";
    }
	/**
	 */
	public SQLQuery getSubSelectQuery()
	{
		return subSelectQuery;
    }
	/**
	 */
	public String getSubSelectField()
	{
		return subSelectField;
    }
	/**
	 */
	public void setSubSelectQuery(SQLQuery subSelectQuery)
	{
		this.subSelectQuery = subSelectQuery;
    }
	/**
	 */
	public void setSubSelectField(String subSelectField)
	{
		this.subSelectField = subSelectField;
    }
	/**
	 */
	public void staticListInsert(String field)
	{
		fields.addElement(field);
	}
	/**
	 * @return a readable string revealing the contents
	 */
	public String stringify()
	{
		return "subSelect on field " + getSubSelectField() + " query " + subSelectQuery;
	}
}
