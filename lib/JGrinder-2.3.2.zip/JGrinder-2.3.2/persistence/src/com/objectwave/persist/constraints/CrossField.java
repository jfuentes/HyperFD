/*
 *  Copyright (C) 2001 David Hoag
 *  ObjectWave Corporation
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *  For a full copy of the license see:
 *  http://www.opensource.org/licenses/lgpl-license.html
 */
package com.objectwave.persist.constraints;
import com.objectwave.exception.NotFoundException;
import com.objectwave.logging.MessageLog;
import com.objectwave.persist.*;
import com.objectwave.persist.examples.*;

import java.text.ParseException;
import java.util.*;
/**
 *  Use this to create multiple constraints on a multiple fields.
 *
 * @author  Dave Hoag
 * @version  $Id: CrossField.java,v 2.2 2002/02/08 22:41:28 dave_hoag Exp $
 */
public class CrossField extends Constraint
{
	static Vector fields = new Vector();
	boolean isAnd;
	Constraint left, right;
	/**
	 * @param  and true if this is an and and false if this is an or
	 * @param  first
	 * @param  second
	 */
	public CrossField(boolean and, Constraint first, Constraint second)
	{
		isAnd = and;
		left = first;
		right = second;
	}
	/**
	 *  Gets the Fields attribute of the CrossField class
	 *
	 * @return  The Fields value
	 */
	public static Vector getFields()
	{
		return fields;
	}
	/**
	 * @return  The StaticList value
	 */
	public Enumeration getStaticList()
	{
		return fields.elements();
	}
	/**
	 * @return  The Type value
	 */
	public String getType()
	{
		return "boolean";
	}
	/**
	 * @return  The UsingColumnName value
	 */
	public boolean isUsingColumnName()
	{
		return true;
	}
	/**
	 * @return  The Alias value
	 */
	protected String getAlias()
	{
		if(getColumnName() != null)
		{
			int idx = getColumnName().indexOf('.');
			if(idx > -1)
			{
				return getColumnName().substring(0, idx + 1);
			}
		}
		return "";
	}
	/**
	 * Do nothing - now uses the other constraint check method
	 *
	 * @param  one
	 * @param  two
	 * @return
	 */
	public boolean checkConstraint(Object one, Object two)
	{
		return false;
	}
	/**
	 * @param  fieldObj java.lang.Object
	 * @param  queryObj java.lang.Object
	 * @param  query
	 * @param  poolElement
	 * @return  boolean
	 */
	public boolean checkConstraint(final SQLQuery query, final Persistence poolElement, final Object fieldObj, final Object queryObj)
	{
		try
		{

			RDBPersistence rdbPersistence = (RDBPersistence) poolElement.getAdapter();
			AttributeTypeColumn col = rdbPersistence.findColumnMap(left.getField());
			Object leftFieldValue = col.getValue(poolElement);
			Object leftQueryValue = col.getValue(query.getSubject());
			col = rdbPersistence.findColumnMap(right.getField());
			Object rightFieldValue = col.getValue(poolElement);
			Object rightQueryValue = col.getValue(query.getSubject());
			if(isAnd)
			{
				return left.checkConstraint(query, poolElement, leftFieldValue, leftQueryValue) && right.checkConstraint(query, poolElement, rightFieldValue, rightQueryValue);
			}
			return left.checkConstraint(query, poolElement, leftFieldValue, leftQueryValue) || right.checkConstraint(query, poolElement, rightFieldValue, rightQueryValue);
		}
		catch(NotFoundException nfe)
		{
			MessageLog.debug(this, "Trouble with constraints", nfe);
			throw new RuntimeException("Failed to check constraint. Could be fatal to application");
		}
	}
	/**
	 * @return
	 */
	public String constructQueryString()
	{
		String andString = " OR ";
		if(isAnd)
		{
			andString = " AND ";
		}
		if(getColumnName() == null)
		{
			throw new IllegalStateException("Attempted to create a query constraint without knowning the column name.");
		}
		StringBuffer result = new StringBuffer();
		result.append('(');
		try
		{
			String colName = deriveColumnName(left);
			result.append(getAlias() + colName);
			result.append(' ');
			result.append(left.constructQueryString());
			//result.append( ' ' );
			result.append(andString);
			//result.append( ' ' );
			colName = deriveColumnName(right);
			result.append(getAlias() + colName);
			result.append(' ');
			result.append(right.constructQueryString());
		}
		catch(NotFoundException ex)
		{
			MessageLog.debug(this, "Failed processing CrossField constraint.", ex);
			throw new IllegalStateException("Can't continue processing this query. Internal failure. ");
		}
		result.append(')');
		return result.toString();
	}
	/**
	 * @param  str
	 * @exception  ParseException
	 */
	public void fromString(String str) throws ParseException
	{
		throw new RuntimeException("Not implemented");
	}
	/**
	 * @param  field
	 */
	public void staticListInsert(String field)
	{
		fields.addElement(field);
	}
	/**
	 * @return
	 */
	public String stringify()
	{
		String andString = " AND ";
		if(!isAnd)
		{
			andString = " OR ";
		}
		return getField() + " ( " + left + andString + right + ")";
	}
	/**
	 * Has the side effect of modifying the constraint to have a persistent
	 * object if one does not already exist.
	 *
	 * @param  constraint
	 * @return
	 * @exception  NotFoundException
	 */
	protected String deriveColumnName(Constraint constraint) throws NotFoundException
	{
		Persistence p = constraint.getPersistence();
		if(p == null)
		{
			//Use this persistent object instead
			p = getPersistence();
			constraint.setPersistence(p);
		}
		RDBPersistence pObj = null;
		if(p.usesAdapter())
		{
			pObj = (RDBPersistence) p.getAdapter();
		}
		else
		{
			pObj = (RDBPersistence) p;
		}
		AttributeTypeColumn col = pObj.findColumnMap(constraint.getField());
		return col.getColumnName();
	}
	/**
	 *  Unit test of some simple Between values.
	 *
	 * @author  dhoag
	 * @version  $Id: CrossField.java,v 2.2 2002/02/08 22:41:28 dave_hoag Exp $
	 */
	public static class Test extends com.objectwave.test.UnitTestBaseImpl
	{
		/**
		 *  The main program for the Test class
		 *
		 * @param  args The command line arguments
		 */
		public static void main(String[] args)
		{
			com.objectwave.test.TestRunner.run(new Test(), args);
		}
		/**
		 *  A unit test for JUnit
		 */
		public void testOr()
		{
			ConstraintCompare first = new ConstraintCompare();
			first.setCompValue("10");
			first.setComparison("<");
			first.setPersistence(new ExampleEmployee());
			first.setField("objectIdentifier");

			ConstraintCompare second = new ConstraintCompare();
			second.setCompValue("30");
			second.setComparison(">");
			second.setPersistence(new ExampleEmployee());
			second.setField("objectIdentifier");
			CrossField bet = new CrossField(false, first, second);
			bet.setColumnName("A.one");

			testContext.assertEquals("(A.databaseIdentifier < 10 OR A.databaseIdentifier > 30)", bet.constructQueryString());
		}
		/**
		 *  A unit test for JUnit
		 */
		public void testMultipleFields()
		{
			ConstraintCompare first = new ConstraintCompare();
			first.setCompValue("dave34");
			first.setComparison("<");
			first.setPersistence(new ExampleEmployee());
			first.setField("emailAddress");
			ConstraintCompare second = new ConstraintCompare();
			second.setCompValue("100");
			second.setComparison(">");
			second.setPersistence(new ExampleEmployee());
			second.setField("objectIdentifier");
			CrossField bet = new CrossField(true, first, second);
			bet.setColumnName("A.one");
			testContext.assertEquals("(A.emailAddress < 'dave34' AND A.databaseIdentifier > 100)", bet.constructQueryString());
		}
		/**
		 *  A unit test for JUnit
		 */
		public void testAnd()
		{
			ConstraintCompare first = new ConstraintCompare();
			first.setCompValue("dave34");
			first.setComparison("<");
			first.setPersistence(new ExampleEmployee());
			first.setField("emailAddress");
			ConstraintCompare second = new ConstraintCompare();
			second.setCompValue("dave");
			second.setComparison(">");
			second.setPersistence(new ExampleEmployee());
			second.setField("emailAddress");
			CrossField bet = new CrossField(true, first, second);
			bet.setColumnName("A.one");
			testContext.assertEquals("(A.emailAddress < 'dave34' AND A.emailAddress > 'dave')", bet.constructQueryString());
		}

	}
}
