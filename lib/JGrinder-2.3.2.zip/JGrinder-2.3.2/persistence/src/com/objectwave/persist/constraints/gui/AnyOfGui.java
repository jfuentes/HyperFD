package com.objectwave.persist.constraints.gui;

import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import com.objectwave.persist.constraints.*;

/**
 *  Define & manage the "any of" and "not any of" constraints.
 * @author Steven Sinclair
 */
public class AnyOfGui extends JComponent implements ConstraintGuiIF
{
	private JComboBox        selectField;
	private JList            list;
	private MyListModel      model;
	private JCheckBox        notCB;
	private JTextField       editable;
	private ConstraintAnyOf  constraintAnyOf;

	/**
	 */
	static class MyListModel extends AbstractListModel
	{
		Vector data = new Vector();

		public void setData(Vector data)
		{
			int size = this.data.size();
			this.data = new Vector();
			if (size > 0)
				fireIntervalRemoved(this, 0, size);
			this.data = data;
			if (this.data != null && this.data.size() > 0)
				fireIntervalAdded(this, 0, this.data.size());
		}

		public Object getElementAt(int row)
		{
			return (data==null||row<0||row>data.size()) ? null : data.elementAt(row);
		}
		public int getSize() { return data==null ? 0 : data.size(); }
		public void modify(String newStr, int idx)
		{
			if (idx < 0) return;
			data.setElementAt(newStr, idx);
			fireContentsChanged(this, idx, idx);
		}
		public void insert(String str)
		{
			System.out.println("list insertion of \"" + str + "\"");
			str = str.trim();
			if (str.length() == 0)
			{
				System.out.println("Reject the empty string.");
				return;
			}
			data.addElement(str);
			fireIntervalAdded(this, data.size()-1, data.size()-1);
		}
		public void remove(int index)
		{
			if (index < 0) return;
			data.removeElementAt(index);
			fireIntervalRemoved(this, index, index);
		}
	}
	public AnyOfGui()
	{
	}
	public void initialize(Constraint constraint)
	{
		this.constraintAnyOf = (ConstraintAnyOf)constraint;

		setLayout(new BorderLayout());

		// Combo box & "not" checkbox
		//
		JPanel fieldPanel = new JPanel();
		fieldPanel.setLayout(new BorderLayout());
		selectField = new JComboBox(constraintAnyOf.getFields());
		if (constraintAnyOf.getFields().size() > 0)
		{
			selectField.setSelectedIndex(0);
		}
		fieldPanel.add("North", selectField);
		notCB = new JCheckBox("not any of");
		fieldPanel.add("South", notCB);

		// Any of list & textfield:
		//
		JPanel listPanel = new JPanel();
		listPanel.setLayout(new BorderLayout());
		model = new MyListModel();
		list = new JList(model);
		JScrollPane scrollPane = new JScrollPane(list);
		listPanel.add("Center", scrollPane);
		editable = new JTextField();
		listPanel.add("South", editable);

		// Edit panel:
		//
		JPanel editPanel = new JPanel();
		JButton addButton = new JButton("add");
		JButton delButton = new JButton("del");
		JButton modButton = new JButton("mod");
		editPanel.add(addButton);
		editPanel.add(delButton);
		editPanel.add(modButton);

		add("North", fieldPanel);
		add("Center", listPanel);
		add("South", editPanel);

		// Hookup listeners
		//
		list.addListSelectionListener(new ListSelectionListener()
			{ public void valueChanged(ListSelectionEvent evt)
				{
					if (evt.getFirstIndex() > -1)
						editable.setText((String)model.data.elementAt(evt.getFirstIndex()));
				}
			} );
		addButton.addActionListener(new ActionListener()
			{ public void actionPerformed(ActionEvent evt)
				{
					System.out.println("Editable text: \"" + editable.getText() + "\"");
					model.insert(editable.getText());
				} } );
		delButton.addActionListener(new ActionListener()
			{ public void actionPerformed(ActionEvent evt)
				{ model.remove(list.getSelectedIndex()); } } );
		modButton.addActionListener(new ActionListener()
			{ public void actionPerformed(ActionEvent evt)
				{ model.modify(editable.getText(), list.getSelectedIndex()); } } );

		displayObject();
	}
	public void displayObject()
	{
		model.setData(constraintAnyOf.getAnyOf());
		notCB.setSelected(constraintAnyOf.getNot());
		selectField.setSelectedItem(constraintAnyOf.getField());
	}
	public void populateObject()
	{
		System.out.println("Setting field to " + selectField.getSelectedItem());
		constraintAnyOf.setField((String)selectField.getSelectedItem());
		constraintAnyOf.setAnyOf(model.data);
		constraintAnyOf.setNot(notCB.isSelected());
	}
}
