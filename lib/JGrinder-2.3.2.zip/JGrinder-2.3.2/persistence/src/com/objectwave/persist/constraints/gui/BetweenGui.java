package com.objectwave.persist.constraints.gui;

import javax.swing.*;
import com.objectwave.persist.*;
import com.objectwave.utility.StringManipulator;
import com.objectwave.persist.constraints.*;

/**
 */
public class BetweenGui extends JPanel implements ConstraintGuiIF
{
	private JComboBox selectFieldCB;
	private JCheckBox notCB;
	private JTextField betweenMinTF;
	private JTextField betweenMaxTF;
	private ConstraintBetween constraintBetween;

	private static class GBC extends java.awt.GridBagConstraints {}

	public BetweenGui()
	{
	}
	/**
	 */
	public void initialize(Constraint constraint)
	{
		this.constraintBetween = (ConstraintBetween )constraint;
		java.awt.GridBagLayout layout = new java.awt.GridBagLayout();
		setLayout(layout);
		selectFieldCB = new JComboBox(constraintBetween.getFields());
		notCB = new JCheckBox("not");
		betweenMinTF = new JTextField();
		betweenMaxTF = new JTextField();
		JLabel labelBetween = new JLabel("between");
		JLabel labelMin = new JLabel("min:");
		JLabel labelMax = new JLabel("max:");
		labelBetween.setForeground(java.awt.Color.black);
		labelMin.setForeground(java.awt.Color.black);
		labelMax.setForeground(java.awt.Color.black);

		GBC gbc = new GBC();
		gbc.insets = new java.awt.Insets(2,2,2,2);
		gbc.fill = GBC.HORIZONTAL;
		gbc.gridwidth = GBC.REMAINDER;
		layout.setConstraints(selectFieldCB, gbc);
		layout.setConstraints(betweenMinTF, gbc);
		layout.setConstraints(betweenMaxTF, gbc);
		layout.setConstraints(labelBetween, gbc);
		gbc.gridwidth = 1;
		layout.setConstraints(labelMin, gbc);
		layout.setConstraints(labelMax, gbc);
		layout.setConstraints(notCB, gbc);
		add(selectFieldCB);
		add(notCB);
		add(labelBetween);
		add(labelMin);
		add(betweenMinTF);
		add(labelMax);
		add(betweenMaxTF);
	}
	public void displayObject()
	{
		betweenMinTF.setText(constraintBetween.getBetweenMin());
		betweenMaxTF.setText(constraintBetween.getBetweenMax());
		notCB.setSelected(constraintBetween.getNot());
		selectFieldCB.setSelectedItem(constraintBetween.getField());
	}
	public void populateObject()
	{
		constraintBetween.setBetweenMin(betweenMinTF.getText());
		constraintBetween.setBetweenMax(betweenMaxTF.getText());
		constraintBetween.setNot(notCB.isSelected());
		constraintBetween.setField((String)selectFieldCB.getSelectedItem());
	}
}
