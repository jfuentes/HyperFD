package com.objectwave.persist.constraints.gui;

import javax.swing.*;
import com.objectwave.persist.constraints.*;

/**
 */
public class CompareGui extends JPanel implements ConstraintGuiIF
{
	private JComboBox selectFieldCB;
	private JComboBox comparisonCB;
	private JCheckBox notCB;
	private JTextField compValueTF;
	private ConstraintCompare constraintCompare;

	private static class GBC extends java.awt.GridBagConstraints {}

	public CompareGui()
	{
	}
	public void initialize(Constraint constraint)
	{
		this.constraintCompare = (ConstraintCompare)constraint;
		java.awt.GridBagLayout layout = new java.awt.GridBagLayout();
		setLayout(layout);
		selectFieldCB = new JComboBox(constraintCompare.getFields());
		comparisonCB = new JComboBox(constraintCompare.getComparisons());
		notCB = new JCheckBox("not");
		compValueTF = new JTextField();
		JLabel label = new JLabel("Value:");
		label.setForeground(java.awt.Color.black);

		GBC gbc = new GBC();
		gbc.insets = new java.awt.Insets(2,2,2,2);
		gbc.fill = GBC.HORIZONTAL;
		gbc.gridwidth = GBC.REMAINDER;
		layout.setConstraints(comparisonCB, gbc);
		layout.setConstraints(selectFieldCB, gbc);
		layout.setConstraints(compValueTF, gbc);
		gbc.gridwidth = 1;
		layout.setConstraints(label, gbc);
		layout.setConstraints(notCB, gbc);
		add(selectFieldCB);
		add(notCB);
		add(comparisonCB);
		add(label);
		add(compValueTF);
	}
	public void displayObject()
	{
		comparisonCB.setSelectedItem(constraintCompare.getComparison());
		notCB.setSelected(constraintCompare.getNot());
		selectFieldCB.setSelectedItem(constraintCompare.getField());
		compValueTF.setText(constraintCompare.getCompValue());
	}
	public static void main(String args[])
	{
		try
		{
			ConstraintCompare c = new ConstraintCompare();
			JFrame frame = null;
			JDialog dialog = new JDialog(frame, "test", true);
			JComponent comp =(JComponent)ConstraintGuiSelection.getInstance().getComponent(c);
			dialog.getContentPane().add(comp);
			java.awt.Dimension dim = comp.getPreferredSize();
			dialog.setBounds(100, 100, dim.width, dim.height+25);
			dialog.setVisible(true);
			System.exit(0);
		}
		catch (Throwable t)
		{
			t.printStackTrace();
		}
	}
	public void populateObject()
	{
		constraintCompare.setComparison(comparisonCB.getSelectedIndex());
		if (constraintCompare.getComparison() == null)
		{
			constraintCompare.setComparison(0); /* "=" */
		}
		constraintCompare.setNot(notCB.isSelected());
		constraintCompare.setField((String)selectFieldCB.getSelectedItem());
		constraintCompare.setCompValue(compValueTF.getText());
	}
}
