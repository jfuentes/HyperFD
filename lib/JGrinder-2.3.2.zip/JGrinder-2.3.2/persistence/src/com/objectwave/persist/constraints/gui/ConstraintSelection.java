package com.objectwave.persist.constraints.gui;

import java.text.ParseException;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.AbstractTableModel;
//import com.objectwave.appArch.organization.*;
import com.objectwave.utility.StringManipulator;
import com.objectwave.utility.StringifyIF;
import com.objectwave.uiWidget.SimpleOkCancelDialog;
//import com.objectwave.templateMerge.*;
import com.objectwave.persist.*;
import com.objectwave.viewUtility.VectorToButtons;
//import com.abnamro.leasing.systemObjects.*;
import com.objectwave.persist.constraints.*;

/**
 * For selecting constraints.
 * @version 1.3
 * @author Steven Sinclair
 */
public class ConstraintSelection
{
	private static String testFields[] = { "status", "name", "lease.leaseNumber", "lease.invalidField", "lease.closeDate", "lease.numberOfInvestors" };
	
	private static class MyTableModel extends AbstractTableModel
	{
		Vector constraints;

		public void addConstraint(Constraint c)
		{
			if (constraints == null)
				constraints = new Vector();
			int idx = constraints.size();
			constraints.addElement(c);
			fireTableRowsInserted(idx, idx);
		}

		public void delConstraint(int idx)
		{
			if (idx<0) return;
			constraints.removeElementAt(idx);
			fireTableRowsDeleted(idx, idx);
		}

		public void replaceConstraint(int idx, Constraint c)
		{
			if (idx<0 || c == null) return;
			System.out.println("Replace constraint at " + idx + ": " + c);
			constraints.setElementAt(c, idx);
			fireTableRowsUpdated(idx, idx);
		}

		public Constraint getConstraint(int idx)
		{
			return idx<0 ? null : (Constraint)constraints.elementAt(idx);
		}
		/**
		*/
		public Vector getConstraints()
		{
			return constraints;
		}

		public static String columns[] = { "Type", "Field", "SQL" };
		public int getColumnCount() { return columns.length; }
		public int getRowCount() { return constraints==null ? 0:constraints.size(); }
		public String getColumnName(int i) { return columns[i]; }
		public Object getValueAt(int row, int col)
		{
			if (constraints == null || row >= constraints.size())
				return null;
			Constraint c = (Constraint)constraints.elementAt(row);
			switch (col)
			{
				case 0: return c.getType();
				case 1: return c.getField();
				case 2: 
				{
					String sql = c.constructQueryString();
					return sql==null ? "<error>" : sql;
				}
			}
			return null;
		}
		public void setValueAt(Object value, int r, int c) { }
	}

	private MyTableModel model;
	private JTable table;
	private JScrollPane tableScroll;
	private JPanel buttonPanel;
	private JPanel selectionPanel;
	private CustomReportIF customReport;
	private Persistence persistence;
	/**
	 */
	private void action(String string) throws IllegalAccessException, ClassNotFoundException, InstantiationException
	{
		if (string.equals("add"))
			add();
		else if (string.equals("del"))
			del();
		else if (string.equals("edit"))
			edit();
	}
	/**
	 */
	private void add() throws IllegalAccessException, ClassNotFoundException, InstantiationException
	{
		Enumeration typesEnum = ConstraintFactory.getTypes();
		Vector types = new Vector(4);
		while (typesEnum.hasMoreElements())
		{
			types.addElement(typesEnum.nextElement());
		}
		VectorToButtons v2b = new VectorToButtons(types);
		v2b.setAction(getAddAction());
		
		JFrame frame = null;
		JDialog dialog = new JDialog(frame, "Add Constraints", true);
		java.awt.Rectangle bounds = dialog.getBounds();
		dialog.setBounds(30, 200, 150, 25 + 25*types.size());
		dialog.getContentPane().add(v2b.getPanel());
		dialog.setVisible(true);
	}
	/**
	 */
	com.objectwave.utility.ActionIF getAddAction()
	{
		return new com.objectwave.utility.ActionIF()
			{ 
				public void performAction(Object obj)
				{
					System.out.println("Clicked on a type button.");
					try
					{
					addType((String)obj);
					}
					catch (Throwable t) 
					{
						t.printStackTrace();
					}
				}
			};
	}
	/**
	 */
	private void addType(String type) throws IllegalAccessException, ClassNotFoundException, InstantiationException
	{
		System.out.println("Add Type");
		Constraint c = ConstraintFactory.createConstraint(type);
		System.out.println("Type: " + c);
		if (c == null)
			return;
		c.setPersistence(getPersistence());
		if (visuallyEditConstraint(c))
			model.addConstraint(c);
	}
	/**
	 */
	private void del()
	{
		model.delConstraint(table.getSelectedRow());
	}
	/**
	 */
	private void edit() throws IllegalAccessException, ClassNotFoundException, InstantiationException
	{
		int idx = table.getSelectedRow();
		if (idx < 0) return;
		if (visuallyEditConstraint((Constraint)model.getConstraint(idx)))
			model.replaceConstraint(idx, (Constraint)model.getConstraint(idx));
	}
	/**
	 */
	protected JPanel getButtons()
	{
		if (buttonPanel == null)
		{
			Vector v = new Vector(3);
			v.addElement("add");
			v.addElement("del");
			v.addElement("edit");
			VectorToButtons v2b = new VectorToButtons(v);
			v2b.setAction(getButtonAction());
			buttonPanel = v2b.getPanel();
			buttonPanel.setLayout(new FlowLayout());
			//
			// Do we need to retain a reference to the v2b object?
			//
		}
		return buttonPanel;
	}
	/**
	 */
	com.objectwave.utility.ActionIF getButtonAction()
	{
		return new com.objectwave.utility.ActionIF()
				{ 
					public void performAction(Object obj) 
					{
						try
						{
							action((String)obj);
						} 
						catch (Throwable t)
						{
							t.printStackTrace();
						}
					}
				};
	}
	/**
	 */
	public Vector getConstraints()
	{
		return model==null ? new Vector() : model.getConstraints();
	}
	/**
	 */
	public Persistence getPersistence() { return persistence; }
	/**
	 */
	public JPanel getSelectionPanel()
	{
		if (selectionPanel == null)
		{
			selectionPanel = new JPanel();
			selectionPanel.setLayout(new BorderLayout());
			getTable();
			selectionPanel.add("Center", tableScroll);
			selectionPanel.add("South", getButtons());
		}
		return selectionPanel;
	}
	protected JTable getTable()
	{
		if (table == null)
		{
			model = new MyTableModel();
			table = new JTable(model);
			table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
			initConstraints(customReport);
			tableScroll = new JScrollPane();
			tableScroll.getViewport().add(table);
			tableScroll.setColumnHeaderView(table.getTableHeader());
		}
		return table;
	}
	public void initConstraints(CustomReportIF customReport)
	{
		System.out.println("ConstraintSelection.initConstraints(" + customReport + ")");
		if (customReport == null)
			return;
		getTable(); // force table's initialization, if required.
		Vector constraints = customReport.getQueryConstraints();
		for (Enumeration e = constraints.elements(); e.hasMoreElements(); )
			model.addConstraint((Constraint)e.nextElement());
	}
	public static void main(String args[])
	{
		Persistence p = null;
		if (args.length == 0)
		{
			System.out.println("A persistence class may be specified as an argument to main.");
		}
		else
		{
			try
			{
				Class pClass = Class.forName(args[0]);
				p = (Persistence)pClass.newInstance();
			}
			catch (ClassCastException ex)
			{
				System.out.println("\"" + args[0] + "\" does not implement Persistence.");
			}
			catch (Exception ex)
			{
				System.out.println("Error loading/instantiating class \"" + args[0] + "\": " + ex);
			}
		}
		
		Enumeration types = ConstraintFactory.getTypes();
		while (types.hasMoreElements())
		{
			Constraint c = ConstraintFactory.createConstraint((String)types.nextElement());
			if (c == null) continue;
			for (int i=0; i<testFields.length; ++i)
				c.staticListInsert(testFields[i]);
		}

		ConstraintSelection cs = new ConstraintSelection();
		if (p != null)
			cs.setPersistence(p);
		SimpleOkCancelDialog dialog = new SimpleOkCancelDialog(null, "Constraints", cs.getSelectionPanel());
		dialog.setBounds(200, 200, 400, 200);
		dialog.setVisible(true);
		if (!dialog.isCancelled())
		{
			Vector constraints = cs.getConstraints();
			System.out.println("The following constraints were defined:");
			if (constraints == null)
				System.out.println("\t[ null vector ]");
			else
			{
				Enumeration enum = constraints.elements();
				while (enum.hasMoreElements())
					System.out.println("\t" + enum.nextElement());
			}
		}
		else
		{
			System.out.println("Cancelled the query selection operation.");
		}
		System.exit(0);
	}
	/**
	 */
	public void setPersistence(Persistence p)
	{
		persistence = p;
	}
	/**
	 */
	protected boolean visuallyEditConstraint(Constraint c) throws IllegalAccessException, ClassNotFoundException, InstantiationException
	{
		SimpleOkCancelDialog dialog;
		JComponent comp = (JComponent)ConstraintGuiSelection.getInstance().getComponent(c);
		dialog = new SimpleOkCancelDialog(null, "Define Constraint", comp);
		ConstraintGuiIF gui = (ConstraintGuiIF)comp;
		gui.displayObject();
		java.awt.Dimension dim = comp.getPreferredSize();
		dialog.setBounds(100, 100, Math.max(150, dim.width), dim.height+50);
		dialog.setVisible(true);
		if (!dialog.isCancelled())
		{
			gui.populateObject();
		}
		return !dialog.isCancelled();
	}
}
