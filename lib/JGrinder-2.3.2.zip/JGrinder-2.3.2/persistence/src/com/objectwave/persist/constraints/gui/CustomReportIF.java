package com.objectwave.persist.constraints.gui;

import java.util.Vector;
/**
 * Used by the ConstraintSelection class.
 * @author Dave Hoag
 * @version 1.0
 */
public interface CustomReportIF {
	Vector getQueryConstraints();
}