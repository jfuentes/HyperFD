package com.objectwave.persist.constraints.gui;

import java.awt.*;
import javax.swing.*;
import com.objectwave.persist.constraints.*;

/**
 *
 */
public class IsNullGui extends JPanel implements ConstraintGuiIF
{
	private JComboBox        selectField;
	private JRadioButton     isNull;
	private JRadioButton     isntNull;
	private ButtonGroup      buttonGroup;
	private JTextField       editable;
	private ConstraintIsNull constraintIsNull;

	public IsNullGui()
	{
	}
	/**
	 */
	public void initialize(Constraint constraint)
	{
		this.constraintIsNull = (ConstraintIsNull)constraint;
		setLayout(new BorderLayout());
		selectField = new JComboBox(constraintIsNull.getFields());
		if (constraintIsNull.getFields().size() > 0)
			selectField.setSelectedIndex(0);
		JPanel buttonPanel = new JPanel();
		buttonGroup = new ButtonGroup();
		isNull   = new JRadioButton("is null");
		isntNull = new JRadioButton("isn't null");
		buttonPanel.add(isNull);
		buttonPanel.add(isntNull);
		add("North", selectField);
		add("South", buttonPanel);
		buttonGroup.add(isNull);
		buttonGroup.add(isntNull);
	}
	public void displayObject()
	{
		isNull.setSelected(!constraintIsNull.getNot());
		selectField.setSelectedItem(constraintIsNull.getField());
	}
	public void populateObject()
	{
		constraintIsNull.setField((String)selectField.getSelectedItem());
		constraintIsNull.setNot(isntNull.isSelected());
	}
}
