/*
 *  Copyright (C) 2001 David Hoag
 *  ObjectWave Corporation
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *  For a full copy of the license see:
 *  http://www.opensource.org/licenses/lgpl-license.html
 */
package com.objectwave.persist.examples;
import com.objectwave.persist.*;
import com.objectwave.persist.mapping.*;
import com.objectwave.transactionalSupport.ObjectEditingView;
import java.lang.reflect.*;

import java.util.Vector;
//import com.objectspace.jgl.*;
/**
 * @author  Dave Hoag
 * @version  $Id: ExampleCompany.java,v 2.1 2001/07/05 13:23:40 dave_hoag Exp $
 */
public class ExampleCompany extends DomainObject
{

	static Field _employees;
	static Field _ceo;
	static Vector classDescriptor;
//	SList employees = new SList();
	ExampleEmployee[] employees;
	ExampleEmployee ceo;
	/**
	 *  ExampleCompany constructor comment.
	 */
	public ExampleCompany()
	{
		super();
	}
	/**
	 *Sets the Ceo attribute of the ExampleCompany object
	 *
	 * @param  emp The new Ceo value
	 */
	public void setCeo(final ExampleEmployee emp)
	{
		editor.set(_ceo, emp, ceo);
	}
	/**
	 * @param  aValue The new Employees value
	 * @author
	 */
	public void setEmployees(Vector aValue)
	{
		editor.set(_employees, aValue, employees);
	}
	/**
	 * @return  The Employees value
	 * @author
	 */
	public ExampleEmployee[] getEmployees()
	{
		return (ExampleEmployee[]) editor.get(_employees, employees);
	}
	/**
	 *Gets the Ceo attribute of the ExampleCompany object
	 *
	 * @return  The Ceo value
	 */
	public ExampleEmployee getCeo()
	{
		return (ExampleEmployee) editor.get(_ceo, ceo);
	}
	/**
	 *  Describe how this class relates to the relational database.
	 */
	public void initDescriptor()
	{
		synchronized(ExampleCompany.class)
		{
			if(classDescriptor != null)
			{
				return;
			}
			Vector tempVector = getSuperDescriptor();
			tempVector.addElement(AttributeTypeColumn.getCollectionRelation(ExampleEmployee.class, _employees));
			tempVector.addElement(AttributeTypeColumn.getInstanceRelation(ExampleEmployee.class, "ceoIdentifier", _ceo));
			classDescriptor = tempVector;
		}
	}
	/**
	 *  Needed to define table name and the description of this class.
	 *
	 * @return
	 */
	public ObjectEditingView initializeObjectEditor()
	{
		final RDBPersistentAdapter result = (RDBPersistentAdapter) super.initializeObjectEditor();
		if(classDescriptor == null)
		{
			initDescriptor();
		}
		result.setTableName("company");
		result.setClassDescription(classDescriptor);
		return result;
	}
	static
	{
		/*
		 *  NAME:fieldDefinition:
		 */
		try
		{
			_employees = ExampleCompany.class.getDeclaredField("employees");
			_employees.setAccessible(true);
			_ceo = ExampleCompany.class.getDeclaredField("ceo");
			_ceo.setAccessible(true);
		}
		catch(NoSuchFieldException ex)
		{
			System.out.println(ex);
		}
	}
}
