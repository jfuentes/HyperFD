/*
 *  Copyright (C) 2001 David Hoag
 *  ObjectWave Corporation
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *  For a full copy of the license see:
 *  http://www.opensource.org/licenses/lgpl-license.html
 */
package com.objectwave.persist.examples;

import com.objectwave.persist.*;
import com.objectwave.persist.mapping.*;
import com.objectwave.transactionalSupport.ObjectEditingView;
import com.objectwave.transactionalSupport.ObjectEditor;
import java.lang.reflect.Field;
import java.util.Vector;
/**
 *  An example of a persistent business object that extends from DomainObject.
 *
 * @author  dhoag
 * @version  $Id: ExampleEmployee.java,v 2.1 2001/07/05 13:23:40 dave_hoag Exp $
 */
public class ExampleEmployee extends DomainObject
{
	/**
	 */
	public static Vector classDescriptor;

	// See below
	/**
	 */
	public static Field _title;
	/**
	 */
	public static Field _person;
	// See below
	/**
	 */
	public static Field _emailAddress;
	/**
	 */
	public static Field _boss;
	/**
	 */
	public static Field _workers;
	/**
	 */
	public static Field _company;
	/**
	 */
	public String title = null;
	/**
	 */
	public String emailAddress = null;
	/**
	 */
	public ExamplePerson person;
	/**
	 */
	public ExampleEmployee boss;
	/**
	 */
	public Vector workers;
	/**
	 */
	public ExampleCompany company;
	/**
	 * @param  args The command line arguments
	 */
	public static void main(String[] args)
	{
		if(0 == args.length)
		{
			System.out.println("Usage java com.objectwave.persist.ExampleEmployee <brokerClassName>");
			return;
		}
		try
		{
			Class c = Class.forName(args[0]);
			Broker broker = (Broker) c.newInstance();
			BrokerFactory.setDefaultBroker(broker);
			SQLQuery.setDefaultBroker(broker);

			ExampleEmployee employee = new ExampleEmployee();
			employee.setTitle("myTitle");
			employee.save();
		}
		catch(Throwable t)
		{
			t.printStackTrace();
		}
	}
	/**
	 *  Generated accessors that route get and set methods through our
	 *  ObjectEditor.
	 *
	 * @param  aValue The new EmailAddress value
	 */
	public void setEmailAddress(final String aValue)
	{
		editor.set(_emailAddress, aValue, emailAddress);
	}
	/**
	 *  Sets the Person attribute of the ExampleEmployee object
	 *
	 * @param  aValue The new Person value
	 */
	public void setPerson(final ExamplePerson aValue)
	{
		editor.set(_person, aValue, person);
	}
	/**
	 *  Sets the Boss attribute of the ExampleEmployee object
	 *
	 * @param  aValue The new Boss value
	 */
	public void setBoss(final ExampleEmployee aValue)
	{
		editor.set(_boss, aValue, boss);
	}
	/**
	 *  Sets the Company attribute of the ExampleEmployee object
	 *
	 * @param  aValue The new Company value
	 */
	public void setCompany(final ExampleCompany aValue)
	{
		editor.set(_company, aValue, company);
	}
	/**
	 *  Sets the Workers attribute of the ExampleEmployee object
	 *
	 * @param  aValue The new Workers value
	 */
	public void setWorkers(final Vector aValue)
	{
		editor.set(_workers, aValue, workers);
	}
	/**
	 *  Generated accessors that route get and set methods through our
	 *  ObjectEditor.
	 *
	 * @param  aValue The new Title value
	 */
	public void setTitle(final String aValue)
	{
		editor.set(_title, aValue, title);
	}
	/**
	 *  Generated accessors that route get and set methods through our
	 *  ObjectEditor.
	 *
	 * @return  The EmailAddress value
	 */
	public String getEmailAddress()
	{
		return (String) editor.get(_emailAddress, emailAddress);
	}
	/**
	 *  Gets the Person attribute of the ExampleEmployee object
	 *
	 * @return  The Person value
	 */
	public ExamplePerson getPerson()
	{
		return (ExamplePerson) editor.get(_person, person);
	}
	/**
	 *  Gets the Boss attribute of the ExampleEmployee object
	 *
	 * @return  The Boss value
	 */
	public ExampleEmployee getBoss()
	{
		return (ExampleEmployee) editor.get(_boss, boss);
	}

	/**
	 *  Gets the Company attribute of the ExampleEmployee object
	 *
	 * @return  The Company value
	 */
	public ExampleCompany getCompany()
	{
		return (ExampleCompany) editor.get(_company, company);
	}

	/**
	 *  Gets the Workers attribute of the ExampleEmployee object
	 *
	 * @return  The Workers value
	 */
	public Vector getWorkers()
	{
		return (Vector) editor.get(_workers, workers);
	}
	/**
	 *  Generated accessors that route get and set methods through our
	 *  ObjectEditor.
	 *
	 * @return  The Title value
	 */
	public String getTitle()
	{
		return (String) editor.get(_title, title);
	}
	/**
	 *  Describe how each attribute relates to the database.
	 */
	public void initDescriptor()
	{
		synchronized(ExampleEmployee.class)
		{
			if(classDescriptor != null)
			{
				return;
			}
			//For Thread Safety
			Vector tempVector = getSuperDescriptor();

			tempVector.addElement(AttributeTypeColumn.getAttributeRelation("title", _title));
			tempVector.addElement(AttributeTypeColumn.getAttributeRelation("emailAddress", _emailAddress));
			tempVector.addElement(AttributeTypeColumn.getInstanceRelation(ExampleEmployee.class, "bossIdentifier", _boss));
			tempVector.addElement(AttributeTypeColumn.getInstanceRelation(ExamplePerson.class, _person));
			tempVector.addElement(AttributeTypeColumn.getCollectionRelation(ExampleEmployee.class, _workers));

			tempVector.addElement(AttributeTypeColumn.getForeignRelation(ExampleCompany.class, "companyIdentifier", _company));

			classDescriptor = tempVector;
		}

	}
	/**
	 *  Needed to define table name and the description of this class.
	 *
	 * @return
	 */
	public ObjectEditingView initializeObjectEditor()
	{
		final RDBPersistentAdapter result = (RDBPersistentAdapter) super.initializeObjectEditor();
		if(classDescriptor == null)
		{
			initDescriptor();
		}
		result.setTableName("employee");
		result.setClassDescription(classDescriptor);
		return result;
	}
	static
	{
		try
		{
			_title = ExampleEmployee.class.getDeclaredField("title");
			_title.setAccessible(true);
			_emailAddress = ExampleEmployee.class.getDeclaredField("emailAddress");
			_emailAddress.setAccessible(true);
			_person = ExampleEmployee.class.getDeclaredField("person");
			_person.setAccessible(true);
			_boss = ExampleEmployee.class.getDeclaredField("boss");
			_boss.setAccessible(true);
			_workers = ExampleEmployee.class.getDeclaredField("workers");
			_workers.setAccessible(true);
			_company = ExampleEmployee.class.getDeclaredField("company");
			_company.setAccessible(true);
		}
		catch(NoSuchFieldException ex)
		{
			ex.printStackTrace();
		}
	}

}
