package com.objectwave.persist.examples;

import com.objectwave.persist.*;
import com.objectwave.persist.mapping.*;
import com.objectwave.transactionalSupport.ObjectEditingView;
import java.lang.reflect.*;
import java.util.Vector;
/**
 *  An example of an object that uses persistence. Relates to the ExampleEmployee
 *  class.
 *
 * @author  dhoag
 * @version  $Id: ExamplePerson.java,v 2.0 2001/06/11 16:00:04 dave_hoag Exp $
 */
public class ExamplePerson extends DomainObject
{
	/**
	 */
	public static Vector classDescriptor;

	/**
	 */
	public static Field _name;
	/**
	 */
	public static Field _employee;
	/**
	 */
	public String name;
	/**
	 */
	public ExampleEmployee employee;
	/**
	 *  Generated accessors that route get and set methods through our ObjectEditor.
	 *
	 * @param  aValue The new Employee value
	 */
	public void setEmployee(ExampleEmployee aValue)
	{
		editor.set(_employee, aValue, employee);
	}
	/**
	 *  Generated accessors that route get and set methods through our ObjectEditor.
	 *
	 * @param  aValue The new Name value
	 */
	public void setName(String aValue)
	{
		editor.set(_name, aValue, name);
	}
	/**
	 *  Gets the Employee attribute of the ExamplePerson object
	 *
	 * @return  The Employee value
	 */
	public ExampleEmployee getEmployee()
	{
		return (ExampleEmployee) editor.get(_employee, employee);
	}
	/**
	 *  Generated accessors that route get and set methods through our ObjectEditor.
	 *
	 * @return  The Name value
	 */
	public String getName()
	{
		return (String) editor.get(_name, name);
	}
	/**
	 *  Describe how each attribute relates to the database.
	 */
	public void initDescriptor()
	{
		synchronized(ExamplePerson.class)
		{
			if(classDescriptor != null)
			{
				return;
			}
			//For Thread Safety
			Vector tempVector = getSuperDescriptor();

			tempVector.addElement(AttributeTypeColumn.getAttributeRelation("name", _name));
			tempVector.addElement(AttributeTypeColumn.getForeignRelation(ExampleEmployee.class, "employeeIdentifier", _employee));
			classDescriptor = tempVector;
		}
	}
	/**
	 *  Needed to define table name and the description of this class.
	 *
	 * @return
	 */
	public ObjectEditingView initializeObjectEditor()
	{
		final RDBPersistentAdapter result = (RDBPersistentAdapter) super.initializeObjectEditor();
		if(classDescriptor == null)
		{
			initDescriptor();
		}
		result.setTableName("person");
		result.setClassDescription(classDescriptor);
		return result;
	}
	/**
	 *  This method allows me to get arounds security problems with updating
	 *  and object from a generic framework. This will change with the JDK1.2 version.
	 *
	 * @param  get
	 * @param  data
	 * @param  fields
	 */
	public void update(boolean get, Object[] data, Field[] fields)
	{
		for(int i = 0; i < data.length; i++)
		{
			try
			{
				if(get)
				{
					data[i] = fields[i].get(this);
				}
				else
				{
					fields[i].set(this, data[i]);
				}
			}
			catch(IllegalAccessException ex)
			{
				System.out.println(ex);
				ex.printStackTrace();
			}
			catch(IllegalArgumentException ex)
			{
				System.out.println("Field " + fields[i] + " " + data[i] + " " + ex);
				ex.printStackTrace();
			}
		}
	}

	static
	{
                 /*NAME:fieldDefinition:*/
		try
		{
			_name = ExamplePerson.class.getDeclaredField("name");
			_employee = ExamplePerson.class.getDeclaredField("employee");
		}
		catch(NoSuchFieldException ex)
		{
			System.out.println(ex);
		}
	}
}
