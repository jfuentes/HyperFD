package com.objectwave.persist.examples;

public class InvertEmployee
{
	private InvertPerson person;
	private int employeeId;
	//Accessor and Mutator methods MUST be at least protected scope
	protected void setInvertPerson( InvertPerson per)
	{
		person = per;
	}
	//Accessor and Mutator methods MUST be at least protected scope
	protected InvertPerson getPerson()
	{
		return person;
	}
	//The methods should also be empty of non standard behavior
	protected int getEmployeeId()
	{
		return employeeId;
	}
	//The methods should also be empty of non standard behavior
	protected void setEmployeeId( int value )
	{
		employeeId = value;
	}
	//At least a protected empty constructor is required.
	protected InvertEmployee()
	{
	}
	public void generateId()
	{
		int id = new java.util.Random().nextInt();
		//You MUST MUST MUST use accessors to manipulate local variables
		setEmployeeId( id );
	}
}
