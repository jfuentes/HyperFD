package com.objectwave.persist.examples;
import java.lang.reflect.Field;

public class InvertEmployeePersistence extends InvertEmployeePersistenceBase
{
	public static Field _person;
	public static Field _employeeId;

	public int getEmployeeId()
	{
		return editor.get( _employeeId, super.getEmployeeId() );
	}
	public void setEmployeeId( int anId )
	{
		editor.set( _employeeId, super.getEmployeeId() , anId );
	}
	public InvertPerson getPerson()
	{
		return (InvertPerson)editor.get( _person, super.getPerson() );
	}
	public void setPerson( InvertPerson aPerson )
	{
		editor.set( _person, super.getPerson(), aPerson );
	}

	static
	{
		try
		{
			_person = InvertEmployeePersistence.class.getDeclaredField("person");
			_person.setAccessible(true);
			_employeeId = InvertEmployeePersistence.class.getDeclaredField("employeeId");
			_employeeId.setAccessible(true);
		}
		catch(Throwable ex)
		{
			//Always catch all exceptions in a static block.
			ex.printStackTrace();
		}
	}
}
