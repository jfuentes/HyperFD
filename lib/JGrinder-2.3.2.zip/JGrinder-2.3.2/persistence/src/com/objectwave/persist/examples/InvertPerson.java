package com.objectwave.persist.examples;

public class InvertPerson 
{
	protected String name;
	protected short age;

	//Accessor and Mutator methods MUST be at least public scope
	public void setName( String per)
	{
		name = per;
	}
	//Accessor and Mutator methods MUST be at least public scope
	public String getName()
	{
		return name;
	}
	//The methods should also be empty of non standard behavior
	public short getAge()
	{
		return age;
	}
	//The methods should also be empty of non standard behavior
	public void setAge( short value )
	{
		age = value;
	}
	public void generateAge()
	{
		int id = new java.util.Random().nextInt( 100 );
		//You MUST MUST MUST use accessors to manipulate local variables
		setAge( (short)id );
	}
}
