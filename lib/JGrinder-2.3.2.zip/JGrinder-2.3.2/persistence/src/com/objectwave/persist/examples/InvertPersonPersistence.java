package com.objectwave.persist.examples;
import java.lang.reflect.Field;
import java.util.HashMap;
import com.objectwave.persist.*;

public class InvertPersonPersistence extends InvertPersonPersistenceBase 
{
	public static Field _name;
	public static Field _age;
	HashMap commandMap;

	public short getAge()
	{
		return editor.get( _age, age );
	}
	public void setAge( short anId )
	{
		editor.set( _age, anId, age );
	}
	public String getName()
	{
		return (String)editor.get( _name, super.getName() );
	}
	public void setName( String aName )
	{
		editor.set( _name, aName, super.getName());
	}
	protected void setup() throws Exception
	{
		setObjectEditor( initializeObjectEditor("InvertPersonPersistence.xml"));
	}
	public InvertPerson newInstance()
	{
		return new InvertPersonPersistence();
	}

	static
	{
		try
		{
			Class clazz = Class.forName( "com.objectwave.persist.examples.InvertPerson" );
			_name = clazz.getDeclaredField("name");
			_name.setAccessible(true);
			_age = clazz.getDeclaredField("age");
			_age.setAccessible(true);
		}
		catch(Throwable ex)
		{
			//Always catch all exceptions in a static block.
			ex.printStackTrace();
		}
	}
}
