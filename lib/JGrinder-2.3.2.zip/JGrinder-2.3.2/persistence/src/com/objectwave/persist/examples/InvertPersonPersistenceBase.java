/* Copyright (C) 2001 David Hoag
 * ObjectWave Corporation
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * For a full copy of the license see:
 * http://www.opensource.org/licenses/lgpl-license.html
 */
package com.objectwave.persist.examples;

import com.objectwave.event.ChangeEventFactoryIF;
import com.objectwave.event.StatusManager;
import com.objectwave.exception.ConfigurationException;
import com.objectwave.exception.ExceptionBuilder;
import com.objectwave.logging.MessageLog;
import com.objectwave.persist.*;
import com.objectwave.persist.mapping.*;
import com.objectwave.persist.xml.*;
import com.objectwave.transactionalSupport.ObjectEditingView;

import com.objectwave.transactionalSupport.ObjectEditor;
import com.objectwave.utility.FileFinder;
import java.io.*;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.reflect.Field;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Vector;
/**
 */
public class InvertPersonPersistenceBase extends InvertPerson implements Persistence
{
	//To gain efficiency, add the following
	//two variables in each and every subclass of DomainObject
	Vector classDescriptor;
	String tableName;

	static Field _objectIdentifier;
	/**
	 */
	public Integer objectIdentifier;
	/**
	 */
	public transient ObjectEditingView editor;
	/**
	 */
	public transient RDBPersistentAdapter adapt;
	private String printString = null;
	private String xmlInitString;
	/**
	 */
	public InvertPersonPersistenceBase()
	{
		try
		{
			setup();
		}
		catch( Throwable t )
		{
			MessageLog.error(this, "Failed to properly initialize the persistent object", t);
			throw new IllegalStateException("Persistent object " + this + " failed to initialize");
		}
	}
	/**
	 * Override this method if you wish to setup your object differently.
	 * This should work if your Xml is found in the directory of the Persistent
	 * class and it has the same name as the persistent class.
	 */
	protected void setup() throws Exception
	{
		setObjectEditor(initializeObjectEditor( null ));
	}
	/**
	 *  Support for individual instances residing in their own brokers.
	 *
	 * @param  aValue The new BrokerName value
	 */
	public void setBrokerName(String aValue)
	{
		getAdapter().setBrokerName(aValue);
	}
	/**
	 *  Sets the AsTransient attribute of the DomainObject object
	 *
	 * @param  value The new AsTransient value
	 */
	public void setAsTransient(boolean value)
	{
		((RDBPersistentAdapter) getAdapter()).setAsTransient(value);
	}
	/**
	 *  For an RDBPersistent system, this will be an RDBPersistentAdapter.
	 *
	 * @param  e The new ObjectEditor value
	 */
	public void setObjectEditor(ObjectEditingView e)
	{
		if(e instanceof RDBPersistentAdapter)
		{
			adapt = (RDBPersistentAdapter) e;
		}
		else if(editor instanceof RDBPersistentAdapter)
		{
			adapt = (RDBPersistentAdapter) editor;
		}
		editor = e;
	}
	/**
	 *  Sets the ObjectIdentifier attribute of the DomainObject object
	 *
	 * @param  aValue The new ObjectIdentifier value
	 */
	public void setObjectIdentifier(Integer aValue)
	{
		editor.set(_objectIdentifier, aValue, objectIdentifier);
	}
	/**
	 *  Sets the PrimaryKeyField attribute of the DomainObject object
	 *
	 * @param  obj The new PrimaryKeyField value
	 */
	public void setPrimaryKeyField(Object obj)
	{
		getAdapter().setPrimaryKeyField(obj);
	}
	/**
	 *  A user friendly description.
	 *
	 * @param  value The new PrintString value
	 */
	public void setPrintString(String value)
	{
		printString = value;
	}
	/**
	 *  Sets the RetrievedFromDatabase attribute of the DomainObject object
	 *
	 * @param  b The new RetrievedFromDatabase value
	 */
	public void setRetrievedFromDatabase(boolean b)
	{
		getAdapter().setRetrievedFromDatabase(b);
	}
	/**
	 *  Gets the Adapter attribute of the DomainObject object
	 *
	 * @return  The Adapter value
	 */
	public Persistence getAdapter()
	{
		if(adapt != null)
		{
			return (Persistence) adapt;
		}
		return (Persistence) editor;
	}
	/**
	 *  Support for individual instances residing in their own brokers.
	 *
	 * @return  The BrokerName value
	 */
	public String getBrokerName()
	{
		return getAdapter().getBrokerName();
	}
	/**
	 *  Gets the ObjectEditor attribute of the DomainObject object
	 *
	 * @return  The ObjectEditor value
	 */
	public ObjectEditingView getObjectEditor()
	{
		return editor;
	}
	/**
	 *  Gets the ObjectIdentifier attribute of the DomainObject object
	 *
	 * @return  The ObjectIdentifier value
	 */
	public Integer getObjectIdentifier()
	{
		return (Integer) editor.get(_objectIdentifier, objectIdentifier);
	}
	/**
	 *  Gets the PrimaryKeyField attribute of the DomainObject object
	 *
	 * @return  The PrimaryKeyField value
	 */
	public Object getPrimaryKeyField()
	{
		return getAdapter().getPrimaryKeyField();
	}
	/**
	 *  Gets the PrimaryKeyField attributes of the DomainObject object
	 *
	 * @return  The PrimaryKeyField value
	 */
	public Object[] getPrimaryKeyFields()
	{
		return getAdapter().getPrimaryKeyFields();
	}
	/**
	 *  Gets the Dirty attribute of the DomainObject object
	 *
	 * @return  The Dirty value
	 */
	public boolean isDirty()
	{
		return getAdapter().isDirty();
	}
	/**
	 *  Gets the RetrievedFromDatabase attribute of the DomainObject object
	 *
	 * @return  The RetrievedFromDatabase value
	 */
	public boolean isRetrievedFromDatabase()
	{
		return getAdapter().isRetrievedFromDatabase();
	}
	/**
	 *  Gets the Transient attribute of the DomainObject object
	 *
	 * @return  The Transient value
	 */
	public boolean isTransient()
	{
		return ((RDBPersistentAdapter) getAdapter()).isTransient();
	}
	/**
	 *  Called to initialize object editor It will use an XML file for the field
	 *  match. This method is only used when using XML files to define your
	 *  persistent map information. The xmlTag parameter can be either the name of
	 *  an XML file or a key to System properties to a value of an XML file name.
	 *
	 * @param  xmlTag String The tag name in the initial file
	 * @param  obj Object The caller himself
	 * @return
	 * @exception  FileNotFoundException
	 * @exception  ConfigurationException
	 * @author  Zhou Cai
	 * @see  #locateXmlMap
	 */
	public ObjectEditingView initializeObjectEditor(final String xmlTag) throws FileNotFoundException, ConfigurationException
	{
		xmlInitString = xmlTag;
		final RDBPersistentAdapter result = (RDBPersistentAdapter) createAdapter(this);
		if(getClassDescriptor() == null)
		{
			initDescriptor(xmlTag, this, result);
		}
		result.setClassDescription(getClassDescriptor());
		result.setTableName(getTableName());
		return result;
	}
	/**
	 *  Read in the XML file and populate the persistent map information. Use
	 *  initializeObjectEditor instead of this method.
	 *
	 * @param  xmlTag
	 * @param  obj
	 * @param  adapter
	 * @exception  FileNotFoundException
	 * @exception  ConfigurationException
	 */
	protected void initDescriptor(final String xmlTag, final Persistence obj, final RDBPersistentAdapter adapter) throws FileNotFoundException, ConfigurationException
	{
		synchronized(getClass())
		{
			if(getClassDescriptor() != null)
			{
				return;
			}
			XMLDecoder xmlDecoder = getXmlDefinition(xmlTag, obj);
			setTableName(xmlDecoder.getTableName());
			adapter.setBrokerGeneratedPrimaryKeys(xmlDecoder.getBrokerGeneratedPrimaryKeys());
			ArrayList listOfAttributes = xmlDecoder.getMaps();
			addDefaultPrimaryAttribute(listOfAttributes);
			Vector map = new Vector(listOfAttributes);
			setClassDescriptor(map);
		}
	}
	/**
	 * @exception  QueryException
	 */
	public void delete() throws QueryException
	{
		getAdapter().delete();
	}
	/**
	 * @exception  QueryException
	 */
	public void insert() throws QueryException
	{
		getAdapter().insert();
	}
	/**
	 *  This method was created in VisualAge.
	 *
	 * @param  wait boolean
	 * @return  boolean
	 */
	public boolean lock(boolean wait)
	{
		if(editor == null)
		{
			return false;
		}
		return editor.lock(wait);
	}
	/**
	 *  Mark this object to be deleted in this transaction. If a transaction is not
	 *  in progress, this object will be deleted immediately.
	 *
	 * @exception  QueryException
	 */
	public void markForDelete() throws QueryException
	{
		((RDBPersistence) getAdapter()).markForDelete();
	}
	/**
	 * @exception  QueryException
	 */
	public void save() throws QueryException
	{
		getAdapter().save();
	}
	/**
	 * @return
	 */
	public String toString()
	{
		if(printString == null)
		{
			return super.toString();
		}
		return printString;
	}
	/**
	 *  This method was created in VisualAge.
	 */
	public void unlock()
	{
		if(editor != null)
		{
			editor.unlock();
		}
	}
	/**
	 *  Method no longer does anything since setAccessible solves our need for this
	 *  behavior.
	 *
	 * @param  get
	 * @param  data
	 * @param  fields
	 */
	public void update(final boolean get, final Object[] data, final Field[] fields)
	{
		throw new UnsupportedOperationException("This method should never be called");
	}
	/**
	 * @return
	 */
	public boolean usesAdapter()
	{
		return true;
	}
	/**
	 */
	protected void setTableName(final String table)
	{
		tableName = table;
	}
	/**
	 */
	protected void setClassDescriptor(final Vector v)
	{
		classDescriptor = v;
	}
	/**
	 */
	protected String getTableName()
	{
		return tableName;
	}
	/**
	 */
	protected Vector getClassDescriptor()
	{
		return classDescriptor;
	}
	/**
	 *  Create the XMLDecoder object that will allow the creation of all of the map
	 *  information.
	 *
	 * @param  xmlTag
	 * @param  obj
	 * @return  The XmlDefinition value
	 * @exception  FileNotFoundException
	 * @exception  ConfigurationException
	 */
	protected XMLDecoder getXmlDefinition(final String xmlTag, final Object obj) throws FileNotFoundException, ConfigurationException
	{
		final String resource = locateXmlMap(xmlTag, obj);
		XMLDecoder xd = new XMLDecoder(resource, obj.getClass());
		return xd;
	}
	/**
	 *  Add primary attribute type with a column name of databaseIdentifer. This is
	 *  the default primary key field. The map may define its own primary key
	 *  field, in which case the default will not be added.
	 *
	 * @param  list ArrayList The list that was found in the Xml map
	 */
	protected void addDefaultPrimaryAttribute(final ArrayList list)
	{
		for(int i = 0; i < list.size(); i++)
		{
			AttributeTypeColumn col = (AttributeTypeColumn) list.get(i);
			if(col.getType() == col.PRIMARYATT)
			{
				//Nothing to do, primary already defined
				return;
			}
		}
		list.add(0, new AttributeTypeColumn("databaseIdentifier", _objectIdentifier, AttributeTypeColumn.PRIMARYATT));
	}
	/**
	 *  Create the new ObjectEditingView instance that is to be our 'adapter' to
	 *  the persistent object.
	 *
	 * @param  persistentObject
	 * @return
	 */
	protected RDBPersistentAdapter createAdapter(final Persistence persistentObject)
	{
		RDBPersistentAdapter result = new RDBPersistentAdapter(persistentObject);
		return result;
	}
	/**
	 *  Find the XML document that contains the persitent map information. First
	 *  decide if the xmlTag is really a key in system properties identifying the
	 *  actual file name. If a key is not found, the xmlTag is assumed to be the
	 *  xml file name. Once the name is determined, locate the XML file. First look
	 *  in same directory as the persisent object class file.
	 *
	 * @param  xmlTag String The tag name for the xml resource.
	 * @param  persistentObject
	 * @return
	 * @exception  ConfigurationException
	 * @exception  FileNotFoundException
	 */
	protected String locateXmlMap(final String xmlTag, final Object persistentObject) throws ConfigurationException, FileNotFoundException
	{
		String xmlName = null;
		if(xmlTag != null)
		{
			xmlName = System.getProperty(xmlTag);
		}
		URL url = null;
		FileFinder ff = new FileFinder();
		try
		{
			if(xmlName == null && xmlTag != null)
			{
				//xmlTag is probably a file name.
				url = ff.getUrl(persistentObject.getClass(), xmlTag);
			}
			else
			if( xmlName != null)
			{
				url = ff.getUrl(persistentObject.getClass(), xmlName);
			}
			//Don't give up yet. Try the simple default way of having a file name match class name
			if(url == null)
			{
				String defaultName = persistentObject.getClass().getName();
				defaultName = "/" + defaultName.replace('.', '/') + ".xml";
				MessageLog.debug(this, "Looking for default xml resource of " + defaultName);
				url = ff.getUrl(persistentObject.getClass(), defaultName);
			}
		}
		catch(java.net.MalformedURLException ex)
		{
			throw ExceptionBuilder.configuration("Exception locating xml resource : " + xmlTag + " -> " + xmlName);
		}
		if(url == null)
		{
			throw new FileNotFoundException("Exception locating xml resource : " + xmlTag + " -> " + xmlName);
		}
		return url.toString();
	}
	/**
	 *  Look for a fully qualified class name in the system parameters like
	 *  com.objectwave.persist.ExamplePerson.listener=com.objectwave.event.AProperyChangeListenerFactory
	 */
	void installPropertyChangeListener()
	{
		try
		{
			String listener = System.getProperty(this.getClass().getName() + ".listener");

			if(listener != null)
			{
				Class c = Class.forName(listener);
				ChangeEventFactoryIF obj = (ChangeEventFactoryIF) c.newInstance();

				if(editor instanceof java.beans.PropertyChangeSupport)
				{
					((java.beans.PropertyChangeSupport) editor).addPropertyChangeListener(obj.getListener());
				}
			}
		}
		catch(Exception e)
		{
			StatusManager.getDefaultManager().fireStatusEvent("Non Fatal Exception in Constructor: " + e.toString());
		}
		//Ignore any exceptions.
	}
	/**
	 *  Since the object editor is transient we need to initialize it. This implies
	 *  that there can be NO outstanding transactions when we serialize the
	 *  business object.
	 *
	 * @param  in
	 * @exception  java.io.IOException
	 * @exception  ClassNotFoundException
	 */
	private void readObject(final java.io.ObjectInputStream in) throws java.io.IOException, ClassNotFoundException
	{
		in.defaultReadObject();
		try
		{
			setObjectEditor(initializeObjectEditor(xmlInitString));
		}
		catch(ConfigurationException ex)
		{
			MessageLog.debug(this, "Exception recovering serialized instance", ex);
			throw new IOException("Can't recover instance due to initialization problem");
		}
		adapt.serializedUpdate(in);
	}
	/**
	 *  Allow the setting of some custom serialized fields.
	 *
	 * @param  out
	 * @exception  IOException
	 */
	private void writeObject(java.io.ObjectOutputStream out) throws IOException
	{
		out.defaultWriteObject();
		adapt.addToStream(out);
	}
	
	static
	{
		try
		{
			_objectIdentifier = InvertPersonPersistenceBase.class.getDeclaredField("objectIdentifier");
			_objectIdentifier.setAccessible(true);
		}
		catch(Throwable ex)
		{
			//Always catch all exceptions in a static block.
			ex.printStackTrace();
		}
	}
}
