/*
 *  Copyright (C) 2001 David Hoag
 *  ObjectWave Corporation
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *  For a full copy of the license see:
 *  http://www.opensource.org/licenses/lgpl-license.html
 */
package com.objectwave.persist.examples;
import com.objectwave.persist.*;
import com.objectwave.persist.broker.FileBroker;
import com.objectwave.persist.mapping.*;
import com.objectwave.transactionalSupport.*;
import com.objectwave.transactionalSupport.ObjectEditingView;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.Vector;

/**
 * @author  dhoag
 * @version  $Id: JoinObject.java,v 2.1 2001/11/02 16:07:56 dave_hoag Exp $
 */
public class JoinObject extends DomainObject
{

	/**
	 */
	public static Vector classDescriptor;
	// See below
	/**
	 */
	public static Field _linkToOne;
	/**
	 */
	public static Field _linkToTwo;
	/**
	 */
	public static Field _dummyField;
	/**
	 */
	public ManySideOne linkToOne;
	/**
	 */
	public ManySideTwo linkToTwo;
	protected Integer dummyField;

	/**
	 *  Constructor for the JoinObject object
	 */
	public JoinObject()
	{
	}
	/**
	 *  Generated accessors that route get and set methods through our
	 *  ObjectEditor.
	 *
	 * @return  The LinkToOne value
	 */
	public ManySideOne getLinkToOne()
	{
		return (ManySideOne) editor.get(_linkToOne, linkToOne);
	}
	/**
	 *  Gets the LinkToTwo attribute of the JoinObject object
	 *
	 * @return  The LinkToTwo value
	 */
	public ManySideTwo getLinkToTwo()
	{
		return (ManySideTwo) editor.get(_linkToTwo, linkToTwo);
	}
	/**
	 *  Describe how each attribute relates to the database.
	 */
	public void initDescriptor()
	{
		synchronized(ExampleEmployee.class)
		{
			if(classDescriptor != null)
			{
				return;
			}
			//For Thread Safety
			Vector tempVector = new Vector();
			AttributeTypeColumn col = AttributeTypeColumn.getForeignRelation(ManySideOne.class, "linkToOne", _linkToOne);
			tempVector.addElement(col);
			col = AttributeTypeColumn.getForeignRelation(ManySideTwo.class, "linkToTwo", _linkToTwo);
			tempVector.addElement(col);

			col = AttributeTypeColumn.getAttributeRelation("linkToOne", _linkToOne);
			//duplicate entry
			col.setAsPrimary();
			tempVector.addElement(col);

			classDescriptor = tempVector;
		}

	}
	/**
	 *  Needed to define table name and the description of this class.
	 *
	 * @return
	 */
	public ObjectEditingView initializeObjectEditor()
	{
		final RDBPersistentAdapter result = new JoinAdapter(this);
		if(classDescriptor == null)
		{
			initDescriptor();
		}
		result.setTableName("joinTable");
		result.setBrokerGeneratedPrimaryKeys(false);
		result.setClassDescription(classDescriptor);
		return result;
	}
	/**
	 * @author  dhoag
	 * @version  $Id: JoinObject.java,v 2.1 2001/11/02 16:07:56 dave_hoag Exp $
	 */
	public static class Test extends com.objectwave.test.UnitTestBaseImpl
	{
		FileBroker fb;
		/**
		 *  The main program for the Test class
		 *
		 * @param  args The command line arguments
		 */
		public static void main(String[] args)
		{
			com.objectwave.test.TestRunner.run(new Test(), args);
		}
		/**
		 *  The JUnit setup method
		 *
		 * @param  str The new Up value
		 * @param  context The new Up value
		 */
		public void setUp(String str, com.objectwave.test.TestContext context)
		{
			fb = new FileBroker();
			BrokerFactory.setDefaultBroker(fb);
			SQLQuery.setDefaultBroker(fb);
		}
		/**
		 *  The teardown method for JUnit
		 *
		 * @param  context
		 */
		public void tearDown(com.objectwave.test.TestContext context)
		{
			fb.close();
			removeFile("manySideOne.dbf");
			removeFile("joinTable.dbf");
			removeFile("manySideTwo.dbf");
		}
		/**
		 *  A unit test for JUnit
		 *
		 * @exception  Exception
		 */
		public void testQuery() throws Exception
		{
			testSave();
			JoinObject join = new JoinObject();
			SQLQuery query = new SQLQuery(join);
			ArrayList list = (ArrayList) query.findCollection(ArrayList.class);
			for(int i = 0; i < list.size(); i++)
			{
				System.out.println(list.get(i));
			}

		}
		/**
		 *  A unit test for JUnit
		 *
		 * @exception  Exception
		 */
		public void testSave() throws Exception
		{
			Session session = Session.createAndJoin("SaveSession");
			session.startTransaction("RDB");
			ManySideOne one = new ManySideOne();
			one.setEmailAddress("FirstOne");
			ManySideOne oneAgain = new ManySideOne();
			oneAgain.setEmailAddress("SecondOne");
			ManySideTwo two = new ManySideTwo();
			two.setTitle("FirstTwo");
			ManySideTwo twoAgain = new ManySideTwo();
			twoAgain.setTitle("SecondTwo");
			JoinObject joinIt = new JoinObject();
			joinIt.linkToOne = one;
			joinIt.linkToTwo = two;
			joinIt.insert();
			one.insert();
			two.insert();
			session.commit();
			session.leave();
		}

	}

	static
	{
		try
		{
			_linkToOne = JoinObject.class.getDeclaredField("linkToOne");
			_linkToOne.setAccessible(true);
			_linkToTwo = JoinObject.class.getDeclaredField("linkToTwo");
			_linkToTwo.setAccessible(true);
			_dummyField = JoinObject.class.getDeclaredField("dummyField");
			_dummyField.setAccessible(true);
		}
		catch(NoSuchFieldException ex)
		{
			System.out.println(ex);
		}
	}
}
