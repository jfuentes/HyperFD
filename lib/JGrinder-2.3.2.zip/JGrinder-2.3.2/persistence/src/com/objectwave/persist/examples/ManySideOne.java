package com.objectwave.persist.examples;
import com.objectwave.persist.*;
import com.objectwave.persist.mapping.*;
import com.objectwave.transactionalSupport.ObjectEditingView;
import java.lang.reflect.*;
import java.util.Vector;

/**
 * @author  dhoag
 * @version  $Id: ManySideOne.java,v 2.0 2001/06/11 16:00:04 dave_hoag Exp $
 */
public class ManySideOne extends DomainObject
{
	/**
	 */
	public static Vector classDescriptor;

	// See below
	/**
	 */
	public static Field _title;
	/**
	 */
	public static Field _joinObjects;
	// See below
	/**
	 */
	public static Field _emailAddress;
	/**
	 */
	public String title = null;
	/**
	 */
	public String emailAddress = null;
	/**
	 */
	public Vector joinObjects;

	/**
	 *  Constructor for the ManySideOne object
	 */
	public ManySideOne()
	{
	}
	/**
	 *  Generated accessors that route get and set methods through our ObjectEditor.
	 *
	 * @param  aValue The new EmailAddress value
	 */
	public void setEmailAddress(String aValue)
	{
		editor.set(_emailAddress, aValue, emailAddress);
	}
	/**
	 *  Sets the JoinObjects attribute of the ManySideOne object
	 *
	 * @param  aValue The new JoinObjects value
	 */
	public void setJoinObjects(Vector aValue)
	{
		editor.set(_joinObjects, aValue, joinObjects);
	}
	/**
	 *  Generated accessors that route get and set methods through our ObjectEditor.
	 *
	 * @param  aValue The new Title value
	 */
	public void setTitle(String aValue)
	{
		editor.set(_title, aValue, title);
	}
	/**
	 *  Generated accessors that route get and set methods through our ObjectEditor.
	 *
	 * @return  The EmailAddress value
	 */
	public String getEmailAddress()
	{
		return (String) editor.get(_emailAddress, emailAddress);
	}
	/**
	 *  Gets the JoinObjects attribute of the ManySideOne object
	 *
	 * @return  The JoinObjects value
	 */
	public Vector getJoinObjects()
	{
		return (Vector) editor.get(_joinObjects, joinObjects);
	}
	/**
	 *  Generated accessors that route get and set methods through our ObjectEditor.
	 *
	 * @return  The Title value
	 */
	public String getTitle()
	{
		return (String) editor.get(_title, title);
	}
	/**
	 *  Describe how each attribute relates to the database.
	 */
	public void initDescriptor()
	{
		synchronized(ManySideOne.class)
		{
			if(classDescriptor != null)
			{
				return;
			}
			//For Thread Safety
			Vector tempVector = getSuperDescriptor();
			AttributeTypeColumn col = AttributeTypeColumn.getAttributeRelation("title", _title);
			tempVector.addElement(col);
			col = AttributeTypeColumn.getAttributeRelation("emailAddress", _emailAddress);
			tempVector.addElement(col);
			col = AttributeTypeColumn.getCollectionRelation(JoinObject.class, _joinObjects);
			col.setJoinOn(JoinObject._linkToOne);
			tempVector.addElement(col);

			classDescriptor = tempVector;
		}

	}
	/**
	 *  Needed to define table name and the description of this class.
	 *
	 * @return
	 */
	public ObjectEditingView initializeObjectEditor()
	{
		final RDBPersistentAdapter result = (RDBPersistentAdapter) super.initializeObjectEditor();
		if(classDescriptor == null)
		{
			initDescriptor();
		}
		result.setTableName("manySideOne");
		result.setClassDescription(classDescriptor);
		return result;
	}

	static
	{
                 /*NAME:fieldDefinition:*/
		try
		{
			_title = ManySideOne.class.getDeclaredField("title");
			_title.setAccessible(true);
			_emailAddress = ManySideOne.class.getDeclaredField("emailAddress");
			_emailAddress.setAccessible(true);
			_joinObjects = ManySideOne.class.getDeclaredField("joinObjects");
			_joinObjects.setAccessible(true);
		}
		catch(NoSuchFieldException ex)
		{
			System.out.println(ex);
		}
	}
}
