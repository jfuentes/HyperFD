package com.objectwave.persist.examples;
import com.objectwave.persist.*;
import com.objectwave.persist.mapping.*;
import com.objectwave.transactionalSupport.ObjectEditingView;
import java.lang.reflect.*;
import java.util.Vector;

/**
 * @author  dhoag
 * @version  $Id: ManySideTwo.java,v 2.0 2001/06/11 16:00:04 dave_hoag Exp $
 */
public class ManySideTwo extends DomainObject
{

	/**
	 */
	public static Vector classDescriptor;
	// See below
	/**
	 */
	public static Field _title;
	/**
	 */
	public static Field _joinObjects;
	/**
	 */
	public static Field _instanceLink;
	/**
	 */
	public static Field _instanceLinkWCol;
	/**
	 */
	public static Field _fkLink;
	/**
	 */
	public String title = null;
	/**
	 */
	public Vector joinObjects;
	/**
	 */
	public JoinObject instanceLink;
	/**
	 */
	public JoinObject instanceLinkWCol;
	/**
	 */
	public JoinObject fkLink;

	/**
	 *  Constructor for the ManySideTwo object
	 */
	public ManySideTwo()
	{
	}
	/**
	 *  Sets the JoinObjects attribute of the ManySideTwo object
	 *
	 * @param  aValue The new JoinObjects value
	 */
	public void setJoinObjects(Vector aValue)
	{
		editor.set(_joinObjects, aValue, joinObjects);
	}
	/**
	 *  Generated accessors that route get and set methods through our ObjectEditor.
	 *
	 * @param  aValue The new Title value
	 */
	public void setTitle(String aValue)
	{
		editor.set(_title, aValue, title);
	}
	/**
	 *  Gets the FkLink attribute of the ManySideTwo object
	 *
	 * @return  The FkLink value
	 */
	public JoinObject getFkLink()
	{
		return (JoinObject) editor.get(_fkLink, fkLink);
	}
	/**
	 *  Gets the InstanceLinkWCol attribute of the ManySideTwo object
	 *
	 * @return  The InstanceLinkWCol value
	 */
	public JoinObject getInstanceLinkWCol()
	{
		return (JoinObject) editor.get(_instanceLinkWCol, instanceLinkWCol);
	}
	/**
	 *  Gets the InstanceLink attribute of the ManySideTwo object
	 *
	 * @return  The InstanceLink value
	 */
	public JoinObject getInstanceLink()
	{
		return (JoinObject) editor.get(_instanceLink, instanceLink);
	}
	/**
	 *  Gets the JoinObjects attribute of the ManySideTwo object
	 *
	 * @return  The JoinObjects value
	 */
	public Vector getJoinObjects()
	{
		return (Vector) editor.get(_joinObjects, joinObjects);
	}
	/**
	 *  Generated accessors that route get and set methods through our ObjectEditor.
	 *
	 * @return  The Title value
	 */
	public String getTitle()
	{
		return (String) editor.get(_title, title);
	}
	/**
	 *  Describe how each attribute relates to the database.
	 */
	public void initDescriptor()
	{
		synchronized(ManySideTwo.class)
		{
			if(classDescriptor != null)
			{
				return;
			}
			//For Thread Safety
			Vector tempVector = getSuperDescriptor();
			AttributeTypeColumn col = AttributeTypeColumn.getAttributeRelation("title", _title);
			tempVector.addElement(col);
			col = AttributeTypeColumn.getCollectionRelation(JoinObject.class, _joinObjects);
			col.setJoinOn(JoinObject._linkToTwo);
			tempVector.addElement(col);
			col = AttributeTypeColumn.getInstanceRelation(JoinObject.class, _instanceLink);
			col.setJoinOn(JoinObject._linkToTwo);
			tempVector.addElement(col);
			col = AttributeTypeColumn.getInstanceRelation(JoinObject.class, "instanceCol", _instanceLinkWCol);
			col.setJoinOn(JoinObject._linkToTwo);
			tempVector.addElement(col);
			col = AttributeTypeColumn.getForeignRelation(JoinObject.class, "fkColumn", _fkLink);
			col.setJoinOn(JoinObject._linkToTwo);
			tempVector.addElement(col);

			classDescriptor = tempVector;
		}

	}
	/**
	 *  Needed to define table name and the description of this class.
	 *
	 * @return
	 */
	public ObjectEditingView initializeObjectEditor()
	{
		final RDBPersistentAdapter result = (RDBPersistentAdapter) super.initializeObjectEditor();
		if(classDescriptor == null)
		{
			initDescriptor();
		}
		result.setTableName("manySideTwo");
		result.setClassDescription(classDescriptor);
		return result;
	}
	// See below

	static
	{
                 /*NAME:fieldDefinition:*/
		try
		{
			_title = ManySideTwo.class.getDeclaredField("title");
			_title.setAccessible(true);
			_joinObjects = ManySideTwo.class.getDeclaredField("joinObjects");
			_joinObjects.setAccessible(true);
			_instanceLink = ManySideTwo.class.getDeclaredField("instanceLink");
			_instanceLink.setAccessible(true);
			_instanceLinkWCol = ManySideTwo.class.getDeclaredField("instanceLinkWCol");
			_instanceLinkWCol.setAccessible(true);
			_fkLink = ManySideTwo.class.getDeclaredField("fkLink");
			_fkLink.setAccessible(true);
		}
		catch(NoSuchFieldException ex)
		{
			System.out.println(ex);
		}
	}
}
