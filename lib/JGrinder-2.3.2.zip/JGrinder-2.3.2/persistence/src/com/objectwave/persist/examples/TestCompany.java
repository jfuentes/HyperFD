package com.objectwave.persist.examples;

import com.objectwave.persist.*;
import com.objectwave.persist.mapping.*;
import com.objectwave.transactionalSupport.ObjectEditingView;
import java.util.Vector;
import java.lang.reflect.Field;

/**
 *
 * @version $Id: TestCompany.java,v 2.0 2001/06/11 16:00:04 dave_hoag Exp $
 */
public class TestCompany extends DomainObject
{
	transient int entityType = TestEntity.COMPANY;

	public String name;
	public String phone;
	public String fax;

	public String moodyRating;
	public int numEmployees;
	public TestPerson primaryContact;
	public static Vector classDescriptor;

	static Field _entityType;
	static Field _name;
	static Field _phone;
	static Field _fax;
	static Field _moodyRating;
	static Field _numEmployees;
	static Field _primaryContact;

	/**
	* This static block will be regenerated if persistence is regenerated.
	*/
	static { /*NAME:fieldDefinition:*/
		try{
			_entityType = TestCompany.class.getDeclaredField("entityType");
			_name = TestCompany.class.getDeclaredField("name");
			_phone = TestCompany.class.getDeclaredField("phone");
			_fax = TestCompany.class.getDeclaredField("fax");
			_moodyRating = TestCompany.class.getDeclaredField("moodyRating");
			_numEmployees = TestCompany.class.getDeclaredField("numEmployees");
			_primaryContact = TestCompany.class.getDeclaredField("primaryContact");
		}
		catch (NoSuchFieldException ex) { System.out.println(ex); }
	}
	/**
	* @author
	*/
	public String getFax()
	{
		return (String)editor.get(_fax, fax);
	}
	/**
	* @author
	*/
	public String getMoodyRating()
	{
		return (String)editor.get(_moodyRating, moodyRating);
	}
	/**
	* @author
	*/
	public String getName()
	{
		return (String)editor.get(_name, name);
	}
	/**
	* @author
	*/
	public int getNumEmployees()
	{
		return (int)editor.get(_numEmployees, numEmployees);
	}
	/**
	* @author
	*/
	public String getPhone()
	{
		return (String)editor.get(_phone, phone);
	}
/**
 *
 * @author Steven Sinclair
 * @return com.objectwave.persist.TestPerson
 */
public TestPerson getPrimaryContact()
{
	return (TestPerson)editor.get(_primaryContact, primaryContact);
}
	/**
	* Describe how this class relates to the relational database.
	*/
	public void initDescriptor()
	{
		synchronized(TestCompany.class)
		{
			if(classDescriptor != null) return;
			//For Thread Safety
			Vector tempVector = getSuperDescriptor();
 			tempVector.addElement(AttributeTypeColumn.getTypeAttributeRelation( "entityType" , _entityType));
			tempVector.addElement(AttributeTypeColumn.getAttributeRelation( "name" , _name));
			tempVector.addElement(AttributeTypeColumn.getAttributeRelation( "phone" , _phone));
			tempVector.addElement(AttributeTypeColumn.getAttributeRelation( "fax" , _fax));
			tempVector.addElement(AttributeTypeColumn.getAttributeRelation( "moodyRating" , _moodyRating));
			tempVector.addElement(AttributeTypeColumn.getAttributeRelation( "numEmployees" , _numEmployees));
			tempVector.addElement(AttributeTypeColumn.getForeignRelation(TestPerson.class, "primaryContact" , _primaryContact));

			classDescriptor = tempVector;
		}
	}
	/**
	* Needed to define table name and the description of this class.
	*/
	public ObjectEditingView initializeObjectEditor()
	{
		final RDBPersistentAdapter result = new RDBExtendablePersistentAdapter(this);
		if(classDescriptor == null) initDescriptor();
		result.setTableName("testEntity");
		result.setClassDescription(classDescriptor);
		return result;
	}
	/**
	* @author
	*/
	public void setFax(String aValue)
	{
		editor.set(_fax, aValue, fax);
	}
	/**
	* @author
	*/
	public void setMoodyRating(String aValue)
	{
		editor.set(_moodyRating, aValue, moodyRating);
	}
	/**
	* @author
	*/
	public void setName(String aValue)
	{
		editor.set(_name, aValue, name);
	}
	/**
	* @author
	*/
	public void setNumEmployees(int aValue)
	{
		editor.set(_numEmployees, aValue, numEmployees);
	}
	/**
	* @author
	*/
	public void setPhone(String aValue)
	{
		editor.set(_phone, aValue, phone);
	}
/**
 *
 * @author Steven Sinclair
 * @param value com.objectwave.persist.TestPerson
 */
public void setPrimaryContact(TestPerson value)
{
	editor.set(_primaryContact, value, primaryContact);
}
	/**  This method allows me to get arounds security problems with updating
	* and object from a generic framework.
	*/
	public void update(boolean get, Object [] data, Field [] fields)
	{
		for(int i = 0; i < data.length; i++){
			try{
			if(get)
				data[i] = fields[i].get(this);
			else
				fields[i].set(this, data[i]);
			} catch(IllegalAccessException ex) { System.out.println(ex); }
			catch(IllegalArgumentException ex) { System.out.println(ex); }
		}
	}
}