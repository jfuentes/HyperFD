package com.objectwave.persist.examples;

import com.objectwave.persist.*;
import com.objectwave.persist.mapping.*;
import com.objectwave.transactionalSupport.ObjectEditingView;
import java.util.Vector;
import java.lang.reflect.Field;
/**
 *
 * @version $Id: TestEntity.java,v 2.0 2001/06/11 16:00:04 dave_hoag Exp $
 */
public class TestEntity extends  DomainObject
{
	public static final int PERSON=1;
	public static final int COMPANY=2;

	transient int entityType;
	public String name;
	public String phone;
	public String fax;

	public String title;
	public double annualIncome;

	String moodyRating;
	int numEmployees;
	TestPerson primaryContact;

	static Field _entityType;
	static Field _name;
	static Field _phone;
	static Field _fax;
	static Field _title;
	static Field _annualIncome;
	static Field _moodyRating;
	static Field _numEmployees;
	static Field _primaryContact;

	static Vector classDescriptor;

	/**
	* This static block will be regenerated if persistence is regenerated.
	*/
	static { // NAME:fieldDefinition:
		try{
			_entityType = TestEntity.class.getDeclaredField("entityType");
			_name = TestEntity.class.getDeclaredField("name");
			_phone = TestEntity.class.getDeclaredField("phone");
			_fax = TestEntity.class.getDeclaredField("fax");
			_title = TestEntity.class.getDeclaredField("title");
			_annualIncome = TestEntity.class.getDeclaredField("annualIncome");
			_moodyRating = TestEntity.class.getDeclaredField("moodyRating");
			_numEmployees = TestEntity.class.getDeclaredField("numEmployees");
			_primaryContact = TestEntity.class.getDeclaredField("primaryContact");
		}
		catch (NoSuchFieldException ex) { System.out.println(ex); }
	}

	class MyAdapter extends RDBExtendablePersistentAdapter
	{
		MyAdapter() { super(null); }
		MyAdapter(Persistence p) { super(p); }
		public Persistence createInstance(final RDBPersistence refObj,
										  final RDBPersistence origObj,
										  final Object classValue)
		{
			return TestEntity.createInstance(refObj, origObj, classValue);
		}
	}
/**
 * Create a new instance of the correct type based on the value
 * of classValue.
 *
 * @author Steven Sinclair
 * @return com.objectwave.persist.Persistence
 * @param refObj com.objectwave.persist.RDBPersistence
 * @param classValue java.lang.Object
 * @param columnValuesHolder com.objectwave.utility.ObjectHolder
 */
protected static Persistence createInstance(RDBPersistence refObj, RDBPersistence origObj, Object classValue)
{
	int type = -1;
	if (classValue != null)
		try { type = ((Integer)classValue).intValue(); } // typeObj is an int, so we expect an Integer.
		catch (NumberFormatException ex) { }

	Persistence obj = null;

	switch (type)
	{
		case PERSON:
			obj = new TestPerson();
			break;
		case COMPANY:
			obj = new TestCompany();
			break;
	}
	return obj;
}
	/**
	* @author
	*/
	protected double getAnnualIncome()
	{
		return (double)editor.get(_annualIncome, annualIncome);
	}
	/**
	* @author
	*/
	protected String getFax()
	{
		return (String)editor.get(_fax, fax);
	}
	/**
	* @author
	*/
	protected String getMoodyRating()
	{
		return (String)editor.get(_moodyRating, moodyRating);
	}
	/**
	* @author
	*/
	public String getName()
	{
		return (String)editor.get(_name, name);
	}
	/**
	* @author
	*/
	protected int getNumEmployees()
	{
		return (int)editor.get(_numEmployees, numEmployees);
	}
	/**
	* @author
	*/
	public String getPhone()
	{
		return (String)editor.get(_phone, phone);
	}
	/**
	* @author
	*/
	protected String getTitle()
	{
		return (String)editor.get(_title, title);
	}
	/**
	* Describe how this class relates to the relational database.
	*/
	public void initDescriptor()
	{
		synchronized(TestEntity.class)
		{
			if(classDescriptor != null) return;
			//For Thread Safety
			Vector tempVector = getSuperDescriptor();

			tempVector.addElement(AttributeTypeColumn.getAttributeRelation( "entityType" , _entityType));
			tempVector.addElement(AttributeTypeColumn.getAttributeRelation( "name" , _name));
			tempVector.addElement(AttributeTypeColumn.getAttributeRelation( "phone" , _phone));
			tempVector.addElement(AttributeTypeColumn.getAttributeRelation( "fax" , _fax));
			tempVector.addElement(AttributeTypeColumn.getAttributeRelation( "title" , _title));
			tempVector.addElement(AttributeTypeColumn.getAttributeRelation( "annualIncome" , _annualIncome));
			tempVector.addElement(AttributeTypeColumn.getAttributeRelation( "moodyRating" , _moodyRating));
			tempVector.addElement(AttributeTypeColumn.getAttributeRelation( "numEmployees" , _numEmployees));
			tempVector.addElement(AttributeTypeColumn.getForeignRelation(TestPerson.class, "primaryContact", _primaryContact));
			classDescriptor = tempVector;
		}
	}
	/**
	* Needed to define table name and the description of this class.
	*/
	public ObjectEditingView initializeObjectEditor()
	{
		final RDBPersistentAdapter result = new MyAdapter(this);
		if(classDescriptor == null) initDescriptor();
		result.setTableName("TestEntity");
		result.setClassDescription(classDescriptor);
		return result;
	}
/**
 *
 * @author Steven Sinclair
 * @param args java.lang.String[]
 */
public static void main(String args[])
{
	if (args.length != 1 || (!args[0].equalsIgnoreCase("insert") &&
	                         !args[0].equalsIgnoreCase("query")))
	{
		System.out.println("Expected args: {insert|query}");
		return;
	}

	com.objectwave.persist.BrokerFactory.useDatabase();
	//((RDBBroker)BrokerFactory.getDefaultBroker()).setUsePreparedStatements(true);

	com.objectwave.transactionalSupport.Session ses;
	ses = com.objectwave.transactionalSupport.Session.createAndJoin("name");
	ses.startTransaction("RDB");

	if (args[0].equalsIgnoreCase("insert"))
	{
		System.out.println("Create a n independant person, a person associated with a company, and a company.");
		TestPerson person = new TestPerson();
		person.setName("A Person's Name");
		person.setPhone("1-555-555-1111");
		person.setFax("1-555-555-1112");
		person.setTitle("A Person's Title");
		person.setAnnualIncome(25000.0);

		TestPerson employee = new TestPerson();
		employee.setName("An Employee's Name");
		employee.setPhone("1-111-111-1111");
		employee.setFax("1-111-111-1112");
		employee.setTitle("An Employee's Title");
		employee.setAnnualIncome(55000.0);

		TestCompany company = new TestCompany();
		company.setName("A Company's Name");
		company.setPhone("1-222-222-2222");
		company.setFax("1-222-222-2223");
		company.setMoodyRating("A++");
		company.setNumEmployees(35);
		company.setPrimaryContact(employee);
	}
	else if (args[0].equalsIgnoreCase("query"))
	{
		TestEntity subject = new TestEntity();
		SQLQuery query = new SQLQuery(subject);
		try
		{
			Vector results = query.find();
			System.out.println("Got " + results.size() + " result(s):");
			for (java.util.Enumeration e = results.elements(); e.hasMoreElements(); )
			{
				Object obj = e.nextElement();
				System.out.println("\t[ class " + obj.getClass() + " ] : " + obj);
				if (TestPerson.class.isInstance(obj))
				{
					TestPerson person = (TestPerson)obj;
					System.out.println("\t\t name .........: " + person.getName());
					System.out.println("\t\t title ........: " + person.getTitle());
					System.out.println("\t\t phone ........: " + person.getPhone());
					System.out.println("\t\t fax ..........: " + person.getFax());
					System.out.println("\t\t ann. income...: " + person.getAnnualIncome());
				}
				else if (TestCompany.class.isInstance(obj))
				{
					TestCompany company = (TestCompany)obj;
					System.out.println("\t\t name .............: " + company.getName());
					System.out.println("\t\t phone ............: " + company.getPhone());
					System.out.println("\t\t fax ..............: " + company.getFax());
					System.out.println("\t\t Moody rating......: " + company.getMoodyRating());
					System.out.println("\t\t # employees.......: " + company.getNumEmployees());
					System.out.println("\t\t primary contact ..: " + (company.getPrimaryContact()==null ? "[null]" : ""+company.getPrimaryContact().getName()));
				}
			}
		}
		catch (QueryException ex)
		{
			System.out.println("Caught query ex.: " + ex);
		}
	}

	try
	{
		ses.commit();
		System.out.println("Session has been committed.");
	}
	catch (com.objectwave.transactionalSupport.UpdateException ex)
	{
		System.out.println("Error committing transaction: " + ex);
		try
		{
			BrokerFactory.getDefaultBroker().rollback();
		}
		catch (QueryException ex2)
		{
			System.out.println("Error in attempted rollback: " + ex2);
		}
	}
}
	/**
	* @author
	*/
	protected void setAnnualIncome(double aValue)
	{
		editor.set(_annualIncome, aValue, annualIncome);
	}
	/**
	* @author
	*/
	public void setFax(String aValue)
	{
		editor.set(_fax, aValue, fax);
	}
	/**
	* @author
	*/
	protected void setMoodyRating(String aValue)
	{
		editor.set(_moodyRating, aValue, moodyRating);
	}
	/**
	* @author
	*/
	public void setName(String aValue)
	{
		editor.set(_name, aValue, name);
	}
	/**
	* @author
	*/
	protected void setNumEmployees(int aValue)
	{
		editor.set(_numEmployees, aValue, numEmployees);
	}
	/**
	* @author
	*/
	protected void setPhone(String aValue)
	{
		editor.set(_phone, aValue, phone);
	}
	/**
	* @author
	*/
	protected void setTitle(String aValue)
	{
		editor.set(_title, aValue, title);
	}
	/**  This method allows me to get arounds security problems with updating
	* and object from a generic framework.
	*/
	public void update(boolean get, Object [] data, Field [] fields)
	{
		for(int i = 0; i < data.length; i++){
			try{
			if(get)
				data[i] = fields[i].get(this);
			else
				fields[i].set(this, data[i]);
			} catch(IllegalAccessException ex) { System.out.println(ex); }
			catch(IllegalArgumentException ex) { System.out.println(ex); }
		}
	}
}