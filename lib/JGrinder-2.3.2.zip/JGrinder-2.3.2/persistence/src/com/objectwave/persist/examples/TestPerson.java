package com.objectwave.persist.examples;

import com.objectwave.persist.*;
import com.objectwave.persist.mapping.*;
import com.objectwave.transactionalSupport.ObjectEditingView;
import java.util.Vector;
import java.lang.reflect.Field;

/**
 *
 * @version $Id: TestPerson.java,v 2.0 2001/06/11 16:00:04 dave_hoag Exp $
 */
public class TestPerson extends DomainObject
{
	public transient int entityType = TestEntity.PERSON;
	public String name;
	public String phone;
	public String fax;

	public String title;
	public double annualIncome;

	public static Vector classDescriptor;

	public static Field _entityType;
	public static Field _name;
	public static Field _phone;
	public static Field _fax;
	public static Field _title;
	public static Field _annualIncome;
	/**
	* This static block will be regenerated if persistence is regenerated.
	*/
	static { /*NAME:fieldDefinition:*/
		try{
			_entityType = TestPerson.class.getDeclaredField("entityType");
			_name = TestPerson.class.getDeclaredField("name");
			_phone = TestPerson.class.getDeclaredField("phone");
			_fax = TestPerson.class.getDeclaredField("fax");
			_title = TestPerson.class.getDeclaredField("title");
			_annualIncome = TestPerson.class.getDeclaredField("annualIncome");

			if(System.getProperty("accessible") != null)
			{
				_entityType.setAccessible(true);
				_name.setAccessible(true);
				_phone.setAccessible(true);
				_fax.setAccessible(true);
				_title.setAccessible(true);
				_annualIncome.setAccessible(true);
			}
		}
		catch (NoSuchFieldException ex) { System.out.println(ex); }
	}
	/**
	* @author
	*/
	public double getAnnualIncome()
	{
		return (double)editor.get(_annualIncome, annualIncome);
	}
	/**
	* @author
	*/
	public String getFax()
	{
		return (String)editor.get(_fax, fax);
	}
	/**
	* @author
	*/
	public String getName()
	{
		return (String)editor.get(_name, name);
	}
	/**
	* @author
	*/
	public String getPhone()
	{
		return (String)editor.get(_phone, phone);
	}
	/**
	* @author
	*/
	public String getTitle()
	{
		return (String)editor.get(_title, title);
	}
	/**
	* Describe how this class relates to the relational database.
	*/
	public void initDescriptor()
	{
		synchronized(TestPerson.class)
		{
			if(classDescriptor != null) return;
			//For Thread Safety
			Vector tempVector = getSuperDescriptor();

			tempVector.addElement(AttributeTypeColumn.getAttributeRelation( "entityType" , _entityType));
			tempVector.addElement(AttributeTypeColumn.getAttributeRelation( "name" , _name));
			tempVector.addElement(AttributeTypeColumn.getAttributeRelation( "fax" , _fax));
			tempVector.addElement(AttributeTypeColumn.getAttributeRelation( "title" , _title));
			tempVector.addElement(AttributeTypeColumn.getAttributeRelation( "phone" , _phone));
			tempVector.addElement(AttributeTypeColumn.getAttributeRelation( "annualIncome" , _annualIncome));

			classDescriptor = tempVector;
		}

	}
	/**
	* Needed to define table name and the description of this class.
	*/
	public ObjectEditingView initializeObjectEditor()
	{
		final RDBPersistentAdapter result = new RDBExtendablePersistentAdapter(this);
		if(classDescriptor == null) initDescriptor();
		result.setTableName("testEntity");
		result.setClassDescription(classDescriptor);
		return result;
	}
	/**
	* @author
	*/
	public void setAnnualIncome(double aValue)
	{
		editor.set(_annualIncome, aValue, annualIncome);
	}
	/**
	* @author
	*/
	public void setFax(String aValue)
	{
		editor.set(_fax, aValue, fax);
	}
	/**
	* @author
	*/
	public void setName(String aValue)
	{
		editor.set(_name, aValue, name);
	}
	/**
	* @author
	*/
	public void setPhone(String aValue)
	{
		editor.set(_phone, aValue, phone);
	}
	/**
	* @author
	*/
	public void setTitle(String aValue)
	{
		editor.set(_title, aValue, title);
	}
	/**  This method allows me to get arounds security problems with updating
	* and object from a generic framework.
	*/
	public void update(boolean get, Object [] data, Field [] fields)
	{
		for(int i = 0; i < data.length; i++){
			try{
			if(get)
				data[i] = fields[i].get(this);
			else
				fields[i].set(this, data[i]);
			} catch(IllegalAccessException ex) { System.out.println(ex); }
			catch(IllegalArgumentException ex) { System.out.println(ex); }
		}
	}
	public static void main(String [] args)
	{
//		BrokerFactory.setDefaultBroker(new NullBroker());
//		SQLQuery.setDefaultBroker(new NullBroker());
		BrokerFactory.useDatabase();
		int count = Integer.valueOf(args[0]).intValue();
		long time = System.currentTimeMillis();
		for(int i = 0; i < count; ++i)
		{
			com.objectwave.transactionalSupport.TransactionLog log = com.objectwave.transactionalSupport.TransactionLog.startTransaction(  "RDB", "context");
			TestPerson person = new TestPerson();
			person.setName("one");
			person.setTitle("asdfasd");
			person.setPhone("asdf");
			person.setAnnualIncome(2342.0d);
			try
			{
			log.commit();
			}
			catch(Exception e) { e.printStackTrace(); }
		}
		time = (System.currentTimeMillis() - time) ;
		System.out.println("Total time " + time + " count/milli " +( count /time) );
	}
}
