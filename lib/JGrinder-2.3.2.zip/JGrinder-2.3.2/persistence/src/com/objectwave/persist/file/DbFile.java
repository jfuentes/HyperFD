/*
 *  Copyright (C) 2001 David Hoag
 *  ObjectWave Corporation
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *  For a full copy of the license see:
 *  http://www.opensource.org/licenses/lgpl-license.html
 */
package com.objectwave.persist.file;
import com.objectwave.logging.MessageLog;
import com.objectwave.persist.*;
import com.objectwave.persist.properties.FilePropertySource;
import com.objectwave.utility.FileLock;
import java.io.*;
import java.util.*;
/**
 *  An abstraction of a flat file that is contain data for a particular
 *  persistent object.
 *
 * @author  Dave Hoag
 * @version  $Id: DbFile.java,v 2.2 2001/11/02 16:07:56 dave_hoag Exp $
 */
public class DbFile
{
	static boolean shared;
	String fileName;
	WeakHashMap objectToRecordHeader;
	RandomAccessFile sourceFile;
	RandomAccessFile indexFile;
	boolean locked = false;
	boolean inUse;
	Long idx;
	long idxPos;
	Thread user;
	/**
	 *  Create a RandomAccessFile with the provided file name to hold 'database'
	 *  records.
	 *
	 * @param  aFileName
	 */
	public DbFile(final String aFileName)
	{
		initialize(aFileName);
	}

	/**
	 * @param  p
	 * @return
	 */
	public static Object buildPrimaryKeyString(Persistence p)
	{
		if(p == null)
		{
			return "";
		}
		Object[] pks = p.getPrimaryKeyFields();
		if(pks == null || pks.length == 0)
		{
			return "";
		}
		else if(pks.length == 1)
		{
			return p.getPrimaryKeyField();
		}
		else
		{
			StringBuffer sb = new StringBuffer();
			sb.append(pks[0].toString());
			for(int i = 1; i < pks.length; i++)
			{
				sb.append('|');
				sb.append(pks[i].toString());
			}
			return sb.toString();
		}
	}
	/**
	 * @param  bValue The new InUse value
	 */
	public void setInUse(final boolean bValue)
	{
		inUse = bValue;
		if(inUse)
		{
			user = Thread.currentThread();
		}
		else
		{
			user = null;
		}
	}
	/**
	 *  Get the next index value. Only one thread can be manipulating a DbFile at a
	 *  time. No need to synchronize.
	 *
	 * @return  The NextIdx value
	 */
	public long getNextIdx()
	{
		long result = idx.longValue() + 1;
		idx = new Long(result);
		return result;
	}
	/**
	 *  Is this file currently in use by this process?
	 *
	 * @return  The InUse value
	 */
	public final boolean isInUse()
	{
		if(inUse && user == Thread.currentThread())
		{
			return false;
		}
		return inUse;
	}
	/**
	 *  Is this file currently locked by this process?
	 *
	 * @return  The Locked value
	 */
	public final boolean isLocked()
	{
		return locked;
	}
	/**
	 * @return  RandomAccessFile The file which represents our database.
	 */
	public RandomAccessFile getSourceFile()
	{
		if(sourceFile == null)
		{
			try
			{
				sourceFile = new RandomAccessFile(fileName, "rw");
			}
			catch(FileNotFoundException ex)
			{
				ex.printStackTrace();
			}
		}
		//will never occur since we are opening "rw"
		return sourceFile;
	}
	/**
	 *  Locate the record header for this persistent object.
	 *
	 * @param  obj
	 * @return  The RecordHeader value
	 * @exception  IOException
	 */
	protected RecordHeader getRecordHeader(final Persistence obj) throws IOException
	{
		Persistence adapter = obj;
		if(obj.usesAdapter())
		{
			adapter = obj.getAdapter();
		}
		RecordHeader header = (RecordHeader) objectToRecordHeader.get(adapter);
		if(header == null && obj.isRetrievedFromDatabase())
		{
			Iterator iterator = iterator();
			while(iterator.hasNext())
			{
				header = (RecordHeader) iterator.next();
				Object pkValue = ObjectBuilder.defaultFormatter.convertType(adapter.getPrimaryKeyField().getClass(), header.getPrimaryKey());
				if(pkValue.equals(buildPrimaryKeyString(adapter)))
				{

					break;
				}
				header = null;
			}
			if(header == null)
			{
				throw new IllegalStateException("The object indicated it was retrieve from database, but no record could be located for it.");
			}
		}
		return header;
	}
	/**
	 * @return
	 * @exception  IOException
	 */
	public Iterator iterator() throws IOException
	{
		RandomAccessFile file = getSourceFile();
//        System.out.println("Starting record iterator at " + (idxPos + 8));
		file.seek(idxPos + 8);
		//Skip the primary key index

		return new RecordIterator(file);
	}
	/**
	 *  Match the Object with it's RecordHeader
	 *
	 * @param  obj
	 * @param  header
	 */
	public void associate(final Persistence obj, final RecordHeader header)
	{
		Persistence adapter = obj;
		if(obj.usesAdapter())
		{
			adapter = obj.getAdapter();
		}
		objectToRecordHeader.put(adapter, header);
	}
	/**
	 *  Take a lock out on the file so that we have exclusive access to this file.
	 *
	 * @exception  IOException
	 */
	public void lock() throws IOException
	{
		if(isLocked())
		{
			return;
		}
		if((!shared) && idx != null)
		{
			//We already have the index, no need to read

			locked = true;
			return;
		}
		RandomAccessFile file = getSourceFile();
		file.seek(0);
		if(shared)
		{
			FileLock.getLock(file);
		}
		locked = true;
		idxPos = file.getFilePointer();
		try
		{
			idx = new Long(file.readLong());
		}
		catch(EOFException ex)
		{
			//File didn't exist. Proceed!

			idx = new Long(0);
			file.writeLong(0);
		}
		catch(IOException e)
		{
			releaseLock();
			throw e;
		}
		catch(Throwable t)
		{
			releaseLock();
			t.printStackTrace();
			throw new IOException(t.toString());
		}
	}
	/**
	 *  Remove the file lock and update the last known index
	 *
	 * @exception  IOException
	 */
	public void releaseLock() throws IOException
	{
		RandomAccessFile file = getSourceFile();
		if(idx != null)
		{
			file.seek(idxPos);
			file.writeLong(idx.longValue());
		}

		if(shared)
		{
			FileLock.releaseLock(file);
			file.close();
			sourceFile = null;
		}
		locked = false;
	}
	/**
	 *  Close the file and release any locks we may have.
	 *
	 * @exception  IOException
	 */
	public void close() throws IOException
	{
		RandomAccessFile file = getSourceFile();
		if(shared)
		{
			FileLock.releaseLock(file);
		}
		file.close();
		sourceFile = null;
		locked = false;
	}
	/**
	 *  Save the provided persistent object. If its new, it will append the object
	 *  at the end of the db file.
	 *
	 * @param  obj
	 * @param  data
	 * @exception  QueryException
	 */
	public void save(final Persistence obj, final byte[] data) throws QueryException
	{
		if(!locked)
		{
			throw new IllegalStateException("Attempt to save to a file when the file is not locked!");
		}
		try
		{
			RecordHeader header = getRecordHeader(obj);
			if(header == null)
			{
				//Must be a new PersistentObject
				appendObject(obj, data);
			}
			else
			{
				try
				{
					header.update(getSourceFile(), data);
				}
				catch(EOFException eof)
				{
					appendObject(obj, data);
				}
			}
		}
		catch(IOException ex)
		{
			throw new QueryException("Failed to save data! ", ex);
		}
	}
	/**
	 *  You can only delete objects that were retieved from the file broker.
	 *
	 * @param  obj
	 * @exception  QueryException
	 */
	public void delete(final Persistence obj) throws QueryException
	{
		if(!locked)
		{
			throw new IllegalStateException("Attempt to delete from a file when the file is not locked!");
		}
		// if it was null, nothing to delete!
		try
		{
			RecordHeader header = getRecordHeader(obj);

			if(header != null)
			{
				header.invalidate(getSourceFile());
			}
		}
		catch(IOException ex)
		{
			throw new QueryException("Failed to delete record ", ex);
		}
	}
	/**
	 * @param  obj
	 * @param  data
	 * @exception  IOException
	 */
	public void appendObject(Persistence obj, byte[] data) throws IOException
	{
		RecordHeader header = RecordHeader.insert(buildPrimaryKeyString(obj).toString(), getSourceFile(), data);
		Persistence adapter = obj;
		if(obj.usesAdapter())
		{
			adapter = obj.getAdapter();
		}
		objectToRecordHeader.put(adapter, header);
	}
	/**
	 * @param  aFileName
	 */
	protected void initialize(final String aFileName)
	{
		fileName = aFileName;
		objectToRecordHeader = new WeakHashMap();
	}

	static
	{
		try
		{
			shared = new FilePropertySource().getShareAccess();
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}

	}
}
