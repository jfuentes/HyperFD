package com.objectwave.persist.file;
import com.objectwave.persist.*;
import com.objectwave.utility.ScalarType;
import java.io.IOException;
import java.util.Date;
/**
 *  Convert the data to a file friendly format. The big deal here is that 'null'
 *  objects will be represented as a string "NULL" in the file.
 *
 * @author  David Hoag
 * @version  $Id: FileObjectFormatter.java,v 2.0 2001/06/11 16:00:04 dave_hoag Exp $
 */
public class FileObjectFormatter extends ObjectFormatter
{
	/**
	 *  Convert the object from its database representation to its actual value in
	 *  the business object. This is the most likely method to be used in other
	 *  processes. If the 'c' is a primtitive type, we force the value to zero.
	 *
	 * @param  c Class to which the object is going to be converted.
	 * @param  obj An unkown object type that may need to be converted to be a type
	 *      of the class 'c'.
	 * @return  An instance of the passed in type.
	 */
	public Object convertType(final Class c, Object obj)
	{
		if(obj instanceof String && obj.equals("NULL"))
		{
			return null;
		}
		return super.convertType(c, obj);
	}
	/**
	 *  Don't use superfulous tick ' characters. Substitute a string "NULL" for
	 *  null values.
	 *
	 * @param  value The value to be added to the StringBuffer
	 * @param  buf The buffer that will hold all of the object's data
	 * @exception  IOException
	 */
	public void formatValue(final Object value, final StringBuffer buf) throws IOException
	{
		if(value == null)
		{
			buf.append("NULL");
			return;
		}
		if(value instanceof String)
		{
			String str = (String) value;
			buf.append(replace1QuoteWith2((String) value));
		}
		else
				if(value instanceof Character)
		{
			buf.append(value);
		}
		else
				if(value instanceof Date)
		{
			formatDate((Date) value, buf);
		}
		else
				if(value instanceof Boolean)
		{
			if(((Boolean) value).booleanValue())
			{
				buf.append("1");
			}
			else
			{
				buf.append("0");
			}
		}
		else
				if(value instanceof Number)
		{
			buf.append(value);
		}
		else
				if(value instanceof ScalarType)
		{
			buf.append(((ScalarType) value).toDatabaseString());
		}
		else
				if(value instanceof java.io.Serializable)
		{
			//Assume we are storing a byte []

			formatSerializable((java.io.Serializable) value, buf);
		}
		else
		{
			buf.append(value);
		}
	}
}
