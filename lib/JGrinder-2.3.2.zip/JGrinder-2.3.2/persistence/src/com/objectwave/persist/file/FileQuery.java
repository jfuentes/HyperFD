/*
 * Copyright (C) 2001 David Hoag
 * ObjectWave Corporation
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * For a full copy of the license see:
 * http://www.opensource.org/licenses/lgpl-license.html
 */
package com.objectwave.persist.file;
import com.objectwave.logging.MessageLog;
import com.objectwave.persist.*;
import com.objectwave.persist.broker.FileBroker;
import com.objectwave.persist.broker.ObjectQuerySupport;
import com.objectwave.persist.file.FileObjectFormatter;
import com.objectwave.persist.sqlConstruction.SqlQueryBuilder;
import com.objectwave.utility.StringManipulator;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
/**
 *  Description: Process SQLQueries to find data in our dbf files.
 *
 * @author  David Hoag
 * @version  $Id: FileQuery.java,v 2.0 2001/06/11 16:00:04 dave_hoag Exp $
 */
public class FileQuery extends ObjectQuerySupport
{
	DbFile dbFile;
	ObjectBuilder builder;
	/**
	 * @param  aQuery
	 * @param  file
	 * @param  build
	 */
	public FileQuery(final SQLQuery aQuery, DbFile file, ObjectBuilder build)
	{
		setSqlQuery(aQuery);
		dbFile = file;
		builder = build;
	}
	/**
	 *  Used for creating test instances.
	 */
	protected FileQuery()
	{
	}
	/**
	 * @return
	 */
	public Object clone()
	{
		FileQuery fq = (FileQuery) super.clone();
		fq.builder = builder;
		fq.dbFile = dbFile;
		return fq;
	}
	/**
	 *  initialize the member variables with data from the SQLQuery.
	 */
	public void initialize()
	{
		super.initialize();
		defaultFormatter = new FileObjectFormatter();
	}
	/**
	 *  Gets the ListOfObjects attribute of the FileQuery object
	 *
	 * @param  expectedType
	 * @return  The ListOfObjects value
	 */
	protected Iterator getListOfObjects(final Persistence expectedType)
	{
		MyIterator result = new MyIterator();
		try
		{
			result.recordHeaders = dbFile.iterator();
			result.querySubject = expectedType;
		}
		catch(IOException ex)
		{
			MessageLog.error(this, "Exception while getting record header iterators", ex);
			throw new RuntimeException("Failed to create db connection");
		}
		return result;
	}
	/**
	 * @author  dhoag
	 * @version  $Id: FileQuery.java,v 2.0 2001/06/11 16:00:04 dave_hoag Exp $
	 */
	public class MyIterator implements Iterator
	{
		Iterator recordHeaders;
		Persistence querySubject;
		/**
		 * @return
		 */
		public boolean hasNext()
		{
			return recordHeaders.hasNext();
		}
		/**
		 */
		public void remove()
		{
			throw new UnsupportedOperationException("Can't remove these elements");
		}
		/**
		 * @return
		 */
		public Object next()
		{
			RecordHeader header = (RecordHeader) recordHeaders.next();
			try
			{
				Persistence obj = builder.buildObject(querySubject, header.getData(dbFile.getSourceFile()), header.getPrimaryKey());
				obj.setRetrievedFromDatabase(true);
				dbFile.associate(obj, header);
				return obj;
			}
			catch(Exception ex)
			{
				MessageLog.error(this, "Failed to create the persistent object", ex);
				throw new RuntimeException("Can not create persistent objects!");
			}
		}
	}
}
