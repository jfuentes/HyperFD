package com.objectwave.persist.file;
import java.io.*;
/**
 * @author  Dave Hoag
 * @version  $Id: RecordHeader.java,v 2.1 2002/03/23 13:42:10 dave_hoag Exp $
 */
public class RecordHeader
{
	static byte[] recordFudge = new byte[10];
	long currentPos;
	boolean isValidValue;
	//Deleted records will no longer be valid
	/**
	 *  If this record is not valid, the pkey will be null
	 */
	String pkey;
	/**
	 *  The distance in bytes from the dataStart position to the next record
	 */
	long bytesToNextRecord;
	long dataStart;
	long timeStamp;
	/**
	 *  Use the 'create' method to instantiate this class.
	 *
	 * @see  #create(java.io.RandomAccessFile)
	 */
	private RecordHeader()
	{
	}
	/**
	 *  Create instances from the RandomAccessFile
	 *
	 * @param  file RandomAccessFile The file upon which to write.
	 * @return  RecordHeader A new instance read from the provided file
	 * @exception  IOException
	 */
	public static RecordHeader create(RandomAccessFile file) throws IOException
	{
		RecordHeader result = new RecordHeader();
		result.currentPos = file.getFilePointer();
		result.isValidValue = file.readBoolean();
		result.timeStamp = file.readLong();
		result.bytesToNextRecord = file.readLong();
		String tmpPKey = file.readUTF();
		//Move the FilePointer
		if(result.isValid())
		{
			result.pkey = tmpPKey;
		}
		result.dataStart = file.getFilePointer();
		return result;
	}
	/**
	 *  Write a new record the random access file.
	 *
	 * @param  primaryKeyField Some string value that will uniquely identify this row.
	 * @param  file RandomAccessFile The file upon which to write.
	 * @param  data byte [] The data from the persistent object.
	 * @return
	 * @exception  IOException
	 */
	public static RecordHeader insert(String primaryKeyField, RandomAccessFile file, byte[] data) throws IOException
	{
		boolean success = false;
		RecordHeader result = new RecordHeader();
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		DataOutputStream dos = new DataOutputStream(bos);
		try
		{
			//Go to the end of the file
			result.currentPos = file.length();
			file.seek(result.currentPos);
//System.out.println("Insert at current pos" + result.currentPos);
			//Mark it as a valid record
			result.isValidValue = true;
			dos.writeBoolean(result.isValidValue);
			//Record the time it was created
			result.timeStamp = System.currentTimeMillis();
			dos.writeLong(result.timeStamp);
			//Figure out the size to make the data region
			int bytesToNextRecord = data.length + recordFudge.length + 4;
			//4 is for the data length field Leave a little growing room
			result.bytesToNextRecord = bytesToNextRecord;
//System.out.println("writing bytes to next " + bytesToNextRecord);
			dos.writeLong(result.bytesToNextRecord);
			//Write out the primary key
			result.pkey = primaryKeyField;
			dos.writeUTF(result.pkey);
			result.dataStart = file.getFilePointer() + bos.size();

//System.out.println("writing data start " + result.dataStart);

			//write the data
			dos.writeInt(data.length);
			dos.write(data);
			//write the fudge
			dos.write(recordFudge);
//System.out.println("Writing byte array at " + file.getFilePointer());
			file.write(bos.toByteArray());
			success = true;
//System.out.println("New end of file " + file.getFilePointer());
			return result;
		}
		finally
		{
			if(!success)
			{
				result.invalidate(file);
			}
		}
	}
	/**
	 * @param  value The new PrimaryKey value
	 */
	public void setPrimaryKey(String value)
	{
		pkey = value;
	}
	/**
	 *  Get the data from the file.
	 *  Assumes pointer of file is at start of data.
	 *
	 * @param  file RandomAccessFile The file upon which to get the data.
	 * @return  The Data value
	 * @exception  IOException
	 */
	public byte[] getData(RandomAccessFile file) throws IOException
	{
		if(file.getFilePointer() != dataStart)
		{
			file.seek(dataStart);
		}
		int length = file.readInt();
		byte[] data = new byte[length];
		file.readFully(data);
//System.out.println( 		file.getFilePointer()  + " " +    (bytesToNextRecord + dataStart) );
		if(file.getFilePointer() != bytesToNextRecord + dataStart)
		{
			file.seek(bytesToNextRecord + dataStart);
		}
		return data;
	}
	/**
	 * @return  boolean
	 */
	public boolean isValid()
	{
		return isValidValue;
	}
	/**
	 *  The pkey read from the record, or null if this record is not valid.
	 *
	 * @return  The PrimaryKey value
	 */
	public String getPrimaryKey()
	{
		return pkey;
	}
	/**
	 * @return  The BytesToNextRecord value
	 */
	public long getBytesToNextRecord()
	{
		return bytesToNextRecord;
	}
	/**
	 *  Move the FilePointer by the appropriate amount to skip this record.
	 *
	 * @param  file RandomAccessFile The file upon which to skip.
	 * @exception  IOException
	 */
	public void skip(RandomAccessFile file) throws IOException
	{
		file.seek(bytesToNextRecord + dataStart);
	}
	/**
	 *  A 'db' update.
	 *  If the record can not be updated an exception is generated and the record is invalidated.
	 *
	 * @param  file RandomAccessFile The file upon which to write.
	 * @param  data
	 * @exception  EOFException - If trying to write more data than is allowed in the current record.
	 * @exception  IOException
	 */
	public void update(RandomAccessFile file, byte[] data) throws EOFException, IOException
	{
//	System.out.println(" Updating " + file.length() );
		boolean success = false;
		try
		{
			file.seek(currentPos);
			file.writeBoolean(true);
			long oldTime = file.readLong();
			if(oldTime != timeStamp)
			{
				System.out.println("Compared file w/ " + oldTime + " in memory time " + timeStamp + " " + currentPos);
				System.err.println("Data corruption? Timestamps don't match.");
			}
			file.seek(currentPos + 1);
//System.out.println("Writing at " + currentPos + " " + data.length );
//			file.skipBytes(-8); -- The negative values didn't work
			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			DataOutputStream dos = new DataOutputStream(bos);

			long tmpTimeStamp = System.currentTimeMillis();
			dos.writeLong(tmpTimeStamp);
			dos.writeLong(bytesToNextRecord);
			//Although, this hasn't changed
			dos.writeUTF(pkey);
			//This really shouldn't change either
			int byteCount = bos.size();

//System.out.println(" dataStart " + dataStart );
			dataStart = file.getFilePointer() + byteCount;
			//If the PKey changes, the dataStart changes.
//System.out.println("New dataStart " + dataStart + " bytes to next " + bytesToNextRecord );

			//Need to add 4 to account for the int length of data
			if(bytesToNextRecord < (data.length + 4))
			{
				throw new EOFException("Not enough room on record for write");
			}
			dos.writeInt(data.length);
			dos.write(data);
//         dos.flush();
			final byte[] actualBytes = bos.toByteArray();
//System.out.println("Writing byte array at " + file.getFilePointer() + " =? " + (currentPos + 1) + " " + actualBytes.length);
			file.write(actualBytes);
			success = true;
//System.out.println("Changing timeStamp to " + tmpTimeStamp + " on " + currentPos );
			timeStamp = tmpTimeStamp;
//file.seek(currentPos + 1);
//System.out.println("File says " + file.readLong());
//ByteArrayInputStream bin =new ByteArrayInputStream(actualBytes);
//DataInputStream din = new DataInputStream(bin);
//System.out.println("Bytes in memory say " + din.readLong());
		}
		finally
		{
//	System.out.println(" Invalidating record ? " + (! success) + " " + file.length() );
			if(!success)
			{
				invalidate(file);
			}
		}
	}
	/**
	 * @param  file RandomAccessFile The file upon which to write.
	 * @exception  IOException
	 */
	public void invalidate(RandomAccessFile file) throws IOException
	{
		isValidValue = false;
		file.seek(currentPos);
		file.writeBoolean(false);
	}
	/**
	 *  Unit tests.
	 *
	 * @author  dhoag
	 * @version  $Id: RecordHeader.java,v 2.1 2002/03/23 13:42:10 dave_hoag Exp $
	 */
	public static class Test extends com.objectwave.test.UnitTestBaseImpl
	{
		RandomAccessFile ram;
		/**
		 *  The main program for the Test class
		 *
		 * @param  args The command line arguments
		 */
		public static void main(String[] args)
		{
			com.objectwave.test.TestRunner.run(new Test(), args);
		}
		//Used by other test classes
		/**
		 *  Gets the TwoRecordFile attribute of the Test class
		 *
		 * @param  fName
		 * @return  The TwoRecordFile value
		 * @exception  IOException
		 */
		static RandomAccessFile getTwoRecordFile(String fName) throws IOException
		{
			RandomAccessFile ram = new RandomAccessFile(fName, "rw");
			byte[] data = new byte[1];
			data[0] = (byte) 4;
			RecordHeader.insert("Pkey", ram, data);
			data[0] = (byte) 5;
			RecordHeader.insert("Pkey2", ram, data);
			return ram;
		}
		/**
		 *  The teardown method for JUnit
		 *
		 * @param  context
		 */
		public void tearDown(com.objectwave.test.TestContext context)
		{
			if(ram != null)
			{
				try
				{
					ram.close();
				}
				catch(Exception ex)
				{
				}
			}
			// Don't care
			File f = new File("person.dbf");
			if(f.exists())
			{
				try
				{
					f.delete();
				}
				catch(Throwable t)
				{
					System.out.println("Failed to remove old db file " + t);
				}
			}
			//Don't really care
		}
		/**
		 *  A unit test for JUnit
		 *
		 * @exception  IOException
		 */
		public void testInvalidate() throws IOException
		{
			ram = new RandomAccessFile("person.dbf", "rw");
			testContext.assertEquals(0, ram.length());
			byte[] data = new byte[1];
			data[0] = (byte) 4;
			RecordHeader header = RecordHeader.insert("Pkey", ram, data);

			testContext.assertTrue("Record not valid!!", header.isValid());
			header.invalidate(ram);
			testContext.assertTrue("Record not invalidated!!", !header.isValid());

			ram.close();
			ram = new RandomAccessFile("person.dbf", "rw");
			header = header.create(ram);

			data = header.getData(ram);
			testContext.assertEquals((byte) 4, data[0]);
			testContext.assertTrue("Record not invalidated!!", !header.isValid());
		}
		/**
		 *  A unit test for JUnit
		 *
		 * @exception  IOException
		 */
		public void testUpdate() throws IOException
		{
			ram = new RandomAccessFile("person.dbf", "rw");
			testContext.assertEquals(0, ram.length());
			byte[] data = new byte[1];
			data[0] = (byte) 4;
			RecordHeader header = RecordHeader.insert("Pkey", ram, data);

			data[0] = (byte) 5;
			header.update(ram, data);

			data = header.getData(ram);
			testContext.assertEquals((byte) 5, data[0]);
		}
		/**
		 *  A unit test for JUnit
		 *
		 * @exception  IOException
		 */
		public void testInsert() throws IOException
		{
			ram = new RandomAccessFile("person.dbf", "rw");
			testContext.assertEquals(0, ram.length());
			byte[] data = new byte[1];
			data[0] = (byte) 4;
			RecordHeader header = RecordHeader.insert("Pkey", ram, data);
			data = header.getData(ram);
			testContext.assertEquals(1, data.length);
			testContext.assertEquals((byte) 4, data[0]);

		}

	}
}
