package com.objectwave.persist.file;
import java.io.*;
import java.util.ArrayList;
/**
 *  A Record is an abstraction of a 'row' in the virtual table.
 *
 * @author  Dave Hoag
 * @version  $Id: RecordIterator.java,v 2.1 2002/03/23 13:42:10 dave_hoag Exp $
 */
public class RecordIterator implements java.util.Iterator
{
	boolean validateData = System.getProperty("ow.strictPkey", "false").equals("true");
	RecordHeader header;
	RandomAccessFile sourceFile;
	long length;
	ArrayList list;
	/**
	 *  Every iterator needs the file upon which to iterate.
	 *
	 * @param  file Description of Parameter
	 * @exception  IOException Description of Exception
	 */
	public RecordIterator(RandomAccessFile file) throws IOException
	{
		sourceFile = file;
		length = file.length();
		if(validateData)
		{
			list = new ArrayList();
		}
	}
	/**
	 *  The file upon which this class is iterating.
	 *
	 * @return  The SourceFile value
	 */
	public RandomAccessFile getSourceFile()
	{
		return sourceFile;
	}
	/**
	 *  Returns true if the iteration has more elements. From the iterator
	 *  interface.
	 *
	 * @return  boolean
	 */
	public boolean hasNext()
	{
		if(length == 0)
		{
			return false;
		}
		try
		{
			prefetch();
		}
		catch(IOException ex)
		{
			System.err.println("Exception creating RecordHeader from file");
			ex.printStackTrace();
		}
		return header != null;
	}
	/**
	 *  Return the next element in the iteration. This element will be a 'record'
	 *  in the database.
	 *
	 * @return  Description of the Returned Value
	 */
	public Object next()
	{
		Object result = header;
		try
		{
			if(header == null)
			{
				prefetch();
				result = header;
			}
			header.skip(getSourceFile());
			header = null;
			prefetch();
			if(header == null)
			{
				//if it is still null, this iteration is complete

				length = 0;
			}
		}
		catch(IOException ex)
		{
			ex.printStackTrace();
			throw new RuntimeException("Failed to fetch next record! " + ex);
		}
		return result;
	}
	/**
	 */
	public void remove()
	{
		if(header != null)
		{
			try
			{
				header.invalidate(getSourceFile());
			}
			catch(Exception e)
			{
				System.err.println("Failed to remove the object from the RecordIterator " + e);
			}
		}
	}
	/**
	 *  We MUST be properly positioned for this to work
	 *
	 * @exception  IOException Description of Exception
	 */
	void prefetch() throws IOException
	{
		while(header == null)
		{
			if(getSourceFile().getFilePointer() >= length)
			{
				return;
			}
			header = RecordHeader.create(getSourceFile());
			if(header == null)
			{
				return;
			}

			if(!header.isValid())
			{
				if(header.dataStart + header.getBytesToNextRecord() >= length)
				{
					header = null;
					return;
				}
				header.skip(getSourceFile());
				//Not a valid record
				header = null;
			}
		}
	}
	/**
	 *  Unit tests.
	 *
	 * @author  dhoag
	 * @version  $Id: RecordIterator.java,v 2.1 2002/03/23 13:42:10 dave_hoag Exp $
	 */
	public static class Test extends com.objectwave.test.UnitTestBaseImpl
	{
		RandomAccessFile ram;
		/**
		 *  The main program for the Test class
		 *
		 * @param  args The command line arguments
		 */
		public static void main(String[] args)
		{
			com.objectwave.test.TestRunner.run(new Test(), args);
		}
		/**
		 *  The JUnit setup method
		 *
		 * @param  str The new Up value
		 * @param  context The new Up value
		 * @exception  Exception
		 */
		public void setUp(String str, com.objectwave.test.TestContext context) throws Exception
		{
			super.setUp(str, context);
			try
			{
				ram = com.objectwave.persist.file.RecordHeader.Test.getTwoRecordFile("person2.dbf");
				ram.seek(0);
			}
			catch(IOException ex)
			{
				ex.printStackTrace();
			}
		}
		/**
		 *  The teardown method for JUnit
		 *
		 * @param  context Description of Parameter
		 */
		public void tearDown(com.objectwave.test.TestContext context)
		{
			try
			{
				ram.close();
			}
			catch(Throwable t)
			{
				System.out.println("Error closing ram " + t);
			}
			//Don't care
			File f = new File("person2.dbf");
			if(f.exists())
			{
				try
				{
					f.delete();
				}
				catch(Throwable t)
				{
					System.out.println("Failed to remove old db file " + t);
				}
			}
			//Don't really care
		}
		/**
		 *  A unit test for JUnit
		 *
		 * @exception  IOException Description of Exception
		 */
		public void testIterateWithInvalid() throws IOException
		{
			RecordIterator it = new RecordIterator(ram);

			RecordHeader header = (RecordHeader) it.next();
			header.invalidate(ram);

			ram.seek(0);
			it = new RecordIterator(ram);
			java.util.ArrayList list = new java.util.ArrayList();
			while(it.hasNext())
			{
				list.add(it.next());
			}
			testContext.assertEquals(1, list.size());
			header = (RecordHeader) list.get(0);
			testContext.assertTrue("Header was marked as invalid!!", header.isValid());
		}
		/**
		 *  A unit test for JUnit
		 *
		 * @exception  IOException Description of Exception
		 */
		public void testIterate() throws IOException
		{
			RecordIterator it = new RecordIterator(ram);
			java.util.ArrayList list = new java.util.ArrayList();
			while(it.hasNext())
			{
				list.add(it.next());
			}
			testContext.assertEquals(2, list.size());
		}

	}
}
