package com.objectwave.persist.gui;
import com.objectwave.persist.*;
import com.objectwave.persist.mapping.RDBPersistentAdapter;
import java.util.*;
import javax.swing.*;

import javax.swing.event.*;
import javax.swing.tree.*;
/**
 *  Used to delete elements from the database. This assumes that all collection
 *  links are Vectors.
 *
 * @author  Dave Hoag
 * @version  $Id: DeleteTree.java,v 2.1 2004/03/20 14:20:58 dave_hoag Exp $
 */
public class DeleteTree implements TreeModel
{
	static Hashtable knownPersistentClasses = new Hashtable();
	Hashtable childrenVectors;
	Persistence root;
	TreeNode rootNode;
	EventListenerList eventList;
	/**
	 * @param  p
	 */
	public DeleteTree(Persistence p)
	{
		//start from this root persistence object and show all sub objects.
		root = p;
		eventList = new EventListenerList();
		childrenVectors = new Hashtable();
	}
	/**
	 *  Returns the child of <I>parent</I> at index <I>index</I> in the parent's
	 *  child array. <I>parent</I> must be a node previously obtained from this
	 *  data source.
	 *
	 * @param  parent a node in the tree, obtained from this data source
	 * @param  index
	 * @return  the child of <I>parent</I> at index <I>index</I>
	 */
	public Object getChild(Object parent, int index)
	{
		TreeNode node = (TreeNode) parent;
		Persistence p = node.obj;
		Vector v = getChildren(p, node);
		return v.elementAt(index);
	}
	/**
	 *  Returns the number of children of <I>parent</I> . Returns 0 if the node is
	 *  a leaf or if it has no children. <I>parent</I> must be a node previously
	 *  obtained from this data source.
	 *
	 * @param  parent a node in the tree, obtained from this data source
	 * @return  the number of children of the node <I>parent</I>
	 */
	public int getChildCount(Object parent)
	{
		TreeNode node = (TreeNode) parent;
		Persistence p = node.obj;
		Vector v = getChildren(p, node);
		return v.size();
	}
	/**
	 *  Returns the index of child in parent.
	 *
	 * @param  parent
	 * @param  child
	 * @return  The IndexOfChild value
	 */
	public int getIndexOfChild(Object parent, Object child)
	{
		System.out.println("Is this called in the read only model?");
		TreeNode node = (TreeNode) parent;
		Persistence p = node.obj;
		Vector v = getChildren(p, node);
		return v.indexOf(child);
	}
	/**
	 * @return  The KnownClasses value
	 */
	public Enumeration getKnownClasses()
	{
		return knownPersistentClasses.keys();
	}
	/**
	 *  Returns the root of the tree. Returns null only if the tree has no nodes.
	 *
	 * @return  the root of the tree
	 */
	public Object getRoot()
	{
		if(rootNode == null)
		{
			rootNode = new TreeNode(root, "", null);
		}
		return rootNode;
	}
	/**
	 *  Returns true if <I>node</I> is a leaf. It is possible for this method to
	 *  return false even if <I>node</I> has no children. A directory in a
	 *  filesystem, for example, may contain no files; the node representing the
	 *  directory is not a leaf, but it also has no children.
	 *
	 * @param  node a node in the tree, obtained from this data source
	 * @return  true if <I>node</I> is a leaf
	 */
	public boolean isLeaf(Object node)
	{
		return getChildCount(node) == 0;
	}
//
//  Change Events
//

	/**
	 *  Adds a listener for the TreeModelEvent posted after the tree changes.
	 *
	 * @param  l the listener to add
	 * @see  #removeTreeModelListener
	 */
	public void addTreeModelListener(TreeModelListener l)
	{
		eventList.add(TreeModelListener.class, l);
	}
	/**
	 * @param  path
	 */
	public void delete(TreePath path)
	{
		TreeNode currentSelection = (TreeNode) path.getLastPathComponent();
		if(currentSelection == null)
		{
			return;
		}
		int idx = 0;
		try
		{
			if(cancelDeletion())
			{
				return;
			}

			currentSelection.obj.delete();
			TreeNode parent = currentSelection.getParent();
			Vector children = getChildren(parent.obj, parent);
			idx = children.indexOf(currentSelection);
			children.removeElement(currentSelection);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		int[] vals = new int[1];
		vals[0] = idx;
		Object[] child = new Object[1];
		child[0] = null;
		Object[] parentPath = new Object[path.getPathCount() - 1];
		for(int i = 0; i < parentPath.length; ++i)
		{
			parentPath[i] = path.getPathComponent(i);
		}
		TreeModelEvent e = new TreeModelEvent(this, parentPath, vals, child);
		fireTreeNodesRemoved(e);
	}
	/**
	 * @param  elements The list of Nodes to delete.
	 * @param  path The initial node that was selected to be deleted.
	 */
	public void deleteCascade(DeleteTree.TreeNode[] elements, TreePath path)
	{
		int idx = 0;

		for(int i = 0; i < elements.length; i++)
		{
			try
			{
				TreeNode currentSelection = elements[i];
				currentSelection.obj.delete();
				TreeNode parent = currentSelection.getParent();
				Vector children = getChildren(parent.obj, parent);
				idx = children.indexOf(currentSelection);
				children.removeElement(currentSelection);
			}
			catch(Exception ex)
			{
				System.out.println(ex);
			}
		}

		Object[] parentPath = new Object[path.getPathCount() - 1];
		for(int i = 0; i < parentPath.length; ++i)
		{
			parentPath[i] = path.getPathComponent(i);
		}

		TreeModelEvent e = new TreeModelEvent(this, parentPath, null, null);
		fireTreeStructureChanged(e);
	}
	/**
	 *  Removes a listener previously added with <B>addTreeModelListener()</B> .
	 *
	 * @param  l the listener to remove
	 * @see  #addTreeModelListener
	 */
	public void removeTreeModelListener(TreeModelListener l)
	{
		eventList.remove(TreeModelListener.class, l);
	}
	/**
	 *  Messaged when the user has altered the value for the item identified by <I>
	 *  path</I> to <I>newValue</I> . If <I>newValue</I> signifies a truly new
	 *  value the model should post a treeNodesChanged event.
	 *
	 * @param  path path to the node that the user has altered.
	 * @param  newValue the new value from the TreeCellEditor.
	 */
	public void valueForPathChanged(TreePath path, Object newValue)
	{
		//This tree is read only
	}
	/**
	 * @param  e
	 */
	protected void fireInsertedEvent(TreeModelEvent e)
	{
		Object[] listeners = eventList.getListenerList();
		for(int i = listeners.length - 2; i >= 0; i -= 2)
		{
			if(listeners[i] == TreeModelListener.class)
			{
				((TreeModelListener) listeners[i + 1]).treeNodesInserted(e);
			}
		}
	}
	/**
	 *  e.path() returns the path the parent of the changed node(s).
	 *  e.childIndices() returns the index(es) of the changed node(s).
	 *
	 * @param  e
	 */
	protected void fireTreeNodesChanged(TreeModelEvent e)
	{
		Object[] listeners = eventList.getListenerList();
		for(int i = listeners.length - 2; i >= 0; i -= 2)
		{
			if(listeners[i] == TreeModelListener.class)
			{
				((TreeModelListener) listeners[i + 1]).treeNodesChanged(e);
			}
		}
	}
	/**
	 * @param  e
	 */
	protected void fireTreeNodesRemoved(TreeModelEvent e)
	{
		Object[] listeners = eventList.getListenerList();
		for(int i = listeners.length - 2; i >= 0; i -= 2)
		{
			if(listeners[i] == TreeModelListener.class)
			{
				((TreeModelListener) listeners[i + 1]).treeNodesRemoved(e);
			}
		}
	}
	/**
	 * @param  e
	 */
	protected void fireTreeStructureChanged(TreeModelEvent e)
	{
		Object[] listeners = eventList.getListenerList();
		for(int i = listeners.length - 2; i >= 0; i -= 2)
		{
			if(listeners[i] == TreeModelListener.class)
			{
				((TreeModelListener) listeners[i + 1]).treeStructureChanged(e);
			}
		}
	}
	/**
	 *  Force the root to contain the vector of children. Usefull for queries
	 *
	 * @param  v
	 */
	public void forceRoot(Vector v)
	{
		Vector realChildren = new Vector();
		Enumeration e = v.elements();
		if(rootNode == null)
		{
			getRoot();
		}
		while(e.hasMoreElements())
		{
			Persistence p = (Persistence) e.nextElement();
			TreeNode node = new TreeNode(p, "", rootNode);
			realChildren.addElement(node);
			knownPersistentClasses.put(p.getClass().getName(), p.getClass());
		}
		realChildren = com.objectwave.utility.Sorter.quickSort(realChildren);
		childrenVectors.put(root, realChildren);
	}
	/**
	 *  Children are any Persistence objects thare reachable from the subject 'p'.
	 *
	 * @param  p
	 * @param  node
	 * @return  The Children value
	 */
	Vector getChildren(Persistence p, TreeNode node)
	{
		Vector result = (Vector) childrenVectors.get(p);
		if(result == null)
		{
			result = new Vector();
		}
		else
		{
			return result;
		}
		RDBPersistentAdapter pObj = null;
		if(p.usesAdapter())
		{
			pObj = (RDBPersistentAdapter) p.getAdapter();
		}
		else
		{
			pObj = (RDBPersistentAdapter) p;
		}

		AttributeTypeColumn[] fkColDefs = pObj.getForeignKeyDescriptions();
		AttributeTypeColumn[] ilColDefs = pObj.getInstanceLinkDescriptions();
		AttributeTypeColumn[] colDefs = new AttributeTypeColumn[fkColDefs.length + ilColDefs.length];
		System.arraycopy(fkColDefs, 0, colDefs, 0, fkColDefs.length);
		System.arraycopy(ilColDefs, 0, colDefs, fkColDefs.length, ilColDefs.length);
		Object aNullObj = null;
		for(int i = 0; i < colDefs.length; i++)
		{
			final AttributeTypeColumn col = colDefs[i];
			Persistence fkData = (Persistence) pObj.get(col.getField(), aNullObj);

			if(fkData != null)
			{
				result.addElement(new TreeNode(fkData, col.getField().getName(), node));
				knownPersistentClasses.put(fkData.getClass().getName(), fkData.getClass());
			}
		}
		colDefs = pObj.getCollectionDescriptions();
		for(int i = 0; i < colDefs.length; i++)
		{
			final AttributeTypeColumn col = colDefs[i];
			Vector v = (Vector) pObj.get(col.getField(), aNullObj);
			if(v == null)
			{
				continue;
			}
			Enumeration e = v.elements();
			int count = 0;
			while(e.hasMoreElements())
			{
				Persistence per = (Persistence) e.nextElement();
				result.addElement(new TreeNode(per, col.getField().getName() + '[' + count++ + ']', node));
				knownPersistentClasses.put(per.getClass().getName(), per.getClass());
			}
		}
		result = com.objectwave.utility.Sorter.quickSort(result);
		childrenVectors.put(p, result);
		return result;
	}
	/**
	 * @return
	 */
	boolean cancelDeletion()
	{
		int y = JOptionPane.showConfirmDialog(null,
				"Are you SURE?", "Confirm deletion.", JOptionPane.YES_NO_OPTION);
		return y == JOptionPane.NO_OPTION;
	}
	/**
	 * @author  dhoag
	 * @version  $Id: DeleteTree.java,v 2.1 2004/03/20 14:20:58 dave_hoag Exp $
	 */
	public class TreeNode
	{
		TreeNode parent;
		String attributeName;
		public Persistence obj;
		/**
		 * @param  p
		 * @param  attributeName
		 * @param  parent
		 */
		TreeNode(Persistence p, String attributeName, TreeNode parent)
		{
			this.parent = parent;
			this.attributeName = attributeName;
			this.obj = p;
		}
		/**
		 * @return  The Parent value
		 */
		public TreeNode getParent()
		{
			return parent;
		}
		/**
		 * @return
		 */
		public String toString()
		{
			Class c = obj.getClass();
			String name = c.getName();
			int idx = name.lastIndexOf('.');
			name = attributeName + name.substring(idx, name.length()) + ':' + obj.getPrimaryKeyField();
			return name;
		}
	}
}
