package com.objectwave.persist.gui;

import javax.swing.event.*;
import javax.swing.tree.*;
import javax.swing.*;
import com.objectwave.persist.*;
import com.objectwave.utility.FileList;
import com.objectwave.uiWidget.ComponentList;
import java.awt.*;
import java.awt.event.*;
/**
 * Provide a list of class
 * @version 2.0
 */
public class SelectAllowableClasses extends javax.swing.JDialog
{
	ComponentList cList ;
	JCheckBox [] items;
	JTextField tfOthers;
	FileList list ;
	class SymWindow extends java.awt.event.WindowAdapter
	{
		public void windowClosing(java.awt.event.WindowEvent event)
		{
			Object object = event.getSource();
			if (object == SelectAllowableClasses.this)
				SelectAllowableClasses_WindowClosing(event);
		}
	}

	//{{DECLARE_CONTROLS
	//}}

	public SelectAllowableClasses(Frame parent, String title, boolean modal)
	{
		this(parent, modal);
		setTitle(title);
	}
	/**
	 */
	public SelectAllowableClasses(Frame w, boolean modal)
	{
		super(w, modal);
		//{{INIT_CONTROLS
		getContentPane().setLayout(new BorderLayout());
		setBounds(100, 100, 430,270);
		setTitle("SelectAllowableClasses");
		//}}

		cList = new ComponentList();
		cList.setHightlight(false);
		
		getContentPane().add(new JScrollPane(cList));
		getContentPane().add("South", getButtonPanel());
		tfOthers = new JTextField();
		getContentPane().add("North", tfOthers);
		AbstractAction anAction = new AbstractAction()
			{
				public void actionPerformed(ActionEvent e) { enterKeyPressed(); }
			};
//        tfOthers.getKeymap().addActionForKeyStroke( KeyStroke.getKeyStroke('\n'), anAction);
  		tfOthers.addActionListener(anAction);

		//{{REGISTER_LISTENERS
		SymWindow aSymWindow = new SymWindow();
		this.addWindowListener(aSymWindow);
		//}}
	}
	/**
	*/
	void close()
	{
		dispatchEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING));
	}
	void enterKeyPressed()
	{
	    try { 
		    Class c = Class.forName(tfOthers.getText());
		    list.addFileName(tfOthers.getText());
		    setFileList(list);
		} catch (Exception e) {}
	}
	/**
	 */
	public JPanel getButtonPanel()
	{
		JPanel panel = new JPanel();
		JButton b = new JButton("Ok");
		b.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent e) { pbOkClicked(); } });
		panel.add(b);
		b = new JButton("Cancel");
		b.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent e) { pbCancelClicked(); } });
		panel.add(b);
		return panel;
	}
	/**
	 */
	void pbCancelClicked()
	{
	    if(items != null)
		    for(int i = 0; i < items.length; ++i)
		    {
		        JCheckBox box = items[i];
		        box.setSelected(false);
		    }
		close();
	}
	/**
	 */
	void pbOkClicked()
	{
		close();
	}
	void SelectAllowableClasses_WindowClosing(java.awt.event.WindowEvent event)
	{
		dispose();
	}
	/**
	 */
	public void setFileList(FileList list)
	{
		this.list = list;
		items = list.getCheckBoxList();
		cList.setListData(items);
	}
}