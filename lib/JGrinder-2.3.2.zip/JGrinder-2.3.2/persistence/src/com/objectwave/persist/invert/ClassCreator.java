package com.objectwave.persist.invert;

public interface ClassCreator
{
	public Class createPersistentClass( Class domainObject ) throws ClassNotFoundException;
}
