package com.objectwave.persist.invert;

import com.objectwave.persist.examples.*;
import com.objectwave.persist.collectionAdapters.SupportedCollections;
import com.objectwave.test.*;
import com.objectwave.transactionalSupport.*;
import com.objectwave.persist.*;
import com.objectwave.persist.broker.*;
import java.util.*;

public class InvertTest extends UnitTestBaseImpl
{
	FileBroker broker;
	public static void main(String [] args )
	{
		new SupportedCollections();
		TestRunner.run( new InvertTest(), args );
	}
	public void setUp( String name, TestContext context )
	{
		broker = new FileBroker();
		BrokerFactory.setDefaultBroker(broker);
		SQLQuery.setDefaultBroker( broker );
	}
	public void tearDown( TestContext context ) throws Exception
	{
		broker.close();
		super.tearDown( context );
		removeFile( "invert_person.dbf" );
		removeFile( "invert_employee.dbf" );
	}
	public void testSaveAndFind() throws Exception
	{
		Session session = Session.createAndJoin("ONE");
		session.startTransaction("RDB");
		InvertPerson person = (InvertPerson )new PersistenceFactory().newInstance( InvertPerson.class );
		person.setName( "Dave" );
		session.commit();
		person = (InvertPerson )new PersistenceFactory().newInstance( InvertPerson.class );
		SQLQuery query = new SQLQuery( (Persistence)person);
		ArrayList list = (ArrayList)query.findCollection( ArrayList.class );
		testContext.assertEquals("Incorrect number of records", 1, list.size() );
	}
}
