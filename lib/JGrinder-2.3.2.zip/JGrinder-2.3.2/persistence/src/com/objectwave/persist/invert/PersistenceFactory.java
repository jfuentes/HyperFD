package com.objectwave.persist.invert;
import com.objectwave.logging.MessageLog;
import com.objectwave.persist.Persistence;

public class PersistenceFactory
{
	/**
	 * Make the object a persistent object.
	 */
	public Persistence insert( Object domainObject )
	{
		return (Persistence)domainObject;
	}
	/**
	 * Remove the object from the persistent store.
	 */
	public void remove( Object domainObject )
	{
	}
	public Persistence queryByExample( Object domainObject )
	{
		return (Persistence)domainObject;
	}

	public Object newInstance( final Class clazz ) throws InstantiationException, ClassNotFoundException, IllegalAccessException
	{
		Class persistentClass = getPersistentClass( clazz );
		return persistentClass.newInstance();
	}
	public Class getPersistentClass( final Class domainObject ) throws ClassNotFoundException
	{
		try
		{
			Class result = Class.forName( getDecoratedName( domainObject.getName() ));
			return result;
		}
		catch( ClassNotFoundException ex)
		{
			try
			{
				//Check for the becl libraries
				Class.forName( "org.apache.bcel.classfile.JavaClass" );
				ClassCreator creator = (ClassCreator)Class.forName("com.objectwave.persist.bcel.Generator").newInstance();
				return creator.createPersistentClass( domainObject );
			}
			catch( Exception ex2 )
			{
				MessageLog.debug(this, "Failed to auto generate persistent class", ex2);
				throw ex;
			}
		}
	}
	protected String getDecoratedName( String className )
	{
		return className + "Persistence";
	}
}
