/* Copyright (C) 2001 David Hoag
 * ObjectWave Corporation
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * For a full copy of the license see:
 * http://www.opensource.org/licenses/lgpl-license.html
 */
package com.objectwave.persist.mapping;
import com.objectwave.persist.AttributeTypeColumn;
import com.objectwave.persist.Persistence;
import com.objectwave.persist.RDBPersistence;
import java.lang.reflect.Field;
/**
 * @author  dhoag
 * @version  $Id: JoinAdapter.java,v 2.0 2001/06/11 16:00:04 dave_hoag Exp $
 */
public class JoinAdapter extends RDBPersistentAdapter
{
	static Field pkeyType;
	Integer dummyField;
	/**
	 *  Constructor for the JoinAdapter object
	 *
	 * @param  p
	 */
	public JoinAdapter(Persistence p)
	{
		super(p);
		setBrokerGeneratedPrimaryKeys(false);
	}
	/**
	 * @return  The PrimaryAttributeDescription value
	 */
	public AttributeTypeColumn getPrimaryAttributeDescription()
	{
		AttributeTypeColumn declaredPkey = super.getPrimaryAttributeDescription();
		return new MyAttributeTypeColumn(declaredPkey);
	}
	/**
	 * @author  dhoag
	 * @version  $Id: JoinAdapter.java,v 2.0 2001/06/11 16:00:04 dave_hoag Exp $
	 */
	class MyAttributeTypeColumn extends AttributeTypeColumn
	{
		AttributeTypeColumn wrapper;
		/**
		 *  Constructor for the MyAttributeTypeColumn object
		 *
		 * @param  real
		 */
		public MyAttributeTypeColumn(AttributeTypeColumn real)
		{
			wrapper = real;
		}
		/**
		 *  Sets the Value attribute of the MyAttributeTypeColumn object
		 *
		 * @param  p The new Value value
		 * @param  value The new Value value
		 */
		public void setValue(final Persistence p, Object value)
		{
			//do nothing
		}
		/**
		 *  Gets the FkPkeyCol attribute of the MyAttributeTypeColumn object
		 *
		 * @param  fkValue
		 * @return  The FkPkeyCol value
		 */
		protected AttributeTypeColumn getFkPkeyCol(final Persistence fkValue)
		{
			final RDBPersistence adapter;
			if(fkValue.usesAdapter())
			{
				adapter = (RDBPersistence) fkValue.getAdapter();
			}
			else
			{
				adapter = (RDBPersistence) fkValue;
			}
			return adapter.getPrimaryAttributeDescription();
		}
		/**
		 *  Gets the Field attribute of the MyAttributeTypeColumn object
		 *
		 * @return  The Field value
		 */
		public Field getField()
		{
			return pkeyType;
		}
		/**
		 *  Gets the Value attribute of the MyAttributeTypeColumn object
		 *
		 * @param  obj
		 * @return  The Value value
		 */
		public Object getValue(final Persistence obj)
		{
			Persistence fkValue = (Persistence) wrapper.getValue(obj);
			Object result = null;
			if(fkValue != null)
			{
				result = getFkPkeyCol(fkValue).getValue(fkValue);
			}
			return result;
		}
	}
	static
	{
		try
		{
			pkeyType = JoinAdapter.class.getDeclaredField("dummyField");
		}
		catch(Throwable t)
		{
			t.printStackTrace();
		}
	}

}
