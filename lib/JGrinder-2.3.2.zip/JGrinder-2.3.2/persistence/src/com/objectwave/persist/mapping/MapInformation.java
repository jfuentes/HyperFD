package com.objectwave.persist.mapping;
import com.objectwave.persist.AttributeTypeColumn;
import com.objectwave.persist.Type;
import java.util.ArrayList;
import java.util.Vector;
/**
 *  Mapping information is unique for every class. We create one instance of
 *  this class for every persistent class we define. This class breaks down the
 *  Vector of the class description into it's individual parts for efficiency
 *  reasons.
 *
 * @author  Dave Hoag
 * @version  $Id: MapInformation.java,v 2.1 2001/08/10 20:30:32 dave_hoag Exp $
 */
public class MapInformation extends AttributeTypeColumn
{
	/**
	 *  Description of the Field
	 */
	public static Object aFakeField;
	final static int MAX_VECTOR_CHECK = 100;
	static java.lang.reflect.Field f;
	final Vector classDescription;
	final int initialSize;
	int vectorCheckCount;

	/**
	 *  Cache of AttributeTypeColumns whose type is AttributeTypeColumn.ATTRIBUTE.
	 */
	final AttributeTypeColumn[] attributes;
	/**
	 *  Cache of AttributeTypeColumns whose type is AttributeTypeColumn.PRIMARYATT.
	 */
	final AttributeTypeColumn[] primaryKeys;
	/**
	 *  Cache of AttributeTypeColumns whose type is AttributeTypeColumn.COLLECTION.
	 */
	final AttributeTypeColumn[] collections;
	/**
	 *  Cache of AttributeTypeColumns whose type is AttributeTypeColumn.FOREIGN.
	 */
	final AttributeTypeColumn[] foreignKeys;
	/**
	 *  Cache of AttributeTypeColumns whose type is AttributeTypeColumn.INSTANCE.
	 */
	final AttributeTypeColumn[] instanceLinks;

	/**
	 *  Break down the vector into its mapping elements.
	 *
	 * @param  v java.util.Vector A description of how a class maps to a database
	 *      table.
	 */
	public MapInformation(final Vector v)
	{
		if(f == null)
		{
			try
			{
				f = MapInformation.class.getDeclaredField("aFakeField");
			}
			catch(Exception e)
			{
			}
		}
		setField(f);
		classDescription = v;
		initialSize = v.size();
		primaryKeys = getDescriptions(AttributeTypeColumn.PRIMARYATT, null);
		instanceLinks = getDescriptions(AttributeTypeColumn.INSTANCE, null);
		foreignKeys = getDescriptions(AttributeTypeColumn.FOREIGN, null);
		attributes = getDescriptions(AttributeTypeColumn.ATTRIBUTE, null);
		collections = getDescriptions(AttributeTypeColumn.COLLECTION, null);
		// We must sort the primary keys in natural order.
		java.util.Arrays.sort(primaryKeys);
		if(vectorCheckCount < MAX_VECTOR_CHECK)
		{
			validateVector();
		}
	}
	/**
	 *  Description of the Method
	 */
	private final static void doNothing()
	{
	}
	/**
	 * @return  AttributeTypeColumn [] Field mapping for primary key links. The primary keys are sorted in their natural order.
	 */
	public final AttributeTypeColumn[] getPrimaryKeyDescriptions()
	{
		if(vectorCheckCount < MAX_VECTOR_CHECK)
		{
			validateVector();
		}
		return primaryKeys;
	}
	/**
	 * @return  AttributeTypeColumn [] Field mapping for instance links.
	 */
	public final AttributeTypeColumn[] getInstanceLinkDescriptions()
	{
		if(vectorCheckCount < MAX_VECTOR_CHECK)
		{
			validateVector();
		}
		return instanceLinks;
	}
	/**
	 * @return  AttributeTypeColumn [] Field mapping for foreign key links.
	 */
	public final AttributeTypeColumn[] getForeignKeyDescriptions()
	{
		if(vectorCheckCount < MAX_VECTOR_CHECK)
		{
			validateVector();
		}
		return foreignKeys;
	}
	/**
	 * @return  AttributeTypeColumn [] Field mapping for attributes. Usually
	 *      columns in a DB Table.
	 */
	public final AttributeTypeColumn[] getAttributeDescriptions()
	{
		if(vectorCheckCount < MAX_VECTOR_CHECK)
		{
			validateVector();
		}
		return attributes;
	}
	/**
	 * @return  AttributeTypeColumn [] Field mapping for collection links.
	 */
	public final AttributeTypeColumn[] getCollectionDescriptions()
	{
		if(vectorCheckCount < MAX_VECTOR_CHECK)
		{
			validateVector();
		}
		return collections;
	}
	/**
	 * @return  AttributeTypeColumn The one and only map entry that represents a
	 *      PrimaryKeyField.
	 */
	public final AttributeTypeColumn getPrimaryAttributeDescription()
	{
		if(vectorCheckCount < MAX_VECTOR_CHECK)
		{
			validateVector();
		}
		return (primaryKeys == null || primaryKeys.length == 0) ? null : primaryKeys[0];
	}

	/**
	 * @return  The ClassDescription value
	 */
	public final Vector getClassDescription()
	{
		return classDescription;
	}
	/**
	 *  Utility method to create the caches of our AttributeTypeColumns. We
	 *  frequently only need one column type or another, so we cache these column
	 *  break outs in variables. This method does the breaking out.
	 *
	 * @param  type Description of Parameter
	 * @param  currentValues Description of Parameter
	 * @return  The Descriptions value
	 */
	protected final AttributeTypeColumn[] getDescriptions(Type type, AttributeTypeColumn[] currentValues)
	{
		// Use the cached value?
		if(currentValues != null)
		{
			return currentValues;
		}
		//Guess not, lets figure it out.
		final Vector v = getClassDescription();
		int size = v.size();
		final ArrayList res = new ArrayList(size);
		for(int i = 0; i < size; ++i)
		{
			AttributeTypeColumn col = (AttributeTypeColumn) v.elementAt(i);
			if(col.getType() == type)
			{
				res.add(col);
			}

			if(type == AttributeTypeColumn.ATTRIBUTE)
			{
				//Make sure we include the TYPEATT (if there is one)
				if(col.getType() == AttributeTypeColumn.TYPEATT)
				{
					// We want to ensure that the type attribute is the first
					// element in the result set of a query/select.
					//
					res.add(0, col);
				}
			}
		}
		currentValues = new AttributeTypeColumn[res.size()];
		res.toArray(currentValues);
		return currentValues;
	}
	/**
	 *  Description of the Method
	 */
	private final void validateVector()
	{
		vectorCheckCount++;
		if(getClassDescription().size() != initialSize)
		{
			throw new RuntimeException("Corrupted Map Information - Description not created in a thread safe manner. Seek help.");
		}
	}
	/**
	 * @author  dhoag
	 * @version  $Id: MapInformation.java,v 2.1 2001/08/10 20:30:32 dave_hoag Exp $
	 */
	public static class Test extends com.objectwave.test.UnitTestBaseImpl
	{
		/**
		 * @param  args The command line arguments
		 */
		public static void main(String[] args)
		{
			com.objectwave.test.TestRunner.run(new Test(), args);
		}
		/**
		 *  A unit test for JUnit
		 *
		 * @exception  NoSuchFieldException Description of Exception
		 */
		public void testGetDescriptions() throws NoSuchFieldException
		{
			Vector vect = new Vector();
			java.lang.reflect.Field field = MapInformation.class.getDeclaredField("initialSize");
			vect.addElement(AttributeTypeColumn.getAttributeRelation("STR", field));
			MapInformation mi = new MapInformation(vect);
			AttributeTypeColumn[] result = mi.getDescriptions(AttributeTypeColumn.ATTRIBUTE, null);
			testContext.assertEquals("Invalid size", result.length, vect.size());
			AttributeTypeColumn[] newResult = mi.getDescriptions(AttributeTypeColumn.ATTRIBUTE, result);
			testContext.assertEquals("Did not use cached result ", newResult, result);
		}
	}
}
