package com.objectwave.persist.mapping;
import com.objectwave.persist.*;
import com.objectwave.persist.broker.*;
import com.objectwave.persist.examples.*;
import com.objectwave.transactionalSupport.*;

import com.objectwave.transactionalSupport.ObjectModified;
import com.objectwave.utility.ScalarType;
/**
 *  For a special kind of change to this object. In particular, a delete request
 *  sent to this object.
 *
 * @author  dhoag
 * @version  $Id: NullChange.java,v 2.0 2001/06/11 16:00:04 dave_hoag Exp $
 */
public class NullChange extends ObjectModified implements com.objectwave.transactionalSupport.ObjectChangeRequest
{
	boolean deleteOnCommit = false;
	boolean newObject;
	RDBPersistentAdapter adapter;
	/**
	 *  Constructor for the NullChange object
	 *
	 * @param  delete
	 * @param  anInsert
	 * @param  anAdapter
	 */
	public NullChange(RDBPersistentAdapter anAdapter, boolean delete, boolean anInsert)
	{
		adapter = anAdapter;
		deleteOnCommit = delete;
		this.newObject = anInsert;
		initObjectModified(RDBPersistentAdapter._deleteThis, null, null, null);
	}
	/**
	 *  Gets the Collection attribute of the NullChange object
	 *
	 * @return  The Collection value
	 */
	public boolean isCollection()
	{
		return false;
	}
	/**
	 *  ObjectModified objects are returned to a pool of object modified objects.
	 *  Don't return this instance of an ObjectModified to the pool.
	 *
	 * @return
	 */
	public boolean returnThis()
	{
		return false;
	}
	/**
	 * @param  force
	 * @exception  com.objectwave.transactionalSupport.UpdateException
	 */
	public void commit(boolean force) throws com.objectwave.transactionalSupport.UpdateException
	{
		if(!deleteOnCommit)
		{
			return;
		}
		try
		{
			adapter.delete();
			adapter.deleteThis = false;
		}
		catch(QueryException ex)
		{
			throw new UpdateException(ex.toString());
		}
	}
	/**
	 */
	public void rollback()
	{
		adapter.deleteThis = false;
		if(newObject && adapter.isRetrievedFromDatabase())
		{
			try
			{
				adapter.delete();
				//Attempt to remove old dead data.
			}
			catch(QueryException ex)
			{
			}
			adapter.setRetrievedFromDatabase(false);
		}
	}
	/**
	 * @return
	 */
	public Object currentValue()
	{
		return new Boolean(true);
	}
	/**
	 * @return
	 */
	public Object originalValue()
	{
		return new Boolean(false);
	}
}
