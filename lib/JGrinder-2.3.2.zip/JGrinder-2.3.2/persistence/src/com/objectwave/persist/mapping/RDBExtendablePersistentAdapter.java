package com.objectwave.persist.mapping;
import com.objectwave.logging.MessageLog;
import com.objectwave.persist.*;
import com.objectwave.transactionalSupport.*;
import com.objectwave.utility.ObjectHolder;
import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.util.Hashtable;

import java.util.Vector;
/**
 *  Designed to support sharing multiple heterogeneous objects in a single database table.
 *
 * @author  Steve Sinclair
 * @version  $Id: RDBExtendablePersistentAdapter.java,v 2.0 2001/06/11 16:00:04 dave_hoag Exp $
 * @see  com.objectwave.persist.broker.RDBBroker
 */
public class RDBExtendablePersistentAdapter extends RDBPersistentAdapter
{
	AttributeTypeColumn typeCol;
	/**
	 *  Constructor:
	 *
	 * @param  p
	 */
	public RDBExtendablePersistentAdapter(final Persistence p)
	{
		this(p, null);
	}
	/**
	 *  Constructor:
	 *
	 * @param  p
	 * @param  brokerName
	 */
	public RDBExtendablePersistentAdapter(final Persistence p, final String brokerName)
	{
		super(p, brokerName);
	}
	/**
	 *  This method must be extended by the custom implementation to return an instance of the correct type.
	 *  It is up to the developer defining the RDBExtendablePersistent object to interpert the 'classValue'
	 *  parameter and return a Persistent object of the correct type.
	 *
	 * @param  classValue java.lang.String The value found in the database as defined by the TypeAtt in the database map.
	 * @param  refObj
	 * @return  Persistence Either the one created through the default mechanism, or one defined
	 * @exception  InstantiationException
	 * @exception  IllegalAccessException
	 */
	public Persistence getInstance(final RDBPersistence refObj, final String classValue) throws InstantiationException, IllegalAccessException
	{
		//c = Map.get(classValue);
		//return c.newInstance();
		return basicNew();
	}
	/**
	 * @return  java.lang.Object
	 * @author  Steven Sinclair
	 */
	public Object getTypeId()
	{
		return getTypeIdentifierDescription().getValue(getPersistentObject());
	}
	/**
	 *  A special type that defines the data that is to be used to determine what
	 *  type of object a database row is representing.
	 *
	 * @return  com.objectwave.persist.AttributeTypeColumn
	 * @author  Steven Sinclair
	 */
	public AttributeTypeColumn getTypeIdentifierDescription()
	{
		if(typeCol != null)
		{
			return typeCol;
		}
		AttributeTypeColumn[] cols = getAttributeDescriptions();
		for(int i = 0; i < cols.length; i++)
		{
			if(cols[i].getType() == AttributeTypeColumn.TYPEATT)
			{
				return (typeCol = cols[i]);
			}
		}
		if(verbose)
		{
			MessageLog.debug(this, "No TYPEATT defined for an extendable persistent adatper. This may be a programming error.");
		}

		return null;
	}
	/**
	 *  Extensions of this class will probably want to override this method to
	 *  return Persistence objects of a given type.  The generated object
	 *  should be based on the value of the typeId parameter, which is the
	 *  value for the TYPEATT-typed column in the database row that we are
	 *  creating an object for.  If this method is not overridden, then there
	 *  is no effect in using extendable persistence.
	 *
	 * @param  refObj com.objectwave.persist.RDBPersistence
	 * @param  typeId java.lang.Object
	 * @param  origObj
	 * @return  com.objectwave.persist.Persistence
	 * @author  Steven Sinclair
	 */
	public Persistence createInstance(final RDBPersistence refObj, final RDBPersistence origObj, final Object typeId)
	{
		try
		{
			return getInstance(refObj, typeId.toString());
		}
		catch(InstantiationException ex)
		{
			if(verbose)
			{
				MessageLog.debug(this, "Exception creating Extendable Persistence instance. " + ex);
			}
		}
		catch(IllegalAccessException ex)
		{
			if(verbose)
			{
				MessageLog.debug(this, "Exception creating Extendable Persistence instance. " + ex);
			}
		}
		return null;
	}
}
