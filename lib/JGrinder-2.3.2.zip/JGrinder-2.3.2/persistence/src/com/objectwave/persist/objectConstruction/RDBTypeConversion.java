package com.objectwave.persist.objectConstruction;

import java.sql.*;
import java.io.*;
import com.objectwave.persist.*;
/**
 * Implements the default support for obtaining values from a database result set.
 * The method 'displayType' is simply for debugging purposes.
 *
 * @version $Id: RDBTypeConversion.java,v 2.0 2001/06/11 16:00:04 dave_hoag Exp $
 */
public class RDBTypeConversion implements RDBTypeConversionIF
{
	boolean verbose = System.getProperty("ow.rdbTypeVerbose") != null;
	static String [] types = { "RDB" };
	static Object [] classes = { RDBTypeConversion.class };
	/**
	 */
    public void setBrokerProperty(BrokerPropertyIF b)
    {
        verbose = b.getProperty("ow.rdbTypeVerbose") != null;
    }
	/**
	 * Used for debugging.  It will print out the column types in a database table.
	 */
	protected void displayType(int columnType, ResultSet set, int columnIndex) throws SQLException
	{
		switch (columnType) {
			case Types.ARRAY: { System.out.println("ARRAY"); break; }
			case Types.BIGINT: { System.out.println("BigInt"); break; }
			case Types.BINARY: { System.out.println("Binary"); break; }
			case Types.BIT: { System.out.println("Bit"); break; }
			case Types.BLOB: { System.out.println("BLOB"); break; }
			case Types.CHAR: { System.out.println("Char"); break; }
			case Types.CLOB: { System.out.println("CLOB"); break; }
			case Types.DATE:  { System.out.println("Date"); break; }
			case Types.DECIMAL: { System.out.println("Decimal"); break; }
			case Types.DISTINCT: { System.out.println("DISTINCT"); break; }
			case Types.DOUBLE: { System.out.println("DOUBLE"); break; }
			case Types.FLOAT:  { System.out.println("Float"); break; }
			case Types.INTEGER: { System.out.println("Integer"); break; }
			case Types.JAVA_OBJECT: { System.out.println("JAVA_OBJECT"); break; }
			case Types.LONGVARBINARY:  { System.out.println("LongVarBinary"); break; }
			case Types.LONGVARCHAR: { System.out.println("LongVarChar"); break; }
			case Types.NULL: { System.out.println("Null"); break; }
			case Types.NUMERIC: { System.out.println("Numeric"); break; }
			case Types.OTHER: { System.out.println("Object"); break; }
			case Types.REAL: { System.out.println("Real"); break; }
			case Types.REF: { System.out.println("REF"); break; }
			case Types.SMALLINT: { System.out.println("SmallInt");; break; }
			case Types.STRUCT: { System.out.println("STRUCT");; break; }
			case Types.TIME: { System.out.println("Time"); break; }
			case Types.TIMESTAMP:  { System.out.println("Timestamp"); break; }
			case Types.TINYINT: { System.out.println("TinyInt"); break; }
			case Types.VARBINARY: { System.out.println("VarBinary"); break; }
			case Types.VARCHAR: { System.out.println("VarChar: " + set.getString(columnIndex)); break; }
		}
	}
	/**
	*/
	public static RDBTypeConversionIF getInstance()
	{
		return getInstance(null);
	}
	/**
	*/
	public static RDBTypeConversionIF getInstance(String instanceType)
	{
		if(instanceType == null) return new RDBTypeConversion();
		for(int i = 0; i < types.length; i++)
		{
			try {
				if(types[i].equals(instanceType))
				{
					if(Class.class.isInstance(classes[i]))
						classes[i] = ((Class)classes[i]).newInstance();
					return (RDBTypeConversionIF)classes[i];
				}
			} catch (Exception e) { throw new RuntimeException(e.toString()); }
		}
		throw new RuntimeException("RDBTypeConversion " + instanceType + " is unknown.");
	}
	/**
	* Return the object in the result set based off the column type.  The mapping
	* was found in one of the Java documents.
	* @param columnType java.sql.Types
	* @param sets java.sql.ResultSet A row in the database.
	* @param columnIndex The column of interest in the result set.
	* @exception java.sql.SQLException Problem retreiving value from result set.
	*/
	public Object resultSetValue(int columnType, ResultSet set, int columnIndex) throws SQLException
	{
		if(verbose)
			displayType(columnType, set, columnIndex);
		switch (columnType)
		{
			case Types.INTEGER: return new Integer(set.getInt(columnIndex));
			case Types.BIT:   return new Boolean(set.getBoolean(columnIndex));
			case Types.TINYINT:
			case Types.SMALLINT: return new Short(set.getShort(columnIndex));
			case Types.BIGINT: return new Long(set.getLong(columnIndex));
			case Types.BINARY:
			case Types.VARBINARY:
			case Types.LONGVARBINARY:
			{
				byte [] vals = set.getBytes(columnIndex);
				return vals;
			}
			case Types.BLOB :
			//This is rudimentary support for a BLOB. This limits the size of a BLOB field to the size
			//of the largest int value
				Blob blob = set.getBlob(columnIndex);
				if(blob != null)
				{
					final long length = blob.length();
					return blob.getBytes(1, (int)length );
				}
				return null;
			case Types.DATE:  return set.getDate(columnIndex);
			case Types.REAL:
			case Types.DECIMAL:
				//If there are three double fields in a row and we run this with a JIT
				//the following will cause an access violation
				//return new Double(set.getDouble(columnIndex));
				String t = set.getString(columnIndex);
				Double result = null;
				if(t != null)
					result =  new Double(t);
				if(result != null)
					return result;
				else
					return new Double(0.0);
			case Types.FLOAT:  return new Float(set.getFloat(columnIndex));
			case Types.OTHER: return set.getObject(columnIndex);
			case Types.TIME: return set.getTime(columnIndex);
			case Types.TIMESTAMP:  return set.getTimestamp(columnIndex);
//  It seems as if getString works just fine for LONGVARCHAR.
//            case Types.LONGVARCHAR: return set.getAsciiStream(columnIndex);
			case Types.LONGVARCHAR:
			case Types.CHAR:
			//The following might seem weird, but we convert the string to the correct
			//numeric type at a later point in the process.
			case Types.NUMERIC:
			case Types.VARCHAR: return set.getString(columnIndex);
			//This is rudimentary support for a CLOB. This limits the size of a CLOB field to the size
			//of a java string
			case Types.CLOB:
				Clob clob = set.getClob(columnIndex);
				if(clob != null)
				{
					final long length = clob.length();
					return clob.getSubString(1, (int)length);
				}
			case Types.NULL: break;
			case Types.DOUBLE: return new Double( set.getDouble( columnIndex ));
		}
		return null;
	}
}
