package com.objectwave.persist.objectConstruction;

import java.lang.*;
import java.sql.*;
import com.objectwave.persist.*;

public interface RDBTypeConversionIF
{
	public Object resultSetValue(int columnType, ResultSet set, int columnIndex) throws SQLException;
	public void setBrokerProperty(BrokerPropertyIF b);
}