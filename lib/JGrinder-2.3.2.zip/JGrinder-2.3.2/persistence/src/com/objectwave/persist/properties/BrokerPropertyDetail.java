/*
 *  Copyright (C) 2001 David Hoag
 *  ObjectWave Corporation
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *  For a full copy of the license see:
 *  http://www.opensource.org/licenses/lgpl-license.html
 */
package com.objectwave.persist.properties;
import com.objectwave.persist.PrimaryKeyStrategy;
import com.objectwave.persist.SQLConvertExceptionIF;
import com.objectwave.persist.broker.SqlConnectionFactory;
import java.sql.Driver;
/**
 *  The properties for configuration of the RDBBroker.
 *
 * @author  dhoag
 * @version  $Id: BrokerPropertyDetail.java,v 2.5 2002/02/11 22:58:05 dave_hoag Exp $
 */
public class BrokerPropertyDetail
{
	//set the default database impl
	String databaseImpl = "com.objectwave.persist.broker.OracleBroker";

	String connectUrl;
	String persistDriver;
	String primaryKeyStrategy;
	PrimaryKeyStrategy actualStrategy;
	String connectionFactory;
	SqlConnectionFactory actualConnectionFactory;
	Driver actualPersistDriver;
	SQLConvertExceptionIF actualConverter;
	String persistUser;
	String persistPassword;
	String exceptionConverter;
	boolean showingSql;
	boolean persistPrepared;
	boolean usePreparedStatements;
	/**
	 *  Constructor for the BrokerPropertyDetail object
	 */
	public BrokerPropertyDetail()
	{
	}
	/**
	 *  Set the value.
	 *
	 * @param  aValue The new DatabaseImpl value
	 */
	public void setDatabaseImpl(String aValue)
	{
		databaseImpl = aValue;
	}
	/**
	 *  Set the value.
	 *
	 * @param  aValue The new ConnectUrl value
	 */
	public void setConnectUrl(String aValue)
	{
		connectUrl = aValue;
	}
	/**
	 *  The name of a class that implements the SQLConvertExceptionIF interface.
	 *
	 * @param  value The new ExceptionConverter value
	 * @exception  ClassNotFoundException
	 */
	public void setExceptionConverter(String value) throws ClassNotFoundException
	{
		Class driverClass = Class.forName(value);
		if(!SQLConvertExceptionIF.class.isAssignableFrom(driverClass))
		{
			throw new ClassCastException("ExceptionConverter attribute is not a SQLConvertExceptionIF class " + driverClass);
		}
		exceptionConverter = value;
	}
	/**
	 *  Sets the PersistPassword attribute of the BrokerPropertyDetail object
	 *
	 * @param  value The new PersistPassword value
	 */
	public void setPersistPassword(String value)
	{
		persistPassword = value;
	}
	/**
	 *  Sets the PersistUser attribute of the BrokerPropertyDetail object
	 *
	 * @param  value The new PersistUser value
	 */
	public void setPersistUser(String value)
	{
		persistUser = value;
	}
	/**
	 *  Set the value.
	 *
	 * @param  aValue The new PersistDriver value
	 * @exception  ClassNotFoundException
	 */
	public void setPersistDriver(String aValue) throws ClassNotFoundException
	{
		Class driverClass = Class.forName(aValue);
		if(!java.sql.Driver.class.isAssignableFrom(driverClass))
		{
			throw new ClassCastException("persistDriver attribute is not a sql driver class " + driverClass);
		}
		persistDriver = aValue;
	}
	/**
	 *  Set the name of the class that is to be used as the SqlConnectionFactory
	 *  for the RDBConnection objects.
	 *
	 * @param  className The new ConnectionFactory value
	 * @exception  ClassNotFoundException
	 */
	public void setConnectionFactory(String className) throws ClassNotFoundException
	{
		Class factory = Class.forName(className);
		if(!SqlConnectionFactory.class.isAssignableFrom(factory))
		{
			throw new ClassCastException(factory + " is not an implementor of SqlConnectionFactory");
		}
		connectionFactory = className;
	}
	/**
	 *  Sets the PrimaryKeyStrategy attribute of the BrokerPropertyDetail object
	 *
	 * @param  str The new PrimaryKeyStrategy value
	 * @exception  ClassNotFoundException
	 */
	public void setPrimaryKeyStrategy(String str) throws ClassNotFoundException
	{
		Class strategy = Class.forName(str);
		if(!PrimaryKeyStrategy.class.isAssignableFrom(strategy))
		{
			throw new ClassCastException(str + " is not an implementor of PrimaryKeyStrategy");
		}
		primaryKeyStrategy = str;
	}
	/**
	 * @param  prep The new UsePreparedStatements value
	 */
	public void setUsePreparedStatements(boolean prep)
	{
		usePreparedStatements = prep;
	}
	/**
	 *  If true, show the sql statements
	 *
	 * @param  showSql The new ShowingSql value
	 */
	public void setShowingSql(boolean showSql)
	{
		showingSql = showSql;
	}
	/**
	 *  Use the BrokerPropertySource to set this value.
	 *
	 * @param  driver The new ActualPersistDriver value
	 */
	protected void setActualPersistDriver(Driver driver)
	{
		actualPersistDriver = driver;
	}
	/**
	 *  Sets the ActualConverter attribute of the BrokerPropertyDetail object
	 *
	 * @param  converter The new ActualConverter value
	 */
	protected void setActualConverter(SQLConvertExceptionIF converter)
	{
		actualConverter = converter;
	}
	/**
	 *  Use the BrokerPropertySource to set these values.
	 *
	 * @param  factory The new ActualConnectionFactory value
	 */
	protected void setActualConnectionFactory(SqlConnectionFactory factory)
	{
		actualConnectionFactory = factory;
	}
	/**
	 *  Use the BrokerPropertySource to set these values.
	 *
	 * @param  strat The new ActualStrategy value
	 */
	protected void setActualStrategy(PrimaryKeyStrategy strat)
	{
		actualStrategy = strat;
	}
	/**
	 * @return  The ExceptionConverter value
	 */
	public String getExceptionConverter()
	{
		return exceptionConverter;
	}
	/**
	 *  Gets the PersistUser attribute of the BrokerPropertyDetail object
	 *
	 * @return  The PersistUser value
	 */
	public String getPersistUser()
	{
		return persistUser;
	}
	/**
	 *  Gets the PersistPassword attribute of the BrokerPropertyDetail object
	 *
	 * @return  The PersistPassword value
	 */
	public String getPersistPassword()
	{
		return persistPassword;
	}
	/**
	 *  Get the value.
	 *
	 * @return  The DatabaseImpl value
	 */
	public String getDatabaseImpl()
	{
		return databaseImpl;
	}

	/**
	 *  Get the value.
	 *
	 * @return  The ConnectUrl value
	 */
	public String getConnectUrl()
	{
		return connectUrl;
	}

	/**
	 *  Get the value.
	 *
	 * @return  The PersistDriver value
	 */
	public String getPersistDriver()
	{
		return persistDriver;
	}
	/**
	 *  Gets the PrimaryKeyStrategy attribute of the BrokerPropertyDetail object
	 *
	 * @return  The PrimaryKeyStrategy value
	 */
	public String getPrimaryKeyStrategy()
	{
		return primaryKeyStrategy;
	}
	/**
	 * @return  The ConnectionFactory value
	 */
	public String getConnectionFactory()
	{
		return connectionFactory;
	}
	/**
	 *  Gets the ShowingSql attribute of the BrokerPropertyDetail object
	 *
	 * @return  The ShowingSql value
	 */
	public boolean isShowingSql()
	{
		return showingSql;
	}
	/**
	 *  Gets the UsePreparedStatements attribute of the BrokerPropertyDetail object
	 *
	 * @return  The UsePreparedStatements value
	 */
	public boolean getUsePreparedStatements()
	{
		return usePreparedStatements;
	}
	/**
	 * @return  The ActualPersistDriver value
	 */
	protected Driver getActualPersistDriver()
	{
		return actualPersistDriver;
	}
	/**
	 *  Gets the ActualConverter attribute of the BrokerPropertyDetail object
	 *
	 * @return  The ActualConverter value
	 */
	protected SQLConvertExceptionIF getActualConverter()
	{
		return actualConverter;
	}
	/**
	 *  Get the actual instance - Normal use should get this from the
	 *  BrokerPropertySource
	 *
	 * @return  The ActualConnectionFactory value
	 */
	protected SqlConnectionFactory getActualConnectionFactory()
	{
		return actualConnectionFactory;
	}
	/**
	 *  Get an instance of the primary key strategy instead of the name
	 *
	 * @return  The ActualStrategy value
	 */
	protected PrimaryKeyStrategy getActualStrategy()
	{
		return actualStrategy;
	}
}
