/*
 *  Copyright (C) 2001 David Hoag
 *  ObjectWave Corporation
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *  For a full copy of the license see:
 *  http://www.opensource.org/licenses/lgpl-license.html
 */
package com.objectwave.persist.properties;
import com.objectwave.configuration.BasicPropertySource;
import com.objectwave.logging.MessageLog;
import com.objectwave.persist.PrimaryKeyStrategy;
import com.objectwave.persist.SQLConvertExceptionIF;
import com.objectwave.persist.broker.SqlConnectionFactory;
import java.sql.Driver;
import java.util.Properties;
/**
 *  This class is stateless and really acts like a finder for property support.
 *
 * @author  David Hoag
 * @version  $Id: BrokerPropertySource.java,v 2.7 2002/02/13 21:36:18 dave_hoag Exp $
 */
public class BrokerPropertySource extends BasicPropertySource
{
	//Default to the known detail class
	static Class detailClass = BrokerPropertyDetail.class;
	String category;
	BrokerPropertyDetail propertyDetail;
	/**
	 *  Constructor for the BrokerPropertySource object
	 */
	public BrokerPropertySource()
	{
		initialize();
	}
	/**
	 *  Bypass the traditional initialization and use the provided parameter as the
	 *  source of property values.
	 *
	 * @param  detail
	 */
	public BrokerPropertySource(BrokerPropertyDetail detail)
	{
		setPropertyDetail(detail);
	}
	/**
	 *  A custom category allows user of this class to define the category.
	 *
	 * @param  customCategory
	 */
	public BrokerPropertySource(String customCategory)
	{
		category = customCategory;
		customInitialize();
	}
	/**
	 *  Facilitate customization by allowing the default detail class to be set
	 *  prior to instantiation. Makes it easy to change detail defaults.
	 *
	 * @param  aBrokerPropertyDetailClass The new DetailClass value
	 * @exception  IllegalArgumentException
	 * @exception  IllegalAccessException
	 * @exception  InstantiationException
	 */
	public static void setDetailClass(Class aBrokerPropertyDetailClass) throws IllegalArgumentException, IllegalAccessException, InstantiationException
	{
		//Validate the provided class
		if(aBrokerPropertyDetailClass == null)
		{
			throw new IllegalArgumentException("A class must be provided");
		}
		if(!BrokerPropertyDetail.class.isAssignableFrom(aBrokerPropertyDetailClass))
		{
			throw new IllegalArgumentException("The class must be assignable from BrokerPropertyDetail");
		}
		//Try to create a new instance - just drop the instance - just making sure its ok
		aBrokerPropertyDetailClass.newInstance();
	}
	/**
	 *  Allow one to programmatically set the values of a broker property source.
	 *
	 * @param  detail The new PropertyDetail value
	 */
	public void setPropertyDetail(final BrokerPropertyDetail detail)
	{
		propertyDetail = detail;
	}
	/**
	 *  Sets the DatabaseImpl attribute of the BrokerPropertyDetail object
	 *
	 * @param  aValue The new DatabaseImpl value
	 */
	public void setDatabaseImpl(String aValue)
	{
		propertyDetail.setDatabaseImpl(aValue);
	}

	/**
	 *  Sets the ConnectUrl attribute of the BrokerPropertyDetail object
	 *
	 * @param  aValue The new ConnectUrl value
	 */
	public void setConnectUrl(String aValue)
	{
		propertyDetail.setConnectUrl(aValue);
	}
	/**
	 *  Sets the PersistUser attribute of the BrokerPropertyDetail object
	 *
	 * @param  aValue The new PersistUser value
	 */
	public void setPersistUser(String aValue)
	{
		propertyDetail.setPersistUser(aValue);
	}
	/**
	 *  Sets the PersistPassword attribute of the BrokerPropertyDetail object
	 *
	 * @param  aValue The new PersistPassword value
	 */
	public void setPersistPassword(String aValue)
	{
		propertyDetail.setPersistPassword(aValue);
	}
	/**
	 *  Sets the PersistDriver attribute of the BrokerPropertyDetail object
	 *
	 * @param  aValue The new PersistDriver value
	 * @exception  ClassNotFoundException
	 */
	public void setPersistDriverName(String aValue) throws ClassNotFoundException
	{
		propertyDetail.setPersistDriver(aValue);
	}
	/**
	 * Force the driver to be a specific java.sql.Driver instance
	 *
	 * @param  driver The new PersistDriver value
	 */
	public void setPersistDriver(Driver driver)
	{
		propertyDetail.setActualPersistDriver(driver);
	}
	/**
	 *  Change the SqlConnectionFactory to an instance of the provided name. Since
	 *  the result of the getConnectionFactory will be cached, changes to this
	 *  value must be done prior to an RDBBroker being initialized.
	 *
	 * @param  connectionFactoryName The new ConnectionFactoryName value
	 * @exception  ClassNotFoundException
	 */
	public void setConnectionFactoryName(final String connectionFactoryName) throws ClassNotFoundException
	{
		propertyDetail.setConnectionFactory(connectionFactoryName);
	}
	/**
	 *Sets the ExceptionConverter attribute of the BrokerPropertySource object
	 *
	 * @param  converter The new ExceptionConverter value
	 */
	public void setExceptionConverter(SQLConvertExceptionIF converter)
	{
		propertyDetail.setActualConverter(converter);
	}
	/**
	 *  If this is true Java Grinder will create prepared statements for every sql
	 *  call. When a duplicate SQL call is invoked the already prepared statement
	 *  is used opposed to generating a new SQL statement.
	 *
	 * @param  val boolean
	 */
	public void setUsePreparedStatements(boolean val)
	{
		propertyDetail.setUsePreparedStatements(val);
	}
	/**
	 *  Force the strategy to be something specific.
	 *
	 * @param  strategy The new PrimaryKeyStrategy value
	 */
	public void setPrimaryKeyStrategy(PrimaryKeyStrategy strategy)
	{
		propertyDetail.setActualStrategy(strategy);
	}
	/**
	 *  Sets the SqlConnectionFactory attribute of the BrokerPropertySource object
	 *
	 * @param  factory The new SqlConnectionFactory value
	 */
	public void setConnectionFactory(SqlConnectionFactory factory)
	{
		propertyDetail.setActualConnectionFactory(factory);
	}
	/**
	 *  Return the instance holding the property values.
	 *
	 * @return  The PropertyDetail value
	 */
	public BrokerPropertyDetail getPropertyDetail()
	{
		return propertyDetail;
	}
	/**
	 *  Gets the PersistPassword attribute of the BrokerPropertyDetail object
	 *
	 * @return  The PersistPassword value
	 */
	public String getPersistPassword()
	{
		return propertyDetail.getPersistPassword();
	}
	/**
	 *  Gets the PersistUser attribute of the BrokerPropertyDetail object
	 *
	 * @return  The PersistUser value
	 */
	public String getPersistUser()
	{
		return propertyDetail.getPersistUser();
	}
	/**
	 *  Return the 'type' of the detail class to populate with configured values.
	 *
	 * @return
	 */
	public Class getExpectedClass()
	{
		return detailClass;
	}
	/**
	 *  Gets the DatabaseImpl attribute of the BrokerPropertyDetail object
	 *
	 * @return  The DatabaseImpl value
	 */
	public String getDatabaseImpl()
	{
		return propertyDetail.getDatabaseImpl();
	}
	/**
	 *  Gets the ConnectUrl attribute of the BrokerPropertyDetail object
	 *
	 * @return  The ConnectUrl value
	 */
	public String getConnectUrl()
	{
		return propertyDetail.getConnectUrl();
	}
	/**
	 *  Gets the UsePreparedStatements attribute of the BrokerPropertyDetail object
	 *
	 * @return  The UsePreparedStatements value
	 */
	public boolean getUsePreparedStatements()
	{
		return propertyDetail.getUsePreparedStatements();
	}
	/**
	 * Get the instance to use as the converter - null is a legal return type
	 *
	 * @return  The ExceptionConverter value
	 */
	public SQLConvertExceptionIF getExceptionConverter()
	{
		SQLConvertExceptionIF result = propertyDetail.getActualConverter();
		if(result == null)
		{
			;
		}
		{
			String driver = propertyDetail.getExceptionConverter();
			if(driver != null)
			{
				try
				{
					Class c = Class.forName(driver);
					result = (SQLConvertExceptionIF) c.newInstance();
					propertyDetail.setActualConverter(result);
				}
				catch(Throwable t)
				{
					MessageLog.debug(this, "Shouldn't occur since value has already been validated", t);
				}
			}
		}
		return result;
	}
	/**
	 *  Gets the PersistDriver attribute of the BrokerPropertyDetail object
	 *
	 * @return  The PersistDriver value
	 */
	public Driver getPersistDriver()
	{
		Driver result = propertyDetail.getActualPersistDriver();
		if(result == null)
		{
			;
		}
		{
			String driver = propertyDetail.getPersistDriver();
			if(driver != null)
			{
				try
				{
					Class c = Class.forName(driver);
					result = (Driver) c.newInstance();
					propertyDetail.setActualPersistDriver(result);
				}
				catch(Throwable t)
				{
					MessageLog.debug(this, "Shouldn't occur since value has already been validated", t);
				}
			}
		}
		return result;
	}
	/**
	 *  Get the connection factory
	 *
	 * @return  The ConnectionFactory value
	 */
	public synchronized SqlConnectionFactory getConnectionFactory()
	{
		SqlConnectionFactory result = propertyDetail.getActualConnectionFactory();

		if(result == null)
		{
			String strat = propertyDetail.getConnectionFactory();
			if(strat != null)
			{
				try
				{
					Class c = Class.forName(strat);
					result = (SqlConnectionFactory) c.newInstance();
					propertyDetail.setActualConnectionFactory(result);
				}
				catch(Throwable t)
				{
					MessageLog.debug(this, "Shouldn't occur since value has already been validated", t);
				}
			}
		}
		return result;
	}
	/**
	 *  Gets the ShowingSql attribute of the BrokerPropertyDetail object
	 *
	 * @return  The ShowingSql value
	 */
	public boolean isShowingSql()
	{
		return propertyDetail.isShowingSql();
	}
	/**
	 *  Get the primaryKeyStrategy. This is the mechanism that will know how to
	 *  figure out the primary key of the provided object.
	 *
	 * @return  The PrimaryKeyStrategy value
	 */
	public synchronized PrimaryKeyStrategy getPrimaryKeyStrategy()
	{
		PrimaryKeyStrategy result = propertyDetail.getActualStrategy();
		if(result == null)
		{
			String strat = propertyDetail.getPrimaryKeyStrategy();
			if(strat != null)
			{
				try
				{
					Class c = Class.forName(strat);
					result = (PrimaryKeyStrategy) c.newInstance();
					propertyDetail.setActualStrategy(result);
				}
				catch(Throwable t)
				{
					MessageLog.error(this, "Shouldn't occur since value has already been validated", t);
				}
			}
		}
		return result;
	}
	/**
	 */
	protected void customInitialize()
	{
		try
		{
			propertyDetail = (BrokerPropertyDetail) getConfigurationInstance(category);
		}
		catch(com.objectwave.exception.ConfigurationException ex)
		{
			MessageLog.error(this, "Failed to get BrokerPropertyDetail!", ex);
		}
	}
	/**
	 *  Find our LoggingPropertySourceDetail instance. The PropertyDetail object
	 *  will actually contain the property values.
	 */
	protected void initialize()
	{
		setPropertyDetail((BrokerPropertyDetail) getConfigObject());
	}
}
