package com.objectwave.persist.properties;
/**
 * @author  dhoag
 * @version  $Id: FilePropertyDetail.java,v 2.0 2001/06/11 16:00:04 dave_hoag Exp $
 */
public class FilePropertyDetail
{
	boolean verbose;
	String dataDirectory;
	boolean shareAccess;
	/**
	 *  Constructor for the FilePropertyDetail object
	 */
	public FilePropertyDetail()
	{
	}
	/**
	 * @param  aValue
	 */
	public void setShareAccess(final boolean aValue)
	{
		shareAccess = aValue;
	}
	/**
	 * @param  aValue The new Verbose value
	 */
	public void setVerbose(final boolean aValue)
	{
		verbose = aValue;
	}
	/**
	 *  The data directory is the target directory.
	 *
	 * @param  aValue The new DataDirectory value
	 */
	public void setDataDirectory(final String aValue)
	{
		dataDirectory = aValue;
	}
	/**
	 * @return
	 */
	public boolean getShareAccess()
	{
		return shareAccess;
	}
	/**
	 * @return  The Verbose value
	 */
	public boolean getVerbose()
	{
		return verbose;
	}
	/**
	 * @return  The DataDirectory value
	 */
	public String getDataDirectory()
	{
		return dataDirectory;
	}
}
