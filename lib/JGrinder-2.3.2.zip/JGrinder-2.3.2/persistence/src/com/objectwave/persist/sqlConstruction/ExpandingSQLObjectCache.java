package com.objectwave.persist.sqlConstruction;
/**
 * Maintain a collection of SQLObject objects.
 * There is a cache per thread. This elminates the need to have synchronized checkin
 * and check out for getting and returning cached objects.
 * Of course, this could pose a problem if one thread checks out objects, and the other
 * returns objects. If that is your situation, an instance of this class must be managed
 * by your application and not via the static methods in this class.
 *
 * @author Craig Murphy
 * @author Dave Hoag
 * @version 1.1
 */
public class ExpandingSQLObjectCache
{
	private SQLObject cache[];
	private int cacheStackPointer;
	private int currentCacheCapacity;
	//private static ThreadLocal threadContext = new ThreadLocal();
	static final boolean verbose = false;
	/**
	 * Initialize this instance to be ready to cache Objects.
	 */
	public ExpandingSQLObjectCache()
	{
		cache = new SQLObject[ currentCacheCapacity = 32 ];
		cacheStackPointer = -1;
	}
	/**
	 * The entry point to the instance related to the current thread, and to get the cached object.
	public static SQLObject getSQLObjectFromCache()
	{
		ExpandingSQLObjectCache cacheObject = (ExpandingSQLObjectCache) threadContext.get();
		if(cacheObject == null)
		{
			cacheObject = new ExpandingSQLObjectCache();
			threadContext.set(cacheObject);
		}

		return cacheObject.getSQLObjectFromCacheWork();
	}
	/**
	 * The intended entry point for returning instances.
	public static final void returnSQLObjectToCache(final SQLObject value )
	{
		ExpandingSQLObjectCache cacheObject = (ExpandingSQLObjectCache) threadContext.get();
		if(cacheObject == null) return;
		cacheObject.returnSQLObjectToCacheWork(value);
	}
	/**
	 * Get the cached object from this instance of ExpandingSQLObjectCache.
	 * @retrun SQLObject A token that keeps track of changes to an object
	 */
	public SQLObject getSQLObjectFromCacheWork()
	{
		if(verbose) System.out.println("get " + cacheStackPointer);
		SQLObject retVal = null;
		if ( 0 <= cacheStackPointer )
		{
			retVal = cache[ cacheStackPointer ];
			cache[ cacheStackPointer-- ] = null; // Give gc a chance to work
		}
		else
		{
			retVal = null; //A return value of null means the Cache is empty
		}
		return retVal;
	}
	/**
	 * Return a checked out instance to this cache.
	 * @param value ObjectModifed - Hopefully and instance that was obtained via the getSQLObjectCacheWork method.
	 */
	public void returnSQLObjectToCacheWork( final SQLObject value )
	{
		if(verbose) System.out.println("ret " + (cacheStackPointer + 1));

		if ( ++cacheStackPointer == currentCacheCapacity )
		{
		   int newCacheCapacity = currentCacheCapacity << 1;
		   SQLObject newCache[] = new SQLObject[ newCacheCapacity ];
		   System.arraycopy( cache,			   // Source
							 0,				   // Source position
							 newCache,			// Destination
							 0,				   // Destination position
							 currentCacheCapacity // length
							);
		  currentCacheCapacity = newCacheCapacity;
		  cache = newCache;
		}
		cache[ cacheStackPointer ] = value;
	}
}
