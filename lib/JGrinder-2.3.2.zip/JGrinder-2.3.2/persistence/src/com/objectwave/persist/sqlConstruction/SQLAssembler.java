package com.objectwave.persist.sqlConstruction;

/**
* An interface that handles that all SQL generating classes must implement.
*
* @see            classBuilder.persist.RDBBroker
* @version        1.0  June 1997
* @author         Dave Hoag
*/
public interface SQLAssembler
{
	public StringBuffer getSqlStatement();
}