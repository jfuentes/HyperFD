package com.objectwave.persist.sqlConstruction;
import java.util.Date;
import java.util.Hashtable;

import java.util.Vector;

/**
 * A class that handles the creation of SQL Update statements.
 * For example:
 * <pre>
 *    SQLUpdate sql = new SQLUpdate();
 *    sql.setTableName("TABLENAME");
 * </pre>
 *
 * @author  Dave Hoag
 * @version  1.2
 * @see  com.objectwave.persist.SQLAssembler
 * @see  com.objectwave.persist.RDBBroker
 */
public class SQLDelete extends SQLObject implements SQLAssembler
{
	Vector whereClause = new Vector(10);
	/**
	 */
	public SQLDelete()
	{
	}
	/**
	 * @param  tableName
	 */
	public SQLDelete(final String tableName)
	{
		setTableName(tableName);
	}
	/**
	 * @return  The SqlStatement value
	 */
	public StringBuffer getSqlStatement()
	{
		StringBuffer buf = new StringBuffer("DELETE FROM ");
		formatTable(buf);
		formatWhereClause(buf);
		return buf;
	}
	/**
	 */
	public void clean()
	{
		super.clean();
		whereClause.clear();
	}
	/**
	 * @param  clause The feature to be added to the WhereClause attribute
	 */
	public void addWhereClause(final String clause)
	{
		whereClause.addElement(clause);
	}
	/**
	 * @param  buf
	 */
	public void formatTable(final StringBuffer buf)
	{
		buf.append(table);
	}
	/**
	 * @param  buf
	 */
	protected void formatWhereClause(final StringBuffer buf)
	{
		int size = whereClause.size();
		if(size > 0)
		{
			buf.append(" WHERE ");
			for(int i = 0; i < size - 1; i++)
			{
				buf.append(whereClause.elementAt(i));
				if(i < size - 1)
				{
					buf.append(" AND ");
					// FIXME: DAH - AND as default?  Query Object?
				}
			}
			buf.append(whereClause.elementAt(size - 1));
		}
	}
	/**
	 * @param  compareWith
	 * @param  column
	 * @param  values
	 */
	public void insertAnyOfClause(final String compareWith, final String column, final Vector values)
	{
		if(values == null || values.size() == 0)
		{
			return;
		}
		StringBuffer clause = new StringBuffer(column + ' ' + compareWith + " (");
		java.util.Enumeration e = values.elements();
		while(e.hasMoreElements())
		{
			Object element = e.nextElement();
			String delimit = (String.class.isInstance(element) ||
					Date.class.isInstance(element))
					 ? "'" : "";

			clause.append(delimit + e.nextElement() + delimit);
			if(e.hasMoreElements())
			{
				clause.append(", ");
			}
		}
		clause.append(')');
		addWhereClause(clause.toString());
	}
	/**
	 * @param  column
	 * @param  value
	 */
	public void insertWhereClause(final String column, final Object value)
	{
		String columnName = column;
		StringBuffer clause = new StringBuffer(column);
		clause.append(" = ");
		formatValue(value, clause);
		addWhereClause(clause.toString());
	}
}
