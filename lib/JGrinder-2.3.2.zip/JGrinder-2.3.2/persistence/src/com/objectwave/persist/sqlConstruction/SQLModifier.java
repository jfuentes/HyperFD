package com.objectwave.persist.sqlConstruction;
import com.objectwave.persist.*;
import com.objectwave.persist.Persistence;
import com.objectwave.persist.QueryException;
import com.objectwave.persist.broker.RDBBroker;

import com.objectwave.utility.Pair;
/**
 * Common behavior necessary for both inserts and updates to through JDBC.
 *
 * @author  Dave Hoag
 * @version  $Id: SQLModifier.java,v 2.1 2001/11/08 20:38:33 dave_hoag Exp $
 * @see  com.objectwave.persist.RDBBroker
 */
public abstract class SQLModifier extends SQLObject implements SQLAssembler
{
	protected String[] columnList = new String[100];
	protected Object[] valueList = new Object[100];
	protected int valueCount = 0;
	protected int[] sqlTypes = null;
	RDBBroker broker;
	/**
	 * @param  newValue com.objectwave.persist.RDBBroker
	 */
	public void setBroker(RDBBroker newValue)
	{
		this.broker = newValue;
	}
	/**
	 * Modify the valueList to use the new column/value mapping.
	 * The columnList should have the same length as the valueList,
	 * and they should both have the same # of arguments as the
	 * lists currently held by the object.  Failure to meet these
	 * requirements will cause ArrayOutOfBoundsExceptions.
	 *
	 * @param  valueList java.lang.Object[]
	 */
	public void setValues(Object[] valueList)
	{
		for(int i = 0; i < valueCount; ++i)
		{
			this.valueList[i] = valueList[i];
		}
	}
	/**
	 * @return  com.objectwave.persist.RDBBroker
	 * @author  Dave Hoag
	 */
	public RDBBroker getBroker()
	{
		return broker;
	}
	/**
	 * @return  java.lang.String[]
	 */
	public String[] getColumnList()
	{
		return columnList;
	}
	/**
	 * @return  java.lang.String
	 */
	public abstract String getPreparedString();
	/**
	 *Gets the SqlStatement attribute of the SQLModifier object
	 *
	 * @return  The SqlStatement value
	 */
	public abstract StringBuffer getSqlStatement();
	/**
	 * @return  java.lang.Object[]
	 */
	public Object[] getValueList()
	{
		return valueList;
	}
	/**
	 * We pool these objects for reuse. Before returning the object to the
	 * pool, clean it up by removing all old values.
	 */
	public void clean()
	{
		super.clean();
		for(int i = 0; i < valueCount; i++)
		{
			columnList[i] = null;
			valueList[i] = null;
		}
		valueCount = 0;
		sqlTypes = null;
		broker = null;
	}
	/**
	 * @param  columnName The feature to be added to the ColumnValue attribute
	 * @param  value The feature to be added to the ColumnValue attribute
	 */
	public void addColumnValue(final String columnName, final Object value)
	{
		if(valueCount == columnList.length)
		{
			//Grow the two collections

			growLists(columnList.length + 20);
		}
		valueList[valueCount] = value;
		columnList[valueCount++] = columnName;
	}
	/**
	 * @param  length
	 */
	protected void growLists(int length)
	{
		String[] newList = new String[length];
		System.arraycopy(columnList, 0, newList, 0, columnList.length);
		columnList = newList;

		Object[] newValueList = new Object[length];
		System.arraycopy(valueList, 0, newValueList, 0, valueList.length);
		valueList = newValueList;
	}
	/**
	 * Add the column names to the list of columns to insert.
	 *
	 * @param  columns The feature to be added to the ColumnList attribute
	 * @deprecated
	 */
	public void addColumnList(final String[] columns)
	{
		if(columnList.length == 0)
		{
			columnList = columns;
		}
		else
		{
			String[] newList = new String[columnList.length + columns.length];
			System.arraycopy(columnList, 0, newList, 0, columnList.length);
			System.arraycopy(columns, 0, newList, columnList.length, columns.length);
			columnList = newList;
		}
	}
	/**
	 * Add values to the list of values to insert. This should match exactly with
	 * addColumnList.
	 *
	 * @param  values The feature to be added to the ValueList attribute
	 * @deprecated
	 */
	public void addValueList(final Object[] values)
	{
		if(valueList.length == 0)
		{
			valueList = values;
		}
		else
		{
			Object[] newList = new Object[valueList.length + values.length];
			//Copy the original values into the new array
			System.arraycopy(valueList, 0, newList, 0, valueList.length);
			//copy the new values into the new array.
			System.arraycopy(values, 0, newList, valueList.length, values.length);
			//Change our reference to the new array.
			valueList = newList;
		}
	}
	/**
	 * Bind the data to the PreparedStatement at the specified index. All data is bound to the
	 * prepared statement via the stmt.setString(index, value) method. This is known to work
	 * for Oracle and it is assumed to work for other databases. The only exception to
	 * to this rule involved Serialized objects and Binary database field types.  The stmt.setBytes(index, bytes)
	 * method is used for data of the binary type.
	 *
	 * @param  stmt java.sql.PreparedStatement The statement that is being reused.
	 * @param  index int The index of the value in the prepared statement.
	 * @param  value java.lang.Object The object to store in the database.
	 * @param  sqlType int The known database column type to which the data is being stored.
	 * @param  verbose
	 * @exception  java.sql.SQLException
	 * @author  Dave Hoag
	 */
	protected void bindValue(final java.sql.PreparedStatement stmt, final int index, Object value, final int sqlType, final boolean verbose) throws java.sql.SQLException
	{
		if(value == null)
		{
			stmt.setNull(index, sqlType);
			if(verbose)
			{
				BrokerFactory.println("... " + columnList[index - 1] + " = null");
			}
		}
		else
		{
			switch (sqlType)
			{
				//case java.sql.Types.CLOB:
				case java.sql.Types.BLOB:
				case java.sql.Types.BINARY:
				case java.sql.Types.VARBINARY:
				case java.sql.Types.LONGVARBINARY:
				{
					try
					{
						bindAsBinaryValue(stmt, index, value, sqlType, verbose);
						break;
					}
					catch(java.io.IOException e)
					{
						BrokerFactory.println("Exception converting binary object. " + e);
					}
				}
				case java.sql.Types.NUMERIC:
				{
					if(value instanceof Number)
					{
						if(verbose)
						{
							BrokerFactory.println("... " + columnList[index - 1] + " = " + String.valueOf(value) + " // " + value.getClass().getName());
						}
						if(value instanceof Long)
						{
							//It's likely that the dbId is a long

							stmt.setLong(index, ((Number) value).longValue());
							break;
						}
						else
								if(value instanceof Integer)
						{
							stmt.setInt(index, ((Number) value).intValue());
							break;
						}
						else
								if(value instanceof Double)
						{
							stmt.setDouble(index, ((Number) value).doubleValue());
							break;
						}
						else
								if(value instanceof Short)
						{
							stmt.setShort(index, ((Number) value).shortValue());
							break;
						}
						else
								if(value instanceof Float)
						{
							stmt.setFloat(index, ((Number) value).floatValue());
							break;
						}
						else
								if(value instanceof Byte)
						{
							stmt.setByte(index, ((Number) value).byteValue());
							break;
						}
					}
				}
				case java.sql.Types.TIMESTAMP:
				{
					if(value instanceof java.sql.Timestamp)
					{
						stmt.setTimestamp(index, (java.sql.Timestamp) value);
						break;
					}
					//otherwise fall into default
				}
				default:
				{
					// This doesn't work
					//try
					//{
					//	stmt.setObject(index, value, sqlType);
					//}
					//catch(Exception ex) { ex.printStackTrace(); }; //try string approach
					if(value instanceof String)
					{
						stmt.setString(index, (String) value);
						if(verbose)
						{
							BrokerFactory.println("... " + columnList[index - 1] + " = " + value + " // String");
						}
					}
					else
					{
						//Is there a bug in this when dealing with '' and strings?

						bindAsStringValue(stmt, index, value, verbose);
					}
				}
			}
		}
	}
	/**
	 * The database column is known to be a binary data type.
	 * Bind the value (either a byte [] or a serializable object) to the column.
	 * Only Serializable and byte [] are supported as valid Java types for a
	 * binary database type.
	 *
	 * @param  stmt
	 * @param  index
	 * @param  value
	 * @param  sqlType
	 * @param  verbose
	 * @exception  java.sql.SQLException
	 * @exception  java.io.IOException
	 */
	private void bindAsBinaryValue(final java.sql.PreparedStatement stmt, final int index, Object value, final int sqlType, final boolean verbose) throws java.sql.SQLException, java.io.IOException
	{
		if(value instanceof byte[])
		{
			stmt.setBytes(index, (byte[]) value);
		}
		else
		{
			final byte[] bytes = getObjectFormatter().serializeObject((java.io.Serializable) value);
//Rumor has it that setBytes should work just fine
//			if(sqlType == java.sql.Types.BLOB)
//			{
//				getObjectFormatter().bindBlob(stmt, bos.toByteArray(), index);
//			}
//			else
//			{
			stmt.setBytes(index, bytes);
//			}
		}
		if(verbose)
		{
			StringBuffer buf = new StringBuffer(6);
			formatValue(value, buf);
			if(buf.length() > 20)
			{
				buf.setLength(20);
				buf.append("...");
			}
			BrokerFactory.println("... " + columnList[index - 1] + " = " + buf.toString() + " // " + value.getClass().getName());
		}
	}
	/**
	 * Bind the value to the prepared statment as a String value.
	 * The JDBC support will convert it to the appropriate type.
	 *
	 * @param  index int Positional value of the parameter
	 * @param  stmt PreparedStatement The object to which this is being bound
	 * @param  verbose boolean Do we print out logging information?
	 * @param  value The value that is converted to a string and then bound to the statement
	 * @exception  java.sql.SQLException
	 */
	private final void bindAsStringValue(final java.sql.PreparedStatement stmt, final int index, final Object value, final boolean verbose) throws java.sql.SQLException
	{
		StringBuffer buf = new StringBuffer(6);
		//Convert the value to a string
		formatValue(value, buf);
		//Remove '\''
		if(buf.charAt(0) == '\'')
		{
			buf.setCharAt(0, ' ');
			buf.setLength(buf.length() - 1);
		}
		final String strValue = buf.toString().trim();
		if(verbose)
		{
			BrokerFactory.println("... " + columnList[index - 1] + " = " + value + " // " + value.getClass().getName());
		}
		stmt.setString(index, strValue);
	}
	/**
	 * Bind data to a prepared statement.
	 *
	 * @param  persistenceClass The persistent class we are updating. Used for a query to determine sql types.
	 * @param  verbose boolean Should we be verbose about this effort?
	 * @param  prepStmt
	 * @exception  java.sql.SQLException An unexcepted database exception.
	 * @exception  QueryException An exception generated by JGrinder.
	 */
	public void bindValues(final java.sql.PreparedStatement prepStmt, final Class persistenceClass, final boolean verbose) throws java.sql.SQLException, QueryException
	{
		if(sqlTypes == null || sqlTypes.length == 0)
		{
			initSqlTypes(persistenceClass);
		}
		for(int i = 0; i < valueCount; i++)
		{
			try
			{
				//SQL column counting begins at 1 not zero
				bindValue(prepStmt, i + 1, valueList[i], sqlTypes[i], verbose);
				valueList[i] = null;
				//Lets not keep references.
			}
			catch(java.sql.SQLException ex)
			{
				BrokerFactory.println("Exception binding value " + columnList[i]);
				throw ex;
			}
		}
	}
	/**
	 * Used by prepared statements to copy the values from on SQLModifier
	 * to another.
	 *
	 * @param  sql The source SQLModifier from which to take values.
	 */
	public void copyValuesFrom(SQLModifier sql)
	{
		setValues(sql.getValueList());
	}
	/**
	 * Discover and record the SQL type codes for the columns.
	 *
	 * @param  persistenceClass
	 * @exception  QueryException
	 * @author  Steven Sinclair
	 */
	private void initSqlTypes(Class persistenceClass) throws QueryException
	{
		Persistence pObj;
		try
		{
			pObj = (Persistence) (persistenceClass.newInstance());
		}
		catch(InstantiationException ex)
		{
			throw new QueryException("initSqlTypes failed", ex);
		}
		catch(IllegalAccessException ex)
		{
			throw new QueryException("initSqlTypes failed", ex);
		}

		if(pObj == null)
		{
			throw new QueryException("InitSQLTypes failed due to impossible situation.", null);
		}

		final SQLQuery query = new SQLQuery(pObj);
		removeRelatedObjects(pObj);

		final AttributeTypeColumn column = broker.getRDBAdapter(pObj).getPrimaryAttributeDescription();
		final Object value = SQLObject.defaultFormatter.convertType(column, String.valueOf(new Integer(-1)));
		pObj.setPrimaryKeyField(value);

		//The types in the list is result of a query of the current type.
		//It may include columns not found in this update statement.
		Pair types[] = getBroker().findColumnSqlTypes(query);

		assignSqlTypesToColumnNames(types);
	}
	/**
	 * Update the member variable sqlTypes with a new array of ints that corresponds to the
	 * member variable columnList. The columnList will be changed since an update or an insert will
	 * not include the primary key, but the query will. Warning, the types array passed in as a
	 * parameter will contain null values upon completion of this method.
	 *
	 * @param  types Pair [] where Pairs have a first element of the column name and the second of the SqlType.
	 */
	private final void assignSqlTypesToColumnNames(final Pair types[])
	{
		//We're going to have a sqlType for each entry in the types collection
		sqlTypes = new int[types.length];
		if(types.length > columnList.length)
		{
			growLists(types.length + 2);
		}
		if(valueCount == types.length)
		{
			//Slam dunk - Assumes insert columns align directly with selects

			for(int i = 0; i < valueCount; ++i)
			{
				sqlTypes[i] = ((Integer) types[i].getSecond()).intValue();
			}
		}
		else
		{
			//Assign those that were are part of the original column list
			for(int i = 0; i < valueCount; i++)
			{
				for(int j = 0; j < types.length; j++)
				{
					if(types[j] != null && columnList[i].equalsIgnoreCase((String) (types[j].getFirst())))
					{
						sqlTypes[i] = ((Integer) types[j].getSecond()).intValue();
						//Mark it as null so we don't consider this type again
						types[j] = null;
						break;
					}
				}
			}
			//Assign any columns not found in the original list to slots at the end of the new columnList
			int currentIdx = valueCount;
			for(int i = 0; i < types.length; i++)
			{
				if(types[i] != null)
				{
					//set both the column name and the sqltype
					sqlTypes[currentIdx] = ((Integer) types[i].getSecond()).intValue();
					columnList[currentIdx] = (String) types[i].getFirst();
					currentIdx++;
				}
			}
		}
	}
	/**
	 * Related objects will result in a query that is not correct for initializing
	 * sql types.
	 *
	 * @param  obj
	 */
	private final void removeRelatedObjects(final Persistence obj)
	{
		final RDBPersistence pObj = broker.getRDBAdapter(obj);

		final AttributeTypeColumn[] cols = pObj.getInstanceLinkDescriptions();
		for(int i = 0; i < cols.length; i++)
		{
			cols[i].setValue(obj, null);
		}
		final AttributeTypeColumn[] otherCols = pObj.getForeignKeyDescriptions();
		for(int i = 0; i < otherCols.length; i++)
		{
			otherCols[i].setValue(obj, null);
		}
	}
}

