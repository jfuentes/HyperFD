package com.objectwave.persist.sqlConstruction;
import com.objectwave.logging.MessageLog;
import com.objectwave.persist.*;
import com.objectwave.persist.ObjectFormatter;

import com.objectwave.utility.StringManipulator;
import java.io.*;
import java.sql.Timestamp;
import java.util.Date;
/**
 * @author  Dave Hoag
 * @version  $Id: SQLObject.java,v 2.1 2001/08/10 20:30:32 dave_hoag Exp $
 */
public abstract class SQLObject
{
	static ObjectFormatter defaultFormatter;
	protected boolean availableForPool = true;
	protected String table;
	ObjectFormatter objectFormatter;
	/**
	 */
	public SQLObject()
	{
		setObjectFormatter(defaultFormatter);
	}
	/**
	 * @return  The DefaultFormatter value
	 */
	public static ObjectFormatter getDefaultFormatter()
	{
		return defaultFormatter;
	}
	/**
	 * @param  canBeUsedInAnObjectPool The new AvailableForPool value
	 */
	public void setAvailableForPool(boolean canBeUsedInAnObjectPool)
	{
		availableForPool = canBeUsedInAnObjectPool;
	}
	/**
	 * @param  tableName The name of the database table this object is to update.
	 */
	public void setTableName(String tableName)
	{
		table = tableName;
	}
	/**
	 *  Allow the changing of the formatter. This allows custom formatting to be
	 *  provided.
	 *
	 * @param  of The new ObjectFormatter value
	 */
	public void setObjectFormatter(ObjectFormatter of)
	{
		objectFormatter = of;
	}
	/**
	 * @return  ObjectFormatter knows how to convert Objects into string values.
	 */
	public ObjectFormatter getObjectFormatter()
	{
		return objectFormatter;
	}
	/**
	 * @return  The AvailableForPool value
	 */
	protected final boolean isAvailableForPool()
	{
		return availableForPool;
	}
	/**
	 *  Restore the object to the state it was in at instantiation time.
	 *  There is a statementFactory per broker. The broker will may override
	 *  the object formatter to use. Once set, its not subject to change, so
	 *  we don't need to clean it.
	 */
	public void clean()
	{
		setTableName(null);
	}
	/**
	 *  Use the default object formatter is none is set.
	 *
	 * @param  value
	 * @param  buf
	 */
	public void formatValue(final Object value, final StringBuffer buf)
	{
		try
		{
			getObjectFormatter().formatValue(value, buf);
		}
		catch(IOException ex)
		{
			MessageLog.debug(this, "Failed to format value for " + value, ex);
			throw new RuntimeException("Data " + value + " could not be processed.");
		}
	}
	/**
	 * @param  column
	 * @param  value
	 */
	public void insertWhereClause(final String column, final Object value)
	{
		throw new UnsupportedOperationException("Optional method insertWhereClause(String, Object) not implemented.");
	}
	static
	{
		defaultFormatter = new ObjectFormatter();
	}
}
