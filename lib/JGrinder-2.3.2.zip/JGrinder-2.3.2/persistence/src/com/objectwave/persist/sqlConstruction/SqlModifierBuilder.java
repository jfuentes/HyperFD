/*
 *  Copyright (C) 2001 David Hoag
 *  ObjectWave Corporation
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *  For a full copy of the license see:
 *  http://www.opensource.org/licenses/lgpl-license.html
 */
package com.objectwave.persist.sqlConstruction;
import com.objectwave.persist.*;
import com.objectwave.persist.broker.*;
import com.objectwave.persist.examples.*;
import com.objectwave.persist.mapping.*;
import java.sql.*;
import java.util.Vector;
/**
 *  Utility class to builder SQL statements that will modify database table
 *  entries.
 *
 * @author  Dave Hoag
 * @version  $Id: SqlModifierBuilder.java,v 2.3 2001/11/02 16:07:56 dave_hoag Exp $
 */
public class SqlModifierBuilder
{
	static String[] types = {"RDB"};
	static Class[] classes = {SqlModifierBuilder.class};
	RDBBroker broker;
	/**
	 * @param  instanceType
	 * @return  The Instance value
	 */
	public static SqlModifierBuilder getInstance(String instanceType)
	{
		if(instanceType == null)
		{
			return new SqlModifierBuilder();
		}
		for(int i = 0; i < types.length; i++)
		{
			try
			{
				if(types[i].equals(instanceType))
				{
					return (SqlModifierBuilder) classes[i].newInstance();
				}
			}
			catch(Exception e)
			{
				throw new RuntimeException(e.toString());
			}
		}
		throw new RuntimeException("SqlModifierBuilder " + instanceType + " is unknown.");
	}
	/**
	 *  Builds the where clause for a sql object. By default we use the primary key
	 *  field to determine what to delete.
	 *
	 * @param  sql
	 * @param  obj
	 * @author  Dave Hoag
	 */
	protected static void buildWhereClause(final SQLObject sql, final RDBPersistence obj)
	{
		AttributeTypeColumn[] atc = obj.getPrimaryKeyDescriptions();
		for(int i = 0; i < atc.length; ++i)
		{
			sql.insertWhereClause(atc[i].getColumnName(), atc[i].getValue(obj.getPersistentObject()));
		}
	}
	/**
	 * @param  newValue com.objectwave.persist.RDBBroker
	 * @author  Dave Hoag
	 */
	public void setBroker(RDBBroker newValue)
	{
		this.broker = newValue;
	}

	/**
	 * @return  com.objectwave.persist.RDBBroker
	 * @author  Dave Hoag
	 */
	public RDBBroker getBroker()
	{
		return broker;
	}
	/**
	 *  Builds a delete sql object.
	 *
	 * @param  obj The object to delete.
	 * @param  sql SQLDelete The instance that will be able to create the sql
	 *      statement.
	 */
	public void buildDeleteStatement(final SQLDelete sql, final RDBPersistence obj)
	{
		sql.setTableName(obj.getTableName(null));
		buildDeleteWhereClause(sql, obj);
	}
	/**
	 *  Create the SQLAssembler that will enable us to create an insert statement.
	 *
	 * @param  sql
	 * @param  pObj
	 * @param  p
	 */
	public void buildInsertStatement(final SQLInsert sql, final RDBPersistence pObj, final Persistence p)
	{
		sql.setTableName(pObj.getTableName(null));
		sql.setBroker(getBroker());

		buildAttributeModifierValues(sql, pObj, p);

		//Give the broker a chance to change something about the SQLInsert object.

		getBroker().update(sql, pObj);
		//Most likely adding the primary key field

		buildForeignKeyModifierValues(sql, pObj, p);
		buildInstanceLinkModifierValues(sql, pObj, p);
	}
	/**
	 *  Create a sql object that will be used to generate the sql statement.
	 *
	 * @param  sql
	 * @param  pObj
	 * @param  p
	 */
	public void buildUpdateStatement(final SQLUpdate sql, final RDBPersistence pObj, final Persistence p)
	{
		sql.setTableName(pObj.getTableName(null));
		sql.setBroker(getBroker());

		buildAttributeModifierValues(sql, pObj, p);
		buildForeignKeyModifierValues(sql, pObj, p);
		buildInstanceLinkModifierValues(sql, pObj, p);
		buildUpdateWhereClause(sql, pObj);
	}
	/**
	 *  Inserts and updates need to add the columns and the values of the columns
	 *  to the sql object.
	 *
	 * @param  sql The sql object that will ultimately generate the sql statement.
	 * @param  pObj Object with which we are inserting/updating the database.
	 * @param  p
	 * @see  com.objectwave.persist.SQLUpdate
	 * @see  com.objectwave.persist.SQLInsert
	 * @see  com.objectwave.persist.SQLModifier
	 */
	protected void buildAttributeModifierValues(final SQLModifier sql, final RDBPersistence pObj, final Persistence p)
	{
		final AttributeTypeColumn[] cols = pObj.getAttributeDescriptions();
		Object value;
		final ObjectFormatter frmt = sql.getObjectFormatter();

		for(int i = 0; i < cols.length; ++i)
		{
			value = cols[i].getValue(p);
			if(value != null && frmt.needsArrayConversion(cols[i]))
			{
				value = frmt.convertArray(value);
			}

			sql.addColumnValue(cols[i].getColumnName(), value);
		}
	}
	/**
	 *  Builds the where clause for a delete sql object. By default we use the
	 *  primary key field to determine what to delete.
	 *
	 * @param  sql
	 * @param  obj
	 * @author  Dave Hoag
	 */
	protected void buildDeleteWhereClause(final SQLDelete sql, final RDBPersistence obj)
	{
		SqlModifierBuilder.buildWhereClause(sql, obj);
	}

	/**
	 *  Check all of the foreignKey fields in pObj for its update values.
	 *
	 * @param  sql
	 * @param  pObj
	 * @param  p
	 */
	protected void buildForeignKeyModifierValues(final SQLModifier sql, final RDBPersistence pObj, final Persistence p)
	{

		AttributeTypeColumn[] cols = pObj.getForeignKeyDescriptions();
		for(int i = 0; i < cols.length; ++i)
		{
			JoinField[] joinFields = cols[i].getJoinFields();
			for(int j = 0; j < joinFields.length; j++)
			{
				JoinField joinField = joinFields[j];
				Object fkRef = convertObjectReference((Persistence) cols[i].getValue(p), pObj, p, joinField.getJoinField());
				sql.addColumnValue(joinField.getJoinColumn(), fkRef);
			}

			//final Object fkRef = convertObjectReference((Persistence) cols[i].getValue(p), pObj, p, cols[i].getJoinOn());
			//sql.addColumnValue(cols[i].getColumnName(), fkRef);
		}
	}
	/**
	 *  Check all of the instance link references of pObj for its update values.
	 *  Only those instance links that have a database column will be added to this
	 *  list.
	 *
	 * @param  sql
	 * @param  pObj
	 * @param  p
	 */
	protected void buildInstanceLinkModifierValues(final SQLModifier sql, final RDBPersistence pObj, final Persistence p)
	{
		AttributeTypeColumn[] defs = pObj.getInstanceLinkDescriptions();

		int countOfRelevantOnes = 0;
		for(int i = 0; i < defs.length; i++)
		{
			//Get a list of those with column names
			if(defs[i].getColumnName() != null)
			{
				countOfRelevantOnes++;
			}
		}

		if(countOfRelevantOnes == 0)
		{
			return;
		}
		//The normal case.

		for(int i = 0; i < defs.length; ++i)
		{
			if(defs[i].getColumnName() != null)
			{
				Object fkData = defs[i].getValue(p);
				fkData = convertObjectReference((Persistence) fkData, pObj, p, defs[i].getJoinOn());
				sql.addColumnValue(defs[i].getColumnName(), fkData);
			}
		}
	}
	/**
	 * @param  sql
	 * @param  obj
	 */
	protected void buildUpdateWhereClause(final SQLUpdate sql, final RDBPersistence obj)
	{
		SqlModifierBuilder.buildWhereClause(sql, obj);
	}
	/**
	 *  Convert a "Persistence" object into the simple numeric value that is to go
	 *  into the database.
	 *
	 * @param  reference
	 * @param  pObj
	 * @param  obj
	 * @param  joinOn
	 * @return
	 */
	protected Object convertObjectReference(final Persistence reference, final RDBPersistence pObj, final Persistence obj, final java.lang.reflect.Field joinOn)
	{
		if(reference != null)
		{
			RDBPersistence pFkData;

			if(reference.usesAdapter())
			{
				pFkData = (RDBPersistence) reference.getAdapter();
			}
			else
			{
				pFkData = (RDBPersistence) reference;
			}

			if(pFkData.isRetrievedFromDatabase() || pFkData.isProxy())
			{
				/*
				 *  We ask how objValue joins to searchObj.
				 *  We will take that join value and
				 *  use it in the where clause.
				 */
				final AttributeTypeColumn joinColumn = pFkData.foreignKeyJoinColumn(pObj, joinOn);
				return joinColumn.getValue(reference);
			}
		}
		// End ifData
		return null;
	}
	/**
	 * @author  dhoag
	 * @version  $Id: SqlModifierBuilder.java,v 2.3 2001/11/02 16:07:56 dave_hoag Exp $
	 */
	public static class Test extends com.objectwave.test.UnitTestBaseImpl
	{
		/**
		 *  The main program for the Test class
		 *
		 * @param  args The command line arguments
		 */
		public static void main(String[] args)
		{
			com.objectwave.test.TestRunner.run(new Test(), args);
		}
		/**
		 *  A unit test for JUnit
		 */
		public void testUpdateBuilding()
		{
			SqlModifierBuilder builder = new SqlModifierBuilder();
			SQLUpdate update;
			ExampleEmployee emp = new ExampleEmployee();
			emp.title = "aTitle";
			emp.emailAddress = "anEmailAddress";
			emp.objectIdentifier = new Integer(100);
			SQLUpdate sqlUpdate = new SQLUpdate();
			builder.buildUpdateStatement(sqlUpdate, (RDBPersistence) emp.getAdapter(), emp);
			String expectedString = "UPDATE employee SET title='aTitle' ,emailAddress='anEmailAddress' ,companyIdentifier=NULL ,bossIdentifier=NULL   WHERE databaseIdentifier = 100";
			testContext.assertEquals(expectedString, sqlUpdate.getSqlStatement().toString());
			expectedString = "UPDATE employee SET title= ?, emailAddress= ?, companyIdentifier= ?, bossIdentifier= ?   WHERE databaseIdentifier = ?";
			testContext.assertEquals(expectedString, sqlUpdate.getPreparedString().trim());
		}
		/**
		 *  A unit test for JUnit
		 */
		public void testUpdateBuilding2()
		{
			SqlModifierBuilder builder = new SqlModifierBuilder();
			SQLUpdate update;
			ExampleEmployee emp = new ExampleEmployee();
			emp.title = "aTitle";
			emp.emailAddress = "anEmailAddress";
			emp.objectIdentifier = new Integer(100);
			ExampleEmployee boss = new ExampleEmployee();
			boss.title = "aBoss";
			boss.objectIdentifier = new Integer(101);
			boss.setRetrievedFromDatabase(true);
			emp.boss = boss;
			SQLUpdate sqlUpdate = new SQLUpdate();
			builder.buildUpdateStatement(sqlUpdate, (RDBPersistence) emp.getAdapter(), emp);
			String expectedString = "UPDATE employee SET title='aTitle' ,emailAddress='anEmailAddress' ,companyIdentifier=NULL ,bossIdentifier=101   WHERE databaseIdentifier = 100";
			testContext.assertEquals(expectedString, sqlUpdate.getSqlStatement().toString());
			expectedString = "UPDATE employee SET title= ?, emailAddress= ?, companyIdentifier= ?, bossIdentifier= ?   WHERE databaseIdentifier = ?";
			testContext.assertEquals(expectedString, sqlUpdate.getPreparedString().trim());
		}
	}
}
