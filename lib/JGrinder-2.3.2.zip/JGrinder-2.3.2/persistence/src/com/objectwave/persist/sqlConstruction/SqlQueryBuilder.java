/*
 *  Copyright (C) 2001 David Hoag
 *  ObjectWave Corporation
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *  For a full copy of the license see:
 *  http://www.opensource.org/licenses/lgpl-license.html
 */
package com.objectwave.persist.sqlConstruction;
import com.objectwave.persist.*;
import com.objectwave.persist.broker.*;
import com.objectwave.persist.constraints.*;
import com.objectwave.persist.examples.*;
import com.objectwave.persist.mapping.*;
import java.util.Vector;
/**
 *  Utility class to build SQL statements.
 *
 * @author  Dave Hoag
 * @version  $Id: SqlQueryBuilder.java,v 2.7 2002/03/23 13:42:11 dave_hoag Exp $
 */
public class SqlQueryBuilder
{

	/**
	 *  Some objects will have a default value. We use 'values' in the object to
	 *  determine 'where clauses' for our SQL statements. Hence we use this method
	 *  throughout the code to 'weed out' default values.
	 *
	 * @param  obj
	 * @return
	 */
	public static boolean defaultValue(final Object obj)
	{
		if(obj instanceof Integer)
		{
			return ((Integer) obj).intValue() == 0;
		}
		if(obj instanceof Boolean)
		{
			return ((Boolean) obj).booleanValue() == false;
		}
		if(obj instanceof String)
		{
			return ((String) obj).equals("");
		}
		if(obj instanceof Long)
		{
			return ((Long) obj).longValue() == 0;
		}
		if(obj instanceof Byte)
		{
			return ((Byte) obj).byteValue() == 0;
		}
		if(obj instanceof Short)
		{
			return ((Short) obj).shortValue() == 0;
		}
		if(obj instanceof Float)
		{
			return ((Float) obj).floatValue() == 0;
		}
		if(obj instanceof Double)
		{
			return ((Double) obj).doubleValue() == 0;
		}
		if(obj instanceof Character)
		{
			return ((Character) obj).charValue() == 0;
		}
		return false;
	}
	/**
	 *  Get a list of all of the columns to be used in the selecte statement. This
	 *  will include the primaryKey column, the foreignKey columns, and any
	 *  instanceLink columns that have columnNames.
	 *
	 * @param  pObj
	 * @param  pRef
	 * @return  The SelectColumnList value
	 * @author  Dave Hoag
	 */
	protected String[] getSelectColumnList(final RDBPersistence pObj, final RDBPersistence pRef)
	{

		java.util.ArrayList list = new java.util.ArrayList();

		AttributeTypeColumn[] pk = pObj.getPrimaryKeyDescriptions();
		AttributeTypeColumn[] att = pObj.getAttributeDescriptions();
		AttributeTypeColumn[] fk = pObj.getForeignKeyTypes(pRef);
		AttributeTypeColumn[] typeMap = pObj.getInstanceLinkTypes(pRef);

		for(int i = 0; i < att.length; ++i)
		{
			list.add(att[i].getColumnName());
		}
		for(int i = 0; i < pk.length; ++i)
		{
			list.add(pk[i].getColumnName());
		}
		for(int i = 0; i < fk.length; ++i)
		{
			JoinField[] joinFields = fk[i].getJoinFields();
			for(int j = 0; j < joinFields.length; j++)
			{
				JoinField joinField = joinFields[j];
				list.add(joinField.getJoinColumn());
			}
		}
		for(int i = 0; i < typeMap.length; ++i)
		{
			if(typeMap[i].getColumnName() != null)
			{
				list.add(typeMap[i].getColumnName());
			}
		}

		String[] ret = new String[list.size()];
		System.arraycopy(list.toArray(), 0, ret, 0, list.size());
		return ret;
	}
	/**
	 *  Update the sql object with the information necessary to perform a count
	 *  statement as requested by the query obj.
	 *
	 * @param  sql The instance that is modified with the SQL code.
	 * @param  obj SQLQuery The details of the count request.
	 */
	public void buildCountStatement(final SQLSelect sql, final SQLQuery obj)
	{
		RDBPersistence pObj = adapter(obj.getSubject());

		pObj.setRecordOffset(0);

		String tableName = pObj.getTableName(null);
		sql.initializeAttributes(tableName, false);
		sql.setCount(true);
		buildFindStatement(pObj, null, sql);
	}
	/**
	 * @param  sqlObj The instance that is modified with the SQL code.
	 * @param  pObj
	 * @param  pRef
	 */
	public void buildFindStatement(final SQLSelect sqlObj, final RDBPersistence pObj, final RDBPersistence pRef)
	{
		buildFindStatement(sqlObj, pObj, pRef, null);
	}
	/**
	 * @param  sqlObj The instance that is modified with the SQL code.
	 * @param  pObj
	 * @param  pRef
	 * @param  constraints
	 */
	public void buildFindStatement(final SQLSelect sqlObj, final RDBPersistence pObj, final RDBPersistence pRef, java.util.List constraints)
	{
		String tableName = pObj.getTableName(pRef);
		sqlObj.initializeAttributes(tableName, false);

		buildFindStatement(pObj, pRef, sqlObj, constraints);
	}
	/**
	 *  Create a find statement.
	 *
	 * @param  pObj
	 * @param  pRef
	 * @param  sql The instance that is modified with the SQL code.
	 */
	public void buildFindStatement(final RDBPersistence pObj, final RDBPersistence pRef, final SQLSelect sql)
	{
		buildFindStatement(pObj, pRef, sql, null);
	}
	/**
	 *  Create a find statement.
	 *
	 * @param  pObj
	 * @param  pRef
	 * @param  sql The instance that is modified with the SQL code.
	 * @param  constraints
	 */
	public void buildFindStatement(final RDBPersistence pObj, final RDBPersistence pRef, final SQLSelect sql, java.util.List constraints)
	{
		SQLQuery q = null;
		//We do the following check to test integrity of the query.
		//If we do not have a sql query, then the users query may not function as expected.
		if(pObj.getObjectEditor() instanceof SQLQuery)
		{
			sql.addColumnList(getSelectColumnList(pObj, pRef));
			q = (SQLQuery) pObj.getObjectEditor();
		}
		else
		{
			if(!pObj.isRetrievedFromDatabase())
			{
				//Probably built a reference in a default constructor

				sql.addColumnList(getSelectColumnList(pObj, pRef));
				q = new SQLQuery(pObj.getPersistentObject());
				//Maybe?
			}

			//We are probably realizing a proxy, in which case we have no columns to retrieve.
			//If we are not realizing a proxy, we should throw this exception
//			throw new RuntimeException ("Invalid query provided " + pObj);
		}
		if(constraints != null)
		{
			for(int i = 0; i < constraints.size(); i++)
			{
				Constraint c = (Constraint) constraints.get(i);
				q.addConstraint((Constraint) constraints.get(i));
			}
		}

		buildAttributeWhereClause(q, sql, pObj, pRef);

		if(!pObj.isRetrievedFromDatabase())
		{
			buildForeignKeyWhereClause(q, sql, pObj, pRef);
			buildInstanceLinkWhereClause(q, sql, pObj, pRef);
//        		self buildMiscWhereClause: sql with: searchObj for: refObj.
		}
	}
	/**
	 *  Build a SQLSelect object from the SQLQuery. The SQLSelect contains the
	 *  information formatting the SQL statement.
	 *
	 * @param  sqlObj The instance that is modified with the SQL code.
	 * @param  obj
	 */
	public void buildFindStatement(final SQLSelect sqlObj, final SQLQuery obj)
	{
		final RDBPersistence pObj = adapter(obj.getSubject());
		pObj.setRecordOffset(0);
		buildFindStatement(sqlObj, pObj, null);
	}
	/**
	 *  Look at all of our attribute values. (non relational values, usually
	 *  primitives or Strings) If we find a value, other than nil or the default
	 *  value, this value will become part of the sql where clause.
	 *
	 * @param  query
	 * @param  sql
	 * @param  pObj
	 * @param  pRef
	 * @see  #defaultValue
	 */
	protected void buildAttributeWhereClause(final SQLQuery query, final SQLSelect sql, final RDBPersistence pObj, final RDBPersistence pRef)
	{
		AttributeTypeColumn[] colDefs = pObj.getAttributeDescriptions();
		final Persistence obj = pObj.getPersistentObject();

		if(pObj.isRetrievedFromDatabase())
		{
			/*
			 *  If the search object is from the database we will
			 *  only add the primary key field to the where clause.
			 */
			SqlModifierBuilder.buildWhereClause(sql, pObj);
			if(RDBExtendablePersistentAdapter.class.isInstance(pObj))
			{
				RDBExtendablePersistentAdapter epObj = (RDBExtendablePersistentAdapter) pObj;
				sql.insertWhereClause(epObj.getTypeIdentifierDescription().getColumnName(), epObj.getTypeIdentifierDescription());
			}
		}
		else
		{
			AttributeTypeColumn[] pkAtc = pObj.getPrimaryKeyDescriptions();
			for(int i = 0; i < pkAtc.length; i++)
			{
				checkFieldForWhereClause(pkAtc[i], query, sql, obj);
			}
			for(int i = 0; i < colDefs.length; i++)
			{
				checkFieldForWhereClause(colDefs[i], query, sql, obj);
			}
		}
	}
	/**
	 * @param  col
	 * @param  query
	 * @param  sql
	 * @param  obj
	 */
	protected void checkFieldForWhereClause(final AttributeTypeColumn col, final SQLQuery query, final SQLSelect sql, final Persistence obj)
	{
		//For query by example, the useFieldValue and compare variables will be properly set
		boolean useFieldValue = true;
		String compare = "=";

		if(query != null)
		{
			//query.getConstraintString(obj, col.getField().getName())
			Constraint constraint = query.getConstraintFor(col.getField().getName());
			if(constraint != null)
			{
				constraint.setObjectFormatter(sql.getObjectFormatter());
				useFieldValue = constraint.isComparisonValueFromPersistentObject();
				if(constraint.isUsingColumnName())
				{
					constraint.setColumnName(sql.getAlias() + "." + col.getColumnName());
					sql.addWhereClause(constraint.constructQueryString());
					return;
					//Where clause added. Done with this column
				}
				compare = constraint.constructQueryString();
			}
			else
			{
				if(query.isLike())
				{
					compare = "LIKE ";
				}
			}
		}

		Object fieldValue = col.getValue(obj);
		if(!useFieldValue)
		{
			//In this instance, the 'compare' field contains the value.
			sql.insertConstraintWhereClause(compare, col.getColumnName());
		}
		else
				if(fieldValue != null && !defaultValue(fieldValue))
		{
			//The compare is a simple '='  or a 'like' and the value comes from the field.
			sql.insertWhereClause(compare, col.getColumnName(), fieldValue);
		}
	}
	/**
	 *  Builds the where clause from the values of the foreign key instance
	 *  variables that are not nil as defined in the foreign key map.
	 *
	 * @param  sql is the SQLObject that we are currently building.
	 * @param  query
	 * @param  pObj
	 * @param  pRef
	 */
	protected void buildForeignKeyWhereClause(final SQLQuery query, final SQLSelect sql, final RDBPersistence pObj, final RDBPersistence pRef)
	{
		final AttributeTypeColumn[] colDefs = pObj.getForeignKeyDescriptions();
		final Persistence obj = pObj.getPersistentObject();

		for(int i = 0; i < colDefs.length; i++)
		{
			final AttributeTypeColumn col = colDefs[i];
			String compare = null;
			Constraint constraint = null;
			if(query != null)
			{
				constraint = query.getConstraintFor(col.getField().getName());
				if(constraint != null)
				{
					constraint.setObjectFormatter(sql.getObjectFormatter());
					compare = constraint.constructQueryString();
				}
			}
			Persistence fkData = (Persistence) col.getValue(obj);
			// Since the "IS [NOT] NULL" constraint is the only valid one for
			// a foreign key, we look explicitly for this constraint.
			if(compare != null)
			{
				if(constraint == null)
				{
					//is null or is not null where clause. Not a join.
					sql.insertWhereClause(compare, colDefs[i].getColumnName(), "");
				}
				else
				{
					sql.insertWhereClause(compare, colDefs[i].getColumnName());
				}
			}
			else
					if(fkData != null)
			{
				RDBPersistence pFkData = adapter(fkData);
				if(pFkData.isRetrievedFromDatabase())
				{
					JoinField[] joinFields = colDefs[i].getJoinFields();
					for(int j = 0; j < joinFields.length; j++)
					{
						JoinField joinField = joinFields[j];
						AttributeTypeColumn joinColumn = pFkData.foreignKeyJoinColumn(pObj, joinField.getJoinField());
						Object join = joinColumn.getValue(fkData);
						sql.insertWhereClause("=", joinField.getJoinColumn(), join);
					}
				}
				else
				{
					SQLSelect sqlObj = createJoinObject(sql, pObj, pFkData, query.getChildConstraintFor(col.getField().getName()));
					JoinField[] joinFields = colDefs[i].getJoinFields();
					for(int j = 0; j < joinFields.length; j++)
					{
						JoinField joinField = joinFields[j];
						AttributeTypeColumn joinColumn = pFkData.foreignKeyJoinColumn(pRef, joinField.getJoinField());
						String colName = joinColumn.getColumnName();
						sql.joinWith(colDefs[i].getField().getName(), sqlObj, joinField.getJoinColumn(), colName, "=");
					}
				}
			}
		}
		// For loop
	}
	/**
	 *  Builds the where clause from the values of the instance link instance
	 *  variables that are not nil as defined in the instance link map.
	 *
	 * @param  sql is the SQLObject that we are currently building.
	 * @param  query
	 * @param  pObj
	 * @param  pRef
	 */
	protected void buildInstanceLinkWhereClause(final SQLQuery query, final SQLSelect sql, final RDBPersistence pObj, final RDBPersistence pRef)
	{
		final Persistence p = pObj.getPersistentObject();
		final AttributeTypeColumn[] cols = pObj.getInstanceLinkTypes(pRef);

		for(int i = 0; i < cols.length; i++)
		{
			Persistence instanceLinkObject = (Persistence) cols[i].getValue(p);
			String colName = cols[i].getColumnName();
			if(instanceLinkObject != null)
			{
				RDBPersistence pIlData = adapter(instanceLinkObject);

				AttributeTypeColumn dataJoinIdx = pIlData.instanceLinkJoinColumn(pObj);
				if(dataJoinIdx.getJoinFields().length == 1)
				{
					if(dataJoinIdx == cols[i])
					{
						//("Just found my self, ignore");
						dataJoinIdx = null;
					}
				}
				//If no back reference from the InstanceLink object to me. My InstanceLink reference
				//is really like a fk reference - treat as such
				if((pIlData.isRetrievedFromDatabase()) && (colName != null) && dataJoinIdx == null)
				{
					final AttributeTypeColumn fkJoinCol = pIlData.foreignKeyJoinColumn(pObj, cols[i].getJoinOn());
					sql.insertWhereClause(colName, fkJoinCol.getValue(instanceLinkObject));
					return;
				}
				//Else, there is a reference from the InstanceLink object that points to me
				//Either through FK or InstanceLink with column
				String toCol = null;
				String fkColName = null;
				if(dataJoinIdx != null)
				{
					final SQLSelect sqlObj = createJoinObject(sql, pObj, pIlData, query.getChildConstraintFor(cols[i].getField().getName()));
					JoinField[] joinFields = dataJoinIdx.getJoinFields();
					for(int j = 0; j < joinFields.length; j++)
					{
						JoinField joinField = joinFields[j];
						AttributeTypeColumn joinColumn = pObj.foreignKeyJoinColumn(pRef, joinField.getJoinField());
						toCol = joinField.getJoinColumn();
						fkColName = joinColumn.getColumnName();
						sql.joinWith(cols[i].getField().getName(), sqlObj, fkColName, toCol, "=");
					}
				}
				else
				{
					final AttributeTypeColumn joinColumn = pObj.foreignKeyJoinColumn(pRef, null);
					fkColName = joinColumn.getColumnName();
					if(fkColName == null)
					{
						fkColName = colName;
					}
					final SQLSelect sqlObj = createJoinObject(sql, pObj, pIlData, query.getChildConstraintFor(cols[i].getField().getName()));
					sql.joinWith(cols[i].getField().getName(), sqlObj, fkColName, fkColName, "=");
				}

			}
			// End ifData
		}
		// For loop
	}
	/**
	 *  Takes care of building a find statement for obj and join it to sql.
	 *
	 * @param  sql is the find statement built for forObj.
	 * @param  forObj is the object from the search object that is referencing obj.
	 *      It is needed to calculate the recordOffset for obj.
	 * @param  obj
	 * @return
	 * @author  Dave Hoag
	 */
	protected SQLSelect createJoinObject(final SQLSelect sql, final RDBPersistence forObj, final RDBPersistence obj)
	{
		return createJoinObject(sql, forObj, obj, null);
	}
	/**
	 *  Takes care of building a find statement for obj and join it to sql.
	 *
	 * @param  sql is the find statement built for forObj.
	 * @param  forObj is the object from the search object that is referencing obj.
	 *      It is needed to calculate the recordOffset for obj.
	 * @param  obj
	 * @param  constraints
	 * @return
	 * @author  Dave Hoag
	 */
	protected SQLSelect createJoinObject(final SQLSelect sql, final RDBPersistence forObj, final RDBPersistence obj, java.util.List constraints)
	{
		/*
		 *  obj's recordOffset in the join of its own find
		 *  statement with sql will be forObj's recordOffset
		 *  plus the size of sql before the join.
		 */
		obj.setRecordOffset(forObj.getRecordOffset() + sql.getRecordSize());
		final SQLSelect sqlSelect = new SQLSelect();
		sqlSelect.setObjectFormatter(sql.getObjectFormatter());
		buildFindStatement(sqlSelect, obj, forObj, constraints);
		return sqlSelect;
	}
	/**
	 *  Get the RDBPersistence adatper from the persistent object.
	 *
	 * @param  obj
	 * @return
	 */
	private final RDBPersistence adapter(final Persistence obj)
	{
		if(obj.usesAdapter())
		{
			return (RDBPersistence) obj.getAdapter();
		}
		else
		{
			return (RDBPersistence) obj;
		}
	}
	//Unit Test built on the JUnit test suite.
	/**
	 * @author  dhoag
	 * @version
	 */
	public static class Test extends com.objectwave.test.UnitTestBaseImpl
	{
		/**
		 *  The main program for the Test class
		 *
		 * @param  args The command line arguments
		 */
		public static void main(String[] args)
		{
			com.objectwave.test.TestRunner.run(new Test(), args);
		}
		/**
		 *  The JUnit setup method
		 *
		 * @param  str The new Up value
		 * @param  cont The new Up value
		 */
		public void setUp(String str, com.objectwave.test.TestContext cont)
		{
			SQLSelect.nextAlias = '0';
		}
		/**
		 *  A unit test for JUnit
		 */
		public void testBuildInstanceLinkWhereClause()
		{
			SqlQueryBuilder builder = new SqlQueryBuilder();
			ExampleEmployee emp = new ExampleEmployee();
			ExamplePerson pers = new ExamplePerson();
			SQLQuery query = new SQLQuery(emp);
			SQLSelect sql = new SQLSelect("one");
			RDBPersistence pObj = (RDBPersistence) emp.getAdapter();
			RDBPersistence pRef = null;
			emp.setPerson(pers);
			builder.buildInstanceLinkWhereClause(query, sql, pObj, pRef);
			java.util.Enumeration e = sql.getWhereClause().elements();
			String obj = null;
			while(e.hasMoreElements())
			{
				obj = (String) e.nextElement();

				int idx = obj.indexOf('=');
				String dbIdent = obj.substring(0, idx - 1);
				String empIdent = obj.substring(idx + 2);
				testContext.assertTrue("Failed to join objects through Instance relation. ", empIdent.endsWith("employeeIdentifier"));
				testContext.assertTrue("Failed to join objects through Instance relation 2. ", dbIdent.endsWith("databaseIdentifier"));
			}
			testContext.assertTrue("No where clauses where found.", obj != null);

		}
		/**
		 *  A unit test for JUnit
		 */
		public void testBuildForeignKeyWhereClause()
		{
			SqlQueryBuilder builder = new SqlQueryBuilder();
			ExampleEmployee emp = new ExampleEmployee();
			ExamplePerson pers = new ExamplePerson();
			SQLQuery query = new SQLQuery(pers);
			SQLSelect sql = new SQLSelect("one");
			RDBPersistence pObj = (RDBPersistence) pers.getAdapter();
			RDBPersistence pRef = null;
			pers.setEmployee(emp);
			builder.buildForeignKeyWhereClause(query, sql, pObj, pRef);
			java.util.Enumeration e = sql.getWhereClause().elements();
			String obj = null;
			while(e.hasMoreElements())
			{
				obj = (String) e.nextElement();
				int idx = obj.indexOf('=');
				String empIdent = obj.substring(0, idx - 1);
				String dbIdent = obj.substring(idx + 2);
				testContext.assertTrue("Failed to join objects through FKey relation. ", empIdent.endsWith("employeeIdentifier"));
				testContext.assertTrue("Failed to join objects through FKey relation 2. ", dbIdent.endsWith("databaseIdentifier"));
			}
			testContext.assertTrue("No where clauses where found.", obj != null);

		}
		/**
		 *  A unit test for JUnit
		 */
		public void testAttributeWhereClause()
		{
			SqlQueryBuilder builder = new SqlQueryBuilder();
			ExampleEmployee emp = new ExampleEmployee();
			SQLQuery query = new SQLQuery(emp);
			SQLSelect sel = new SQLSelect("one");
			RDBPersistence pObj = (RDBPersistence) emp.getAdapter();
			RDBPersistence pRef = null;
			emp.setTitle("one");
			builder.buildAttributeWhereClause(query, sel, pObj, pRef);
			java.util.Enumeration e = sel.getWhereClause().elements();
			Object obj = null;
			while(e.hasMoreElements())
			{
				obj = e.nextElement();
				String queryString = obj.toString();
				testContext.assertTrue("Invalid where clause: " + queryString, queryString.endsWith("title = 'one'"));
				testContext.assertTrue("Alias on simple where clause failed to pass. ", queryString.charAt(1) == '.');
			}
			testContext.assertTrue("No where clauses where found.", obj != null);
		}
		/**
		 *  A unit test for JUnit
		 */
		public void testAttributeWhereClauseWithBetweenConstraint()
		{
			SqlQueryBuilder builder = new SqlQueryBuilder();
			ExampleEmployee emp = new ExampleEmployee();
			SQLQuery query = new SQLQuery(emp);
			SQLSelect sel = new SQLSelect("one");
			RDBPersistence pObj = (RDBPersistence) emp.getAdapter();
			RDBPersistence pRef = null;
			//emp.setTitle("one");
			com.objectwave.persist.constraints.ConstraintBetween c = (com.objectwave.persist.constraints.ConstraintBetween) com.objectwave.persist.constraints.ConstraintFactory.createConstraint("between");
			c.setPersistence(emp);
			c.setField("title");
			c.setNot(true);
			c.setBetweenMax("10");
			c.setBetweenMin("1");
			query.addConstraint(c);
			builder.buildAttributeWhereClause(query, sel, pObj, pRef);
			java.util.Enumeration e = sel.getWhereClause().elements();
			Object obj = null;
			while(e.hasMoreElements())
			{
				obj = e.nextElement();
				String queryString = obj.toString();
				testContext.assertTrue("Invalid where clause: " + queryString, queryString.endsWith("title NOT BETWEEN '1' AND '10'"));
				testContext.assertTrue("Alias on simple where clause failed to pass. ", queryString.charAt(1) == '.');
			}
			testContext.assertTrue("No where clauses where found.", obj != null);
		}
		/**
		 *  A unit test for JUnit
		 */
		public void testAttributeWhereClauseWithConstraintOnPkey()
		{
			SqlQueryBuilder builder = new SqlQueryBuilder();
			ExampleEmployee emp = new ExampleEmployee();
			SQLQuery query = new SQLQuery(emp);
			SQLSelect sel = new SQLSelect("one");
			RDBPersistence pObj = (RDBPersistence) emp.getAdapter();
			RDBPersistence pRef = null;
			//emp.setTitle("one");
			com.objectwave.persist.constraints.ConstraintCompare c = new com.objectwave.persist.constraints.ConstraintCompare();
			c.setPersistence(emp);
			c.setField("objectIdentifier");
			c.setComparison("<");
			c.setNot(true);
			c.setCompValue("10");
			query.addConstraint(c);
			builder.buildAttributeWhereClause(query, sel, pObj, pRef);
			java.util.Enumeration e = sel.getWhereClause().elements();
			Object obj = null;
			while(e.hasMoreElements())
			{
				obj = e.nextElement();
				String queryString = obj.toString();
				//System.out.println(queryString);
				testContext.assertTrue("Invalid where clause: " + queryString, queryString.endsWith("A.databaseIdentifier >= 10"));
			}
			testContext.assertTrue("Expected where clause on primary key field.", obj != null);
		}
		/**
		 *  A unit test for JUnit
		 */
		public void testAttributeWhereClauseWithConstraint()
		{
			SqlQueryBuilder builder = new SqlQueryBuilder();
			ExampleEmployee emp = new ExampleEmployee();
			SQLQuery query = new SQLQuery(emp);
			SQLSelect sel = new SQLSelect("one");
			RDBPersistence pObj = (RDBPersistence) emp.getAdapter();
			RDBPersistence pRef = null;
			//emp.setTitle("one");
			com.objectwave.persist.constraints.ConstraintCompare c = new com.objectwave.persist.constraints.ConstraintCompare();
			c.setPersistence(emp);
			c.setField("title");
			c.setComparison("=");
			c.setNot(true);
			c.setCompValue("one");
			query.addConstraint(c);
			builder.buildAttributeWhereClause(query, sel, pObj, pRef);
			java.util.Enumeration e = sel.getWhereClause().elements();
			Object obj = null;
			while(e.hasMoreElements())
			{
				obj = e.nextElement();
				String queryString = obj.toString();
				//System.out.println(queryString);
				testContext.assertTrue("Invalid where clause: " + queryString, queryString.endsWith("A.title != 'one'"));
				testContext.assertTrue("Alias on simple where clause failed to pass. ", queryString.charAt(1) == '.');
			}
			testContext.assertTrue("No where clauses where found.", obj != null);
		}
		/**
		 *  A unit test for JUnit
		 */
		public void testAttWhereWithBooleanConstraint()
		{
			SqlQueryBuilder builder = new SqlQueryBuilder();
			ExampleEmployee emp = new ExampleEmployee();
			SQLQuery query = new SQLQuery(emp);
			SQLSelect sel = new SQLSelect("one");
			RDBPersistence pObj = (RDBPersistence) emp.getAdapter();
			RDBPersistence pRef = null;
			//emp.setTitle("one");
			com.objectwave.persist.constraints.ConstraintCompare c = new com.objectwave.persist.constraints.ConstraintCompare();
			c.setPersistence(emp);
			c.setField("title");
			c.setComparison("=");
			c.setNot(true);
			c.setCompValue("one");

			com.objectwave.persist.constraints.ConstraintCompare c2 = new com.objectwave.persist.constraints.ConstraintCompare();
			c2.setPersistence(emp);
			c2.setField("title");
			c2.setComparison("=");
			c2.setNot(true);
			c2.setCompValue("otherValue");
			ConstraintBoolean booleanC = new ConstraintBoolean(true, c, c2);
			booleanC.setField("title");
			query.addConstraint(booleanC);
			builder.buildAttributeWhereClause(query, sel, pObj, pRef);
			String clause = sel.getWhereClause().firstElement().toString();

			testContext.assertEquals("(A.title != 'one' AND A.title != 'otherValue')", clause);
		}
		/**
		 *  A unit test for JUnit
		 */
		public void testJoinQuery2()
		{
			SqlQueryBuilder builder = new SqlQueryBuilder();
			ExampleEmployee emp = new ExampleEmployee();
			ExamplePerson pers = new ExamplePerson();
			emp.setPerson(pers);
			SQLQuery query = new SQLQuery(emp);
			SQLSelect.nextAlias = '0';
			SQLSelect sel = new SQLSelect();
			builder.buildFindStatement(sel, query);
			testContext.assertEquals("SELECT A.title, A.emailAddress, A.databaseIdentifier, A.companyIdentifier, A.bossIdentifier, B.name, B.databaseIdentifier, B.employeeIdentifier FROM employee A ,person B WHERE A.databaseIdentifier = B.employeeIdentifier", sel.getSqlStatement().toString());
		}
		/**
		 *  A unit test for JUnit
		 */
		public void testJoinQuery()
		{
			SqlQueryBuilder builder = new SqlQueryBuilder();
			ExampleEmployee emp = new ExampleEmployee();
			SQLQuery query = new SQLQuery(emp);
			ExamplePerson pers = new ExamplePerson();
			emp.setPerson(pers);
			SQLSelect.nextAlias = '0';
			SQLSelect sel = new SQLSelect();
			builder.buildFindStatement(sel, query);
			testContext.assertEquals("SELECT A.title, A.emailAddress, A.databaseIdentifier, A.companyIdentifier, A.bossIdentifier, B.name, B.databaseIdentifier, B.employeeIdentifier FROM employee A ,person B WHERE A.databaseIdentifier = B.employeeIdentifier", sel.getSqlStatement().toString());
		}
		/**
		 *  A unit test for JUnit
		 */
		public void testInstanceProxyJoin()
		{
			SqlQueryBuilder builder = new SqlQueryBuilder();
			ExampleEmployee emp = new ExampleEmployee();
			emp.setRetrievedFromDatabase(true);
			emp.setPrimaryKeyField(new Integer(10));
			ExamplePerson pers = new ExamplePerson();
			SQLQuery query = new SQLQuery(pers);
			pers.setEmployee(emp);
			((RDBPersistentAdapter) pers.getAdapter()).setProxy(true);
			SQLSelect.nextAlias = '0';
			SQLSelect sel = new SQLSelect();
			builder.buildFindStatement(sel, query);
			testContext.assertEquals("SELECT A.name, A.databaseIdentifier, A.employeeIdentifier FROM person A WHERE A.employeeIdentifier = 10", sel.getSqlStatement().toString());
		}
	}
}
