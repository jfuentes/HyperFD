package com.objectwave.persist.sqlConstruction;

import java.sql.PreparedStatement;

/**
 * @author Steve Sinclair
 * @version 2.0
 */
public class SqlStatementCacheItem
{
	protected SQLModifier modifier;
	protected Class persistenceClass;
	protected PreparedStatement statement;

	/**
	 */
	public SqlStatementCacheItem() {}
	/**
	 */
	public SqlStatementCacheItem(SQLModifier modifier, PreparedStatement prepStmt, Class persistenceClass)
	{
		setModifier(modifier);
		setStatement( prepStmt);
		setPersistenceClass(persistenceClass);
	}
	public void setModifier(SQLModifier modif)
	{
		modifier = modif;
	}
	public void setStatement(PreparedStatement prepStmt)
	{
		statement = prepStmt;
	}
	public SQLModifier getModifier()
	{
		return modifier;
	}
	public PreparedStatement getStatement()
	{
		return statement;
	}
/**
 * This method was created in VisualAge.
 * @return java.lang.Class
 */
public Class getPersistenceClass() {
	return persistenceClass;
}
/**
 * This method was created in VisualAge.
 * @param newValue java.lang.Class
 */
public void setPersistenceClass(Class newValue) {
	this.persistenceClass = newValue;
}

}
