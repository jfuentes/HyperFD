package com.objectwave.persist.sqlConstruction;
import com.objectwave.persist.ObjectFormatter;
import com.objectwave.persist.Persistence;
import com.objectwave.persist.QueryException;
import com.objectwave.persist.broker.RDBBroker;
/**
 *  Use this factory to create the instances of SQLInsert, SQLDelete, etc...
 *
 * @author  Dave Hoag
 * @version  $Id: StatementFactory.java,v 2.1 2002/03/23 13:42:11 dave_hoag Exp $
 */
public class StatementFactory
{
	static StatementFactory instance;
	ObjectFormatter objectFormatter;
	ThreadLocal insertContext;
	ThreadLocal updateContext;
	ThreadLocal deleteContext;
	ThreadLocal selectContext;
	/**
	 */
	public StatementFactory()
	{
		initialize();
	}
	/**
	 *  Supports a singelton approach, but this is not how it is used.
	 *
	 * @return  The Instance value
	 */
	public static synchronized StatementFactory getInstance()
	{
		if(instance == null)
		{
			instance = new StatementFactory();
		}
		return instance;
	}
	/**
	 * @param  args The command line arguments
	 */
	public static void main(String[] args)
	{
		int count = new Integer(args[0]).intValue();
		long time = System.currentTimeMillis();
		for(int i = 0; i < count; ++i)
		{
			SQLUpdate obj = new SQLUpdate();
			if(obj.getValueList() == null)
			{
			}
		}
		System.out.println(System.currentTimeMillis() - time);
		StatementFactory fact = new StatementFactory();
		time = System.currentTimeMillis();
		for(int i = 0; i < count; ++i)
		{
			SQLUpdate obj = fact.newUpdate();
			fact.returnUpdate(obj);
			if(obj.getValueList() == null)
			{
			}
		}
		System.out.println(System.currentTimeMillis() - time);
	}
	/**
	 * @param  formatter The new ObjectFormatter value
	 */
	public final void setObjectFormatter(final ObjectFormatter formatter)
	{
		objectFormatter = formatter;
	}
	/**
	 * @return  The ObjectFormatter value
	 */
	public final ObjectFormatter getObjectFormatter()
	{
		return objectFormatter;
	}
	/**
	 * @param  threadContext
	 * @return  The ObjectCache value
	 */
	protected final ExpandingSQLObjectCache getObjectCache(final ThreadLocal threadContext)
	{
		ExpandingSQLObjectCache cacheObject = (ExpandingSQLObjectCache) threadContext.get();
		if(cacheObject == null)
		{
			cacheObject = new ExpandingSQLObjectCache();
			threadContext.set(cacheObject);
		}
		return cacheObject;
	}
	/**
	 */
	protected void initialize()
	{
		insertContext = new ThreadLocal();
		updateContext = new ThreadLocal();
		deleteContext = new ThreadLocal();
		selectContext = new ThreadLocal();
	}
	/**
	 * @return
	 */
	public SQLInsert newInsert()
	{
		SQLInsert result = (SQLInsert) getObjectCache(insertContext).getSQLObjectFromCacheWork();
		if(result == null)
		{
			result = new SQLInsert();
			if(getObjectFormatter() != null)
			{
				result.setObjectFormatter(getObjectFormatter());
			}
		}
		return result;
	}
	/**
	 * @param  ins
	 */
	public void returnInsert(final SQLInsert ins)
	{
		if(ins.isAvailableForPool())
		{
			ins.clean();
			getObjectCache(insertContext).returnSQLObjectToCacheWork(ins);
		}
	}
	/**
	 * @return
	 */
	public SQLUpdate newUpdate()
	{
		SQLUpdate result = (SQLUpdate) getObjectCache(updateContext).getSQLObjectFromCacheWork();
		if(result == null)
		{
			result = new SQLUpdate();
			if(getObjectFormatter() != null)
			{
				result.setObjectFormatter(getObjectFormatter());
			}
		}
		return result;
	}
	/**
	 * @param  upd
	 */
	public void returnUpdate(final SQLUpdate upd)
	{
		if(upd.isAvailableForPool())
		{
			upd.clean();
			getObjectCache(updateContext).returnSQLObjectToCacheWork(upd);
		}
	}
	/**
	 * @return
	 */
	public SQLSelect newSelect()
	{
		SQLSelect result = (SQLSelect) getObjectCache(selectContext).getSQLObjectFromCacheWork();
		if(result == null)
		{
			result = new SQLSelect();
			if(getObjectFormatter() != null)
			{
				result.setObjectFormatter(getObjectFormatter());
			}
		}
		return result;
	}
	/**
	 * @param  sel
	 */
	public void returnSelect(final SQLSelect sel)
	{
		if(sel.isAvailableForPool())
		{
			sel.clean();
			getObjectCache(selectContext).returnSQLObjectToCacheWork(sel);
		}
	}
	/**
	 * @return
	 */
	public SQLDelete newDelete()
	{
		SQLDelete result = (SQLDelete) getObjectCache(deleteContext).getSQLObjectFromCacheWork();
		if(result == null)
		{
			result = new SQLDelete();
			if(getObjectFormatter() != null)
			{
				result.setObjectFormatter(getObjectFormatter());
			}
		}
		return result;
	}
	/**
	 * @param  del
	 */
	public void returnDelete(final SQLDelete del)
	{
		if(del.isAvailableForPool())
		{
			del.clean();
			getObjectCache(deleteContext).returnSQLObjectToCacheWork(del);
		}
	}
	/**
	 *  Unit tests.
	 *
	 * @author  dhoag
	 * @version  $Id: StatementFactory.java,v 2.1 2002/03/23 13:42:11 dave_hoag Exp $
	 */
	public static class Test extends com.objectwave.test.UnitTestBaseImpl
	{
		/**
		 *  The main program for the Test class
		 *
		 * @param  args The command line arguments
		 */
		public static void main(String[] args)
		{
			com.objectwave.test.TestRunner.run(new Test(), args);
		}
		/**
		 *  A unit test for JUnit
		 */
		public void testRefetch()
		{
			StatementFactory fact = new StatementFactory();
			SQLObject obj = fact.newDelete();
			fact.returnDelete((SQLDelete) obj);
			SQLObject reObj = fact.newDelete();
			testContext.assertEquals("Delete object failed to return cached version", obj, reObj);

			obj = fact.newInsert();
			fact.returnInsert((SQLInsert) obj);
			reObj = fact.newInsert();
			testContext.assertEquals("Insert object failed to return cached version", obj, reObj);

			obj = fact.newUpdate();
			fact.returnUpdate((SQLUpdate) obj);
			reObj = fact.newUpdate();
			testContext.assertEquals("Update object failed to return cached version", obj, reObj);

			obj = fact.newSelect();
			fact.returnSelect((SQLSelect) obj);
			reObj = fact.newSelect();
			testContext.assertEquals("Select object failed to return cached version", obj, reObj);
		}
		/**
		 *  A unit test for JUnit
		 */
		public void testEmptyFetch()
		{
			StatementFactory fact = new StatementFactory();
			SQLObject obj = fact.newDelete();
			testContext.assertTrue("Failed to get delete object", obj instanceof SQLDelete);

			obj = fact.newInsert();
			testContext.assertTrue("Failed to get delete object", obj instanceof SQLInsert);

			obj = fact.newUpdate();
			testContext.assertTrue("Failed to get delete object", obj instanceof SQLUpdate);

			obj = fact.newSelect();
			testContext.assertTrue("Failed to get delete object", obj instanceof SQLSelect);
		}
	}
}
