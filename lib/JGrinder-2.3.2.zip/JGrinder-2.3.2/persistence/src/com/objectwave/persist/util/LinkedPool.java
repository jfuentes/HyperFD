package com.objectwave.persist.util;

import java.util.Hashtable;
import java.util.Enumeration;
import com.objectwave.persist.*;

/**
 * Used be the object pool support.
 * @version $Id: LinkedPool.java,v 2.0 2001/06/11 16:00:04 dave_hoag Exp $
 * @author Dave Hoag
 */
class LinkedPool implements Cloneable, java.io.Serializable
{
	boolean verbose = false;
	LinkedPool next = null;
	String uid;
	Persistence object;

	/**
	*/
	LinkedPool(){}
	/**
	*/
	public LinkedPool(final String uid, final Persistence source)
	{
		this.uid = uid;
		this.object = source;
	}
	/**
	*/
	void add(final LinkedPool pool)
	{
		pool.next = next;
		next = pool;
	}
	/**
	 */
	LinkedPool remove(final String uid, final Persistence source, LinkedPool prev)
	{
		if(this.uid == null)
		{
			if(this.next == null) //we've reached the end of the line.
                return this;
            return next.remove(uid, source, this);
		}
	    int compare = this.uid.compareTo(uid);
	    if(compare == 0)
	    {
	        if(prev == null) return null;// <-Should be impossible
	        prev.next = this.next;
	        return prev;
	    }
		if(next != null)
		{
		    return next.remove(uid, source, this);
		}
		return this;
	}
	/**
	 */
	Persistence add(final String uid, final Persistence source)
	{
		if(this.uid == null)
		{
			if(this.next == null) //we've reached the end of the line.
			{
				add(new LinkedPool(uid.toString(), source));
				return source;
			}
			else
				return next.add(uid, source);
		}
	    int compare = this.uid.compareTo(uid);
	    if(compare == 0) return this.object;
	    if(compare < 0)
	    {
			insert(new LinkedPool(uid.toString(), source));
			return source;
		}
		else
		{
			if(next != null)
				return next.add(uid, source);
			else {
				add(new LinkedPool(uid.toString(), source));
				return source;
			}
		}
	}
	/**
	* Used for thread safe traversal of the object pool.
	*/
	public Object clone()
	{
		LinkedPool result = new LinkedPool();
		result.uid = uid;
		result.object = object;
		LinkedPool nextElement = next;
		LinkedPool newResult = result;
		while(nextElement != null){
			LinkedPool newNext = new LinkedPool();
			newNext.uid = nextElement.uid;
			newNext.object = nextElement.object;
			newResult.next = newNext;
			nextElement = nextElement.next;
			newResult = newNext;
		}
		return result;
	}
	/**
	*/
	public java.util.Enumeration elements()
	{
		return new java.util.Enumeration()
		{
			LinkedPool current = LinkedPool.this;
			public boolean hasMoreElements(){ return current.next != null; }
			public Object nextElement()
			{
				current = current.next;
				return current.object;
			}
		};
	}
	/**
	*/
	Persistence find(final String objUid)
	{
	    if(this.uid == null)
	    {
	        if(next != null)
	            return next.find(objUid);
	        return null;
	    }
	    if(verbose)
			System.out.println("Comparing " + this.uid + " to " + objUid + " " + this.object);
	    if(this.uid.equals(objUid))
	        return this.object;
		if(next != null)
	        return next.find(objUid);
		else
			return null;
	}
	/**
	*/
	void insert(final LinkedPool pool)
	{
		String tmpUid = pool.uid;
		Persistence tmpObj = pool.object;
		add(pool);
		pool.uid = this.uid;
		pool.object = this.object;
		this.uid = tmpUid;
		this.object = tmpObj;
	}
}