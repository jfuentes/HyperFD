package com.objectwave.persist.value;
import java.util.*;
/**
 * @author  cson
 * @version  $Id: Attribute.java,v 1.1 2001/10/03 14:59:03 dave_hoag Exp $
 */
public class Attribute
{
	String sortOrder = null;
	String domainProperty = null;
	String valueField = null;

	/**
	 *Sets the SortOrder attribute of the Attribute object
	 *
	 * @param  value The new SortOrder value
	 */
	public void setSortOrder(String value)
	{
		this.sortOrder = value;
	}

	/**
	 *Sets the DomainProperty attribute of the Attribute object
	 *
	 * @param  value The new DomainProperty value
	 */
	public void setDomainProperty(String value)
	{
		this.domainProperty = value;
	}

	/**
	 *Sets the ValueField attribute of the Attribute object
	 *
	 * @param  value The new ValueField value
	 */
	public void setValueField(String value)
	{
		this.valueField = value;
	}
	/**
	 *Gets the SortOrder attribute of the Attribute object
	 *
	 * @return  The SortOrder value
	 */
	public String getSortOrder()
	{
		return sortOrder;
	}

	/**
	 *Gets the DomainProperty attribute of the Attribute object
	 *
	 * @return  The DomainProperty value
	 */
	public String getDomainProperty()
	{
		return domainProperty;
	}

	/**
	 *Gets the ValueField attribute of the Attribute object
	 *
	 * @return  The ValueField value
	 */
	public String getValueField()
	{
		return valueField;
	}

	/**
	 * @return
	 */
	public boolean hasSortOrder()
	{
		return sortOrder != null;
	}

	/**
	 * @return
	 */
	public boolean hasDomainProperty()
	{
		return domainProperty != null;
	}

	/**
	 * @return
	 */
	public boolean hasValueField()
	{
		return valueField != null;
	}

}
