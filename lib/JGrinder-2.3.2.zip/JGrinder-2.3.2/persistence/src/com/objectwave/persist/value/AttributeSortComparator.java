package com.objectwave.persist.value;

/**
 * @author  cson
 * @version  $Id: AttributeSortComparator.java,v 1.1 2001/10/03 14:59:03 dave_hoag Exp $
 */
public class AttributeSortComparator implements java.util.Comparator
{
	/**
	 * @param  o1
	 * @param  o2
	 * @return
	 */
	public int compare(Object o1, Object o2)
	{
		if(o1 == null || o2 == null)
		{
			if(o1 == null)
			{
				return -1;
			}
			else if(o2 == null)
			{
				return 1;
			}
			else
			{
				return 0;
			}
		}
		else
		{
			Attribute a1 = (Attribute) o1;
			Attribute a2 = (Attribute) o2;
			return a1.getSortOrder().compareTo(a2.getSortOrder());
		}
	}
	/**
	 * @param  obj
	 * @return
	 */
	public boolean equals(Object obj)
	{
		if(obj != null && (obj instanceof AttributeSortComparator))
		{
			return true;
		}
		return false;
	}
}
