package com.objectwave.persist.value;
import java.util.*;
/**
 * @author  cson
 * @version  $Id: Constraint.java,v 1.1 2001/10/03 14:59:03 dave_hoag Exp $
 */
public class Constraint
{
	String not = null;
	String betweenMax = null;
	String betweenMin = null;
	String notEquals = null;
	String matches = null;
	String like = null;
	String lessThan = null;
	String lessOrEqual = null;
	String greaterThan = null;
	String greaterOrEqual = null;
	String equals = null;
	String domainProperty = null;

	/**
	 *Sets the Not attribute of the Constraint object
	 *
	 * @param  value The new Not value
	 */
	public void setNot(String value)
	{
		this.not = value;
	}

	/**
	 *Sets the BetweenMax attribute of the Constraint object
	 *
	 * @param  value The new BetweenMax value
	 */
	public void setBetweenMax(String value)
	{
		this.betweenMax = value;
	}

	/**
	 *Sets the BetweenMin attribute of the Constraint object
	 *
	 * @param  value The new BetweenMin value
	 */
	public void setBetweenMin(String value)
	{
		this.betweenMin = value;
	}

	/**
	 *Sets the NotEquals attribute of the Constraint object
	 *
	 * @param  value The new NotEquals value
	 */
	public void setNotEquals(String value)
	{
		this.notEquals = value;
	}

	/**
	 *Sets the Matches attribute of the Constraint object
	 *
	 * @param  value The new Matches value
	 */
	public void setMatches(String value)
	{
		this.matches = value;
	}

	/**
	 *Sets the Like attribute of the Constraint object
	 *
	 * @param  value The new Like value
	 */
	public void setLike(String value)
	{
		this.like = value;
	}

	/**
	 *Sets the LessThan attribute of the Constraint object
	 *
	 * @param  value The new LessThan value
	 */
	public void setLessThan(String value)
	{
		this.lessThan = value;
	}

	/**
	 *Sets the LessOrEqual attribute of the Constraint object
	 *
	 * @param  value The new LessOrEqual value
	 */
	public void setLessOrEqual(String value)
	{
		this.lessOrEqual = value;
	}

	/**
	 *Sets the GreaterThan attribute of the Constraint object
	 *
	 * @param  value The new GreaterThan value
	 */
	public void setGreaterThan(String value)
	{
		this.greaterThan = value;
	}

	/**
	 *Sets the GreaterOrEqual attribute of the Constraint object
	 *
	 * @param  value The new GreaterOrEqual value
	 */
	public void setGreaterOrEqual(String value)
	{
		this.greaterOrEqual = value;
	}

	/**
	 *Sets the Equals attribute of the Constraint object
	 *
	 * @param  value The new Equals value
	 */
	public void setEquals(String value)
	{
		this.equals = value;
	}

	/**
	 *Sets the DomainProperty attribute of the Constraint object
	 *
	 * @param  value The new DomainProperty value
	 */
	public void setDomainProperty(String value)
	{
		this.domainProperty = value;
	}
	/**
	 *Gets the Not attribute of the Constraint object
	 *
	 * @return  The Not value
	 */
	public String getNot()
	{
		return not;
	}

	/**
	 *Gets the BetweenMax attribute of the Constraint object
	 *
	 * @return  The BetweenMax value
	 */
	public String getBetweenMax()
	{
		return betweenMax;
	}

	/**
	 *Gets the BetweenMin attribute of the Constraint object
	 *
	 * @return  The BetweenMin value
	 */
	public String getBetweenMin()
	{
		return betweenMin;
	}

	/**
	 *Gets the NotEquals attribute of the Constraint object
	 *
	 * @return  The NotEquals value
	 */
	public String getNotEquals()
	{
		return notEquals;
	}

	/**
	 *Gets the Matches attribute of the Constraint object
	 *
	 * @return  The Matches value
	 */
	public String getMatches()
	{
		return matches;
	}

	/**
	 *Gets the Like attribute of the Constraint object
	 *
	 * @return  The Like value
	 */
	public String getLike()
	{
		return like;
	}

	/**
	 *Gets the LessThan attribute of the Constraint object
	 *
	 * @return  The LessThan value
	 */
	public String getLessThan()
	{
		return lessThan;
	}

	/**
	 *Gets the LessOrEqual attribute of the Constraint object
	 *
	 * @return  The LessOrEqual value
	 */
	public String getLessOrEqual()
	{
		return lessOrEqual;
	}

	/**
	 *Gets the GreaterThan attribute of the Constraint object
	 *
	 * @return  The GreaterThan value
	 */
	public String getGreaterThan()
	{
		return greaterThan;
	}

	/**
	 *Gets the GreaterOrEqual attribute of the Constraint object
	 *
	 * @return  The GreaterOrEqual value
	 */
	public String getGreaterOrEqual()
	{
		return greaterOrEqual;
	}

	/**
	 *Gets the Equals attribute of the Constraint object
	 *
	 * @return  The Equals value
	 */
	public String getEquals()
	{
		return equals;
	}

	/**
	 *Gets the DomainProperty attribute of the Constraint object
	 *
	 * @return  The DomainProperty value
	 */
	public String getDomainProperty()
	{
		return domainProperty;
	}

	/**
	 * @return
	 */
	public boolean hasNot()
	{
		return not != null;
	}

	/**
	 * @return
	 */
	public boolean hasBetweenMax()
	{
		return betweenMax != null;
	}

	/**
	 * @return
	 */
	public boolean hasBetweenMin()
	{
		return betweenMin != null;
	}

	/**
	 * @return
	 */
	public boolean hasNotEquals()
	{
		return notEquals != null;
	}

	/**
	 * @return
	 */
	public boolean hasMatches()
	{
		return matches != null;
	}

	/**
	 * @return
	 */
	public boolean hasLike()
	{
		return like != null;
	}

	/**
	 * @return
	 */
	public boolean hasLessThan()
	{
		return lessThan != null;
	}

	/**
	 * @return
	 */
	public boolean hasLessOrEqual()
	{
		return lessOrEqual != null;
	}

	/**
	 * @return
	 */
	public boolean hasGreaterThan()
	{
		return greaterThan != null;
	}

	/**
	 * @return
	 */
	public boolean hasGreaterOrEqual()
	{
		return greaterOrEqual != null;
	}

	/**
	 * @return
	 */
	public boolean hasEquals()
	{
		return equals != null;
	}

	/**
	 * @return
	 */
	public boolean hasDomainProperty()
	{
		return domainProperty != null;
	}

}
