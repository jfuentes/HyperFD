package com.objectwave.persist.value;

/**
 * @author  cson
 * @version  $Id: PersonValue.java,v 1.1 2001/10/03 14:59:03 dave_hoag Exp $
 */
public class PersonValue
{

	private String firstName;
	private String lastName;
	private int age;
	private String areaCode;
	private String phoneNumber;
	private String extension;

	/**
	 *Gets the FirstName attribute of the PersonValue object
	 *
	 * @return  The FirstName value
	 */
	public String getFirstName()
	{
		return firstName;
	}
	/**
	 *Gets the LastName attribute of the PersonValue object
	 *
	 * @return  The LastName value
	 */
	public String getLastName()
	{
		return lastName;
	}
	/**
	 *Gets the Age attribute of the PersonValue object
	 *
	 * @return  The Age value
	 */
	public int getAge()
	{
		return age;
	}
	/**
	 *Gets the AreaCode attribute of the PersonValue object
	 *
	 * @return  The AreaCode value
	 */
	public String getAreaCode()
	{
		return areaCode;
	}
	/**
	 *Gets the PhoneNumber attribute of the PersonValue object
	 *
	 * @return  The PhoneNumber value
	 */
	public String getPhoneNumber()
	{
		return phoneNumber;
	}
	/**
	 *Gets the Extension attribute of the PersonValue object
	 *
	 * @return  The Extension value
	 */
	public String getExtension()
	{
		return extension;
	}

}
