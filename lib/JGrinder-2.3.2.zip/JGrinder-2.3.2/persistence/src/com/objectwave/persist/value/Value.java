package com.objectwave.persist.value;
import java.util.*;
/**
 * @author  cson
 * @version  $Id: Value.java,v 1.1 2001/10/03 14:59:03 dave_hoag Exp $
 */
public class Value
{
	Vector constraint = new Vector();
	Vector attribute = new Vector();
	String domainClass = null;
	String valueClass = null;

	/**
	 *Sets the DomainClass attribute of the Value object
	 *
	 * @param  value The new DomainClass value
	 */
	public void setDomainClass(String value)
	{
		this.domainClass = value;
	}

	/**
	 *Sets the ValueClass attribute of the Value object
	 *
	 * @param  value The new ValueClass value
	 */
	public void setValueClass(String value)
	{
		this.valueClass = value;
	}
	/**
	 *Gets the Constraint attribute of the Value object
	 *
	 * @param  index
	 * @return  The Constraint value
	 */
	public Constraint getConstraint(int index)
	{
		return (Constraint) constraint.elementAt(index);
	}

	/**
	 *Gets the ConstraintCount attribute of the Value object
	 *
	 * @return  The ConstraintCount value
	 */
	public int getConstraintCount()
	{
		return constraint.size();
	}
	/**
	 *Gets the Attribute attribute of the Value object
	 *
	 * @param  index
	 * @return  The Attribute value
	 */
	public Attribute getAttribute(int index)
	{
		return (Attribute) attribute.elementAt(index);
	}

	/**
	 *Gets the AttributeCount attribute of the Value object
	 *
	 * @return  The AttributeCount value
	 */
	public int getAttributeCount()
	{
		return attribute.size();
	}
	/**
	 *Gets the DomainClass attribute of the Value object
	 *
	 * @return  The DomainClass value
	 */
	public String getDomainClass()
	{
		return domainClass;
	}

	/**
	 *Gets the ValueClass attribute of the Value object
	 *
	 * @return  The ValueClass value
	 */
	public String getValueClass()
	{
		return valueClass;
	}

	/**
	 *Adds a feature to the Constraint attribute of the Value object
	 *
	 * @param  item The feature to be added to the Constraint attribute
	 */
	public void addConstraint(Constraint item)
	{
		this.constraint.addElement(item);
	}

	/**
	 * @return
	 */
	public Enumeration constraints()
	{
		return constraint.elements();
	}

	/**
	 *Adds a feature to the Attribute attribute of the Value object
	 *
	 * @param  item The feature to be added to the Attribute attribute
	 */
	public void addAttribute(Attribute item)
	{
		this.attribute.addElement(item);
	}

	/**
	 * @return
	 */
	public Enumeration attributes()
	{
		return attribute.elements();
	}

	/**
	 * @return
	 */
	public boolean hasDomainClass()
	{
		return domainClass != null;
	}

	/**
	 * @return
	 */
	public boolean hasValueClass()
	{
		return valueClass != null;
	}

}
