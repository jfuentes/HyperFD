package com.objectwave.persist.value;
import com.objectwave.persist.BrokerFactory;
import com.objectwave.persist.Persistence;
import com.objectwave.persist.SQLQuery;
import com.objectwave.persist.constraints.ConstraintBetween;
import com.objectwave.persist.constraints.ConstraintCompare;
import com.objectwave.utility.ReflectiveHelper;

import com.objectwave.xjr.XJRFactory;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.Vector;

/**
 * @author  cson
 * @version  $Id: ValueConstructor.java,v 1.1 2001/10/03 14:59:03 dave_hoag Exp $
 */
public class ValueConstructor
{

	/**
	 */
	public final static String XJR_DEFAULT_PACKAGE = "com.objectwave.persist.value";

	/**
	 *Sets the XmlConstraints attribute of the ValueConstructor class
	 *
	 * @param  value The new XmlConstraints value
	 * @param  query The new XmlConstraints value
	 * @exception  Exception
	 */
	private static void setXmlConstraints(Value value, SQLQuery query) throws Exception
	{
		for(Enumeration e = value.constraints(); e.hasMoreElements(); )
		{
			Constraint c = (Constraint) e.nextElement();

			com.objectwave.persist.constraints.Constraint constraint = null;
			String property = c.getDomainProperty();

			if(c.hasBetweenMin() && c.hasBetweenMax())
			{
				constraint = new ConstraintBetween();
				constraint.setField(property);
				ConstraintBetween cb = (ConstraintBetween) constraint;
				cb.setBetweenMin(c.getBetweenMin());
				cb.setBetweenMax(c.getBetweenMax());
			}
			else
			{

				constraint = new ConstraintCompare();
				constraint.setField(property);
				ConstraintCompare cc = (ConstraintCompare) constraint;

				if(c.hasEquals())
				{
					cc.setCompValue(c.getEquals());
					cc.setComparison(ConstraintCompare.equalsIndex);
				}
				else if(c.hasGreaterOrEqual())
				{
					cc.setCompValue(c.getGreaterOrEqual());
					cc.setComparison(ConstraintCompare.greaterOrEqualIndex);
				}
				else if(c.hasGreaterThan())
				{
					cc.setCompValue(c.getGreaterThan());
					cc.setComparison(ConstraintCompare.greaterThanIndex);
				}
				else if(c.hasLessOrEqual())
				{
					cc.setCompValue(c.getLessOrEqual());
					cc.setComparison(ConstraintCompare.lessOrEqualIndex);
				}
				else if(c.hasLessThan())
				{
					cc.setCompValue(c.getLessThan());
					cc.setComparison(ConstraintCompare.lessThanIndex);
				}
				else if(c.hasLike())
				{
					cc.setCompValue(c.getLike());
					cc.setComparison(ConstraintCompare.likeIndex);
				}
				else if(c.hasMatches())
				{
					cc.setCompValue(c.getMatches());
					cc.setComparison(ConstraintCompare.matchesIndex);
				}
				else if(c.hasNotEquals())
				{
					cc.setCompValue(c.getNotEquals());
					cc.setComparison(ConstraintCompare.notEqualsIndex);
				}
			}
			if(c.hasNot() && "true".equalsIgnoreCase(c.getNot()))
			{
				constraint.setNot(true);
			}
			query.addConstraint(constraint);
		}

	}

	/**
	 *Sets the Value attribute of the ValueConstructor class
	 *
	 * @param  domainObject The new Value value
	 * @param  property The new Value value
	 * @param  value The new Value value
	 * @exception  Exception
	 */
	private static void setValue(Object domainObject, String property, Object value) throws Exception
	{
		int index = property.indexOf(".");
		String suffix = null;
		boolean multiValue = false;
		if(index > -1)
		{
			multiValue = true;
			property = property.substring(0, index);
			suffix = property.substring(index + 1);
		}

		ReflectiveHelper rh = new ReflectiveHelper();
		Class domainClass = domainObject.getClass();
		Field propertyField = domainClass.getDeclaredField(property);
		if(index == -1)
		{
			rh.setValue(propertyField, value, domainObject);
		}
		else
		{
			setValue(rh.getValue(propertyField, domainObject), suffix, value);
		}
	}


	/**
	 *Sets the Field attribute of the ValueConstructor class
	 *
	 * @param  valueObject The new Field value
	 * @param  val The new Field value
	 * @param  property The new Field value
	 * @exception  Exception
	 */
	private static void setField(Object valueObject, Object val, String property) throws Exception
	{
		Field field = valueObject.getClass().getDeclaredField(property);
		field.setAccessible(true);
		field.set(valueObject, val);
	}

	/**
	 *Gets the OrderByList attribute of the ValueConstructor class
	 *
	 * @param  value
	 * @return  The OrderByList value
	 */
	private static Vector getOrderByList(Value value)
	{
		ArrayList list = new ArrayList();
		Vector v = new Vector();
		for(Enumeration e = value.attributes(); e.hasMoreElements(); )
		{
			Attribute attr = (Attribute) e.nextElement();
			if(attr.hasSortOrder())
			{
				list.add(attr);
			}
		}
		Collections.sort(list, new AttributeSortComparator());
		for(Iterator it = list.iterator(); it.hasNext(); )
		{
			v.add(((Attribute) it.next()).getDomainProperty());
		}
		return v;
	}


	/**
	 *Gets the Value attribute of the ValueConstructor class
	 *
	 * @param  domainObject
	 * @param  property
	 * @return  The Value value
	 * @exception  Exception
	 */
	private static Object getValue(Object domainObject, String property) throws Exception
	{
		int index = property.indexOf(".");
		String suffix = null;
		boolean multiValue = false;
		if(index > -1)
		{
			multiValue = true;
			suffix = property.substring(index + 1);
			property = property.substring(0, index);
		}

		ReflectiveHelper rh = new ReflectiveHelper();
		Class domainClass = domainObject.getClass();
		Field propertyField = domainClass.getDeclaredField(property);
		if(!multiValue)
		{
			return rh.getValue(propertyField, domainObject);
		}
		else
		{
			return getValue(rh.getValue(propertyField, domainObject), suffix);
		}

	}

	/**
	 * @param  xmlResource
	 * @return
	 */
	public static java.util.Collection find(String xmlResource)
	{
		return find(xmlResource, null);
	}

	/**
	 * @param  xmlResource
	 * @return
	 */
	public static java.util.Collection find(java.net.URL xmlResource)
	{
		return find(xmlResource, null);
	}

	/**
	 * @param  xmlResource
	 * @param  p
	 * @return
	 */
	public static java.util.Collection find(String xmlResource, Persistence p)
	{
		java.net.URL resourceURL = ClassLoader.getSystemClassLoader().getResource(xmlResource);
		return find(resourceURL, null);
	}

	/**
	 * @param  xmlResource
	 * @param  p
	 * @return
	 */
	public static java.util.Collection find(java.net.URL xmlResource, Persistence p)
	{
		if(xmlResource == null)
		{
			throw new IllegalArgumentException("xmlResource " + xmlResource + " is not valid");
		}

		ArrayList list = new ArrayList();
		XJRFactory factory = new XJRFactory();
		factory.setDefaultPackage(XJR_DEFAULT_PACKAGE);

		try
		{
			Value value = ((Value) factory.build(xmlResource));
			if(p == null)
			{
				p = (Persistence) Class.forName(value.getDomainClass()).newInstance();
			}
			SQLQuery query = new SQLQuery(p);
			query.setOrderByList(getOrderByList(value));
			setXmlConstraints(value, query);
			for(Iterator it = query.find().iterator(); it.hasNext(); )
			{
				list.add(createValueObject(value, it.next()));
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return list;
	}

	/**
	 * @param  value
	 * @param  domainObject
	 * @return
	 * @exception  Exception
	 */
	private static Object createValueObject(Value value, Object domainObject) throws Exception
	{
		Object valueObject = Class.forName(value.getValueClass()).newInstance();
		for(Enumeration e = value.attributes(); e.hasMoreElements(); )
		{
			Attribute attr = (Attribute) e.nextElement();
			Object val = getValue(domainObject, attr.getDomainProperty());
			setField(valueObject, val, attr.getValueField());
		}
		return valueObject;
	}

}
