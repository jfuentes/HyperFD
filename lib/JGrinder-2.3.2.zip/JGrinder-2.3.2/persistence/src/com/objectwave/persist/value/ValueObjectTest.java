package com.objectwave.persist.value;
import com.objectwave.logging.MessageLog;
import com.objectwave.persist.Broker;
import com.objectwave.persist.BrokerFactory;

import com.objectwave.persist.SQLQuery;
import com.objectwave.persist.broker.FileBroker;
import com.objectwave.persist.broker.RDBBroker;
import com.objectwave.persist.xml.test.*;
import com.objectwave.transactionalSupport.TransactionLog;
import java.util.Collection;
import java.util.Iterator;

/**
 * Don't use these classes, project not completed.
 *
 * @author  cson
 * @version  $Id: ValueObjectTest.java,v 1.2 2002/02/01 21:43:07 dave_hoag Exp $
 */
public class ValueObjectTest
{

	/**
	 * @author  cson
	 * @version  $Id: ValueObjectTest.java,v 1.2 2002/02/01 21:43:07 dave_hoag Exp $
	 */
	public static class Test extends com.objectwave.test.UnitTestBaseImpl
	{

		private final static String CONNECT_URL = "jdbc:hsqldb:.";
		private final static String USERNAME = "sa";
		private final static String PASSWORD = "";

		private final static String SQL_SEQUENCE = "CREATE TABLE sequence( nextval int PRIMARY KEY)";
		private final static String SQL_SEQUENCE_INIT = "INSERT INTO sequence(nextval) VALUES(1)";
		private final static String SQL_SEQUENCE_DROP = "DROP TABLE sequence";

		private final static String SQL_CREATE_PERSON =
				"CREATE TABLE person(\n" +
				" first_name  VARCHAR(40) NOT NULL,\n" +
				" last_name VARCHAR(40) NOT NULL,\n" +
				" age int,\n" +
				" PRIMARY KEY (first_name, last_name)\n" +
				")";
		private final static String SQL_DROP_PERSON = "DROP TABLE person";

		private final static String SQL_CREATE_PHONE =
				"CREATE TABLE phone(\n" +
				" prefix VARCHAR(3) NOT NULL,\n" +
				" phone_number VARCHAR(8) NOT NULL,\n" +
				" extension VARCHAR(4),\n" +
				" PRIMARY KEY (prefix, phone_number)\n" +
				")";
		private final static String SQL_DROP_PHONE = "DROP TABLE phone";

		private final static String SQL_CREATE_PERSON_PHONE =
				"CREATE TABLE person_phone(\n" +
				"oid INT PRIMARY KEY,\n" +
				"first_name VARCHAR(40) NOT NULL,\n" +
				"last_name VARCHAR(40) NOT NULL,\n" +
				"prefix VARCHAR(3) NOT NULL,\n" +
				"phone_number VARCHAR(7) NOT NULL,\n" +
				"FOREIGN KEY(first_name, last_name) REFERENCES person(first_name, last_name),\n" +
				"FOREIGN KEY(prefix, phone_number) REFERENCES phone(prefix, phone_number)\n" +
				")";
		private final static String SQL_DROP_PERSON_PHONE = "DROP TABLE person_phone";

		private final static String FIRST_NAME = "John";
		private final static String LAST_NAME = "Doe";
		private final static int AGE = 30;

		private final static String PHONE_NUMBER = "555-3030";
		private final static String PREFIX = "312";
		private final static String EXTENSION = "8989";

		private Person person = null;
		private Phone phone = null;
		private PersonPhone personPhone = null;

		/**
		 *The main program for the RDBTest class
		 *
		 * @param  args The command line arguments
		 */
		public static void main(String[] args)
		{
			com.objectwave.test.TestRunner.run(new Test(), args);
		}

		/**
		 * Don't run these tests since this code is not ready for deployment.
		 *
		 * @exception  Exception
		 */
		public void donTestHypersonic() throws Exception
		{
			System.setProperty("ow.persistVerbose", "true");
			System.setProperty("ow.persistConnectionVerbose", "true");
			System.setProperty("ow.persistUser", USERNAME);
			System.setProperty("ow.persistPassword", PASSWORD);
			System.setProperty("ow.persistDriver", "org.hsqldb.jdbcDriver");
			System.setProperty("ow.databaseImpl", "com.objectwave.persist.broker.HypersonicBroker");
			System.setProperty("ow.connectUrl", CONNECT_URL);
			System.setProperty("ow.useConnectionPool", "true");
			BrokerFactory.useDatabase();
			RDBBroker broker = new com.objectwave.persist.broker.HypersonicBroker();
			broker.initialize();
			BrokerFactory.setDefaultBroker(broker);
			SQLQuery.setDefaultBroker(broker);
			buildDatabase(broker);

			populate();
			query();

			deleteDatabase(broker);
		}

		/**
		 *A unit test for JUnit
		 *
		 * @exception  Exception
		 */
		private void populate() throws Exception
		{
			Person filler1 = new Person();
			filler1.setFirstName("fillerfirst");
			filler1.setLastName("fillerlast");
			filler1.save();

			TransactionLog log = TransactionLog.startTransaction("RDB", "context");
			person = new Person();
			person.setFirstName(FIRST_NAME);
			person.setLastName(LAST_NAME);
			person.setAge(AGE);
			phone = new Phone();
			phone.setPrefix(PREFIX);
			phone.setPhoneNumber(PHONE_NUMBER);
			phone.setExtension(EXTENSION);
			personPhone = new PersonPhone();
			personPhone.setPerson(person);
			personPhone.setPhone(phone);
			log.commit();

			Phone filler2 = new Phone();
			filler2.setPrefix("000");
			filler2.setPhoneNumber("5555555");
			filler2.save();
			PersonPhone filler3 = new PersonPhone();
			filler3.setPerson(filler1);
			filler3.setPhone(filler2);
			filler3.save();

		}

		/**
		 *A unit test for JUnit
		 *
		 * @exception  Exception
		 */
		private void query() throws Exception
		{
			java.util.Iterator it = ValueConstructor.find("com/objectwave/persist/value/PersonValue.xml").iterator();
			while(it.hasNext())
			{
				PersonValue person = (PersonValue) it.next();
				System.err.println("----------------------------------");
				System.err.println("First Name: " + person.getFirstName());
				System.err.println("Last Name: " + person.getLastName());
				System.err.println("Age: " + person.getAge());
				System.err.println("Area Code: " + person.getAreaCode());
				System.err.println("Phone Number: " + person.getPhoneNumber());
				System.err.println("Extension: " + person.getExtension());
				System.err.println("----------------------------------");
			}
		}

		/**
		 *The teardown method for JUnit
		 *
		 * @param  context
		 * @exception  Exception
		 */
		public void tearDown(com.objectwave.test.TestContext context) throws Exception
		{

			if(BrokerFactory.getDefaultBroker() instanceof FileBroker)
			{
				MessageLog.debug(this, "Removing files!");
				removeFile("person.dbf");
				removeFile("phone.dbf");
				removeFile("person_phone.dbf");
			}
		}

		/**
		 * @param  broker
		 */
		private void buildDatabase(RDBBroker broker)
		{
			try
			{
				broker.getConnection().execSql(SQL_SEQUENCE);
				broker.getConnection().execSql(SQL_SEQUENCE_INIT);
				broker.getConnection().execSql(SQL_CREATE_PERSON);
				broker.getConnection().execSql(SQL_CREATE_PHONE);
				broker.getConnection().execSql(SQL_CREATE_PERSON_PHONE);
			}
			catch(Exception e)
			{
				MessageLog.error(this, "Failed to build database", e);
				e.printStackTrace();
			}
		}

		/**
		 * @param  broker
		 */
		private void deleteDatabase(RDBBroker broker)
		{
			try
			{
				broker.getConnection().execSql(SQL_SEQUENCE_DROP);
				broker.getConnection().execSql(SQL_DROP_PERSON);
				broker.getConnection().execSql(SQL_DROP_PHONE);
				broker.getConnection().execSql(SQL_DROP_PERSON_PHONE);
			}
			catch(Exception e)
			{
				MessageLog.error(this, "Failed to build database", e);
				e.printStackTrace();
			}
		}

	}

}
