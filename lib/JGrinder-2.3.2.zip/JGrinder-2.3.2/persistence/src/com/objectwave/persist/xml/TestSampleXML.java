package com.objectwave.persist.xml;

import com.objectwave.persist.examples.DomainObject;
import java.lang.reflect.*;

public class TestSampleXML extends DomainObject{
	String id;
	String fieldName_attribute;
	String fieldName_collection;
	String fieldName_instance1;
	String fieldName_instance2;
	String fieldName_foreign;
	String fieldName_typeatt;

	public static Field _id;
	public static Field _fieldName_attribute;
	public static Field _fieldName_collection;
	public static Field _fieldName_instance1;
	public static Field _fieldName_instance2;
	public static Field _fieldName_foreign;
	public static Field _fieldName_typeatt;

	static { /*NAME:fieldDefinition:*/
		try{
			_id = TestSampleXML.class.getDeclaredField("id");
			_fieldName_attribute = TestSampleXML.class.getDeclaredField("fieldName_attribute");
			_fieldName_collection = TestSampleXML.class.getDeclaredField("fieldName_collection");
			_fieldName_instance1 = TestSampleXML.class.getDeclaredField("fieldName_instance1");
			_fieldName_instance2 = TestSampleXML.class.getDeclaredField("fieldName_instance2");
			_fieldName_foreign = TestSampleXML.class.getDeclaredField("fieldName_foreign");
			_fieldName_typeatt = TestSampleXML.class.getDeclaredField("fieldName_typeatt");

			// suppress access checking for these fields.
			_id.setAccessible(true);
			_fieldName_attribute.setAccessible(true);
			_fieldName_collection.setAccessible(true);
			_fieldName_instance1.setAccessible(true);
			_fieldName_instance2.setAccessible(true);
			_fieldName_foreign.setAccessible(true);
			_fieldName_typeatt.setAccessible(true);
		}
		catch (NoSuchFieldException ex) { System.err.println(ex); ex.printStackTrace(); }
	}


	public TestSampleXML() {
	}
}