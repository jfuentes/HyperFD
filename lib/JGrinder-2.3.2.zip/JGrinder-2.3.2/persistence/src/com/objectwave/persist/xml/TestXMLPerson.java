/* Copyright (C) 2001 David Hoag
 * ObjectWave Corporation
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * For a full copy of the license see:
 * http://www.opensource.org/licenses/lgpl-license.html
 */
package com.objectwave.persist.xml;
import com.objectwave.exception.*;
import com.objectwave.logging.*;

import com.objectwave.persist.*;
import com.objectwave.persist.broker.*;
import com.objectwave.persist.examples.*;
import com.objectwave.transactionalSupport.ObjectEditingView;
import java.io.File;
import java.io.FileNotFoundException;
import java.lang.reflect.Field;
import java.util.Properties;
import java.util.Vector;
/**
 *  A sample for using a XML file to read match field
 *
 * @author  Zhou Cai
 * @version  $Id: TestXMLPerson.java,v 2.4 2002/03/23 13:42:11 dave_hoag Exp $
 */
public class TestXMLPerson extends DomainObject
{
	/**
	 */
	public static Field _name;
	/**
	 */
	public static Field _phone;
	/**
	 */
	public static Field _fax;
	/**
	 */
	public static Field _title;
	/**
	 */
	public static Field _annualIncome;
	/**
	 */
	public static Field _company;
	/**
	 */
	public static Field _founderOf;

	static Vector classDescriptor;
	static String tableName;

	String name;
	String phone;
	String fax;
	String title;
	double annualIncome;
	TestXMLCompany company;
	TestXMLCompany founderOf;
	/**
	 *  Using this method to do the field match with xml file tag note:
	 *  "table.testPerson" in method means tha tag name for XML file which include
	 *  all the field match info. There are two acceptable parameters for the
	 *  initializeObjectEditor string value. One is a key that gets mapped to
	 *  system properties to an XML file, or the just the actual name of the xml
	 *  file. See the constructor of TestXMLCompany for a comparison.
	 *
	 * @exception  FileNotFoundException
	 * @exception  ConfigurationException
	 */
	public TestXMLPerson() throws FileNotFoundException, ConfigurationException
	{
		setObjectEditor(initializeObjectEditor("table.testPerson", this));
		adapt.setBrokerGeneratedPrimaryKeys(false);
	}

	/**
	 *  Sets the Company attribute of the TestXMLPerson object
	 *
	 * @param  aValue The new Company value
	 */
	public void setCompany(TestXMLCompany aValue)
	{
		editor.set(_company, aValue, company);
	}

	/**
	 *  Sets the FounderOf attribute of the TestXMLPerson object
	 *
	 * @param  aValue The new FounderOf value
	 */
	public void setFounderOf(TestXMLCompany aValue)
	{
		editor.set(_founderOf, aValue, founderOf);
	}

	/**
	 *  Sets the AnnualIncome attribute of the TestXMLPerson object
	 *
	 * @param  aValue The new AnnualIncome value
	 */
	public void setAnnualIncome(double aValue)
	{
		editor.set(_annualIncome, aValue, annualIncome);
	}

	/**
	 *  Sets the Fax attribute of the TestXMLPerson object
	 *
	 * @param  aValue The new Fax value
	 */
	public void setFax(String aValue)
	{
		editor.set(_fax, aValue, fax);
	}

	/**
	 *  Sets the Name attribute of the TestXMLPerson object
	 *
	 * @param  aValue The new Name value
	 */
	public void setName(String aValue)
	{
		editor.set(_name, aValue, name);
	}

	/**
	 *  Sets the Phone attribute of the TestXMLPerson object
	 *
	 * @param  aValue The new Phone value
	 */
	public void setPhone(String aValue)
	{
		editor.set(_phone, aValue, phone);
	}

	/**
	 *  Sets the Title attribute of the TestXMLPerson object
	 *
	 * @param  aValue The new Title value
	 */
	public void setTitle(String aValue)
	{
		editor.set(_title, aValue, title);
	}

	/**
	 *  Gets the AnnualIncome attribute of the TestXMLPerson object
	 *
	 * @return  The AnnualIncome value
	 */
	public double getAnnualIncome()
	{
		return (double) editor.get(_annualIncome, annualIncome);
	}

	/**
	 *  Gets the Fax attribute of the TestXMLPerson object
	 *
	 * @return  The Fax value
	 */
	public String getFax()
	{
		return (String) editor.get(_fax, fax);
	}

	/**
	 *  Gets the Name attribute of the TestXMLPerson object
	 *
	 * @return  The Name value
	 */
	public String getName()
	{
		return (String) editor.get(_name, name);
	}

	/**
	 *  Gets the Phone attribute of the TestXMLPerson object
	 *
	 * @return  The Phone value
	 */
	public String getPhone()
	{
		return (String) editor.get(_phone, phone);
	}

	/**
	 *  Gets the Title attribute of the TestXMLPerson object
	 *
	 * @return  The Title value
	 */
	public String getTitle()
	{
		return (String) editor.get(_title, title);
	}

	/**
	 *  Gets the Company attribute of the TestXMLPerson object
	 *
	 * @return  The Company value
	 */
	public TestXMLCompany getCompany()
	{
		return (TestXMLCompany) editor.get(_company, company);
	}

	/**
	 *  Gets the FounderOf attribute of the TestXMLPerson object
	 *
	 * @return  The FounderOf value
	 */
	public TestXMLCompany getFounderOf()
	{
		return (TestXMLCompany) editor.get(_founderOf, founderOf);
	}
	/**
	 *  Use an instance method to access a static variable. This method MUST be
	 *  duplicated in each and every subclass. This allows our generic logic in
	 *  this super class to modify static state in a subclass.
	 *
	 * @param  table The new TableName value
	 */
	protected void setTableName(final String table)
	{
		tableName = table;
	}
	/**
	 *  Use an instance method to access a static variable. This method MUST be
	 *  duplicated in each and every subclass. This allows our generic logic in
	 *  this super class to modify static state in a subclass.
	 *
	 * @param  v The new ClassDescriptor value
	 */
	protected void setClassDescriptor(final Vector v)
	{
		classDescriptor = v;
	}
	/**
	 *  Use an instance method to access a static variable. This method MUST be
	 *  duplicated in each and every subclass. This allows our generic logic in
	 *  this super class to modify static state in a subclass.
	 *
	 * @return  The TableName value
	 */
	protected String getTableName()
	{
		return tableName;
	}
	/**
	 *  Use an instance method to access a static variable. This method MUST be
	 *  duplicated in each and every subclass. This allows our generic logic in
	 *  this super class to modify static state in a subclass.
	 *
	 * @return  The ClassDescriptor value
	 */
	protected Vector getClassDescriptor()
	{
		return classDescriptor;
	}

	/**
	 * @author  dhoag
	 * @version  $Id: TestXMLPerson.java,v 2.4 2002/03/23 13:42:11 dave_hoag Exp $
	 */
	public static class Test extends com.objectwave.test.UnitTestBaseImpl
	{
//        static FileBroker defaultBroker = new FileBroker();

//        Broker broker;

		/**
		 *  initialize the environment parameters. Note: set
		 *  "ow.persistConnectionVerbose" to "true" if want to show the SQL queries
		 *  jGrinder generates when running.
		 *
		 * @param  args The command line arguments
		 */
		/*
		 *  static{
		 *  System.setProperty("ow.persistDriver", "sun.jdbc.odbc.JdbcOdbcDriver");
		 *  System.setProperty("ow.persistVerbose", "true");
		 *  System.setProperty("ow.persistConnectionVerbose","true");
		 *  System.setProperty("ow.connectUrl","jdbc:odbc:test");
		 *  System.setProperty("table.testPerson", "testPerson.xml");
		 *  System.setProperty("table.testCompany", "testCompany.xml");
		 *  System.setProperty("ow.databaseImpl", "com.objectwave.persist.broker.AccessBroker");
		 *  BrokerFactory.useDatabase();
		 *  }
		 */
		public static void main(String[] args)
		{
			com.objectwave.test.TestRunner.run(new Test(), args);
		}

		/**
		 *  The JUnit setup method
		 *
		 * @param  str The new Up value
		 * @param  context The new Up value
		 * @exception  Exception
		 */
		public void setUp(String str, com.objectwave.test.TestContext context) throws Exception
		{
			super.setUp(str, context);

			System.setProperty("ow.persistVerbose", "true");
			System.setProperty("ow.persistConnectionVerbose", "true");
			System.setProperty("table.testPerson", "testPerson.xml");
			System.setProperty("table.testCompany", "testCompany.xml");

//			com.objectwave.transactionalSupport.TransactionLog.Test.reset();
			Broker broker = new FileBroker();
			System.out.println("Using default broker of " + broker);
			BrokerFactory.setDefaultBroker(broker);
			SQLQuery.setDefaultBroker(broker);
			com.objectwave.transactionalSupport.TransactionLog.Test.reset();
		}

		/**
		 * @exception  Exception
		 */
		public void insert() throws Exception
		{
			com.objectwave.transactionalSupport.TransactionLog log = com.objectwave.transactionalSupport.TransactionLog.startTransaction("RDB", "context");
			TestXMLPerson person1 = new TestXMLPerson();
			person1.setName("three");
			person1.setTitle("asdfasd");
			person1.setPhone("9876543");
			person1.setFax("1234567");
			person1.setAnnualIncome(2342.0d);

			TestXMLPerson person2 = new TestXMLPerson();
			person2.setName("four");
			person2.setTitle("asdfasd");
			person2.setPhone("9876543");
			person2.setFax("1234567");
			person2.setAnnualIncome(2342.0d);

			TestXMLCompany cc = new TestXMLCompany();
			cc.setAddress("1131 Wacker Dr");
			cc.setName("Objectwave");

			person1.setCompany(cc);
			person2.setCompany(cc);

			person1.setFounderOf(cc);
			person2.setFounderOf(cc);

			log.commit();
		}
		/**
		 * @exception  Exception
		 */
		public void delete() throws Exception
		{
			com.objectwave.transactionalSupport.TransactionLog log = com.objectwave.transactionalSupport.TransactionLog.startTransaction("RDB", "context");

			TestXMLPerson p1 = new TestXMLPerson();
			p1.setName("four");
			SQLQuery q = new SQLQuery(p1);

			Vector v = q.find();
			System.out.println("find " + v.size() + " to be deleted");
			for(int i = 0; i < v.size(); i++)
			{
				TestXMLPerson t = (TestXMLPerson) v.elementAt(i);
				t.markForDelete();
			}
			log.commit();
		}

		/**
		 * @exception  Exception
		 */
		public void query() throws Exception
		{
			TestXMLPerson p = new TestXMLPerson();
			SQLQuery q = new SQLQuery(p);
			p.setName("three");

			Vector v = q.find();
			System.out.println("Find " + v.size() + " person");
			for(int i = 0; i < v.size(); i++)
			{
				TestXMLPerson t = (TestXMLPerson) v.elementAt(i);
				System.out.println("title =" + t.getTitle());
				System.out.println("phone=" + t.getPhone());
				System.out.println("fax =" + t.getFax());
				System.out.println("Annual Income=" + t.getAnnualIncome());
			}
		}
		/**
		 *  A unit test for JUnit
		 *
		 * @exception  Exception
		 */
		public void testInsert() throws Exception
		{
			System.out.println("verbose=" + System.getProperty("ow.persistVerbose"));
			TestXMLPerson person1 = new TestXMLPerson();
			person1.setName("three");
			person1.setTitle("asdfasd");
			person1.setPhone("9876543");
			person1.setFax("1234567");
			person1.setAnnualIncome(2342.0d);

			BrokerFactory.getDefaultBroker().save(person1);

			testContext.assertTrue("Employee not marked as saved!", person1.isRetrievedFromDatabase());
			testContext.assertTrue("PKey was not set! ", person1.getName() != null);

			TestXMLPerson search = new TestXMLPerson();
			SQLQuery query = new SQLQuery(search);

			//search.setName("three");
			search.setName("three");
			Vector result = query.find();
			testContext.assertEquals("Wrong number of persons found!", 1, result.size());
		}
		/**
		 *  The teardown method for JUnit
		 *
		 * @param  context Description of Parameter
		 */
		public void tearDown(com.objectwave.test.TestContext context)
		{
			try
			{
				TestXMLPerson person = new TestXMLPerson();
				SQLQuery pers = new SQLQuery(person);

				try
				{
					pers.deleteAll();
				}
				catch(Exception ex)
				{
					System.err.println("May have failed to clean database " + ex);
				}

				BrokerFactory.getDefaultBroker().close();
				File f = new File("testPerson.dbf");
				if(f.exists())
				{
					f.delete();
				}
			}
			catch(ConfigurationException e)
			{
				MessageLog.error(this, "Failed create persistence map from XML file", e);
				e.printStackTrace();
			}
			catch(Throwable t)
			{
				System.out.println("Failed to remove old db file " + t);
			}
			//Don't really care
		}
	}
	static
	{
		/*
		 *  NAME:fieldDefinition:
		 */
		try
		{
			_name = TestXMLPerson.class.getDeclaredField("name");
			_phone = TestXMLPerson.class.getDeclaredField("phone");
			_fax = TestXMLPerson.class.getDeclaredField("fax");
			_title = TestXMLPerson.class.getDeclaredField("title");
			_annualIncome = TestXMLPerson.class.getDeclaredField("annualIncome");
			_company = TestXMLPerson.class.getDeclaredField("company");
			_founderOf = TestXMLPerson.class.getDeclaredField("founderOf");

			// suppress access checking for these fields.
			_name.setAccessible(true);
			_phone.setAccessible(true);
			_fax.setAccessible(true);
			_title.setAccessible(true);
			_annualIncome.setAccessible(true);
			_company.setAccessible(true);
			_founderOf.setAccessible(true);
		}
		catch(NoSuchFieldException ex)
		{
			System.out.println(ex);
		}
	}
}
