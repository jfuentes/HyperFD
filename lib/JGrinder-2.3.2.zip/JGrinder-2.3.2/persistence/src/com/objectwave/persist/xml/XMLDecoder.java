package com.objectwave.persist.xml;
import com.objectwave.exception.*;
import com.objectwave.logging.*;

import com.objectwave.persist.*;
import com.objectwave.persist.constraints.*;
import com.objectwave.persist.examples.DomainObject;
import com.objectwave.persist.invert.PersistenceFactory;
import com.objectwave.transactionalSupport.*;
import com.objectwave.utility.FileFinder;
import java.lang.reflect.Field;
import java.net.URL;
import java.util.*;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.SAXNotRecognizedException;
import org.xml.sax.SAXNotSupportedException;
import org.xml.sax.SAXParseException;

import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;
/**
 *  Read the XML file to find the all the mapping information
 *
 * @author  Zhou Cai
 * @version  1.4: XMLDecoder.java,v 1.3 2001/01/26 20:57:09 dhoag Exp $
 */
public class XMLDecoder extends DefaultHandler
{

	String tableName;
	ArrayList maps;
	Class currentClass;
	ConstraintCompare collectionConstraint;

	AttributeTypeColumn fk;
	Class fkClass;

	String currCollClass;
	String currCollField;

	boolean brokerGeneratedPrimaryKeys = true;

	/**
	 *  Constructor
	 *
	 * @param  uri The XML file name
	 * @param  classInstance The class for matching Field
	 * @exception  ConfigurationException
	 */
	public XMLDecoder(String uri, Class classInstance) throws ConfigurationException
	{
		maps = new ArrayList();
		setCurrentClass(classInstance);
		parse(uri);
	}

	/**
	 *  Sets the CurrentClass attribute of the XMLDecoder object
	 *
	 * @param  classInstance The new CurrentClass value
	 */
	void setCurrentClass(Class classInstance)
	{
		currentClass = classInstance;
	}

	/**
	 *  Sets the TableName attribute of the XMLDecoder object
	 *
	 * @param  aName The new TableName value
	 */
	void setTableName(String aName)
	{
		this.tableName = aName;
	}

	/**
	 *  set the collection
	 *
	 * @param  attrs Attributes the attributes of field information
	 */
	void setCollection(Attributes attrs)
	{
		this.currCollClass = attrs.getValue("class");
		this.currCollField = attrs.getValue("field_name");
	}

	/**
	 *  Sets the Constraint attribute used in the collection. With it, one
	 *  collection could show multiple set.
	 *
	 * @param  attrs The new Constraint value
	 */
	void setConstraint(Attributes attrs)
	{
		String tableFieldName = attrs.getValue("table_field_name");
		String value = attrs.getValue("value");

		collectionConstraint = new ConstraintCompare();
		collectionConstraint.setComparison(ConstraintCompare.equalsIndex);
		collectionConstraint.setCompValue(value);
		collectionConstraint.setField(tableFieldName);
	}
	/**
	 * Try to set the parser property, but don't bomb out if we fail
	 *
	 * @param  rdr The new ParserFeature value
	 * @param  prop The new ParserFeature value
	 * @param  value The new ParserFeature value
	 */
	protected void setParserFeature(XMLReader rdr, String prop, boolean value)
	{
		try
		{
			rdr.setFeature(prop, value);
		}
		catch(SAXNotSupportedException sp)
		{
			MessageLog.debug(this, "Failed to set the sax feature - attempting to continue! " + sp);
		}
		catch(SAXNotRecognizedException re)
		{
			MessageLog.debug(this, "Failed to set the sax feature - attempting to continue! " + re);
		}
	}

	/**
	 *  Gets the TableName attribute of the XMLDecoder object
	 *
	 * @return  The TableName value
	 */
	public String getTableName()
	{
		return this.tableName;
	}

	/**
	 * @return  int
	 * @author  Steven Sinclair
	 */
	public boolean getBrokerGeneratedPrimaryKeys()
	{
		return brokerGeneratedPrimaryKeys;
	}

	/**
	 *  Gets the Maps attribute of the XMLDecoder object
	 *
	 * @return  The Maps value
	 */
	public ArrayList getMaps()
	{
		return this.maps;
	}

	/**
	 *  This method will parse a single element in an XML document. It is called
	 *  automatically by the XML Parser.
	 *
	 * @param  uri String The Namespace URI
	 * @param  local String The local name (without prefix)
	 * @param  raw String The raw XML 1.0 name (with prefix)
	 * @param  attrs Attributes The attributes attached to the element.
	 */
	public void startElement(String uri, String local, String raw, Attributes attrs)
	{
		if(local.equals("table"))
		{
			setTableName(attrs.getValue("name"));
		}
		else if(local.equals("primary"))
		{
			addPrimary(attrs);
		}
		else if(local.equals("attribute"))
		{
			addAttribute(attrs);
		}
		else if(local.equals("instance"))
		{
			addInstance(attrs);
		}
		else if(local.equals("collection"))
		{
			setCollection(attrs);
		}
		else if(local.equals("foreign"))
		{
			addForeign(attrs);
		}
		else if(local.equals("typeatt"))
		{
			addTypeatt(attrs);
		}
		else if(local.equals("constraint"))
		{
			setConstraint(attrs);
		}
		else if(local.equals("join"))
		{
			addJoin(attrs);
		}
		else
		{
			//Sometimes local is blank, and raw has the value - not sure why
			if(raw != null)
			{
				//pass null in as raw to avoid infinite recursion
				startElement(uri, raw, null, attrs);
			}
		}

	}
	/**
	 *  This method will parse the collection in an XML document. It is called
	 *  automatically by the XML Parser.
	 *
	 * @param  uri String The Namespace URI
	 * @param  local String The local name (without prefix)
	 * @param  raw String The raw XML 1.0 name (with prefix)
	 */
	public void endElement(String uri, String local, String raw)
	{
		if(raw.equals("collection"))
		{
			addCollection();
		}
	}

	/**
	 *  Parse the XML
	 *
	 * @param  uri The XML file name
	 * @exception  ConfigurationException
	 */
	void parse(String uri) throws ConfigurationException
	{
		try
		{
			XMLReader parser = SAXParserFactory.newInstance().newSAXParser().getXMLReader();
			parser.setContentHandler(this);
			parser.setErrorHandler(this);

			setParserFeature(parser, "http://xml.org/sax/features/validation", true);
			setParserFeature(parser, "http://apache.org/xml/features/continue-after-fatal-error", true);

			parser.parse(uri);
		}
		catch(Exception exception)
		{
			MessageLog.warn(this, "Failed create persistence map from XML file", exception);
			throw ExceptionBuilder.configuration("Failed create persistence map from XML file: " + exception);
		}
		if((this.currCollClass != null) || (this.currCollField != null))
		{
			throw ExceptionBuilder.configuration("Failed create correct persistence map from XML file + dangling collection details " );
		}
	}
	/**
	 *  add the primary
	 *
	 * @param  attrs Attributes the attributes of field information
	 */
	void addPrimary(Attributes attrs)
	{
		String fieldName = attrs.getValue("field_name");
		String tableFieldName = attrs.getValue("table_field_name");
		if("false".equals(attrs.getValue("sequence")))
		{
			brokerGeneratedPrimaryKeys = false;
		}
		Field f = null;
		try
		{
			f = currentClass.getDeclaredField(fieldName);
			f = (Field) f.get(null);
		}
		catch(Exception ex)
		{
			MessageLog.debug(this, "Field Not found", ex);
		}

		AttributeTypeColumn atc = new AttributeTypeColumn(tableFieldName, f, AttributeTypeColumn.PRIMARYATT);
		maps.add(atc);
	}

	/**
	 *  add the attribute
	 *
	 * @param  attrs Attributes the attributes of field information
	 */
	void addAttribute(Attributes attrs)
	{
		String fieldName = attrs.getValue("field_name");
		String tableFieldName = attrs.getValue("table_field_name");
		Field f = null;
		try
		{
			f = currentClass.getDeclaredField(fieldName);
			f = (Field) f.get(null);
		}
		catch(Exception e)
		{
			MessageLog.debug(this, "Add Attribute Incorrect", e);
		}
		AttributeTypeColumn atc = AttributeTypeColumn.getAttributeRelation(tableFieldName, f);
		maps.add(atc);
	}

	/**
	 *  add the collection
	 */
	void addCollection()
	{
		if((this.currCollClass == null) || (this.currCollField == null))
		{
			return;
		}

		Field f = null;
		Class c = null;
		try
		{
			c = forName(this.currCollClass);
			f = currentClass.getDeclaredField(this.currCollField);
			f = (Field) f.get(null);
		}
		catch(Exception e)
		{
			MessageLog.debug(this, "Add Collection incorrect", e);
		}
		AttributeTypeColumn newCollAttr = AttributeTypeColumn.getCollectionRelation(c, f);
		if(this.collectionConstraint != null)
		{
			newCollAttr.setConstraint(this.collectionConstraint);
		}
		maps.add(newCollAttr);
		this.currCollClass = null;
		this.currCollField = null;
	}
	/**
	 */
	protected Class forName( String className ) throws ClassNotFoundException
	{
		try
		{
			ClassLoader loader = Thread.currentThread().getContextClassLoader();
			if( loader == null ) return Class.forName( className); 

			return Class.forName( className, true, loader );
		}
		catch( ClassNotFoundException ex )
		{
			//Could be a dynamic persistent class
			try
			{
				if( className.endsWith( "Persistence" ) )
				{
					String newName = className.substring( 0, className.lastIndexOf( "Persistence" ) );
					//Try to get the non persistent domain object class
					Class clazz = forName( newName );

					PersistenceFactory factory = new PersistenceFactory();
					Class result = factory.getPersistentClass( clazz );
					return result;
				}
			}
			catch( ClassNotFoundException ex2 )
			{
			}
			throw ex;
		}
	}
	/**
	 *  add the foreign
	 *
	 * @param  attrs Attributes the attributes of field information
	 */
	void addForeign(Attributes attrs)
	{
		String className = attrs.getValue("class");
		String fieldName = attrs.getValue("field_name");
		String tableFieldName = attrs.getValue("table_field_name");
		String joinFieldName = attrs.getValue("join_field");
		Field f = null;
		Field joinField = null;
		try
		{
			fkClass = forName(className);
			f = currentClass.getDeclaredField(fieldName);
			f = (Field) f.get(null);
			if(joinFieldName != null && (!joinFieldName.trim().equals("")))
			{
				joinField = fkClass.getDeclaredField(joinFieldName);
				joinField = (Field) joinField.get(null);
			}
		}
		catch(Exception e)
		{
			MessageLog.debug(this, "Add Foreign Incorrect", e);
		}
		fk = AttributeTypeColumn.getForeignRelation(fkClass, tableFieldName, f);
		if(joinField != null)
		{
			fk.setJoinOn(joinField);
		}
		maps.add(fk);
	}
	/**
	 *  add the join
	 *
	 * @param  attrs Attributes the attributes of field information
	 */
	void addJoin(Attributes attrs)
	{
		String tableFieldName = attrs.getValue("table_field_name");
		String joinFieldName = attrs.getValue("join_field");

		if(tableFieldName == null || tableFieldName.trim().length() == 0)
		{
			return;
		}

		Field field = null;
		try
		{
			if(joinFieldName != null && (!joinFieldName.trim().equals("")))
			{
				field = fkClass.getDeclaredField(joinFieldName);
				field = (Field) field.get(null);
				JoinField jf = new JoinField(tableFieldName, field);
				fk.addJoinField(jf);
			}
		}
		catch(Exception e)
		{
			MessageLog.debug(this, "Add Join Incorrect", e);
		}

	}
	/**
	 *  add the instance
	 *
	 * @param  attrs Attributes the attributes of field information
	 */
	void addInstance(Attributes attrs)
	{
		String className = attrs.getValue("class");
		String fieldName = attrs.getValue("field_name");
		String tableFieldName = attrs.getValue("table_field_name");
		Field f = null;
		Class c = null;

		try
		{
			c = forName(className);
			f = currentClass.getDeclaredField(fieldName);
			f = (Field) f.get(null);
		}
		catch(Exception e)
		{
			MessageLog.debug(this, "Add Instance Incorrect", e);
		}

		if(tableFieldName == null || tableFieldName.trim().length() == 0)
		{
			maps.add(AttributeTypeColumn.getInstanceRelation(c, f));
		}
		else
		{
			maps.add(AttributeTypeColumn.getInstanceRelation(c, tableFieldName, f));
		}
	}

	/**
	 *  add the typeatt
	 *
	 * @param  attrs Attributes the attributes of field information
	 */
	void addTypeatt(Attributes attrs)
	{
		String fieldName = attrs.getValue("field_name");
		String tableFieldName = attrs.getValue("table_field_name");
		Field f = null;
		try
		{
			f = currentClass.getDeclaredField(fieldName);
			f = (Field) f.get(null);
		}
		catch(Exception e)
		{
			MessageLog.debug(this, "Add TypeAtt Incorrect", e);
		}

		AttributeTypeColumn atc = AttributeTypeColumn.getTypeAttributeRelation(tableFieldName, f);
		maps.add(atc);
	}
	/**
	 *  Unit Test
	 *
	 * @author  Zhou Cai
	 * @version  $Id: XMLDecoder.java,v 2.8 2002/08/23 21:03:03 dave_hoag Exp $
	 */
	public static class Test extends com.objectwave.test.UnitTestBaseImpl
	{
		/**
		 *  The main program for the Test class
		 *
		 * @param  args The command line arguments
		 */
		public static void main(String[] args)
		{
			com.objectwave.test.TestRunner.run(new Test(), args);
		}

		/**
		 *  A unit test for JUnit
		 *
		 * @exception  ConfigurationException
		 * @exception  java.net.MalformedURLException
		 */
		public void testSample() throws ConfigurationException, java.net.MalformedURLException
		{

			com.objectwave.persist.xml.TestSampleXML tsm = new TestSampleXML();
			Class c = tsm.getClass();

			URL url;
			url = new FileFinder().getUrl(c, "sample.xml");

			XMLDecoder xd;
			xd = new XMLDecoder(url.toString(), c);

			testContext.assertTrue("table name not corrent", (xd.getTableName().equals("tableName")));
			ArrayList maps = xd.getMaps();

			   //for (int i = 0; i < maps.size(); i++) {
			   //System.out.println( ((AttributeTypeColumn) maps.get(i) ) );
			  // }

			testContext.assertEquals("Incorrect map size!", 8, maps.size());

			AttributeTypeColumn atc = (AttributeTypeColumn) maps.get(0);
			testContext.assertTrue("1.type incorrect", (atc.getType() == AttributeTypeColumn.PRIMARYATT));

			atc = (AttributeTypeColumn) maps.get(1);
			testContext.assertTrue("2.type incorrect", (atc.getType() == AttributeTypeColumn.ATTRIBUTE));
			testContext.assertTrue("field name incorrect", atc.getField().getName().equals("fieldName_attribute"));
			testContext.assertTrue("table field name incorrect", atc.getColumnName().equals("tableFieldName_attribute"));

			atc = (AttributeTypeColumn) maps.get(4);
			testContext.assertEquals("3.type incorrect", atc.getType(), AttributeTypeColumn.FOREIGN );
			testContext.assertEquals("3.incorrect related object", atc.getRelatedType(), TestXMLPerson.class );
			testContext.assertTrue("Should not have a join on spec", atc.getJoinOn() == null);
			atc = (AttributeTypeColumn) maps.get(5);
			testContext.assertEquals("4.type incorrect", AttributeTypeColumn.FOREIGN, atc.getType());
			testContext.assertTrue("4.incorrect related object", (atc.getRelatedType() == TestXMLPerson.class));
			testContext.assertTrue("4.Should have a join on field ", atc.getJoinOn() != null);
			testContext.assertTrue("4.Should be exact instance! ", TestXMLPerson._fax == atc.getJoinOn());
		}
	}
}

