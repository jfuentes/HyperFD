/* Copyright (C) 2001 David Hoag
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * For a full copy of the license see:
 * http://www.opensource.org/licenses/lgpl-license.html
 */
package com.objectwave.persist.xml.test;
import java.util.Collection;
import java.util.Iterator;
import com.objectwave.logging.MessageLog;
import com.objectwave.persist.Broker;
import com.objectwave.persist.BrokerFactory;

import com.objectwave.persist.SQLQuery;
import com.objectwave.persist.broker.FileBroker;
import com.objectwave.persist.broker.RDBBroker;
import com.objectwave.transactionalSupport.TransactionLog;

/**
 * @author  cson
 * @version  $Id: MultiplePrimaryKeyTest.java,v 1.5 2002/03/09 17:13:47 dave_hoag Exp $
 */
public class MultiplePrimaryKeyTest extends com.objectwave.test.UnitTestBaseImpl
{

	private Person person = null;
	private PersonPhone personPhone = null;
	private Phone phone = null;
	private final static int AGE = 30;

	private final static String CONNECT_URL = "jdbc:hsqldb:.";
	private final static String EXTENSION = "8989";

	private final static String FIRST_NAME = "John";
	private final static String LAST_NAME = "Doe";
	private final static String PASSWORD = "";

	private final static String PHONE_NUMBER = "555-3030";
	private final static String PREFIX = "312";

	private final static String SQL_CREATE_PERSON =
			"CREATE TABLE person(\n" +
			" first_name  VARCHAR(40) NOT NULL,\n" +
			" last_name VARCHAR(40) NOT NULL,\n" +
			" age int,\n" +
			" PRIMARY KEY (first_name, last_name)\n" +
			")";

	private final static String SQL_CREATE_PERSON_PHONE =
			"CREATE TABLE person_phone(\n" +
			"oid INT PRIMARY KEY,\n" +
			"first_name VARCHAR(40) NOT NULL,\n" +
			"last_name VARCHAR(40) NOT NULL,\n" +
			"prefix VARCHAR(3) NOT NULL,\n" +
			"phone_number VARCHAR(7) NOT NULL,\n" +
			"FOREIGN KEY(first_name, last_name) REFERENCES person(first_name, last_name),\n" +
			"FOREIGN KEY(prefix, phone_number) REFERENCES phone(prefix, phone_number)\n" +
			")";

	private final static String SQL_CREATE_PHONE =
			"CREATE TABLE phone(\n" +
			" prefix VARCHAR(3) NOT NULL,\n" +
			" phone_number VARCHAR(8) NOT NULL,\n" +
			" extension VARCHAR(4),\n" +
			" PRIMARY KEY (prefix, phone_number)\n" +
			")";
	private final static String SQL_DROP_PERSON = "DROP TABLE person";
	private final static String SQL_DROP_PERSON_PHONE = "DROP TABLE person_phone";
	private final static String SQL_DROP_PHONE = "DROP TABLE phone";

	private final static String SQL_SEQUENCE = "CREATE TABLE sequence( nextval int PRIMARY KEY)";
	private final static String SQL_SEQUENCE_DROP = "DROP TABLE sequence";
	private final static String SQL_SEQUENCE_INIT = "INSERT INTO sequence(nextval) VALUES(1)";
	private final static String USERNAME = "sa";

	/**
	 * @param  broker
	 */
	private void buildDatabase(RDBBroker broker)
	{
		try
		{
			broker.getConnection().execSql(SQL_SEQUENCE);
			broker.getConnection().execSql(SQL_SEQUENCE_INIT);
			broker.getConnection().execSql(SQL_CREATE_PERSON);
			broker.getConnection().execSql(SQL_CREATE_PHONE);
			broker.getConnection().execSql(SQL_CREATE_PERSON_PHONE);
		}
		catch(Exception e)
		{
			MessageLog.error(this, "Failed to build database", e);
			e.printStackTrace();
		}
	}

	/**
	 * @param  broker
	 */
	private void deleteDatabase(RDBBroker broker)
	{
		try
		{
			broker.getConnection().execSql(SQL_SEQUENCE_DROP);
			broker.getConnection().execSql(SQL_DROP_PERSON);
			broker.getConnection().execSql(SQL_DROP_PHONE);
			broker.getConnection().execSql(SQL_DROP_PERSON_PHONE);
		}
		catch(Exception e)
		{
			MessageLog.error(this, "Failed to build database", e);
			e.printStackTrace();
		}
	}

	/**
	 *  A unit test for JUnit
	 *
	 * @exception  Exception
	 */
	private void populate() throws Exception
	{
		Person filler1 = new Person();
		filler1.setFirstName("fillerfirst");
		filler1.setLastName("fillerlast");
		filler1.save();

		TransactionLog log = TransactionLog.startTransaction("RDB", "context");
		person = new Person();
		person.setFirstName(FIRST_NAME);
		person.setLastName(LAST_NAME);
		person.setAge(AGE);
		phone = new Phone();
		phone.setPrefix(PREFIX);
		phone.setPhoneNumber(PHONE_NUMBER);
		phone.setExtension(EXTENSION);
		personPhone = new PersonPhone();
		personPhone.setPerson(person);
		personPhone.setPhone(phone);
		log.commit();

		Phone filler2 = new Phone();
		filler2.setPrefix("000");
		filler2.setPhoneNumber("5555555");
		filler2.save();
		PersonPhone filler3 = new PersonPhone();
		filler3.setPerson(filler1);
		filler3.setPhone(filler2);
		filler3.save();

	}

	/**
	 *  A unit test for JUnit
	 *
	 * @exception  Exception
	 */
	private void query() throws Exception
	{
		person = new Person();
		SQLQuery query = new SQLQuery(person);
		person.setFirstName(FIRST_NAME);
		person.setLastName(LAST_NAME);

		person = (Person) query.findUnique();

		testContext.assertEquals("Failed on Query", person.getAge(), AGE);
		java.util.Collection personPhones = person.getPersonPhone();
		testContext.assertTrue( "Failed to realize proxy of PersonPhone", personPhones != null  );
		testContext.assertEquals("Failed on Proxy Realization of PersonPhone", personPhones.size(), 1);
		java.util.Iterator it = personPhones.iterator();
		while(it.hasNext())
		{
			Phone phone = ((PersonPhone) it.next()).getPhone();
			testContext.assertEquals("Failed on Proxy Realization of Phone on COLLECTION relation", phone.getExtension(), EXTENSION);
		}
		personPhone = person.getPersonPhone2();
		testContext.assertTrue("Failed on Proxy Realization of Phone on INSTANCE realtion - not found ", personPhone != null);
		phone = personPhone.getPhone();
		testContext.assertEquals("Failed on Proxy Realization of Phone on INSTANCE realtion", phone.getExtension(), EXTENSION);

	}

	/**
	 *  A unit test for JUnit
	 *
	 * @exception  Exception
	 */
	private void remove() throws Exception
	{
		person = new Person();
		SQLQuery query = new SQLQuery(person);
		person.setFirstName(FIRST_NAME);
		person.setLastName(LAST_NAME);
		person = (Person) query.findUnique();
		personPhone = person.getPersonPhone2();
		phone = personPhone.getPhone();
		personPhone.delete();
		phone.delete();
		person.delete();

		person = new Person();
		query = new SQLQuery(person);
		person.setFirstName(FIRST_NAME);
		person.setLastName(LAST_NAME);
		person = (Person) query.findUnique();
		testContext.assertTrue("Failed on Remove", person == null);
	}

	/**
	 *  A unit test for JUnit
	 *
	 * @exception  Exception
	 */
	private void save() throws Exception
	{
		person = new Person();
		SQLQuery query = new SQLQuery(person);
		person.setFirstName(FIRST_NAME);
		person.setLastName(LAST_NAME);
		person = (Person) query.findUnique();
		personPhone = person.getPersonPhone2();
		phone = personPhone.getPhone();
		phone.setExtension("0909");
		phone.save();

		person = new Person();
		query = new SQLQuery(person);
		person.setFirstName(FIRST_NAME);
		person.setLastName(LAST_NAME);
		person = (Person) query.findUnique();
		phone = person.getPersonPhone2().getPhone();
		testContext.assertEquals("Failed on Update", phone.getExtension(), "0909");
	}

	/**
	 *  The teardown method for JUnit
	 *
	 * @param  context
	 * @exception  Exception
	 */
	public void tearDown(com.objectwave.test.TestContext context) throws Exception
	{
		if(BrokerFactory.getDefaultBroker() instanceof FileBroker)
		{
			MessageLog.debug(this, "Removing files!");
			removeFile("person.dbf");
			removeFile("phone.dbf");
			removeFile("person_phone.dbf");
		}
	}

	/**
	 *  Test Multiple Primary Key support in Hypersonic
	 *
	 * @exception  Exception
	 */
	public void testFileBroker() throws Exception
	{

		System.setProperty("ow.persistVerbose", "true");
		System.setProperty("ow.persistConnectionVerbose", "true");
		Broker broker = new FileBroker();
		try
		{
			BrokerFactory.setDefaultBroker(broker);
			SQLQuery.setDefaultBroker(broker);
			com.objectwave.transactionalSupport.TransactionLog.Test.reset();

			populate();
			query();
			save();
			remove();
		}
		finally
		{
			broker.close();
		}

	}

	/**
	 *  Test Multiple Primary Key support in Hypersonic
	 *
	 * @exception  Exception
	 */
	public void testHypersonic() throws Exception
	{
		System.setProperty("ow.persistVerbose", "true");
		System.setProperty("ow.persistConnectionVerbose", "true");
		System.setProperty("ow.persistUser", USERNAME);
		System.setProperty("ow.persistPassword", PASSWORD);
		System.setProperty("ow.persistDriver", "org.hsqldb.jdbcDriver");
		System.setProperty("ow.databaseImpl", "com.objectwave.persist.broker.HypersonicBroker");
		System.setProperty("ow.connectUrl", CONNECT_URL);
		System.setProperty("ow.useConnectionPool", "true");
		BrokerFactory.useDatabase();
		RDBBroker broker = new com.objectwave.persist.broker.HypersonicBroker();
		broker.initialize();
		BrokerFactory.setDefaultBroker(broker);
		SQLQuery.setDefaultBroker(broker);
		buildDatabase(broker);

		populate();
		query();
		save();
		remove();

		deleteDatabase(broker);

	}

	/**
	 *  The main program for the RDBTest class
	 *
	 * @param  args The command line arguments
	 */
	public static void main(String[] args)
	{
		com.objectwave.test.TestRunner.run(new MultiplePrimaryKeyTest(), args);
	}

}
