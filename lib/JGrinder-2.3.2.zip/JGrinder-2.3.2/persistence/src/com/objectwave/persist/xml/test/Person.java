/* Copyright (C) 2001 David Hoag
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * For a full copy of the license see:
 * http://www.opensource.org/licenses/lgpl-license.html
 */
package com.objectwave.persist.xml.test;
import java.lang.reflect.Field;
import java.util.Vector;

import com.objectwave.persist.examples.DomainObject;
/**
 *  A simple persistent object defined by the Person.xml file.
 *
 * @author  cson
 * @version  $Id: Person.java,v 1.2 2002/03/09 17:13:47 dave_hoag Exp $
 */
public class Person extends DomainObject
{
	int age;

	String firstName;
	String lastName;
	Vector personPhone;
	PersonPhone personPhone2;
	public static Field _age;
	public static Field _firstname;
	public static Field _lastname;
	public static Field _personPhone;
	public static Field _personPhone2;

	static Vector classDescriptor;
	static String tableName;

	/**
	 *  Constructor for the Person object
	 *
	 * @exception  Exception
	 */
	public Person() throws Exception
	{
		setObjectEditor(initializeObjectEditor("Person.xml", this));
	}
	/**
	 *  Gets the Age attribute of the Person object
	 *
	 * @return  The Age value
	 */
	public int getAge()
	{
		return (int) editor.get(_age, age);
	}
	/**
	 *  Use an instance method to access a static variable. This method MUST be
	 *  duplicated in each and every subclass. This allows our generic logic in
	 *  this super class to modify static state in a subclass.
	 *
	 * @return  The ClassDescriptor value
	 */
	protected Vector getClassDescriptor()
	{
		return classDescriptor;
	}

	/**
	 *  Gets the FirstName attribute of the Person object
	 *
	 * @return  The FirstName value
	 */
	public String getFirstName()
	{
		return (String) editor.get(_firstname, firstName);
	}
	/**
	 *  Gets the LastName attribute of the Person object
	 *
	 * @return  The LastName value
	 */
	public String getLastName()
	{
		return (String) editor.get(_lastname, lastName);
	}
	/**
	 *  Gets the PersonPhone attribute of the Person object
	 *
	 * @return  The PersonPhone value
	 */
	public Vector getPersonPhone()
	{
		return (Vector) editor.get(_personPhone, personPhone);
	}
	/**
	 *  Gets the PersonPhone2 attribute of the Person object
	 *
	 * @return  The PersonPhone2 value
	 */
	public PersonPhone getPersonPhone2()
	{
		return (PersonPhone) editor.get(_personPhone2, personPhone2);
	}
	/**
	 *  Use an instance method to access a static variable. This method MUST be
	 *  duplicated in each and every subclass. This allows our generic logic in
	 *  this super class to modify static state in a subclass.
	 *
	 * @return  The TableName value
	 */
	protected String getTableName()
	{
		return tableName;
	}
	/**
	 *  Sets the Age attribute of the Person object
	 *
	 * @param  aValue The new Age value
	 */
	public void setAge(int aValue)
	{
		editor.set(_age, aValue, age);
	}
	/**
	 *  Use an instance method to access a static variable. This method MUST be
	 *  duplicated in each and every subclass. This allows our generic logic in
	 *  this super class to modify static state in a subclass.
	 *
	 * @param  v The new ClassDescriptor value
	 */
	protected void setClassDescriptor(final Vector v)
	{
		classDescriptor = v;
	}
	/**
	 *  Sets the FirstName attribute of the Person object
	 *
	 * @param  aValue The new FirstName value
	 */
	public void setFirstName(String aValue)
	{
		editor.set(_firstname, aValue, firstName);
	}
	/**
	 *  Sets the LastName attribute of the Person object
	 *
	 * @param  aValue The new LastName value
	 */
	public void setLastName(String aValue)
	{
		editor.set(_lastname, aValue, lastName);
	}
	/**
	 *  Sets the PersonPhone attribute of the Person object
	 *
	 * @param  aValue The new PersonPhone value
	 */
	public void setPersonPhone(Vector aValue)
	{
		editor.set(_personPhone, aValue, personPhone);
	}
	/**
	 *  Sets the PersonPhone2 attribute of the Person object
	 *
	 * @param  aValue The new PersonPhone2 value
	 */
	public void setPersonPhone2(PersonPhone aValue)
	{
		editor.set(_personPhone2, aValue, personPhone2);
	}
	/**
	 *  Use an instance method to access a static variable. This method MUST be
	 *  duplicated in each and every subclass. This allows our generic logic in
	 *  this super class to modify static state in a subclass.
	 *
	 * @param  table The new TableName value
	 */
	protected void setTableName(final String table)
	{
		tableName = table;
	}

	/**
	 * @param  get
	 * @param  data
	 * @param  fields
	 */
	public void update(boolean get, Object[] data, Field[] fields)
	{
		for(int i = 0; i < data.length; i++)
		{
			try
			{
				if(get)
				{
					data[i] = fields[i].get(this);
				}
				else
				{
					fields[i].set(this, data[i]);
				}
			}
			catch(IllegalAccessException ex)
			{
				System.out.println(ex);
			}
		}
	}
	public static class Test extends com.objectwave.test.UnitTestBaseImpl
	{
		public void testMap() throws Exception
		{
			Person pers = new Person();
			com.objectwave.persist.mapping.RDBPersistentAdapter adapter = (com.objectwave.persist.mapping.RDBPersistentAdapter) pers.getAdapter();
			com.objectwave.persist.AttributeTypeColumn[] cols = adapter.getCollectionDescriptions();
			testContext.assertEquals("The collection cols were not defined!", 1, cols.length);
			cols = adapter.getPrimaryKeyDescriptions();
			testContext.assertEquals("The primaryKey cols were not defined!", 2, cols.length);
		}
		public static void main(String[] args)
		{
			com.objectwave.test.TestRunner.run(new Test(), args);
		}
	}

	static
	{
		try
		{
			_firstname = Person.class.getDeclaredField("firstName");
			_lastname = Person.class.getDeclaredField("lastName");
			_age = Person.class.getDeclaredField("age");
			_personPhone = Person.class.getDeclaredField("personPhone");
			_personPhone2 = Person.class.getDeclaredField("personPhone2");
		}
		catch(NoSuchFieldException ex)
		{
			System.out.println(ex);
		}
	}
}
