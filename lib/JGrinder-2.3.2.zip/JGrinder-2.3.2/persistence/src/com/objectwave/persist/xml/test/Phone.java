package com.objectwave.persist.xml.test;

import com.objectwave.persist.examples.DomainObject;
import java.lang.reflect.Field;
import java.util.Vector;

/**
 * @author  cson
 * @version  $Id: Phone.java,v 1.2 2002/03/09 17:13:47 dave_hoag Exp $
 */
public class Phone extends DomainObject
{

	/**
	 */
	public static Field _prefix;
	/**
	 */
	public static Field _phoneNumber;
	/**
	 */
	public static Field _extension;

	String prefix;
	String phoneNumber;
	String extension;

	/**
	 *Constructor for the Phone object
	 *
	 * @exception  Exception
	 */
	public Phone() throws Exception
	{
		setObjectEditor(initializeObjectEditor("Phone.xml", this));
	}

	/**
	 *Sets the Prefix attribute of the Phone object
	 *
	 * @param  aValue The new Prefix value
	 */
	public void setPrefix(String aValue)
	{
		editor.set(_prefix, aValue, prefix);
	}
	/**
	 *Sets the PhoneNumber attribute of the Phone object
	 *
	 * @param  aValue The new PhoneNumber value
	 */
	public void setPhoneNumber(String aValue)
	{
		editor.set(_phoneNumber, aValue, phoneNumber);
	}
	/**
	 *Sets the Extension attribute of the Phone object
	 *
	 * @param  aValue The new Extension value
	 */
	public void setExtension(String aValue)
	{
		editor.set(_extension, aValue, extension);
	}

	/**
	 *Gets the Prefix attribute of the Phone object
	 *
	 * @return  The Prefix value
	 */
	public String getPrefix()
	{
		return (String) editor.get(_prefix, prefix);
	}
	/**
	 *Gets the PhoneNumber attribute of the Phone object
	 *
	 * @return  The PhoneNumber value
	 */
	public String getPhoneNumber()
	{
		return (String) editor.get(_phoneNumber, phoneNumber);
	}
	/**
	 *Gets the Extension attribute of the Phone object
	 *
	 * @return  The Extension value
	 */
	public String getExtension()
	{
		return (String) editor.get(_extension, extension);
	}

	/**
	 * @param  get
	 * @param  data
	 * @param  fields
	 */
	public void update(boolean get, Object[] data, Field[] fields)
	{
		for(int i = 0; i < data.length; i++)
		{
			try
			{
				if(get)
				{
					data[i] = fields[i].get(this);
				}
				else
				{
					fields[i].set(this, data[i]);
				}
			}
			catch(IllegalAccessException ex)
			{
				System.out.println(ex);
			}
		}
	}

	static
	{
		try
		{
			_prefix = Phone.class.getDeclaredField("prefix");
			_phoneNumber = Phone.class.getDeclaredField("phoneNumber");
			_extension = Phone.class.getDeclaredField("extension");
		}
		catch(NoSuchFieldException ex)
		{
			System.out.println(ex);
			ex.printStackTrace();
		}
	}
}
