/* Copyright (C) 2001 David Hoag
 * ObjectWave Corporation
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * For a full copy of the license see:
 * http://www.opensource.org/licenses/lgpl-license.html
 */
package com.objectwave.transactSecurity;
import com.objectwave.transactionalSupport.*;

import java.lang.*;
/**
 *  Used to provide security on every business object access. This class hooks
 *  into the com.objectwave.transactionalSupport.ObjectEditor. Works like this.
 *  <l>- Create instance of this. - addObjectAccessListener to listen for
 *  activity on all objects. - addClassObjectAccessListener to listen for
 *  activity that are instances of a particular class.</l> When an access
 *  occurs, all appropriate listeners will be notified.
 *
 * @author  Dave Hoag
 * @version  $Id: AccessSecurityManager.java,v 2.0 2001/06/11 16:00:04 dave_hoag Exp $
 * @see  com.objectwave.transactionalSupport.ObjectEditor
 */
public class AccessSecurityManager implements com.objectwave.transactionalSupport.AccessSecurityIF
{
	/**
	 *  Variable holds the listeners who want to be notified of EVERY object
	 *  access.
	 */
	AccessList accessListenerList = new AccessList();
	ListenerTree accessListenerTree = new ListenerTree();
	/**
	 *  Test Routine
	 *
	 * @param  args The command line arguments
	 */
	public static void main(String[] args)
	{
		AccessSecurityManager mgr = new AccessSecurityManager();
		ObjectAccessListener list =
			new ObjectAccessListener()
			{
				/**
				 * @param  e
				 */
				public void objectAccessed(ObjectAccessEvent e)
				{
					System.out.println("MGR HERE");
				}
			};
		mgr.addClassObjectAccessListener(list, Object.class);
		mgr.addClassObjectAccessListener(list, String.class);
		list =
			new ObjectAccessListener()
			{
				/**
				 * @param  e
				 */
				public void objectAccessed(ObjectAccessEvent e)
				{
					System.out.println("HERE");
				}
			};
		mgr.addObjectAccessListener(list);
		mgr.checkWriteAccess(mgr, null);
		mgr.checkWriteAccess(new String(), null);
	}
	/**
	 *  Add a listener for access to instances of 'type'.
	 *
	 * @param  list The feature to be added to the ClassObjectAccessListener
	 *      attribute
	 * @param  type The feature to be added to the ClassObjectAccessListener
	 *      attribute
	 */
	public void addClassObjectAccessListener(final ObjectAccessListener list, final Class type)
	{
		accessListenerTree = accessListenerTree.addObjectAccessListener(type, list, accessListenerTree);
	}
	/**
	 *  Add a listener for each and every object access.
	 *
	 * @param  list The feature to be added to the ObjectAccessListener attribute
	 */
	public void addObjectAccessListener(final ObjectAccessListener list)
	{
		accessListenerList = accessListenerList.addObjectAccessListener(list);
	}
	/**
	 *  Being notified from the that someone wants to get values from the provide
	 *  parameter.
	 *
	 * @param  obj
	 * @param  f
	 * @exception  SecurityException
	 */
	public void checkReadAccess(final Object obj, final java.lang.reflect.Field f) throws SecurityException
	{
		ObjectAccessEvent evt = null;
		if(accessListenerList.needsExecution())
		{
			evt = new ObjectAccessEvent(obj, f, ObjectAccessEvent.READ);
			fireObjectAccessEvent(evt);
		}
		if(evt == null)
		{
			evt = new ObjectAccessEvent(obj, f, ObjectAccessEvent.READ);
		}
		accessListenerTree.fireObjectAccessEvent(evt);
	}
	/**
	 *  Being notified from the that someone wants to set values on the provide
	 *  parameter. Great pains are made to avoid creating any objects we won't
	 *  ultimately need.
	 *
	 * @param  obj
	 * @param  f
	 * @exception  SecurityException
	 */
	public void checkWriteAccess(final Object obj, final java.lang.reflect.Field f) throws SecurityException
	{
		ObjectAccessEvent evt = null;
		if(accessListenerList.needsExecution())
		{
			evt = new ObjectAccessEvent(obj, f, ObjectAccessEvent.WRITE);
			accessListenerList.fireObjectAccessEvent(evt);
		}
		if(accessListenerTree.needsExecution())
		{
			if(evt == null)
			{
				evt = new ObjectAccessEvent(obj, f, ObjectAccessEvent.WRITE);
			}
			accessListenerTree.fireObjectAccessEvent(evt);
		}
	}
	/**
	 *  Notify all listeners of an ObjectAccessEvent.
	 *
	 * @param  alert
	 */
	public void fireObjectAccessEvent(final ObjectAccessEvent alert)
	{
		accessListenerList.fireObjectAccessEvent(alert);
	}
	/**
	 *  Remove a listener for each and every object access.
	 *
	 * @param  list
	 */
	public void removeObjectAccessListener(final ObjectAccessListener list)
	{
		accessListenerList = accessListenerList.removeObjectAccessListener(list);
	}
	/**
	 * @author  dhoag
	 * @version  $Id: AccessSecurityManager.java,v 2.0 2001/06/11 16:00:04 dave_hoag Exp $
	 */
	private class ListenerTree
	{
		ListenerTree next = null;
		Class type = null;
		ListenerTree children = null;
		AccessList list = new AccessList();
		/**
		 * @return
		 */
		protected boolean needsExecution()
		{
			if(list.needsExecution())
			{
				return true;
			}
			if(next != null && next.needsExecution())
			{
				return true;
			}
			if(children != null && children.needsExecution())
			{
				return true;
			}
			return false;
		}
		/**
		 * @param  alert
		 * @param  source
		 */
		protected void fireObjectAccessEvent(final ObjectAccessEvent alert, final Object source)
		{
			if(type == null)
			{
				return;
			}
			if(type.isInstance(source))
			{
				list.fireObjectAccessEvent(alert);
				if(children != null)
				{
					children.fireObjectAccessEvent(alert, source);
				}
			}
			if(next != null)
			{
				next.fireObjectAccessEvent(alert, source);
			}
		}
		/**
		 * @param  alert
		 */
		protected void fireObjectAccessEvent(final ObjectAccessEvent alert)
		{
			if(type == null)
			{
				return;
			}
			Object source = alert.getSource();
			fireObjectAccessEvent(alert, source);
		}
		/**
		 *  Build a link list structure that takes into account class heirarchy. The
		 *  goal here is to visit the least amount of nodes to determine who needs to
		 *  be notified of an 'access' event.
		 *
		 * @param  objectClass The feature to be added to the ObjectAccessListener
		 *      attribute
		 * @param  listener The feature to be added to the ObjectAccessListener
		 *      attribute
		 * @param  root The feature to be added to the ObjectAccessListener attribute
		 * @return
		 */
		protected ListenerTree addObjectAccessListener(final Class objectClass, final ObjectAccessListener listener, ListenerTree root)
		{
			if(type == null)
			{
				type = objectClass;
				list = list.addObjectAccessListener(listener);
			}
			else
					if(objectClass == type)
			{
				list = list.addObjectAccessListener(listener);
			}
			else
			//is type a superClass of objectClass
			if(type.isAssignableFrom(objectClass))
			{
				if(children == null)
				{
					children = new ListenerTree();
				}
				children = children.addObjectAccessListener(objectClass, listener, children);
			}
			else
			//is objectClass is a superclass of type?
			if(objectClass.isAssignableFrom(type))
			{
				root = new ListenerTree();
				root.children = this;
				root.type = objectClass;
				root.next = this.next;
				this.next = null;
				root.list = root.list.addObjectAccessListener(listener);
			}
			else
					if(next == null)
			{
				next = new ListenerTree();
				next.type = objectClass;
				next.list = next.list.addObjectAccessListener(listener);
			}
			else
			{
				next = next.addObjectAccessListener(objectClass, listener, next);
			}

			return root;
		}
	}
	/**
	 *  An inner class that is used to provide a link list of access listeners.
	 *
	 * @author  dhoag
	 * @version  $Id: AccessSecurityManager.java,v 2.0 2001/06/11 16:00:04 dave_hoag Exp $
	 */
	private class AccessList
	{
		AccessList next = null;
		ObjectAccessListener listener = null;
		/**
		 * @return
		 */
		protected boolean needsExecution()
		{
			return next != null;
		}
		/**
		 * @param  alert
		 */
		protected void fireObjectAccessEvent(final ObjectAccessEvent alert)
		{
			SecurityException ex = null;
			//The last entry will never have a listener.
			if(needsExecution())
			{
				// Make sure all listeners have a chance to veto access.
				try
				{
					listener.objectAccessed(alert);
				}
				catch(SecurityException e)
				{
					ex = e;
				}
				next.fireObjectAccessEvent(alert);
			}
			if(ex != null)
			{
				throw ex;
			}
		}
		/**
		 * @param  list The feature to be added to the ObjectAccessListener attribute
		 * @return
		 */
		protected AccessList addObjectAccessListener(final ObjectAccessListener list)
		{
			AccessList result = new AccessList();
			result.next = this;
			result.listener = list;
			return result;
		}
		/**
		 * @param  list
		 * @return
		 */
		protected AccessList removeObjectAccessListener(final ObjectAccessListener list)
		{
			AccessList head = this;
			if(listener == list)
			{
				return next;
			}
			if(next != null)
			{
				next = next.removeObjectAccessListener(list);
			}
			return head;
		}
	}
}
