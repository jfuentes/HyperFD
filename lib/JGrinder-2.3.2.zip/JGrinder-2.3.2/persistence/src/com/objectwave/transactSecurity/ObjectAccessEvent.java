/* Copyright (C) 2001 David Hoag
 * ObjectWave Corporation
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * For a full copy of the license see:
 * http://www.opensource.org/licenses/lgpl-license.html
 */
package com.objectwave.transactSecurity;

import java.util.*;
/**
 *  Event object that represents an attempt to access data on a particular
 *  object
 *
 * @author  dhoag
 * @version  $Id: ObjectAccessEvent.java,v 2.0 2001/06/11 16:00:04 dave_hoag Exp $
 */
public class ObjectAccessEvent extends java.util.EventObject
{
	final static ObjectAccessEvent READ = new ObjectAccessEvent("READ ACCESS");
	final static ObjectAccessEvent WRITE = new ObjectAccessEvent("WRITE ACCESS");

	ObjectAccessEvent type;
	java.lang.reflect.Field field;

	/**
	 * @param  obj
	 * @param  f
	 * @param  type
	 */
	public ObjectAccessEvent(Object obj, java.lang.reflect.Field f, ObjectAccessEvent type)
	{
		super(obj);
		this.type = type;
		field = f;
	}
	/**
	 * @param  description
	 */
	private ObjectAccessEvent(String description)
	{
		super(description);
	}
}
