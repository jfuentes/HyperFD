package com.objectwave.transactionalSupport;

import java.util.Vector;
import java.lang.reflect.Field;
/**
* An example of a persistent business object that extends from TransactionalObjectAdapter.
*/
public class ExampleObject extends TransactionalObjectAdapter
{
	static Vector classDescriptor;
	String	title = null;
	String	emailAddress = null;
	long aLong;

	// See below
	static Field _title;
	static Field _emailAddress;
	static Field _aLong;
	/**
	* Define the fields that we will commonly use when updating values in this object.
	* I could have done this at run time, but it would have added substantial performance
	* issues.
	*/
	static { /*NAME:fieldDefinition:*/
		try{
			_title = ExampleObject.class.getDeclaredField("title");
			_emailAddress = ExampleObject.class.getDeclaredField("emailAddress");
			_aLong = ExampleObject.class.getDeclaredField("aLong");
		}
		catch (NoSuchFieldException ex) { System.out.println(ex); }
	}
	/**
	* Generated accessors that route get and set methods through our ObjectEditor.
	*/
	public String getEmailAddress()
	{
		return (String)editor.get(_emailAddress, emailAddress);
	}
	/**
	* Generated accessors that route get and set methods through our ObjectEditor.
	*/
	public long getALong()
	{
		return editor.get(_aLong, aLong);
	}
	/**
	* Generated accessors that route get and set methods through our ObjectEditor.
	*/
	public void setALong(long aValue)
	{
		editor.set(_aLong, aValue, aLong);
	}
	/**
	* Generated accessors that route get and set methods through our ObjectEditor.
	*/
	public String getTitle()
	{
		return (String)editor.get(_title, title);
	}
	/**
	* Generated accessors that route get and set methods through our ObjectEditor.
	*/
	public void setEmailAddress(String aValue)
	{
		editor.set(_emailAddress, aValue, emailAddress);
	}
	/**
	* Generated accessors that route get and set methods through our ObjectEditor.
	*/
	public void setTitle(String aValue)
	{
		editor.set(_title, aValue, title);
	}
	/**  This method allows me to get arounds security problems with updating
	* and object from a generic framework. This will change with the JDK1.2 version.
	*/
	public void update(boolean get, Object [] data, Field [] fields)
	{
		for(int i = 0; i < data.length; i++)
		{
			try
			{
				if(get)
					data[i] = fields[i].get(this);
				else 
				{
					fields[i].set(this, data[i]);
				}
			} catch(IllegalAccessException ex) { System.out.println(ex); }
			catch(IllegalArgumentException ex) { System.out.println(ex); }
		}
	}
	/**
	 */
	public static void main(String [] args)
	{
		int iterations = new Integer(args[0]).intValue();
		long start = System.currentTimeMillis();
		for(int i = 0; i < iterations; ++i)
		{
			TransactionLog log = TransactionLog.startTransaction("one", "-+-+-");
			ExampleObject one = new ExampleObject();
			ExampleObject two = new ExampleObject();
			ExampleObject three = new ExampleObject();
			one.setTitle("one");
			two.setTitle("one");
			three.setTitle("one");
			one.getTitle();
			two.getTitle();
			three.getTitle();
			try
			{
			log.commit();
			}
			catch (Exception e) { e.printStackTrace(); } 
			one = new ExampleObject();
			log = TransactionLog.startTransaction("one", "-+-+-");
			one.setTitle("one");
			TransactionLog subLog = TransactionLog.startTransaction("one", "-+-+-");
			
			two.setTitle("one");
			three.setTitle("one");
			one.getTitle();
			two.getTitle();
			three.getTitle();
			try{
			subLog.commit();
			}
			catch (Exception e) { e.printStackTrace(); } 
			one.getTitle();
			two.getTitle();
			three.getTitle();
			log.rollback();

			log = TransactionLog.startTransaction("one", "-+-+-");
			one.setTitle("one");
			subLog = TransactionLog.startTransaction("one", "-+-+-");
			two.setTitle("one");
			three.setTitle("one");
			one.getTitle();
			one.setTitle("twoAgain");
			one.setTitle("again");
			one.setTitle("threAgain");
			one.getTitle();
			two.getTitle();
			three.getTitle();
			subLog.rollback();
			one.getTitle();
			two.getTitle();
			three.getTitle();
			try{
			log.commit();
			}
			catch (Exception e) { e.printStackTrace(); } 
		} 
		System.out.println(System.currentTimeMillis() - start);
	} 
}