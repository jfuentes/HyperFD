package com.objectwave.transactionalSupport;
/**
 * Maintain a collection of ObjectModified objects.
 * A unique cached exists for each thread. See ExpandingObjectModifiedCache for details.
 * 
 * @author Craig Murphy 
 * @author Dave Hoag
 * @version 2.1
 * @see com.objectwave.transactionalSupport.ExpandingObjectModifiedCache
 */
public class ExpandingObjectModifiedArrayCache
{
	private ObjectModified cache[][];
	private int cacheStackPointer;
	private int currentCacheCapacity;

	static ThreadLocal threadContext = new ThreadLocal();
	static final boolean verbose = false;
	/**
	 */
	public ExpandingObjectModifiedArrayCache()
	{
		cache = new ObjectModified[ currentCacheCapacity = 32 ][];
		cacheStackPointer = -1;
	}
	/**
	 * Entry point to get objects from the cache.
	 */
	public static final ObjectModified [] getObjectModifiedFromCache()
	{
		ExpandingObjectModifiedArrayCache cacheObject =(ExpandingObjectModifiedArrayCache ) threadContext.get();
		if(cacheObject == null)
		{
			cacheObject = new ExpandingObjectModifiedArrayCache();
			threadContext.set(cacheObject);
		}
		return cacheObject.getObjectModifiedFromCacheWork();
	}
	/**
	 * Entry point to return objects to the cache.
	 */
	public final static void returnObjectModifiedToCache( final ObjectModified [] value )
	{
		ExpandingObjectModifiedArrayCache cacheObject = (ExpandingObjectModifiedArrayCache )threadContext.get();
		if(cacheObject != null)
		{
			cacheObject.returnObjectModifiedToCacheWork(value);
		}
	}
	/** 
	 * Attempt to lift an array out of the cache. If there are no elements in the array, create a new one.
	 */
	public final ObjectModified [] getObjectModifiedFromCacheWork()
	{
		if(verbose) System.out.println("get " + cacheStackPointer);
		ObjectModified [] retVal = null;
		if ( 0 <= cacheStackPointer )
		{
			retVal = cache[ cacheStackPointer ];
			cache[ cacheStackPointer-- ] = null; // Give gc a chance to work
		}
		else
		{
			retVal = new ObjectModified[35];
		}
		return retVal;
	}
	/**
	 * Cache arrays of various sizes.
	 * This method will clean the array before returning it to the cache.
	 */
	public final void returnObjectModifiedToCacheWork( final ObjectModified [] value )
	{
		//Only clean up to the first null value - This requires a knowledge of how the arrays are used
		for(int i = 0; i < value.length; ++i)
		{
			if(value[i] == null) break;
			value[i] = null;
		} 
		if(verbose) System.out.println("ret " + (cacheStackPointer + 1));

		if ( ++cacheStackPointer == currentCacheCapacity )
		{
		   int newCacheCapacity = currentCacheCapacity << 1;
		   ObjectModified newCache[][] = new ObjectModified[ newCacheCapacity ][];
		   System.arraycopy( cache,			   // Source
							 0,				   // Source position
							 newCache,			// Destination
							 0,				   // Destination position
							 currentCacheCapacity // length
							);
		  currentCacheCapacity = newCacheCapacity;
		  cache = newCache;
		}
		cache[ cacheStackPointer ] = value;
	}
/**
*/
public static void main(String [] args)
{
	ExpandingObjectModifiedArrayCache cache = new ExpandingObjectModifiedArrayCache();
	ObjectModified[] one = cache.getObjectModifiedFromCache();
	ObjectModified[] two  = cache.getObjectModifiedFromCache();
	ObjectModified aOne = new ObjectModified();
	ObjectModified aTwo = new ObjectModified();
	one[0] = aOne;
	two[1] = aTwo;
	cache.returnObjectModifiedToCache(one);
	cache.returnObjectModifiedToCache(two);
	two  = cache.getObjectModifiedFromCache();
	System.out.println(two[1] == aTwo);
	one = cache.getObjectModifiedFromCache();
	System.out.println(one[0] == aOne);
} 
}
