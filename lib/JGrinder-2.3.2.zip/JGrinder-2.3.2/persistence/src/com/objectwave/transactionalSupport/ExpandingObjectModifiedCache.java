package com.objectwave.transactionalSupport;
/**
 * Maintain a collection of ObjectModified objects.
 * There is a cache per thread. This elminates the need to have synchronized checkin
 * and check out for getting and returning cached objects.
 * Of course, this could pose a problem if one thread checks out objects, and the other
 * returns objects. If that is your situation, an instance of this class must be managed
 * by your application and not via the static methods in this class.
 * 
 * @author Craig Murphy 
 * @author Dave Hoag
 * @version 1.1
 */
public class ExpandingObjectModifiedCache
{
	private ObjectModified cache[];
	private int cacheStackPointer;
	private int currentCacheCapacity;
	private static ThreadLocal threadContext = new ThreadLocal();
	static final boolean verbose = false;
	/**
	 * Initialize this instance to be ready to cache Objects.
	 */
	public ExpandingObjectModifiedCache()
	{
		cache = new ObjectModified[ currentCacheCapacity = 32 ];
		cacheStackPointer = -1;
	}
	/**
	 * The entry point to the instance related to the current thread, and to get the cached object.
	 */
	public static ObjectModified getObjectModifiedFromCache()
	{
		ExpandingObjectModifiedCache cacheObject = (ExpandingObjectModifiedCache) threadContext.get();
		if(cacheObject == null)
		{
			cacheObject = new ExpandingObjectModifiedCache();
			threadContext.set(cacheObject);
		}

		return cacheObject.getObjectModifiedFromCacheWork();
	}
	/**
	 * The intended entry point for returning instances.
	 */
	public static final void returnObjectModifiedToCache(final ObjectModified value )
	{
		ExpandingObjectModifiedCache cacheObject = (ExpandingObjectModifiedCache) threadContext.get();
		if(cacheObject == null) return;
		cacheObject.returnObjectModifiedToCacheWork(value);
	}
	/**
	 * Get the cached object from this instance of ExpandingObjectModifiedCache.
	 * @retrun ObjectModified A token that keeps track of changes to an object
	 */
	public ObjectModified getObjectModifiedFromCacheWork()
	{
		if(verbose) System.out.println("get " + cacheStackPointer);
		ObjectModified retVal = null;
		if ( 0 <= cacheStackPointer )
		{
			retVal = cache[ cacheStackPointer ];
			cache[ cacheStackPointer-- ] = null; // Give gc a chance to work
		}
		else
		{
			retVal = new ObjectModified();
		}
		return retVal;
	}
	/**
	 * Return a checked out instance to this cache.
	 * @param value ObjectModifed - Hopefully and instance that was obtained via the getObjectModifiedCacheWork method.
	 */
	public void returnObjectModifiedToCacheWork( final ObjectModified value )
	{
		if(verbose) System.out.println("ret " + (cacheStackPointer + 1));

		if ( ++cacheStackPointer == currentCacheCapacity )
		{
		   int newCacheCapacity = currentCacheCapacity << 1;
		   ObjectModified newCache[] = new ObjectModified[ newCacheCapacity ];
		   System.arraycopy( cache,			   // Source
							 0,				   // Source position
							 newCache,			// Destination
							 0,				   // Destination position
							 currentCacheCapacity // length
							);
		  currentCacheCapacity = newCacheCapacity;
		  cache = newCache;
		}
		cache[ cacheStackPointer ] = value;
	}
}
