/*
 *  Copyright (C) 2001 David Hoag
 *  ObjectWave Corporation
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *  For a full copy of the license see:
 *  http://www.opensource.org/licenses/lgpl-license.html
 */
package com.objectwave.transactionalSupport;
import java.beans.*;
import java.io.Serializable;
import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.util.*;
/**
 *  Tracks changes to a TransactionalObjectIF. If you wish to see verbose output
 *  of the NoFieldObjectEditor, start your application ow.objectEditVerbose=true
 *
 * @author  dhoag
 * @version  $Id: NoFieldObjectEditor.java,v 1.1 2002/02/01 21:46:40 dave_hoag Exp $
 * @see  com.objectwave.transactionalSupport.ObjectEditingView
 */
public class NoFieldObjectEditor implements Serializable, ObjectEditingView
{
	boolean verbose = true;

	/**
	 */
	boolean isTransient;
	transient TransactionLog singleLog;
	transient NoFieldObjectModified[] fieldToChangeMap;
	transient HashMap objectMods;
	TransactionalObjectIF domainObject;

	// These object are for the support of pessimistic locking.
	transient Object syncObject;
	transient Thread lockedBy;
	transient int refCount;
	Object[] data;
	/**
	 *  Constructor for the NoFieldObjectEditor object
	 */
	public NoFieldObjectEditor()
	{
	}
	/**
	 *  Manage the changes for the transactional domainObject. Every instance of
	 *  NoFieldObjectEditor is responsible for only one TransactionalObjectIF.
	 *
	 * @param  domainObject
	 */
	public NoFieldObjectEditor(TransactionalObjectIF domainObject)
	{
		this.domainObject = domainObject;
	}
	/**
	 *  Search the provided list of changes for change to the particular field.
	 *  While this is indeed a linear search, it beats the pants off performance
	 *  wise on a HashMap lookup (since the lists are always small).
	 *
	 * @param  list NoFieldObjectModified [] A list of changes.
	 * @param  field The field for which we are looking for changes.
	 * @return  The Mods value
	 */
	protected final static NoFieldObjectModified getMods(final int field, final NoFieldObjectModified[] list)
	{
		if(list != null)
		{
			return list[field];
		}
		return null;
	}
	/**
	 *Sets the Field attribute of the NoFieldObjectEditor object
	 *
	 * @param  idx The new Field value
	 * @param  value The new Field value
	 */
	protected void setField(int idx, Object value)
	{
		data[idx] = value;
	}
	/**
	 *  Delegate to the set(int, Object, Object) method.
	 *
	 * @param  adapt
	 * @param  val
	 * @param  originalVal
	 */
	public void set(int adapt, byte val, byte originalVal)
	{
		if(val == originalVal)
		{
			Object values = new Byte(val);
			setValue(adapt, values, values);
		}
		else
		{
			setValue(adapt, new Byte(val), new Byte(originalVal));
		}
	}
	/**
	 *  Delegate to the set(int, Object, Object) method.
	 *
	 * @param  adapt
	 * @param  val
	 * @param  originalVal
	 */
	public void set(int adapt, char val, char originalVal)
	{
		if(val == originalVal)
		{
			Object values = new Character(val);
			setValue(adapt, values, values);
		}
		else
		{
			setValue(adapt, new Character(val), new Character(originalVal));
		}
	}
	/**
	 *  Delegate to the set(int, Object, Object) method.
	 *
	 * @param  adapt
	 * @param  val
	 * @param  originalVal
	 */
	public void set(int adapt, double val, double originalVal)
	{
		if(val == originalVal)
		{
			Object values = new Double(val);
			setValue(adapt, values, values);
		}
		else
		{
			setValue(adapt, new Double(val), new Double(originalVal));
		}
	}
	/**
	 *  Delegate to the set(int, Object, Object) method.
	 *
	 * @param  adapt
	 * @param  val
	 * @param  originalVal
	 */
	public void set(int adapt, float val, float originalVal)
	{
		if(val == originalVal)
		{
			Object values = new Float(val);
			setValue(adapt, values, values);
		}
		else
		{
			setValue(adapt, new Float(val), new Float(originalVal));
		}
	}
	/**
	 *  Delegate to the set(int, Object, Object) method.
	 *
	 * @param  adapt
	 * @param  val
	 * @param  originalVal
	 */
	public void set(int adapt, int val, int originalVal)
	{
		if(val == originalVal)
		{
			Object values = new Integer(val);
			setValue(adapt, values, values);
		}
		else
		{
			setValue(adapt, new Integer(val), new Integer(originalVal));
		}
	}
	/**
	 *  Delegate to the set(int, Object, Object) method.
	 *
	 * @param  adapt
	 * @param  val
	 * @param  originalVal
	 */
	public void set(int adapt, long val, long originalVal)
	{
		if(val == originalVal)
		{
			Object values = new Long(val);
			setValue(adapt, values, values);
		}
		else
		{
			setValue(adapt, new Long(val), new Long(originalVal));
		}
	}
	/**
	 *  Delegate to the setValue(int, Object, Object) method.
	 *
	 * @param  adapt
	 * @param  val
	 * @param  originalVal
	 * @see  #setValue(java.lang.int, java.lang.Object, java.lang.Object)
	 */
	public void set(final int adapt, final Object val, final Object originalVal)
	{
		setValue(adapt, val, originalVal);
	}
	/**
	 *  Delegate to the set(int, Object, Object) method.
	 *
	 * @param  adapt
	 * @param  val
	 * @param  originalVal
	 */
	public void set(final int adapt, final String val, final String originalVal)
	{
		if((val != null) && (val == originalVal || val.equals(originalVal)))
		{
			setValue(adapt, originalVal, originalVal);
		}
		else
		{
			setValue(adapt, val, originalVal);
		}
	}
	/**
	 *  Delegate to the set(int, Object, Object) method.
	 *
	 * @param  adapt
	 * @param  val
	 * @param  originalVal
	 */
	public void set(final int adapt, final Date val, final Date originalVal)
	{
		if((val != null) && (val.equals(originalVal)))
		{
			setValue(adapt, originalVal, originalVal);
		}
		else
		{
			setValue(adapt, val, originalVal);
		}
	}
	/**
	 *  Delegate to the set(int, Object, Object) method.
	 *
	 * @param  adapt
	 * @param  val
	 * @param  originalVal
	 */
	public void set(int adapt, short val, short originalVal)
	{
		if(val == originalVal)
		{
			Object values = new Short(val);
			setValue(adapt, values, values);
		}
		else
		{
			setValue(adapt, new Short(val), new Short(originalVal));
		}
	}
	/**
	 *  Delegate to the set(int, Object, Object) method.
	 *
	 * @param  adapt
	 * @param  val
	 * @param  originalVal
	 */
	public void set(int adapt, boolean val, boolean originalVal)
	{
		if(val == originalVal)
		{
			Object values = new Boolean(val);
			setValue(adapt, values, values);
		}
		else
		{
			setValue(adapt, new Boolean(val), new Boolean(originalVal));
		}
	}
	/**
	 *  A transient object. We do not keep track of changes for 'transient'
	 *  objects. Perhaps 'transient' is an incorrect term.
	 *
	 * @param  value The new AsTransient value
	 */
	public void setAsTransient(boolean value)
	{
		isTransient = value;
	}
	/**
	 *  The main workhorse method for all of the set methods.
	 *
	 * @param  adapt The new Value value
	 * @param  val The new Value value
	 * @param  originalVal The new Value value
	 */
	protected void setValue(final int adapt, final Object val, final Object originalVal)
	{
		TransactionLog log = TransactionLog.getCurrentInstance();

		waitForLock();

		if(verbose)
		{
			System.out.print("Setting field " + adapt + " to " + val + " on ");
			if(isTransient)
			{
				System.out.print("transient ");
			}
			System.out.println(domainObject.getClass().getName() + '@' + domainObject.hashCode());
		}

		if((log == null) || (isTransient))
		{
			setField(adapt, val);
		}
		/*
		 *  else if((val == null) && (originalVal == null))
		 *  {
		 *  clearOutUncommitedChanges(log, adapt);
		 *  return;
		 *  }
		 *  else if(val == originalVal)
		 *  {
		 *  clearOutUncommitedChanges(log, adapt);
		 *  return;
		 *  }
		 */
		else
		{
			Class type = null;
			if(val != null)
			{
				type = val.getClass();
			}
			else
			{
				type = originalVal.getClass();
			}

			NoFieldObjectModified mod = new NoFieldObjectModified();
			mod.initObjectModified(this, adapt, domainObject, val, originalVal, type);
			markChange(mod, log);
		}
	}
	/**
	 * @param  adapt
	 * @param  val
	 * @param  originalVal
	 */
	public void set(Field adapt, byte val, byte originalVal)
	{
	}
	/**
	 * @param  adapt
	 * @param  val
	 * @param  originalVal
	 */
	public void set(Field adapt, char val, char originalVal)
	{
	}
	/**
	 * @param  adapt
	 * @param  val
	 * @param  originalVal
	 */
	public void set(Field adapt, double val, double originalVal)
	{
	}
	/**
	 * @param  adapt
	 * @param  val
	 * @param  originalVal
	 */
	public void set(Field adapt, float val, float originalVal)
	{
	}
	/**
	 * @param  adapt
	 * @param  val
	 * @param  originalVal
	 */
	public void set(Field adapt, int val, int originalVal)
	{
	}
	/**
	 * @param  adapt
	 * @param  val
	 * @param  originalVal
	 */
	public void set(Field adapt, long val, long originalVal)
	{
	}
	/**
	 * @param  adapt
	 * @param  val
	 * @param  originalVal
	 */
	public void set(final Field adapt, final Object val, final Object originalVal)
	{
	}
	/**
	 * @param  adapt
	 * @param  val
	 * @param  originalVal
	 */
	public void set(Field adapt, String val, String originalVal)
	{
	}
	/**
	 * @param  adapt
	 * @param  val
	 * @param  originalVal
	 */
	public void set(Field adapt, Date val, Date originalVal)
	{
	}
	/**
	 * @param  adapt
	 * @param  val
	 * @param  originalVal
	 */
	public void set(Field adapt, short val, short originalVal)
	{
	}
	/**
	 * @param  adapt
	 * @param  val
	 * @param  originalVal
	 */
	public void set(Field adapt, boolean val, boolean originalVal)
	{
	}
	/**
	 *Gets the Field attribute of the NoFieldObjectEditor object
	 *
	 * @param  idx
	 * @return  The Field value
	 */
	protected Object getField(int idx)
	{
		return data[idx];
	}
	/**
	 * @param  adapt
	 * @param  val
	 * @return
	 */
	public byte get(int adapt, byte val)
	{
		TransactionLog log = TransactionLog.getCurrentInstance();

		if((log == null) || (isTransient) || !containsAnyChanges())
		{
			return val;
		}
		//The value passed in as the old value is indeed the correct value.

		while(log != null)
		{
			NoFieldObjectModified[] list = getFieldMap(log);
			if(list != null)
			{
				NoFieldObjectModified obj = getMods(adapt, list);
				if(obj != null)
				{
					return ((Byte) obj.currentValue()).byteValue();
				}
			}
			log = log.getParentTransaction();
		}

		return val;
	}
	/**
	 * @param  adapt
	 * @param  val
	 * @return
	 */
	public char get(int adapt, char val)
	{
		TransactionLog log = TransactionLog.getCurrentInstance();

		if((log == null) || (isTransient) || !containsAnyChanges())
		{
			return val;
		}
		//The value passed in as the old value is indeed the correct value.

		while(log != null)
		{
			NoFieldObjectModified[] list = getFieldMap(log);
			if(list != null)
			{
				NoFieldObjectModified obj = getMods(adapt, list);
				if(obj != null)
				{
					return ((Character) obj.currentValue()).charValue();
				}
			}
			log = log.getParentTransaction();
		}

		return val;
	}
	/**
	 * @param  adapt
	 * @param  val
	 * @return
	 */
	public double get(int adapt, double val)
	{
		TransactionLog log = TransactionLog.getCurrentInstance();

		if((log == null) || (isTransient) || !containsAnyChanges())
		{
			return val;
		}
		//The value passed in as the old value is indeed the correct value.

		while(log != null)
		{
			NoFieldObjectModified[] list = getFieldMap(log);
			if(list != null)
			{
				NoFieldObjectModified obj = getMods(adapt, list);
				if(obj != null)
				{
					return ((Double) obj.currentValue()).doubleValue();
				}
			}
			log = log.getParentTransaction();
		}

		return val;
	}
	/**
	 * @param  adapt
	 * @param  val
	 * @return
	 */
	public float get(int adapt, final float val)
	{
		TransactionLog log = TransactionLog.getCurrentInstance();

		if((log == null) || (isTransient) || !containsAnyChanges())
		{
			return val;
		}
		//The value passed in as the old value is indeed the correct value.

		while(log != null)
		{
			NoFieldObjectModified[] list = getFieldMap(log);
			if(list != null)
			{
				NoFieldObjectModified obj = getMods(adapt, list);
				if(obj != null)
				{
					return ((Float) obj.currentValue()).floatValue();
				}
			}
			log = log.getParentTransaction();
		}

		return val;
	}
	/**
	 *  No longer uses the convience method. This must be as fast as possible.
	 *
	 * @param  adapt
	 * @param  oldValue
	 * @return
	 */
	public int get(final int adapt, final int oldValue)
	{
		TransactionLog log = TransactionLog.getCurrentInstance();

		if((log == null) || (isTransient) || !containsAnyChanges())
		{
			return oldValue;
		}
		//The value passed in as the old value is indeed the correct value.

		while(log != null)
		{
			NoFieldObjectModified[] list = getFieldMap(log);
			if(list != null)
			{
				NoFieldObjectModified obj = getMods(adapt, list);
				if(obj != null)
				{
					return ((Integer) obj.currentValue()).intValue();
				}
			}
			log = log.getParentTransaction();
		}

		return oldValue;
	}
	/**
	 * @param  adapt
	 * @param  val
	 * @return
	 */
	public long get(int adapt, long val)
	{
		TransactionLog log = TransactionLog.getCurrentInstance();

		if((log == null) || (isTransient) || !containsAnyChanges())
		{
			return val;
		}
		//The value passed in as the old value is indeed the correct value.

		while(log != null)
		{
			NoFieldObjectModified[] list = getFieldMap(log);
			if(list != null)
			{
				NoFieldObjectModified obj = getMods(adapt, list);
				if(obj != null)
				{
					return ((Long) obj.currentValue()).longValue();
				}
			}
			log = log.getParentTransaction();
		}

		return val;
	}
	/**
	 * @param  adapt
	 * @param  oldValue
	 * @return
	 */
	public Object get(final int adapt, final Object oldValue)
	{
		TransactionLog log = TransactionLog.getCurrentInstance();

		//Do not include objectMods in this comparison. Vector, Array, and HashMap screw this up.
		if((log == null) || (isTransient))
		{
			return oldValue;
		}
		//The value passed in as the old value is indeed the correct value.

		return getValue(adapt, oldValue, log);
	}
	/**
	 * @param  adapt
	 * @param  val
	 * @return
	 */
	public short get(int adapt, short val)
	{
		TransactionLog log = TransactionLog.getCurrentInstance();

		if((log == null) || (isTransient) || !containsAnyChanges())
		{
			return val;
		}
		//The value passed in as the old value is indeed the correct value.

		while(log != null)
		{
			NoFieldObjectModified[] list = getFieldMap(log);
			if(list != null)
			{
				NoFieldObjectModified obj = getMods(adapt, list);
				if(obj != null)
				{
					return ((Short) obj.currentValue()).shortValue();
				}
			}
			log = log.getParentTransaction();
		}

		return val;
	}
	/**
	 * @param  adapt
	 * @param  val
	 * @return
	 */
	public String get(int adapt, String val)
	{
		TransactionLog log = TransactionLog.getCurrentInstance();

		if((log == null) || (isTransient) || !containsAnyChanges())
		{
			return val;
		}
		//The value passed in as the old value is indeed the correct value.

		while(log != null)
		{
			NoFieldObjectModified[] list = getFieldMap(log);
			if(list != null)
			{
				NoFieldObjectModified obj = getMods(adapt, list);
				if(obj != null)
				{
					return (String) obj.currentValue();
				}
			}
			log = log.getParentTransaction();
		}

		return val;
	}
	/**
	 * @param  adapt
	 * @param  val
	 * @return
	 */
	public boolean get(int adapt, boolean val)
	{
		TransactionLog log = TransactionLog.getCurrentInstance();

		if((log == null) || (isTransient) || !containsAnyChanges())
		{
			return val;
		}
		//The value passed in as the old value is indeed the correct value.

		while(log != null)
		{
			NoFieldObjectModified[] list = getFieldMap(log);
			if(list != null)
			{
				NoFieldObjectModified obj = getMods(adapt, list);
				if(obj != null)
				{
					return ((Boolean) obj.currentValue()).booleanValue();
				}
			}
			log = log.getParentTransaction();
		}

		return val;
	}
	/**
	 * @param  log TransactionLog The current transaction context
	 * @return  Vector of ObjectChangeRequests that represent collection changes.
	 */
	public Vector getCollectionChanges(final TransactionLog log)
	{
		Vector result = new Vector();
		NoFieldObjectModified[] iterator = getFieldMap(log);
		if(iterator != null)
		{
			for(int i = 0; i < iterator.length; ++i)
			{
				NoFieldObjectModified req = iterator[i];
				if(req != null && req.isCollection())
				{
					result.addElement(req);
				}
			}
		}
		return result;
	}
	/**
	 * @return  The DomainObject value
	 */
	public TransactionalObjectIF getDomainObject()
	{
		return domainObject;
	}
	/**
	 *  If we have any changes in the current transaction log, return true;
	 *
	 * @return  boolean Indicating one of the following:
	 *  <li> There is no current transaction.</li>
	 *  <li> The current object is transient</li>
	 *  <li> There is a transaction and the current object is not transient and
	 *  there are changes to the object.</li>
	 */
	public boolean isDirty()
	{
		TransactionLog log = TransactionLog.getCurrentInstance();
		if((log == null) || (isTransient))
		{
			return true;
		}
		if(objectMods == null && singleLog == null)
		{
			return false;
		}
		NoFieldObjectModified[] list = getFieldMap(log);
		if(list == null)
		{
			return false;
		}
		boolean change = false;
		for(int i = 0; i < list.length; ++i)
		{
			if(list[i] != null)
			{
				change = true;
				break;
			}
		}
		return change;
	}
	/**
	 *  A transient object. We do not keep track of changes for 'transient'
	 *  objects. Perhaps 'transient' is an incorrect term.
	 *
	 * @return  The Transient value
	 */
	public boolean isTransient()
	{
		return isTransient;
	}
	/**
	 *  For the provided TransactionLog, get the list of known changes.
	 *
	 * @param  log TransactionLog The transaction in question.
	 * @return  NoFieldObjectModified [] The holder of the changes. The first null value
	 *  is the end of the change list.
	 */
	protected final synchronized NoFieldObjectModified[] getFieldMap(final TransactionLog log)
	{
		if(log == singleLog)
		{
			return fieldToChangeMap;
		}
		if(objectMods == null)
		{
			return null;
		}
		NoFieldObjectModified[] lastFieldMap = (NoFieldObjectModified[]) objectMods.get(log);
		return lastFieldMap;
	}
	/**
	 *  The main workhorse method for all of the get methods.
	 *
	 * @param  log TransactionLog The current transaction context
	 * @param  adapt
	 * @param  oldValue
	 * @return  Object The transactionally accurate value of the field 'adapt'.
	 */
	protected Object getValue(final int adapt, final Object oldValue, TransactionLog log)
	{
		if(verbose)
		{
			System.out.print("getting " + adapt + " from " + log + " " + Thread.currentThread());
			if(isTransient)
			{
				System.out.print(" is transient ");
			}
			System.out.println(domainObject.getClass().getName() + '@' + domainObject.hashCode());
		}
		final boolean hasPotentialMods = (objectMods != null || singleLog != null);
		//Object mods may be null if the field is a Vector, Array, or HashMap.
		//We still want to go through this method to handle that situation.
		if(hasPotentialMods)
		{
			while(log != null)
			{
				NoFieldObjectModified[] list = getFieldMap(log);
				if(list != null)
				{
					NoFieldObjectModified obj = getMods(adapt, list);
					if(obj != null)
					{
						return obj.currentValue();
					}
				}
				log = log.getParentTransaction();
			}
		}
		//If we reach here, no current value has been found.
		if(oldValue == null)
		{
			return null;
		}

		final Object newVal = perhapsCloneCollection(adapt, oldValue);
		//newVal will be null if the object is not a collection.
		if(newVal != null)
		{
			return newVal;
		}

		//Finally, look in the object for the object value
//		return getDomainField(adapt);  - The old value is the value in the object
		return oldValue;
	}
	/**
	 *  Used to lazily initialize the syncObject. ex. if(syncObject == null)
	 *  syncObject = getSyncObject();
	 *
	 * @return  The SyncObject value
	 */
	private synchronized Object getSyncObject()
	{
		if(syncObject != null)
		{
			return syncObject;
		}
		syncObject = new Object();
		return syncObject;
	}
	/**
	 * @param  adapt
	 * @param  val
	 * @return
	 */
	public byte get(Field adapt, byte val)
	{
		return 0;
	}
	/**
	 * @param  adapt
	 * @param  val
	 * @return
	 */
	public char get(Field adapt, char val)
	{
		return ' ';
	}
	/**
	 * @param  adapt
	 * @param  val
	 * @return
	 */
	public double get(Field adapt, double val)
	{
		return 0d;
	}
	/**
	 * @param  adapt
	 * @param  val
	 * @return
	 */
	public float get(Field adapt, float val)
	{
		return 0f;
	}
	/**
	 * @param  adapt
	 * @param  oldValue
	 * @return
	 */
	public int get(Field adapt, int oldValue)
	{
		return 0;
	}
	/**
	 * @param  adapt
	 * @param  val
	 * @return
	 */
	public long get(Field adapt, long val)
	{
		return 0l;
	}
	/**
	 * @param  adapt
	 * @param  oldValue
	 * @return
	 */
	public Object get(final Field adapt, final Object oldValue)
	{
		return null;
	}
	/**
	 * @param  adapt
	 * @param  val
	 * @return
	 */
	public short get(Field adapt, short val)
	{
		return 0;
	}
	/**
	 * @param  adapt
	 * @param  val
	 * @return
	 */
	public boolean get(Field adapt, boolean val)
	{
		return false;
	}
	/**
	 * @param  size
	 */
	public void initFieldSize(int size)
	{
		data = new Object[size];
	}
	/**
	 *  Drop any changes associated with a specified transaction log. This is a
	 *  dangerous move. Avoid doing this. Public only because of the interface.
	 *
	 * @param  log TransactionLog The transaction in question.
	 */
	public synchronized void clearChanges(final TransactionLog log)
	{
		clearChanges(log, true);
	}
	/**
	 *  In the event that we call setValue(aVal) to change an object. And then we
	 *  call setValue(aVal) to restore that object to the originalValue then we
	 *  want to toss the old Object Mods.
	 *
	 * @param  log TransactionLog The current transaction context
	 * @param  force
	 * @exception  UpdateException
	 * @fixme  Still under construction private synchronized void
	 *  clearOutUncommitedChanges(TransactionLog log, final int field) {
	 *  Clear out any previous, and uncommited, changes. while(log != null &&
	 *  (! noKnownLogs())) { NoFieldObjectModified [] list = getFieldMap(log); if(list
	 *  != null) { NoFieldObjectModified obj = null; int i = 0; for(; i < list.length;
	 *  ++i) { if(list[i] != null && list[i].getAccessor() == field) { obj =
	 *  list[i]; break; } } if(obj != null) { if(i == 0 && there are no other
	 *  changes ) { clearChanges(log); return; } list[i] = null; return; } }
	 *  I'm not so sure this is correct. Why do I want to remove changes from
	 *  parent transactions? log = log.getParentTransaction(); On 6/9/98 I
	 *  added the following line. log = null; } }
	 */
	/**
	 *  In the event that we call setValue(aVal) to change an object. And then we
	 *  call setValue(aVal) to restore that object to the originalValue then we
	 *  want to toss the old Object Mods.
	 *
	 *  In the event that we call setValue(aVal) to change an object. And then we
	 *  call setValue(aVal) to restore that object to the originalValue then we
	 *  want to toss the old Object Mods.
	 *
	 *  In the event that we call setValue(aVal) to change an object. And then we
	 *  call setValue(aVal) to restore that object to the originalValue then we
	 *  want to toss the old Object Mods.
	 *
	 *  In the event that we call setValue(aVal) to change an object. And then we
	 *  call setValue(aVal) to restore that object to the originalValue then we
	 *  want to toss the old Object Mods.
	 *
	 *  In the event that we call setValue(aVal) to change an object. And then we
	 *  call setValue(aVal) to restore that object to the originalValue then we
	 *  want to toss the old Object Mods.
	 *
	 *  In the event that we call setValue(aVal) to change an object. And then we
	 *  call setValue(aVal) to restore that object to the originalValue then we
	 *  want to toss the old Object Mods. In the event that we call setValue(aVal)
	 *  to change an object. And then we call setValue(aVal) to restore that object
	 *  to the originalValue then we want to toss the old Object Mods. In the event
	 *  that we call setValue(aVal) to change an object. And then we call
	 *  setValue(aVal) to restore that object to the originalValue then we want to
	 *  toss the old Object Mods. Commit every change request for the specified
	 *  transaction log. This will actually put the values into the Objects.
	 *
	 * @param  log TransactionLog The current transaction context
	 * @param  force
	 * @exception  UpdateException
	 */
	public synchronized void commit(final TransactionLog log, final boolean force) throws UpdateException
	{
		NoFieldObjectModified[] iterator = getFieldMap(log);
		if(verbose)
		{
			System.out.println("Commiting " + this + " getDomain " + getDomainObject().getClass().getName() + '@' + getDomainObject().hashCode());
		}
		if(iterator != null)
		{
			for(int i = 0; i < iterator.length; ++i)
			{
				NoFieldObjectModified req = iterator[i];
				if(req != null)
				{
					if(verbose)
					{
						System.out.println("\t" + req.adapter + " value: " + req.currentValue());
						System.out.println("\tChange domain " + req.domainObject.getClass().getName() + '@' + req.domainObject.hashCode());
						try
						{
							req.commit(force);
						}
						catch(UpdateException ex)
						{
							System.out.println("### - Commit failed " + ex);
							throw ex;
						}
					}
					else
					{
						req.commit(force);
					}
				}
				else
				{
					//we are done at the first null

					return;
				}
			}
		}
	}
	/**
	 *  Are there ANY changes for ANY transaction log for this object.
	 *
	 * @return
	 */
	public final boolean containsAnyChanges()
	{
		if(singleLog != null)
		{
			return true;
		}
		return (objectMods != null && objectMods.size() != 0);
	}
	/**
	 *  If we have any changes which are not the result of a collection change,
	 *  return true. Similar to isDirty, but only ignores collection changes.
	 *
	 * @param  log TransactionLog The current transaction context
	 * @return
	 * @see  #isDirty
	 */
	public boolean containsAttributeChanges(final TransactionLog log)
	{
		NoFieldObjectModified[] iterator = getFieldMap(log);
		if(iterator != null)
		{
			for(int i = 0; i < iterator.length; ++i)
			{
				NoFieldObjectModified req = iterator[i];
				if(req != null)
				{
					if(!req.isCollection())
					{
						return true;
					}
				}
				else
				{
					//We are done at the first null

					return false;
				}
			}
		}
		return false;
	}
	/**
	 *  Pessimistically lock the object. Note that a thread calling lock() must
	 *  eventually call unlock(), to allow and waiting threads access to this
	 *  object. Failure to unlock this object will likely lead to stagnant threads,
	 *  a prime candidate for a deadlock situation. In short, always unlock the
	 *  object. This locking scheme is also reference-counted to accomodate the
	 *  rare scenario where a thread may lock an object several times: the object
	 *  remains locked until it has been unlocked the same number of times that it
	 *  has been locked.
	 *
	 * @param  wait boolean true if the current thread should wait until lock is
	 *  available. Otherwise return immediately.
	 * @return  boolean true if and only if the object was successfully locked.
	 */
	public boolean lock(boolean wait)
	{
		if(syncObject == null)
		{
			syncObject = getSyncObject();
		}
		synchronized(syncObject)
		{
			if(lockedBy() != null && lockedBy != Thread.currentThread())
			{
				if(!wait)
				{
					return false;
				}
				else
				{
					// This loop should not go on forever, assuming that threads who
					// lock do eventually unlock.
					//
					while(lockedBy != null)
					{
						try
						{
							syncObject.wait();
							// notify()'d when the object is unlocked()
						}
						catch(InterruptedException ex)
						{
							System.out.println("NoFieldObjectEditor>>Lock XXXXX  I N T E R R U P T E D XXXXX" + lockedBy);
							return false;
						}
					}
				}
			}
			refCount = 1;
			lockedBy = Thread.currentThread();
			return true;
		}
	}
	/**
	 * @return  java.lang.Thread
	 */
	public Thread lockedBy()
	{
		return lockedBy;
	}
	/**
	 *  Record that the TransactionalObject has been changed. The changes are
	 *  encapsulated in the ObjectChangeRequest object, and the Transaction in
	 *  which the change occurred is the the log.
	 *
	 * @param  log TransactionLog The current transaction context
	 * @param  mod
	 */
	public void markChange(final NoFieldObjectModified mod, final TransactionLog log)
	{
		if(verbose)
		{
			System.out.println("Changed : " + domainObject.getClass() + '@' + domainObject.hashCode());
		}

		log.addObject(this);

		NoFieldObjectModified[] list = getFieldMap(log);
		if(list == null)
		{
			list = new NoFieldObjectModified[data.length];
			putFieldMap(log, list);
		}
		putMod(list, mod, log);
	}
	/**
	 *  Used by nested transactions. A subtransaction has been commited. Move the
	 *  sub transaction changes to the parent transaction.
	 *
	 * @param  log TransactionLog The current transaction context
	 * @param  newLog
	 */
	public synchronized void migrateChanges(final TransactionLog log, final TransactionLog newLog)
	{
		if(verbose)
		{
			System.out.println("Migrating " + domainObject.getClass().getName() + '@' + domainObject.hashCode() + " from " + log + " to " + newLog);
		}

		//A performance optimization. Relies heavily upon the way getFieldMap() & putFieldMap() are implemented.
		NoFieldObjectModified[] newList = null;
		if(log == singleLog)
		{
			if(objectMods != null)
			{
				newList = (NoFieldObjectModified[]) objectMods.get(newLog);
			}
			if(newList == null)
			{
				singleLog = newLog;
				newLog.addObject(this);
				//clearChanges(log, false); - No need to clear since I am replacing the singleLog reference
				return;
			}
		}
		else
		{
			newList = getFieldMap(newLog);
		}

		//By passed optimization - A slightly more complex transaction is in progress
		NoFieldObjectModified[] list = getFieldMap(log);
		if(list == null)
		{
			return;
		}

		newLog.addObject(this);
		if(newList == null)
		{
			putFieldMap(newLog, list);
			newList = list;
		}
		else
		{
			for(int i = 0; i < list.length; ++i)
			{
				if(list[i] != null)
				{
					putMod(newList, list[i], newLog);
				}
			}
		}
		clearChanges(log, false);
	}
	/**
	 *  Undo any changes made to this object in the provided transaction.
	 *
	 * @param  log TransactionLog The current transaction context
	 * @param  forget
	 */
	public synchronized void rollback(TransactionLog log, boolean forget)
	{
		NoFieldObjectModified[] iterator = getFieldMap(log);
		if(iterator != null)
		{
			for(int i = 0; i < iterator.length; ++i)
			{
				NoFieldObjectModified req = iterator[i];
				if(req != null)
				{
					req.rollback();
				}
			}
		}
		if(forget)
		{
			clearChanges(log, true);
		}
	}
	/**
	 *  Unlock the pessimistically
	 */
	public void unlock()
	{
		if(syncObject == null)
		{
			syncObject = getSyncObject();
		}
		synchronized(syncObject)
		{
			// verify that the owner thread is the one doing the unlock.
			//
			if(lockedBy() != null && lockedBy == Thread.currentThread())
			{
				if(--refCount > 0)
				{
					return;
				}
				lockedBy = null;

				// Ensure that any 'naughty' threads stuck in setValue(...)
				// will eventually proceed, as well as polite threads waiting
				// in the lock() method.
				//
				syncObject.notifyAll();
			}
		}
	}
	/**
	 *  For the prodided transaction log, this provided list of changes exists. You
	 *  can't have two threads updating the field map at the same time.
	 *
	 * @param  log TransactionLog The transaction in progress.
	 * @param  list NoFieldObjectModified [] This list will hold the changes.
	 */
	protected final synchronized void putFieldMap(final TransactionLog log, final NoFieldObjectModified[] list)
	{
		if(singleLog == null)
		{
			singleLog = log;
			fieldToChangeMap = list;
			if(objectMods != null)
			{
				//May not happen, but just in case.

				objectMods.remove(log);
			}
		}
		else
				if(log == singleLog)
		{
			fieldToChangeMap = list;
		}
		else
		{
			if(objectMods == null)
			{
				objectMods = new HashMap(15);
			}
			objectMods.put(log, list);
		}
	}
	/**
	 *  protected final NoFieldObjectModified [] getFieldMap(final TransactionLog log) {
	 *  if(log == singleLog) return fieldToChangeMap; if(objectMods == null) return
	 *  null; return (ObjectModified [])objectMods.get(log); } protected
	 *  synchronized final void putFieldMap(final TransactionLog log, final
	 *  NoFieldObjectModified [] list) { if(singleLog == null) { singleLog = log;
	 *  fieldToChangeMap = list; } else if(log == singleLog) { fieldToChangeMap =
	 *  list; } else { if(objectMods == null) { objectMods = new HashMap(15); }
	 *  objectMods.put(log, list); } } Abstract the implementation of keeping track
	 *  of changes.
	 *
	 * @return
	 */
	protected final boolean noKnownLogs()
	{
		return objectMods == null && singleLog == null;
	}
	/**
	 *  Used by the persistent code to avoid the enumeration overhead
	 *
	 * @param  log TransactionLog The transaction in question.
	 * @return
	 */
	protected final NoFieldObjectModified[] quickChanges(TransactionLog log)
	{
		NoFieldObjectModified[] list = getFieldMap(log);
		if(list != null)
		{
			return list;
		}
		return new NoFieldObjectModified[0];
	}
	/**
	 *  Drop any changes associated with a specified transaction log.
	 *
	 * @param  releaseObjects boolean A true values indicates that NoFieldObjectModified
	 *  objects should be returned to the queue.
	 * @param  log TransactionLog The transaction in question.
	 */
	protected void clearChanges(final TransactionLog log, final boolean releaseObjects)
	{
		if(singleLog == log)
		{
			singleLog = null;
			if(releaseObjects)
			{
				//For now, don't worry about caching
				//returnObjects(fieldToChangeMap);
			}
			fieldToChangeMap = null;
		}
		else
				if(objectMods != null)
		{
			NoFieldObjectModified[] list = (NoFieldObjectModified[]) objectMods.remove(log);
			if(releaseObjects && list != null)
			{
				//For now, don't worry about caching
				//returnObjects(list);
			}
		}
	}
	/**
	 * @param  log TransactionLog The current transaction context
	 * @param  list
	 * @param  mod
	 */
	protected final void putMod(final NoFieldObjectModified[] list, final NoFieldObjectModified mod, final TransactionLog log)
	{
		//insert the mod into the list
		int field = mod.adapter;

		list[field] = mod;
	}
	/**
	 *  If the old value is a collection, we make a copy of it.
	 *
	 * @param  adapt
	 * @param  oldValue
	 * @return  Collection or null. NULL if the type is not a collection.
	 */
	Object perhapsCloneCollection(final int adapt, final Object oldValue)
	{
		// Because the array may be modified, we must duplicate it and set it
		// as a new value.
		if(oldValue.getClass().isArray())
		{
			return cloneArray(oldValue, adapt);
		}
		//If this object is a collection, attempt to clone it.
		if(SupportedCollections.isCollection(oldValue))
		{
			Object newVal = SupportedCollections.cloneCollection(oldValue);
			if(newVal != oldValue)
			{
				set(adapt, newVal, oldValue);
			}
			return newVal;
		}
		return null;
	}
	/**
	 *  Copy the array when the 'get' method is invoked. This allows the object
	 *  editor to support rollbacks on arrays.
	 *
	 * @param  oldValue
	 * @param  adapt
	 * @return
	 */
	Object cloneArray(final Object oldValue, final int adapt)
	{
		int length = Array.getLength(oldValue);
		Object newVal = Array.newInstance(oldValue.getClass().getComponentType(), length);
		for(int i = 0; i < length; i++)
		{
			Array.set(newVal, i, (Array.get(oldValue, i)));
		}
		set(adapt, newVal, oldValue);
		return newVal;
	}
	/**
	 */
	void waitForLock()
	{
		if(lockedBy() != null)
		{
			if(syncObject == null)
			{
				syncObject = getSyncObject();
			}
			synchronized(syncObject)
			{
				// This loop should not be forever: once notified, this thread
				// will eventually see lockedBy==null, assuming that the other
				// threads call unlock() as they oughta.
				//
				while(lockedBy != null && lockedBy != Thread.currentThread())
				{
					try
					{
						syncObject.wait();
					}
					catch(InterruptedException ex)
					{
					}
				}
			}
		}
	}
	/**
	 *  An enumeration of ObjectChangeRequest objects for this particular
	 *  transaction log;
	 *
	 * @param  log TransactionLog The transaction in question.
	 * @return
	 * @todo  Make this actually work
	 */
	public Enumeration changes(TransactionLog log)
	{
		if(noKnownLogs())
		{
			return new Vector().elements();
		}
		NoFieldObjectModified[] list = getFieldMap(log);
		if(list == null)
		{
			return new Vector().elements();
		}

		return new Vector().elements();
		//return new EmptyEnumeration(list);
	}
	/**
	 *  Return all objects in the array to the cache objects. Caching objects
	 *  improve performance and memory usage.
	 *
	 * @param  list
	 * @todo  Perhaps implement the ObjectPool
	 */
	private final void returnObjects(final NoFieldObjectModified[] list)
	{
		for(int i = 0; i < list.length; ++i)
		{
			if(list[i] != null)
			{
				/*
				 *  Don't worry about this for now
				 *  list[i].clean();
				 *  if(list[i].returnThis())
				 *  {
				 *  ExpandingObjectModifiedCache.returnObjectModifiedToCache(list[i]);
				 *  }
				 */
				list[i] = null;
			}
		}
	}
	/**
	 * @author  dhoag
	 * @version  $Id: NoFieldObjectEditor.java,v 1.1 2002/02/01 21:46:40 dave_hoag Exp $
	 */
	public static class Test extends com.objectwave.test.UnitTestBaseImpl
	{
		String one;
		Vector v;
		int adapt = 0;
		int collectionAdapt = 1;
		/**
		 * @param  args The command line arguments
		 */
		public static void main(String[] args)
		{
			com.objectwave.test.TestRunner.run(new Test(), args);
		}
		/**
		 * @param  testName The new Up value
		 * @param  context The new Up value
		 * @exception  Exception
		 */
		public void setUp(String testName, com.objectwave.test.TestContext context) throws Exception
		{
			super.setUp(testName, context);

			TransactionLog.Test.reset();
		}

	}
}
