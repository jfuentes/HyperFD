package com.objectwave.transactionalSupport;

import java.lang.reflect.Field;
import java.util.Hashtable;
import java.util.Vector;

/**
 * The details of a change to a particular object.
 * Every change will create an NoFieldObjectModified object.
 * There will be only one NoFieldObjectModified instance per attribute per transaction.
 *
 * Only 1 thread will be calling get and set with this class.
 *
 * @author  dhoag
 * @version  $Id: NoFieldObjectModified.java,v 1.2 2002/03/23 13:42:11 dave_hoag Exp $
 */
public class NoFieldObjectModified implements ObjectChangeRequest
{
	int adapter;
	Object oldValue;
	Object newValue;
	TransactionalObjectIF domainObject;
	boolean collection;
	//* If I cause the exception, then I do not want to change my object back to its original value!
	boolean iCommited = false;
	NoFieldObjectEditor noFieldGuy;
	Class type;
	final Class stringClass = String.class;
	/**
	 */
	protected NoFieldObjectModified()
	{
	}
	/**
	 * Update the domain object to contain the 'value' at the field for this object.
	 * Only 1 thread will be calling get and set with this class.
	 *
	 * @param  value The value do place in the field.
	 */
	void set(Object value)
	{
		noFieldGuy.setField(adapter, value);
	}
	/**
	 * Get the current value in the domain object represented by the field
	 * for which this object represents.
	 * Only 1 thread will be calling get and set with this class.
	 *
	 * @return
	 */
	Object get()
	{
		return noFieldGuy.getField(adapter);
	}
	/**
	 * Is this field representing an Array, Hashtable, or a Vector?
	 *
	 * @return  The Collection value
	 */
	public boolean isCollection()
	{
		return collection;
	}
	/**
	 * A workaround for a small problem
	 *
	 * @return
	 */
	public boolean returnThis()
	{
		return true;
	}
	/**
	 */
	protected void clean()
	{
		adapter = -1;
		oldValue = null;
		newValue = null;
		domainObject = null;
		collection = false;
		iCommited = false;
		type = null;
		noFieldGuy = null;
	}
	/**
	 * Set the changed values.
	 *
	 * @param  backReference
	 * @param  adapt
	 * @param  theInstance
	 * @param  newVal
	 * @param  old
	 * @param  adapterType
	 */
	protected void initObjectModified(final NoFieldObjectEditor backReference, final int adapt, final TransactionalObjectIF theInstance, final Object newVal, final Object old, final Class adapterType)
	{
		if(adapt < 0 || adapt > backReference.data.length)
		{
			throw new RuntimeException("Illegal field index");
		}
		noFieldGuy = backReference;
		adapter = adapt;
		oldValue = old;
		newValue = newVal;
		domainObject = theInstance;

		if(!(adapterType == stringClass || adapterType.isPrimitive()))
		{
			//Not a string or a primitive
			if(adapterType.isArray())
			{
				collection = true;
			}
			else
			{
				Object notNullObject;
				if(oldValue != null)
				{
					notNullObject = oldValue;
				}
				else if(newValue != null)
				{
					notNullObject = newValue;
				}
				else
				{
					return;
				}
				collection = SupportedCollections.isCollection(notNullObject);
			}
		}
	}
	/**
	 * Place the new value into the domain object.  Prior to updating the domain object
	 * we validate that no one else has updated this particular field in the domain
	 * object. If someone has, an UpdateException will be thrown.
	 *
	 * @param  force Override the default behavior of checking if the object has changed.
	 * @exception  UpdateException
	 */
	public void commit(final boolean force) throws UpdateException
	{
		try
		{
			Object obj = get();
			if(obj != oldValue)
			{
				//Theyre not same object

				//Fail if the current value is null || if the current value is not equal to the stored value
				final boolean fail = (obj == null) || (!obj.equals(oldValue));
				if(!force && fail)
				{
					throw new UpdateException("\nIn " + domainObject + " Value for " + " modified.  expected: '" + oldValue + "' found: '" + obj + '\'');
				}
			}
			set(newValue);
			iCommited = true;
		}
		catch(RuntimeException e)
		{
			throw new UpdateException("\nIn " + domainObject + "\n" + e);
		}
	}
	/**
	 * @return  Object The 'current' value of the Object. This is NOT actually what value
	 * is found in the domain object. Rather what the value will be when the change is
	 * committed.
	 */
	public Object currentValue()
	{
		return newValue;
	}
	/**
	 * @return  Object value found in the domain object when this change occurred.
	 */
	public Object originalValue()
	{
		return oldValue;
	}
	/**
	 * Change the domain object to contain the 'old' value.
	 * There is nothing to rollback if I did not commit.
	 */
	public void rollback()
	{
		if(iCommited)
		{
			set(oldValue);
		}
	}
	/**
	 * @author  dhoag
	 * @version  $Id: NoFieldObjectModified.java,v 1.2 2002/03/23 13:42:11 dave_hoag Exp $
	 */
	public static class Test extends com.objectwave.test.UnitTestBaseImpl
	{
		/**
		 * @param  args The command line arguments
		 */
		public static void main(String[] args)
		{
			com.objectwave.test.TestRunner.run(new Test(), args);
		}
		/**
		 * @exception  UpdateException
		 * @exception  NoSuchFieldException
		 * @exception  IllegalAccessException
		 */
		public void testCommitChanges() throws UpdateException, NoSuchFieldException, IllegalAccessException
		{
			NoFieldObjectModified mod = new NoFieldObjectModified();
			NoFieldObjectEditor editor = new NoFieldObjectEditor();
			mod.noFieldGuy = editor;
			editor.initFieldSize(1);
			editor.setField(0, new Integer(10));

			mod.adapter = 0;
			mod.newValue = new Integer(312);
			mod.oldValue = new Integer(30);
			try
			{
				mod.commit(false);
				testContext.assertTrue("Excpected exception, but none occured. ", false);
			}
			catch(UpdateException ex)
			{
			}
			mod.oldValue = new Integer(10);
			mod.commit(false);
			testContext.assertEquals(312, ((Integer) editor.getField(0)).intValue());

			mod.oldValue = new Integer(312);
			mod.newValue = new Integer(31);
			mod.commit(true);
			testContext.assertEquals(31, ((Integer) editor.getField(0)).intValue());
		}
	}
}
