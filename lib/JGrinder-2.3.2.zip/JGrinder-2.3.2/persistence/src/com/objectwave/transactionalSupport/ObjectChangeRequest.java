package com.objectwave.transactionalSupport;

import java.lang.reflect.Field;
/**
 * The interface to objects that will keep track of details of a change
 * to a transactional object.
 *
 * @author  dhoag
 * @version  $Id: ObjectChangeRequest.java,v 2.1 2002/02/01 21:43:07 dave_hoag Exp $
 */
public interface ObjectChangeRequest
{

	/**
	 * Commit the change.
	 *
	 * @param  force Ignore any values found in the domain object.
	 * @exception  UpdateException
	 */
	public void commit(boolean force) throws UpdateException;
	/**
	 * @return
	 */
	public Object currentValue();
	/**
	 *Gets the Collection attribute of the ObjectChangeRequest object
	 *
	 * @return  The Collection value
	 */
	public boolean isCollection();
	/**
	 * @return  Object value found in the domain object when this change occurred.
	 */
	public Object originalValue();
	/**
	 */
	public void rollback();
}
