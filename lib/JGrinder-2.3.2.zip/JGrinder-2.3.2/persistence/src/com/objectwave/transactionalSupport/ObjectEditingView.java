package com.objectwave.transactionalSupport;

/**
 * The interface to the object that will keep track of ObjectChanges.
 *
 * @author  dhoag
 * @version  $Id: ObjectEditingView.java,v 2.1 2002/02/01 21:43:07 dave_hoag Exp $
 */
public interface ObjectEditingView extends SetAndGetDelegateIF
{
	/**
	 * An enumeration of ObjectChangeRequest objects for this particular
	 * transaction log.
	 *
	 * @param  log
	 * @return
	 */
	public java.util.Enumeration changes(TransactionLog log);
	/**
	 * DO NOT USE THIS METHOD.
	 *
	 * @param  log
	 */
	public void clearChanges(TransactionLog log);
	/**
	 * Commit the changes found in the transaction log to the transactional object.
	 *
	 * @param  log
	 * @param  force
	 * @exception  UpdateException
	 */
	public void commit(TransactionLog log, boolean force) throws UpdateException;
	/**
	 * Broader in scope than isDirty. Are there ANY changes for ANY transaction log for this object.
	 *
	 * @return
	 */
	public boolean containsAnyChanges();
	/**
	 * The object for which this EditingView represents.
	 *
	 * @return  The DomainObject value
	 */
	public TransactionalObjectIF getDomainObject();
	/**
	 *Gets the Dirty attribute of the ObjectEditingView object
	 *
	 * @return  The Dirty value
	 */
	public boolean isDirty();
	/**
	 *Gets the Transient attribute of the ObjectEditingView object
	 *
	 * @return  The Transient value
	 */
	public boolean isTransient();
	/**
	 *   Pessimistically lock the object.  Note that a thread calling lock() must eventually
	 * call unlock(), to allow and waiting threads access to this object.  Failure to unlock
	 * this object will likely lead to stagnant threads, a prime candidate for a deadlock
	 * situation.  In short, always unlock the object.
	 *
	 *   This locking scheme is also reference-counted to accomodate the rare scenario where
	 * a thread may lock an object several times: the object remains locked until it has been
	 * unlocked the same number of times that it has been locked.
	 *
	 * @param  wait boolean true if the current thread should wait until lock is available. Otherwise return immediately.
	 * @return  boolean true if and only if the object was successfully locked.
	 */
	boolean lock(boolean wait);
	/**
	 * Used by nested transactions. A subtransaction has been commited.  Move the sub transaction
	 * changes to the parent transaction.
	 *
	 * @param  log
	 * @param  newLog
	 */
	public void migrateChanges(TransactionLog log, TransactionLog newLog);
	/**
	 * Rollback the changes found in the transaction log to the transactional object.
	 *
	 * @param  log
	 * @param  forget
	 */
	public void rollback(TransactionLog log, boolean forget);
	/**
	 *Sets the AsTransient attribute of the ObjectEditingView object
	 *
	 * @param  value The new AsTransient value
	 */
	public void setAsTransient(boolean value);
	/**
	 * This method was created in VisualAge.
	 */
	void unlock();
}
