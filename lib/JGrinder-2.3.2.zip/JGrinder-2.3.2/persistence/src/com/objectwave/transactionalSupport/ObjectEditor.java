/*
 *  Copyright (C) 2001 David Hoag
 *  ObjectWave Corporation
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *  For a full copy of the license see:
 *  http://www.opensource.org/licenses/lgpl-license.html
 */
package com.objectwave.transactionalSupport;
import java.beans.*;
import java.io.Serializable;
import java.lang.reflect.Array;
import java.lang.reflect.Field;
import com.objectwave.logging.MessageLog;
import java.util.*;
/**
 *  Tracks changes to a TransactionalObjectIF. If you wish to see verbose output
 *  of the ObjectEditor, start your application ow.objectEditVerbose=true
 *
 * @author  dhoag
 * @version  $Id: ObjectEditor.java,v 2.4 2002/03/23 13:42:11 dave_hoag Exp $
 * @see  com.objectwave.transactionalSupport.ObjectEditingView
 * @question  By extending PropertyChangeSupport we will consume more memory.
 *  Should this be the default?
 */
public class ObjectEditor implements ObjectEditingView, Serializable
{
	protected static AccessSecurityIF security = null;

	//Static references
	final static boolean verbose = System.getProperty("ow.objectEditVerbose") != null;
	final static boolean firePropertyChangeEvents = false;

	/**
	 */
	public final transient Object[] dataExchange = new Object[1];
	protected final transient Field[] fds = new Field[1];
	boolean isTransient;
	transient TransactionLog singleLog;
	transient ObjectModified[] fieldToChangeMap;
	transient HashMap objectMods;
	TransactionalObjectIF domainObject;
	transient TransactionLog lastLog;
	transient ObjectModified[] lastFieldMap;

	// These object are for the support of pessimistic locking.
	transient Object syncObject;
	transient Thread lockedBy;
	transient int refCount;
	/**
	 *  Constructor for the ObjectEditor object
	 */
	public ObjectEditor()
	{
	}
	/**
	 *  Manage the changes for the transactional domainObject. Every instance of
	 *  ObjectEditor is responsible for only one TransactionalObjectIF.
	 *
	 * @param  domainObject
	 */
	public ObjectEditor(TransactionalObjectIF domainObject)
	{
		this.domainObject = domainObject;
	}
	/**
	 *  Search the provided list of changes for change to the particular field.
	 *  While this is indeed a linear search, it beats the pants off performance
	 *  wise on a HashMap lookup (since the lists are always small).
	 *
	 * @param  list ObjectModified [] A list of changes.
	 * @param  field The field for which we are looking for changes.
	 * @return  The Mods value
	 */
	protected final static ObjectModified getMods(final Field field, final ObjectModified[] list)
	{
		for(int i = 0; i < list.length; ++i)
		{
			if(list[i] != null)
			{
				if(list[i].getAccessor() == field)
				{
					return list[i];
				}
			}
			else
			{
				//Exit at the first null object in the ObjectModified [] list.
				return null;
			}
		}
		return null;
	}
	/**
	 *  Delegate to the set(Field, Object, Object) method.
	 *
	 * @param  adapt
	 * @param  val
	 * @param  originalVal
	 */
	public void set(Field adapt, byte val, byte originalVal)
	{
		if(val == originalVal)
		{
			Object values = new Byte(val);
			setValue(adapt, values, values);
		}
		else
		{
			setValue(adapt, new Byte(val), new Byte(originalVal));
		}
	}
	/**
	 *  Delegate to the set(Field, Object, Object) method.
	 *
	 * @param  adapt
	 * @param  val
	 * @param  originalVal
	 */
	public void set(Field adapt, char val, char originalVal)
	{
		if(val == originalVal)
		{
			Object values = new Character(val);
			setValue(adapt, values, values);
		}
		else
		{
			setValue(adapt, new Character(val), new Character(originalVal));
		}
	}
	/**
	 *  Delegate to the set(Field, Object, Object) method.
	 *
	 * @param  adapt
	 * @param  val
	 * @param  originalVal
	 */
	public void set(Field adapt, double val, double originalVal)
	{
		if(val == originalVal)
		{
			Object values = new Double(val);
			setValue(adapt, values, values);
		}
		else
		{
			setValue(adapt, new Double(val), new Double(originalVal));
		}
	}
	/**
	 *  Delegate to the set(Field, Object, Object) method.
	 *
	 * @param  adapt
	 * @param  val
	 * @param  originalVal
	 */
	public void set(Field adapt, float val, float originalVal)
	{
		if(val == originalVal)
		{
			Object values = new Float(val);
			setValue(adapt, values, values);
		}
		else
		{
			setValue(adapt, new Float(val), new Float(originalVal));
		}
	}
	/**
	 *  Delegate to the set(Field, Object, Object) method.
	 *
	 * @param  adapt
	 * @param  val
	 * @param  originalVal
	 */
	public void set(Field adapt, int val, int originalVal)
	{
		if(val == originalVal)
		{
			Object values = new Integer(val);
			setValue(adapt, values, values);
		}
		else
		{
			setValue(adapt, new Integer(val), new Integer(originalVal));
		}
	}
	/**
	 *  Delegate to the set(Field, Object, Object) method.
	 *
	 * @param  adapt
	 * @param  val
	 * @param  originalVal
	 */
	public void set(Field adapt, long val, long originalVal)
	{
		if(val == originalVal)
		{
			Object values = new Long(val);
			setValue(adapt, values, values);
		}
		else
		{
			setValue(adapt, new Long(val), new Long(originalVal));
		}
	}
	/**
	 *  Delegate to the setValue(Field, Object, Object) method.
	 *
	 * @param  adapt
	 * @param  val
	 * @param  originalVal
	 * @see  #setValue(java.lang.Field, java.lang.Object, java.lang.Object)
	 */
	public void set(final Field adapt, final Object val, final Object originalVal)
	{
		setValue(adapt, val, originalVal);
	}
	/**
	 *  Delegate to the set(Field, Object, Object) method.
	 *
	 * @param  adapt
	 * @param  val
	 * @param  originalVal
	 */
	public void set(final Field adapt, final String val, final String originalVal)
	{
		if((val != null) && (val == originalVal || val.equals(originalVal)))
		{
			setValue(adapt, originalVal, originalVal);
		}
		else
		{
			setValue(adapt, val, originalVal);
		}
	}
	/**
	 *  Delegate to the set(Field, Object, Object) method.
	 *
	 * @param  adapt
	 * @param  val
	 * @param  originalVal
	 */
	public void set(final Field adapt, final Date val, final Date originalVal)
	{
		if((val != null) && (val.equals(originalVal)))
		{
			setValue(adapt, originalVal, originalVal);
		}
		else
		{
			setValue(adapt, val, originalVal);
		}
	}
	/**
	 *  Delegate to the set(Field, Object, Object) method.
	 *
	 * @param  adapt
	 * @param  val
	 * @param  originalVal
	 */
	public void set(Field adapt, short val, short originalVal)
	{
		if(val == originalVal)
		{
			Object values = new Short(val);
			setValue(adapt, values, values);
		}
		else
		{
			setValue(adapt, new Short(val), new Short(originalVal));
		}
	}
	/**
	 *  Delegate to the set(Field, Object, Object) method.
	 *
	 * @param  adapt
	 * @param  val
	 * @param  originalVal
	 */
	public void set(Field adapt, boolean val, boolean originalVal)
	{
		if(val == originalVal)
		{
			Object values = new Boolean(val);
			setValue(adapt, values, values);
		}
		else
		{
			setValue(adapt, new Boolean(val), new Boolean(originalVal));
		}
	}
	/**
	 *  A transient object. We do not keep track of changes for 'transient'
	 *  objects. Perhaps 'transient' is an incorrect term.
	 *
	 * @param  value The new AsTransient value
	 */
	public void setAsTransient(boolean value)
	{
		isTransient = value;
	}
	/**
	 *  Security allows one to prevent access to a fields value. In the event of a
	 *  'set' restriction, a runtime security exception will be thrown. A 'get'
	 *  restriction will not throw an exception, but instead return an incorrect
	 *  value.
	 *
	 * @param  s The new Security value
	 */
	public void setSecurity(AccessSecurityIF s)
	{
		security = s;
	}
	/**
	 *  Set the value 'val' on the domain object at field 'adapt'.
	 *
	 * @param  adapt The new DomainField value
	 * @param  val The new DomainField value
	 */
	protected void setDomainField(final Field adapt, final Object val)
	{
		if(adapt.isAccessible())
		{
			try
			{
				adapt.set(domainObject, val);
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		else
		{
			synchronized(dataExchange)
			{
				dataExchange[0] = val;
				fds[0] = adapt;
				domainObject.update(false, dataExchange, fds);
			}
		}
	}
	/**
	 *  The main workhorse method for all of the set methods.
	 *
	 * @param  adapt The new Value value
	 * @param  val The new Value value
	 * @param  originalVal The new Value value
	 */
	protected void setValue(final Field adapt, final Object val, final Object originalVal)
	{
		if(security != null)
		{
			// For now, throw the exception if security access violated.
			// try {
			security.checkWriteAccess(getDomainObject(), adapt);
			// } catch (SecurityException e) {}
		}
		TransactionLog log = TransactionLog.getCurrentInstance();

		waitForLock();

		if(verbose)
		{
			System.out.print("Setting " + adapt.getName() + " to " + val + " on ");
			if(isTransient)
			{
				System.out.print("transient ");
			}
			System.out.println(domainObject.getClass().getName() + '@' + domainObject.hashCode());
		}

//		if(firePropertyChangeEvents)
		//Question: How much overhead does this introduce?
//			firePropertyChange(adapt.getName(), originalVal, val);

		if((log == null) || (isTransient))
		{
			setDomainField(adapt, val);
		}
		/*
		 *  else if((val == null) && (originalVal == null))
		 *  {
		 *  clearOutUncommitedChanges(log, adapt);
		 *  return;
		 *  }
		 *  else if(val == originalVal)
		 *  {
		 *  clearOutUncommitedChanges(log, adapt);
		 *  return;
		 *  }
		 */
		else
		{
			ObjectModified mod = ExpandingObjectModifiedCache.getObjectModifiedFromCache();
			mod.initObjectModified(adapt, domainObject, val, originalVal);
			markChange(mod, log);
		}
	}
	/**
	 * @param  adapt
	 * @param  val
	 * @return
	 */
	public byte get(Field adapt, byte val)
	{
		if(security != null)
		{
			// For now, Just return a null value. Never let them see original value.
			try
			{
				security.checkReadAccess(getDomainObject(), adapt);
			}
			catch(SecurityException ex)
			{
				return 0;
			}
		}
		TransactionLog log = TransactionLog.getCurrentInstance();

		if((log == null) || (isTransient) || !containsAnyChanges())
		{
			return val;
		}
		//The value passed in as the old value is indeed the correct value.

		while(log != null)
		{
			ObjectModified[] list = getFieldMap(log);
			if(list != null)
			{
				ObjectModified obj = getMods(adapt, list);
				if(obj != null)
				{
					return ((Byte) obj.currentValue()).byteValue();
				}
			}
			log = log.getParentTransaction();
		}

		return val;
	}
	/**
	 * @param  adapt
	 * @param  val
	 * @return
	 */
	public char get(Field adapt, char val)
	{
		if(security != null)
		{
			// For now, Just return a null value. Never let them see original value.
			try
			{
				security.checkReadAccess(getDomainObject(), adapt);
			}
			catch(SecurityException ex)
			{
				return ' ';
			}
		}
		TransactionLog log = TransactionLog.getCurrentInstance();

		if((log == null) || (isTransient) || !containsAnyChanges())
		{
			return val;
		}
		//The value passed in as the old value is indeed the correct value.

		while(log != null)
		{
			ObjectModified[] list = getFieldMap(log);
			if(list != null)
			{
				ObjectModified obj = getMods(adapt, list);
				if(obj != null)
				{
					return ((Character) obj.currentValue()).charValue();
				}
			}
			log = log.getParentTransaction();
		}

		return val;
	}
	/**
	 * @param  adapt
	 * @param  val
	 * @return
	 */
	public double get(Field adapt, double val)
	{
		if(security != null)
		{
			// For now, Just return a null value. Never let them see original value.
			try
			{
				security.checkReadAccess(getDomainObject(), adapt);
			}
			catch(SecurityException ex)
			{
				return 0;
			}
		}
		TransactionLog log = TransactionLog.getCurrentInstance();

		if((log == null) || (isTransient) || !containsAnyChanges())
		{
			return val;
		}
		//The value passed in as the old value is indeed the correct value.

		while(log != null)
		{
			ObjectModified[] list = getFieldMap(log);
			if(list != null)
			{
				ObjectModified obj = getMods(adapt, list);
				if(obj != null)
				{
					return ((Double) obj.currentValue()).doubleValue();
				}
			}
			log = log.getParentTransaction();
		}

		return val;
	}
	/**
	 * @param  adapt
	 * @param  val
	 * @return
	 */
	public float get(Field adapt, final float val)
	{
		if(security != null)
		{
			// For now, Just return a null value. Never let them see original value.
			try
			{
				security.checkReadAccess(getDomainObject(), adapt);
			}
			catch(SecurityException ex)
			{
				return 0;
			}
		}
		TransactionLog log = TransactionLog.getCurrentInstance();

		if((log == null) || (isTransient) || !containsAnyChanges())
		{
			return val;
		}
		//The value passed in as the old value is indeed the correct value.

		while(log != null)
		{
			ObjectModified[] list = getFieldMap(log);
			if(list != null)
			{
				ObjectModified obj = getMods(adapt, list);
				if(obj != null)
				{
					return ((Float) obj.currentValue()).floatValue();
				}
			}
			log = log.getParentTransaction();
		}

		return val;
	}
	/**
	 *  No longer uses the convience method. This must be as fast as possible.
	 *
	 * @param  adapt
	 * @param  oldValue
	 * @return
	 */
	public int get(final Field adapt, final int oldValue)
	{
		if(security != null)
		{
			// For now, Just return a null value. Never let them see original value.
			try
			{
				security.checkReadAccess(getDomainObject(), adapt);
			}
			catch(SecurityException ex)
			{
				return 0;
			}
		}
		TransactionLog log = TransactionLog.getCurrentInstance();

		if((log == null) || (isTransient) || !containsAnyChanges())
		{
			return oldValue;
		}
		//The value passed in as the old value is indeed the correct value.

		while(log != null)
		{
			ObjectModified[] list = getFieldMap(log);
			if(list != null)
			{
				ObjectModified obj = getMods(adapt, list);
				if(obj != null)
				{
					return ((Integer) obj.currentValue()).intValue();
				}
			}
			log = log.getParentTransaction();
		}

		return oldValue;
	}
	/**
	 * @param  adapt
	 * @param  val
	 * @return
	 */
	public long get(Field adapt, long val)
	{
		if(security != null)
		{
			// For now, Just return a null value. Never let them see original value.
			try
			{
				security.checkReadAccess(getDomainObject(), adapt);
			}
			catch(SecurityException ex)
			{
				return 0;
			}
		}
		TransactionLog log = TransactionLog.getCurrentInstance();

		if((log == null) || (isTransient) || !containsAnyChanges())
		{
			return val;
		}
		//The value passed in as the old value is indeed the correct value.

		while(log != null)
		{
			ObjectModified[] list = getFieldMap(log);
			if(list != null)
			{
				ObjectModified obj = getMods(adapt, list);
				if(obj != null)
				{
					return ((Long) obj.currentValue()).longValue();
				}
			}
			log = log.getParentTransaction();
		}

		return val;
	}
	/**
	 * @param  adapt
	 * @param  oldValue
	 * @return
	 */
	public Object get(final Field adapt, final Object oldValue)
	{
		if(security != null)
		{
			// For now, Just return a null value. Never let them see original value.
			try
			{
				security.checkReadAccess(getDomainObject(), adapt);
			}
			catch(SecurityException ex)
			{
				return null;
			}
		}
		TransactionLog log = TransactionLog.getCurrentInstance();

		//Do not include objectMods in this comparison. Vector, Array, and HashMap screw this up.
		if((log == null) || (isTransient))
		{
			return oldValue;
		}
		//The value passed in as the old value is indeed the correct value.

		return getValue(adapt, oldValue, log);
	}
	/**
	 * @param  adapt
	 * @param  val
	 * @return
	 */
	public short get(Field adapt, short val)
	{
		if(security != null)
		{
			// For now, Just return a null value. Never let them see original value.
			try
			{
				security.checkReadAccess(getDomainObject(), adapt);
			}
			catch(SecurityException ex)
			{
				return 0;
			}
		}
		TransactionLog log = TransactionLog.getCurrentInstance();

		if((log == null) || (isTransient) || !containsAnyChanges())
		{
			return val;
		}
		//The value passed in as the old value is indeed the correct value.

		while(log != null)
		{
			ObjectModified[] list = getFieldMap(log);
			if(list != null)
			{
				ObjectModified obj = getMods(adapt, list);
				if(obj != null)
				{
					return ((Short) obj.currentValue()).shortValue();
				}
			}
			log = log.getParentTransaction();
		}

		return val;
	}
	/**
	 * @param  adapt
	 * @param  val
	 * @return
	 */
	public String get(Field adapt, String val)
	{
		if(security != null)
		{
			// For now, Just return a null value. Never let them see original value.
			try
			{
				security.checkReadAccess(getDomainObject(), adapt);
			}
			catch(SecurityException ex)
			{
				return null;
			}
		}
		TransactionLog log = TransactionLog.getCurrentInstance();

		if((log == null) || (isTransient) || !containsAnyChanges())
		{
			return val;
		}
		//The value passed in as the old value is indeed the correct value.

		while(log != null)
		{
			ObjectModified[] list = getFieldMap(log);
			if(list != null)
			{
				ObjectModified obj = getMods(adapt, list);
				if(obj != null)
				{
					return (String) obj.currentValue();
				}
			}
			log = log.getParentTransaction();
		}

		return val;
	}
	/**
	 * @param  adapt
	 * @param  val
	 * @return
	 */
	public boolean get(Field adapt, boolean val)
	{
		if(security != null)
		{
			// For now, Just return a null value. Never let them see original value.
			try
			{
				security.checkReadAccess(getDomainObject(), adapt);
			}
			catch(SecurityException ex)
			{
				return false;
			}
		}
		TransactionLog log = TransactionLog.getCurrentInstance();

		if((log == null) || (isTransient) || !containsAnyChanges())
		{
			return val;
		}
		//The value passed in as the old value is indeed the correct value.

		while(log != null)
		{
			ObjectModified[] list = getFieldMap(log);
			if(list != null)
			{
				ObjectModified obj = getMods(adapt, list);
				if(obj != null)
				{
					return ((Boolean) obj.currentValue()).booleanValue();
				}
			}
			log = log.getParentTransaction();
		}

		return val;
	}
	/**
	 * @param  log TransactionLog The current transaction context
	 * @return  Vector of ObjectChangeRequests that represent collection changes.
	 */
	public Vector getCollectionChanges(final TransactionLog log)
	{
		Vector result = new Vector();
		ObjectModified[] iterator = getFieldMap(log);
		if(iterator != null)
		{
			for(int i = 0; i < iterator.length; ++i)
			{
				ObjectModified req = iterator[i];
				if(req != null && req.isCollection())
				{
					result.addElement(req);
				}
			}
		}
		return result;
	}
	/**
	 * @return  The DomainObject value
	 */
	public TransactionalObjectIF getDomainObject()
	{
		return domainObject;
	}
	/**
	 * @return  The Security value
	 * @see  #setSecurity
	 */
	public AccessSecurityIF getSecurity()
	{
		return security;
	}
	/**
	 *  If we have any changes in the current transaction log, return true;
	 *
	 * @return  boolean Indicating one of the following:
	 *  <li> There is no current transaction.</li>
	 *  <li> The current object is transient</li>
	 *  <li> There is a transaction and the current object is not transient and
	 *  there are changes to the object.</li>
	 */
	public boolean isDirty()
	{
		TransactionLog log = TransactionLog.getCurrentInstance();
		if((log == null) || (isTransient))
		{
			return true;
		}
		if(objectMods == null && singleLog == null)
		{
			return false;
		}
		ObjectModified[] list = getFieldMap(log);
		if(list == null)
		{
			return false;
		}
		boolean change = false;
		for(int i = 0; i < list.length; ++i)
		{
			if(list[i] != null)
			{
				change = true;
				break;
			}
		}
		return change;
	}
	/**
	 *  A transient object. We do not keep track of changes for 'transient'
	 *  objects. Perhaps 'transient' is an incorrect term.
	 *
	 * @return  The Transient value
	 */
	public boolean isTransient()
	{
		return isTransient;
	}
	/**
	 *  For the provided TransactionLog, get the list of known changes.
	 *
	 * @param  log TransactionLog The transaction in question.
	 * @return  ObjectModified [] The holder of the changes. The first null value
	 *  is the end of the change list.
	 */
	protected final synchronized ObjectModified[] getFieldMap(final TransactionLog log)
	{
		if(log == singleLog)
		{
			return fieldToChangeMap;
		}
		if(objectMods == null)
		{
			return null;
		}
		if(lastLog != log)
		{
			lastLog = log;
			lastFieldMap = (ObjectModified[]) objectMods.get(log);
		}
		return lastFieldMap;
	}
	/**
	 *  Get the value from the domain object at field 'adapt'.
	 *
	 * @param  adapt
	 * @return  The DomainField value
	 */
	protected Object getDomainField(final Field adapt)
	{
		if(adapt.isAccessible())
		{
			try
			{
				return adapt.get(domainObject);
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		synchronized(dataExchange)
		{
			fds[0] = adapt;
			domainObject.update(true, dataExchange, fds);
			return dataExchange[0];
		}
	}
	/**
	 *  The main workhorse method for all of the get methods.
	 *
	 * @param  log TransactionLog The current transaction context
	 * @param  adapt
	 * @param  oldValue
	 * @return  Object The transactionally accurate value of the field 'adapt'.
	 */
	protected Object getValue(final Field adapt, final Object oldValue, TransactionLog log)
	{
		if(verbose)
		{
			System.out.print("getting " + adapt.getName() + " from " + log + " " + Thread.currentThread());
			if(isTransient)
			{
				System.out.print(" is transient ");
			}
			System.out.println(domainObject.getClass().getName() + '@' + domainObject.hashCode());
		}
		final boolean hasPotentialMods = (objectMods != null || singleLog != null);
		//Object mods may be null if the field is a Vector, Array, or HashMap.
		//We still want to go through this method to handle that situation.
		if(hasPotentialMods)
		{
			while(log != null)
			{
				ObjectModified[] list = getFieldMap(log);
				if(list != null)
				{
					ObjectModified obj = getMods(adapt, list);
					if(obj != null)
					{
						return obj.currentValue();
					}
				}
				log = log.getParentTransaction();
			}
		}
		//If we reach here, no current value has been found.
		if(oldValue == null)
		{
			return null;
		}

		final Object newVal = perhapsCloneCollection(adapt, oldValue);
		//newVal will be null if the object is not a collection.
		if(newVal != null)
		{
			return newVal;
		}

		//Finally, look in the object for the object value
//		return getDomainField(adapt);  - The old value is the value in the object
		return oldValue;
	}
	/**
	 *  Used to lazily initialize the syncObject. ex. if(syncObject == null)
	 *  syncObject = getSyncObject();
	 *
	 * @return  The SyncObject value
	 */
	private synchronized Object getSyncObject()
	{
		if(syncObject != null)
		{
			return syncObject;
		}
		syncObject = new Object();
		return syncObject;
	}
	/**
	 *  An enumeration of ObjectChangeRequest objects for this particular
	 *  transaction log;
	 *
	 * @param  log TransactionLog The transaction in question.
	 * @return
	 */
	public Enumeration changes(TransactionLog log)
	{
		if(noKnownLogs())
		{
			return new EmptyEnumeration(null);
		}
		ObjectModified[] list = getFieldMap(log);
		if(list == null)
		{
			return new EmptyEnumeration(null);
		}

		return new EmptyEnumeration(list);
	}
	/**
	 *  Drop any changes associated with a specified transaction log. This is a
	 *  dangerous move. Avoid doing this. Public only because of the interface.
	 *
	 * @param  log TransactionLog The transaction in question.
	 */
	public synchronized void clearChanges(final TransactionLog log)
	{
		clearChanges(log, true);
	}
	/**
	 *  In the event that we call setValue(aVal) to change an object. And then we
	 *  call setValue(aVal) to restore that object to the originalValue then we
	 *  want to toss the old Object Mods.
	 *
	 * @param  log TransactionLog The current transaction context
	 * @param  force
	 * @exception  UpdateException
	 * @fixme  Still under construction private synchronized void
	 *  clearOutUncommitedChanges(TransactionLog log, final Field field) {
	 *  Clear out any previous, and uncommited, changes. while(log != null &&
	 *  (! noKnownLogs())) { ObjectModified [] list = getFieldMap(log); if(list
	 *  != null) { ObjectModified obj = null; int i = 0; for(; i < list.length;
	 *  ++i) { if(list[i] != null && list[i].getAccessor() == field) { obj =
	 *  list[i]; break; } } if(obj != null) { if(i == 0 && there are no other
	 *  changes ) { clearChanges(log); return; } list[i] = null; return; } }
	 *  I'm not so sure this is correct. Why do I want to remove changes from
	 *  parent transactions? log = log.getParentTransaction(); On 6/9/98 I
	 *  added the following line. log = null; } }
	 */
	/**
	 *  In the event that we call setValue(aVal) to change an object. And then we
	 *  call setValue(aVal) to restore that object to the originalValue then we
	 *  want to toss the old Object Mods.
	 *
	 *  In the event that we call setValue(aVal) to change an object. And then we
	 *  call setValue(aVal) to restore that object to the originalValue then we
	 *  want to toss the old Object Mods.
	 *
	 *  In the event that we call setValue(aVal) to change an object. And then we
	 *  call setValue(aVal) to restore that object to the originalValue then we
	 *  want to toss the old Object Mods.
	 *
	 *  In the event that we call setValue(aVal) to change an object. And then we
	 *  call setValue(aVal) to restore that object to the originalValue then we
	 *  want to toss the old Object Mods. In the event that we call setValue(aVal)
	 *  to change an object. And then we call setValue(aVal) to restore that object
	 *  to the originalValue then we want to toss the old Object Mods. In the event
	 *  that we call setValue(aVal) to change an object. And then we call
	 *  setValue(aVal) to restore that object to the originalValue then we want to
	 *  toss the old Object Mods. Commit every change request for the specified
	 *  transaction log. This will actually put the values into the Objects.
	 *
	 * @param  log TransactionLog The current transaction context
	 * @param  force
	 * @exception  UpdateException
	 */
	public synchronized void commit(final TransactionLog log, final boolean force) throws UpdateException
	{
		ObjectModified[] iterator = getFieldMap(log);
		if(verbose)
		{
			System.out.println("Commiting " + this + " getDomain " + getDomainObject().getClass().getName() + '@' + getDomainObject().hashCode());
		}
		if(iterator != null)
		{
			for(int i = 0; i < iterator.length; ++i)
			{
				ObjectModified req = iterator[i];
				if(req != null)
				{
					if(verbose)
					{
						System.out.println("\t" + req.getAccessor().getName() + " value: " + req.currentValue());
						System.out.println("\tChange domain " + req.domainObject.getClass().getName() + '@' + req.domainObject.hashCode());
						try
						{
							req.commit(force);
						}
						catch(UpdateException ex)
						{
							System.out.println("### - Commit failed " + ex);
							throw ex;
						}
					}
					else
					{
						req.commit(force);
					}
				}
				else
				{
					//we are done at the first null

					return;
				}
			}
		}
	}
	/**
	 *  Are there ANY changes for ANY transaction log for this object.
	 *
	 * @return
	 */
	public final boolean containsAnyChanges()
	{
		if(singleLog != null)
		{
			return true;
		}
		return (objectMods != null && objectMods.size() != 0);
	}
	/**
	 *  If we have any changes which are not the result of a collection change,
	 *  return true. Similar to isDirty, but only ignores collection changes.
	 *
	 * @param  log TransactionLog The current transaction context
	 * @return
	 * @see  #isDirty
	 */
	public boolean containsAttributeChanges(final TransactionLog log)
	{
		ObjectModified[] iterator = getFieldMap(log);
		if(iterator != null)
		{
			for(int i = 0; i < iterator.length; ++i)
			{
				ObjectModified req = iterator[i];
				if(req != null)
				{
					if(!req.isCollection())
					{
						return true;
					}
				}
				else
				{
					//We are done at the first null

					return false;
				}
			}
		}
		return false;
	}
	/**
	 *  Pessimistically lock the object. Note that a thread calling lock() must
	 *  eventually call unlock(), to allow and waiting threads access to this
	 *  object. Failure to unlock this object will likely lead to stagnant threads,
	 *  a prime candidate for a deadlock situation. In short, always unlock the
	 *  object. This locking scheme is also reference-counted to accomodate the
	 *  rare scenario where a thread may lock an object several times: the object
	 *  remains locked until it has been unlocked the same number of times that it
	 *  has been locked.
	 *
	 * @param  wait boolean true if the current thread should wait until lock is
	 *  available. Otherwise return immediately.
	 * @return  boolean true if and only if the object was successfully locked.
	 */
	public boolean lock(boolean wait)
	{
		if(syncObject == null)
		{
			syncObject = getSyncObject();
		}
		synchronized(syncObject)
		{
			if(lockedBy() != null && lockedBy != Thread.currentThread())
			{
				if(!wait)
				{
					return false;
				}
				else
				{
					// This loop should not go on forever, assuming that threads who
					// lock do eventually unlock.
					//
					while(lockedBy != null)
					{
						try
						{
							syncObject.wait();
							// notify()'d when the object is unlocked()
						}
						catch(InterruptedException ex)
						{
							MessageLog.error(this, "ObjectEditor>>Lock XXXXX  I N T E R R U P T E D XXXXX" + lockedBy, ex);
							return false;
						}
					}
				}
			}
			refCount = 1;
			lockedBy = Thread.currentThread();
			return true;
		}
	}
	/**
	 * @return  java.lang.Thread
	 */
	public Thread lockedBy()
	{
		return lockedBy;
	}
	/**
	 *  Record that the TransactionalObject has been changed. The changes are
	 *  encapsulated in the ObjectChangeRequest object, and the Transaction in
	 *  which the change occurred is the the log.
	 *
	 * @param  log TransactionLog The current transaction context
	 * @param  mod
	 */
	public void markChange(final ObjectChangeRequest mod, final TransactionLog log)
	{
		if(verbose)
		{
			System.out.println("Changed : " + domainObject.getClass() + '@' + domainObject.hashCode());
		}

		log.addObject(this);

		ObjectModified[] list = getFieldMap(log);
		if(list == null)
		{
			list = ExpandingObjectModifiedArrayCache.getObjectModifiedFromCache();
			putFieldMap(log, list);
		}
		putMod(list, (ObjectModified) mod, log);
	}
	/**
	 *  Used by nested transactions. A subtransaction has been commited. Move the
	 *  sub transaction changes to the parent transaction.
	 *
	 * @param  log TransactionLog The current transaction context
	 * @param  newLog
	 */
	public synchronized void migrateChanges(final TransactionLog log, final TransactionLog newLog)
	{
		if(verbose)
		{
			System.out.println("Migrating " + domainObject.getClass().getName() + '@' + domainObject.hashCode() + " from " + log + " to " + newLog);
		}

		//A performance optimization. Relies heavily upon the way getFieldMap() & putFieldMap() are implemented.
		ObjectModified[] newList = null;
		if(log == singleLog)
		{
			if(objectMods != null)
			{
				newList = (ObjectModified[]) objectMods.get(newLog);
			}
			if(newList == null)
			{
				singleLog = newLog;
				newLog.addObject(this);
				//clearChanges(log, false); - No need to clear since I am replacing the singleLog reference
				lastLog = newLog;
				lastFieldMap = fieldToChangeMap;
				return;
			}
		}
		else
		{
			newList = getFieldMap(newLog);
		}

		//By passed optimization - A slightly more complex transaction is in progress
		ObjectModified[] list = getFieldMap(log);
		if(list == null)
		{
			return;
		}

		newLog.addObject(this);
		if(newList == null)
		{
			putFieldMap(newLog, list);
			newList = list;
		}
		else
		{
			for(int i = 0; i < list.length; ++i)
			{
				if(list[i] != null)
				{
					putMod(newList, list[i], newLog);
				}
			}
		}
		clearChanges(log, false);
		lastLog = newLog;
		lastFieldMap = newList;
	}
	/**
	 *  Undo any changes made to this object in the provided transaction.
	 *
	 * @param  log TransactionLog The current transaction context
	 * @param  forget
	 */
	public synchronized void rollback(TransactionLog log, boolean forget)
	{
		ObjectModified[] iterator = getFieldMap(log);
		if(iterator != null)
		{
			for(int i = 0; i < iterator.length; ++i)
			{
				ObjectModified req = iterator[i];
				if(req != null)
				{
					req.rollback();
				}
			}
		}
		if(forget)
		{
			clearChanges(log, true);
		}
	}
	/**
	 *  Unlock the pessimistically
	 */
	public void unlock()
	{
		if(syncObject == null)
		{
			syncObject = getSyncObject();
		}
		synchronized(syncObject)
		{
			// verify that the owner thread is the one doing the unlock.
			//
			if(lockedBy() != null && lockedBy == Thread.currentThread())
			{
				if(--refCount > 0)
				{
					return;
				}
				lockedBy = null;

				// Ensure that any 'naughty' threads stuck in setValue(...)
				// will eventually proceed, as well as polite threads waiting
				// in the lock() method.
				//
				syncObject.notifyAll();
			}
		}
	}
	/**
	 *  For the prodided transaction log, this provided list of changes exists. You
	 *  can't have two threads updating the field map at the same time.
	 *
	 * @param  log TransactionLog The transaction in progress.
	 * @param  list ObjectModified [] This list will hold the changes.
	 */
	protected final synchronized void putFieldMap(final TransactionLog log, final ObjectModified[] list)
	{
		if(singleLog == null)
		{
			singleLog = log;
			fieldToChangeMap = list;
			if(objectMods != null)
			{
				//May not happen, but just in case.

				objectMods.remove(log);
				lastLog = null;
			}
		}
		else
				if(log == singleLog)
		{
			fieldToChangeMap = list;
		}
		else
		{
			if(objectMods == null)
			{
				objectMods = new HashMap(15);
			}
			objectMods.put(log, list);
			lastLog = log;
			lastFieldMap = list;
		}
	}
	/**
	 *  protected final ObjectModified [] getFieldMap(final TransactionLog log) {
	 *  if(log == singleLog) return fieldToChangeMap; if(objectMods == null) return
	 *  null; return (ObjectModified [])objectMods.get(log); } protected
	 *  synchronized final void putFieldMap(final TransactionLog log, final
	 *  ObjectModified [] list) { if(singleLog == null) { singleLog = log;
	 *  fieldToChangeMap = list; } else if(log == singleLog) { fieldToChangeMap =
	 *  list; } else { if(objectMods == null) { objectMods = new HashMap(15); }
	 *  objectMods.put(log, list); } } Abstract the implementation of keeping track
	 *  of changes.
	 *
	 * @return
	 */
	protected final boolean noKnownLogs()
	{
		return objectMods == null && singleLog == null;
	}
	/**
	 *  Used by the persistent code to avoid the enumeration overhead
	 *
	 * @param  log TransactionLog The transaction in question.
	 * @return
	 */
	protected final ObjectModified[] quickChanges(TransactionLog log)
	{
		ObjectModified[] list = getFieldMap(log);
		if(list != null)
		{
			return list;
		}
		return new ObjectModified[0];
	}
	/**
	 *  Drop any changes associated with a specified transaction log.
	 *
	 * @param  releaseObjects boolean A true values indicates that ObjectModified
	 *  objects should be returned to the queue.
	 * @param  log TransactionLog The transaction in question.
	 */
	protected void clearChanges(final TransactionLog log, final boolean releaseObjects)
	{
		if(singleLog == log)
		{
			singleLog = null;
			if(releaseObjects)
			{
				returnObjects(fieldToChangeMap);
			}
			fieldToChangeMap = null;
		}
		else
				if(objectMods != null)
		{
			ObjectModified[] list = (ObjectModified[]) objectMods.remove(log);
			if(releaseObjects && list != null)
			{
				returnObjects(list);
			}
		}
		lastLog = null;
		lastFieldMap = null;
	}
	/**
	 * @param  log TransactionLog The current transaction context
	 * @param  list
	 * @param  mod
	 */
	protected final void putMod(final ObjectModified[] list, final ObjectModified mod, final TransactionLog log)
	{
		//insert the mod into the list
		Field field = mod.adapter;
		for(int i = 0; i < list.length; ++i)
		{
			if(list[i] == null)
			{
				list[i] = mod;
				return;
			}
			else
					if(list[i].adapter == field)
			{
				list[i].clean();
				if(list[i].returnThis())
				{
					ExpandingObjectModifiedCache.returnObjectModifiedToCache(list[i]);
				}
				list[i] = mod;
				return;
			}
		}
		//Had to grow the list
		ObjectModified[] tmp = new ObjectModified[list.length + 10];
		tmp[list.length] = mod;
		System.arraycopy(list, 0, tmp, 0, list.length);
		ExpandingObjectModifiedArrayCache.returnObjectModifiedToCache(list);
		putFieldMap(log, tmp);
	}
	/**
	 *  If the old value is a collection, we make a copy of it.
	 *
	 * @param  adapt
	 * @param  oldValue
	 * @return  Collection or null. NULL if the type is not a collection.
	 */
	Object perhapsCloneCollection(final Field adapt, final Object oldValue)
	{
		// Because the array may be modified, we must duplicate it and set it
		// as a new value.
		if(oldValue.getClass().isArray())
		{
			return cloneArray(oldValue, adapt);
		}
		//If this object is a collection, attempt to clone it.
		if(SupportedCollections.isCollection(oldValue))
		{
			Object newVal = SupportedCollections.cloneCollection(oldValue);
			if(newVal != oldValue)
			{
				set(adapt, newVal, oldValue);
			}
			return newVal;
		}
		return null;
	}
	/**
	 *  Copy the array when the 'get' method is invoked. This allows the object
	 *  editor to support rollbacks on arrays.
	 *
	 * @param  oldValue
	 * @param  adapt
	 * @return
	 */
	Object cloneArray(final Object oldValue, final Field adapt)
	{
		int length = Array.getLength(oldValue);
		Object newVal = Array.newInstance(oldValue.getClass().getComponentType(), length);
		for(int i = 0; i < length; i++)
		{
			Array.set(newVal, i, (Array.get(oldValue, i)));
		}
		set(adapt, newVal, oldValue);
		return newVal;
	}
	/**
	 */
	void waitForLock()
	{
		if(lockedBy() != null)
		{
			if(syncObject == null)
			{
				syncObject = getSyncObject();
			}
			synchronized(syncObject)
			{
				// This loop should not be forever: once notified, this thread
				// will eventually see lockedBy==null, assuming that the other
				// threads call unlock() as they oughta.
				//
				while(lockedBy != null && lockedBy != Thread.currentThread())
				{
					try
					{
						syncObject.wait();
					}
					catch(InterruptedException ex)
					{
					}
				}
			}
		}
	}
	/**
	 *  Return all objects in the array to the cache objects. Caching objects
	 *  improve performance and memory usage.
	 *
	 * @param  list
	 */
	private final void returnObjects(final ObjectModified[] list)
	{
		for(int i = 0; i < list.length; ++i)
		{
			if(list[i] == null)
			{
				ExpandingObjectModifiedArrayCache.returnObjectModifiedToCache(list);
				return;
				//Exit at first null.
			}

			list[i].clean();
			if(list[i].returnThis())
			{
				ExpandingObjectModifiedCache.returnObjectModifiedToCache(list[i]);
			}
			list[i] = null;
		}
		ExpandingObjectModifiedArrayCache.returnObjectModifiedToCache(list);
	}
	/**
	 * @author  dhoag
	 * @version  $Id: ObjectEditor.java,v 2.4 2002/03/23 13:42:11 dave_hoag Exp $
	 */
	public static class Test extends com.objectwave.test.UnitTestBaseImpl
	{
		String one;
		Vector v;
		Field adapt;
		Field collectionAdapt;
		/**
		 * @param  args The command line arguments
		 */
		public static void main(String[] args)
		{
			com.objectwave.test.TestRunner.run(new Test(), args);
		}
		/**
		 * @param  testName The new Up value
		 * @param  context The new Up value
		 * @exception  Exception
		 */
		public void setUp(String testName, com.objectwave.test.TestContext context) throws Exception
		{
			super.setUp(testName, context);

			TransactionLog.Test.reset();
			try
			{
				adapt = Test.class.getDeclaredField("one");
				collectionAdapt = Test.class.getDeclaredField("v");
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		/**
		 * @exception  UpdateException
		 */
		public void testOne() throws UpdateException
		{
			synchronized(TransactionLog.class)
			{
				TransactionLog.setUsingSessions(false);
				TransactionLog log = TransactionLog.startTransaction("newOne", "myContext");
				ExampleObject one = new ExampleObject();
				one.setTitle("title");
				testContext.assertTrue("Change not kept transactional", one.title == null);
				testContext.assertEquals("title", one.getTitle());
				TransactionLog sublog = TransactionLog.startTransaction("newOne", "myContext");
				ExampleObject two = new ExampleObject();
				two.setTitle("title");
				one.setALong(1203L);
//			two.title = "a forced change";
				sublog.commit();
				sublog = TransactionLog.startTransaction("newOne", "myContext");
				two = new ExampleObject();
				two.setTitle("title");
				one.setTitle("title2");
//			two.title = "a forced change";
				sublog.commit();
				try
				{
					log.commit();
				}
				catch(Exception t)
				{
					log.rollback();
				}

			}
		}
		/**
		 */
		public void testExceptions()
		{
			//Runtime.getRuntime().traceMethodCalls(true);
			try
			{
				synchronized(TransactionLog.class)
				{
					TransactionLog.setUsingSessions(false);

					TransactionLog log = TransactionLog.startTransaction("newOne", "myContext");
					ExampleObject one = new ExampleObject();
					one.setTitle("title");
					testContext.assertTrue("Change not kept transactional", one.title == null);
					testContext.assertEquals("title", one.getTitle());
					ExampleObject two = new ExampleObject();
					two.setTitle("title");
					two.title = "a forced change";
					try
					{
						log.commit();
						testContext.assertTrue("No exception thrown!!!", false);
					}
					catch(UpdateException ex)
					{
					}
					testContext.assertTrue("Change commited, even though exception failed.", one.title == null);
					testContext.assertEquals("title", one.getTitle());
					testContext.assertEquals("a forced change", two.title);
					log.rollback();
					testContext.assertTrue("Object value was wrong in the end.", one.getTitle() == null);
				}
			}
			finally
			{
				Runtime.getRuntime().traceMethodCalls(false);
			}
		}
		/**
		 */
		public void testChangeTypes()
		{
			synchronized(TransactionLog.class)
			{
				TransactionLog.setUsingSessions(false);
				TransactionalObjectAdapter obj = new TransactionalObjectAdapter();
				ObjectEditor oe = new ObjectEditor(obj);
				TransactionLog log = TransactionLog.startTransaction("newOne", "myContext");
				oe.setValue(adapt, "one", null);
				testContext.assertTrue("No Changes detected!", oe.containsAnyChanges());
				testContext.assertTrue("Attribute change not detected. ", oe.containsAttributeChanges(log));
				Vector v = oe.getCollectionChanges(log);
				testContext.assertTrue("Incorrect collection change detected. ", v.size() == 0);
				oe.getValue(collectionAdapt, new Vector(), log);
				v = oe.getCollectionChanges(log);
				testContext.assertTrue("Incorrect collection change detected. ", v.size() == 1);
				oe.setValue(adapt, null, null);
//This behavior is no longer supported.
//			testContext.assertTrue("Attribute Changes detected, when there should be none. ", ! oe.containsAttributeChanges(log));
				testContext.assertTrue("No Changes detected! Collection should be present.", oe.containsAnyChanges());
				log.rollback();
			}
		}
		/**
		 */
		public void testMigrateChanges()
		{
			synchronized(TransactionLog.class)
			{
				TransactionLog.setUsingSessions(false);
				TransactionalObjectAdapter obj = new TransactionalObjectAdapter();
				ObjectEditor oe = new ObjectEditor(obj);
				TransactionLog log = TransactionLog.startTransaction("newOne", "myContext");
				oe.setValue(adapt, "one", null);
				testContext.assertEquals("one", oe.getValue(adapt, null, log));
				TransactionLog secondLog = TransactionLog.startTransaction("anewOne", "myContext");
				testContext.assertTrue("No values set in subtransaction ", !oe.isDirty());
				oe.setValue(adapt, "two", null);
				testContext.assertTrue("Subtransaction is dirty, but not reported as such ", oe.isDirty());
				testContext.assertEquals("one", oe.getValue(adapt, null, log));
				testContext.assertEquals("two", oe.getValue(adapt, null, secondLog));
				try
				{
					secondLog.commit();
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
				//The commit has changed the previous transactional value to be "two" instead of "one"
				testContext.assertEquals("two", oe.getValue(adapt, null, log));
				log.rollback();
			}
		}
		/**
		 */
		public void testDuplicateSets()
		{
			synchronized(TransactionLog.class)
			{
				TransactionLog.setUsingSessions(false);
				TransactionalObjectAdapter obj = new TransactionalObjectAdapter();
				ObjectEditor oe = new ObjectEditor(obj);
				TransactionLog log = TransactionLog.startTransaction("newOne", "myContext");
				oe.setValue(adapt, "one", "one");
//This behavior is no longer supported.
//			testContext.assertTrue("Changes detected when new value == old value.", ! oe.containsAnyChanges());
				oe.setValue(adapt, "one", "orig");
				testContext.assertTrue("No Changes detected!", oe.containsAnyChanges());
				oe.setValue(adapt, null, null);
//This behavior is no longer supported.
//			testContext.assertTrue("Changes detected when setting object back to orig value.", ! oe.containsAnyChanges());
				log.rollback();
			}
		}
		/**
		 */
		public void testContainsChanges()
		{
			synchronized(TransactionLog.class)
			{
				TransactionLog.setUsingSessions(false);
				TransactionalObjectAdapter obj = new TransactionalObjectAdapter();
				ObjectEditor oe = new ObjectEditor(obj);
				TransactionLog log = TransactionLog.startTransaction("newOne", "myContext");
				testContext.assertTrue("Changes detected when there should be none.", !oe.containsAnyChanges());
				oe.setValue(adapt, "one", null);
				testContext.assertTrue("No Changes detected!", oe.containsAnyChanges());
				log.rollback();
				testContext.assertTrue("Changes detected when there should be none.", !oe.containsAnyChanges());
			}
		}
		/**
		 */
		public void testChanges()
		{
			synchronized(TransactionLog.class)
			{
				TransactionLog.setUsingSessions(false);
				TransactionalObjectAdapter obj = new TransactionalObjectAdapter();
				ObjectEditor oe = new ObjectEditor(obj);
				TransactionLog log = TransactionLog.startTransaction("newOne", "myContext");
				ObjectModified om = new ObjectModified();
				om.initObjectModified(adapt, obj, "one", null);
				oe.markChange(om, log);
				Enumeration e = oe.changes(log);
				int count = 0;
				while(e.hasMoreElements())
				{
					testContext.assertEquals(om, e.nextElement());
					count++;
				}
				log.rollback();
				testContext.assertEquals("Incorrect number of changes", 1, count);
			}
		}
		/**
		 */
		public void testQuickChanges()
		{
			synchronized(TransactionLog.class)
			{
				TransactionLog.setUsingSessions(false);
				TransactionalObjectAdapter obj = new TransactionalObjectAdapter();
				ObjectEditor oe = new ObjectEditor(obj);
				TransactionLog log = TransactionLog.startTransaction("newOne", "myContext");
				ObjectModified om = new ObjectModified();
				om.initObjectModified(adapt, obj, "one", null);
				oe.markChange(om, log);
				ObjectModified[] e = oe.quickChanges(log);
				int count = 0;
				while(e[count] != null)
				{
					testContext.assertEquals(om, e[count]);
					count++;
				}
				log.rollback();
				testContext.assertEquals("Incorrect number of changes", 1, count);
			}
		}
		/**
		 */
		public void testPrimitives()
		{
			synchronized(TransactionLog.class)
			{
				TransactionLog.setUsingSessions(false);
				TransactionalObjectAdapter obj = new TransactionalObjectAdapter();
				ObjectEditor oe = new ObjectEditor(obj);
				TransactionLog log = TransactionLog.startTransaction("newOne", "myContext");
				short sh = 10;
				oe.set(adapt, sh, (short) 0);
				testContext.assertEquals("getValue Primitive short failed.", sh, ((Short) oe.getValue(adapt, new Short((short) 0), log)).shortValue());
				TransactionLog.setContext("myContext");
				testContext.assertEquals("Get Primitive short failed.", sh, oe.get(adapt, (short) 0));
				int in = 11;
				oe.set(adapt, in, (int) 0);
				testContext.assertEquals("Get Primitive int failed.", in, oe.get(adapt, 0));
				long lg = 12;
				oe.set(adapt, lg, 0L);
				testContext.assertEquals("Get Primitive long failed.", lg, oe.get(adapt, 0L));
				byte bt = 2;
				oe.set(adapt, bt, (byte) 0);
				testContext.assertEquals("Get Primitive byte failed.", bt, oe.get(adapt, (byte) 0));
				boolean bl = true;
				oe.set(adapt, bl, false);
				testContext.assertTrue("Get Primitive boolean failed.", oe.get(adapt, (boolean) false));
				char ch = ';';
				oe.set(adapt, ch, 'f');
				testContext.assertEquals("Get Primitive char failed.", ch, oe.get(adapt, 'f'));
				float ft = (float) 2.1;
				oe.set(adapt, ft, (float) 0);
				testContext.assertEquals("Get Primitive float failed.", ft, oe.get(adapt, (float) 0), 0.0);
				double db = 2.42;
				oe.set(adapt, db, 0.0);
				testContext.assertEquals("Get Primitive double failed.", db, oe.get(adapt, 0.0), 0.0);

				ExampleObject aobj = new ExampleObject();
				oe.set(collectionAdapt, aobj, null);
				ExampleObject nullObject = null;
				testContext.assertEquals("Get Object failed.", aobj, oe.get(collectionAdapt, nullObject));

				log.rollback();
			}
		}
		/**
		 */
		public void testSetValue()
		{
			synchronized(TransactionLog.class)
			{
				TransactionLog.setUsingSessions(false);
				TransactionalObjectAdapter obj = new TransactionalObjectAdapter();
				ObjectEditor oe = new ObjectEditor(obj);
				TransactionLog log = TransactionLog.startTransaction("newOne", "myContext");
				oe.setValue(adapt, "one", null);
				testContext.assertEquals("The result from getValue is wrong!", "one", oe.getValue(adapt, null, log));
				testContext.assertEquals(log, TransactionLog.getCurrentInstance());
				testContext.assertEquals("The result from get is wrong!", "one", oe.get(adapt, null));
				TransactionLog secondLog = TransactionLog.startRootTransaction("anewOne", "anotherContext");
				testContext.assertTrue("Should be a null value", oe.getValue(adapt, null, new TransactionLog()) == null);
				oe.setValue(adapt, "two", null);
				testContext.assertEquals("one", oe.getValue(adapt, null, log));
				testContext.assertEquals("two", oe.getValue(adapt, null, secondLog));
				log.rollback();
				secondLog.rollback();
			}
		}
		/**
		 */
		public void testMarkChange()
		{
			synchronized(TransactionLog.class)
			{
				TransactionLog.setUsingSessions(false);
				TransactionalObjectAdapter obj = new TransactionalObjectAdapter();
				ObjectEditor oe = new ObjectEditor(obj);
				//		TransactionLog log = TransactionLog.getNewTransaction("newOne");
				TransactionLog log = TransactionLog.startTransaction("newOne", "myContext");
				ObjectModified om = new ObjectModified();
				om.initObjectModified(adapt, obj, "one", null);
				oe.markChange(om, log);
				testContext.assertEquals("one", oe.getValue(adapt, "old", log));
				log.rollback();
				testContext.assertTrue("Should be null! " + oe.getValue(adapt, null, log), oe.getValue(adapt, null, log) == null);
			}
		}
	}
	/**
	 *  A Helper class that lets me keep the Enumeration as the changes return type
	 *
	 * @author  dhoag
	 * @version  $Id: ObjectEditor.java,v 2.4 2002/03/23 13:42:11 dave_hoag Exp $
	 */
	class EmptyEnumeration implements Enumeration
	{
		Object[] iterator;
		int current = 0;
		/**
		 *  Constructor for the EmptyEnumeration object
		 *
		 * @param  it
		 */
		public EmptyEnumeration(Object[] it)
		{
			iterator = it;
		}
		/**
		 * @return
		 */
		public boolean hasMoreElements()
		{
			if(iterator == null)
			{
				return false;
			}
			else
			{
				if(current < (iterator.length))
				{
					return iterator[current] != null;
				}
				return false;
			}
		}
		/**
		 * @return
		 */
		public Object nextElement()
		{
			return iterator[current++];
		}
	}
}
