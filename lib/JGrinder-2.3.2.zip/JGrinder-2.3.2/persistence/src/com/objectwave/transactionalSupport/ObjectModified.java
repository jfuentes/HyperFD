package com.objectwave.transactionalSupport;

import java.lang.reflect.Field;
import java.util.Vector;
import java.util.Hashtable;

/**
 * The details of a change to a particular object.
 * Every change will create an ObjectModified object.
 * There will be only one ObjectModified instance per attribute per transaction.
 *
 * Only 1 thread will be calling get and set with this class.
 *
 * @version 2.4
 */
public class ObjectModified implements ObjectChangeRequest
{
	Field adapter;
	Object oldValue;
	Object newValue;
	TransactionalObjectIF domainObject;
	boolean collection;
	//* If I cause the exception, then I do not want to change my object back to its original value!
	boolean iCommited = false;
	final Field [] fields = new Field [1];
	final Object [] data = new Object [1];
	final Class stringClass = String.class;
	/**
	 * Store the changes to the domain object.
	 *
	 * @param adapt The java.lang.Field object for which this object will track changes.
	 * @param theInstance The transactional object for which this instance is keeping changes.
	 * @param newVal The new value in this field. This will be the value returned by currentValue().
	 * @param old The value in the domain object when this change was made.
	 */
	protected ObjectModified()
	{
	}
	/** A workaround for a small problem */
	public boolean returnThis()
	{
		return true;
	}
	/**
	 */
	protected void clean()
	{
		adapter = null;
		fields [0] = null;
		oldValue = null;
		newValue = null;
		domainObject = null;
		collection = false;
		iCommited = false;
	}
	/**
	 * Set the changed values.
	 */
	protected void initObjectModified(final Field adapt, final TransactionalObjectIF theInstance,  final Object newVal, final Object old)
	{
		if(adapt == null) throw new RuntimeException();
		adapter = adapt;
		fields [0] = adapter;
		oldValue = old;
		newValue = newVal;
		domainObject = theInstance;
		Class adapterType = adapter.getType();
		if( ! (adapterType == stringClass || adapterType.isPrimitive()))
		{ //Not a string or a primitive
			if(adapterType.isArray())
			{
				collection = true;
			}
			else
			{
				Object notNullObject;
				if(oldValue != null) notNullObject = oldValue;
				else if(newValue != null) notNullObject = newValue;
				else return;
				collection = SupportedCollections.isCollection(notNullObject);
			}
		}
	}
	/**
	* Place the new value into the domain object.  Prior to updating the domain object
	* we validate that no one else has updated this particular field in the domain
	* object. If someone has, an UpdateException will be thrown.
	* @param force Override the default behavior of checking if the object has changed.
	* @exception UpdateException
	*/
	public void commit(final boolean force) throws UpdateException
	{
		try
		{
			Object obj = get();
			if(obj != oldValue) //Theyre not same object
			{
				//Fail if the current value is null || if the current value is not equal to the stored value
				final boolean fail = (obj == null) || (! obj.equals(oldValue));
				if(! force && fail)
				{
					throw new UpdateException("\nIn " + domainObject + " Value for " + adapter.getName() + " modified.  expected: '" + oldValue + "' found: '" +  obj + '\'');
				}
			}
			set( newValue);
			iCommited = true;
		}
		catch (RuntimeException e)
		{
			throw new UpdateException("\nIn " + domainObject + "\n" + adapter.getName() + e);
		}
	}
	/**
	* @return Object The 'current' value of the Object. This is NOT actually what value
	* is found in the domain object. Rather what the value will be when the change is
	* committed.
	*/
	public Object currentValue(){ return newValue; }
	/**
	* Get the current value in the domain object represented by the field
	* for which this object represents.
	* Only 1 thread will be calling get and set with this class.
	*/
	Object get()
	{
		if(adapter.isAccessible())
		{
			try
			{
				return adapter.get(domainObject);
			}
			catch(Exception e) { e.printStackTrace(); }
			return null;
		}
		else
		{
			domainObject.update(true, data, fields);
			Object obj = data[0];
			data[0] = null;
			return obj;
		}
	}
	/**
	* @return java.lang.Field object in which this change occurred.
	*/
	public final Field getAccessor(){ return adapter;  }
	/**
	* Is this field representing an Array, Hashtable, or a Vector?
	*/
	public boolean isCollection(){ return collection; }
	/**
	* @return Object value found in the domain object when this change occurred.
	*/
	public Object originalValue(){ return oldValue; }
	/**
	* Change the domain object to contain the 'old' value.
	* There is nothing to rollback if I did not commit.
	*/
	public void rollback(){ if(iCommited) set( oldValue);  }
	/**
	* Update the domain object to contain the 'value' at the field for this object.
	* Only 1 thread will be calling get and set with this class.
	* @param value The value do place in the field.
	*/
	void set(Object value)
	{
		if(adapter.isAccessible())
		{
			try
			{
				adapter.set(domainObject, value);
			}
			catch(Exception e) { e.printStackTrace(); }
		}
		else
		{
			data [0] = value;
			domainObject.update(false, data, fields);
			data[0] = null;
		}

	}
	public static class Test extends com.objectwave.test.UnitTestBaseImpl
	{
		int number;
		int setNum;
		/**
		 */
		public static void main(String [] args)
		{
			com.objectwave.test.TestRunner.run(new Test(), args);
		}
		/**
		 *
		 */
		public void testCommitChanges() throws UpdateException, NoSuchFieldException, IllegalAccessException
		{
			number = 10;
			ObjectModified mod = new ObjectModified()
			{
				Object get(){ return new Integer(number); }
				void set(Object obj){ setNum = Integer.parseInt(obj.toString()); }
			};
			mod.adapter = Test.class.getDeclaredField("number");
			mod.newValue = new Integer(312);
			mod.oldValue = new Integer(30);
			try
			{
				mod.commit(false);
				testContext.assertTrue("Excpected exception, but none occured. ", false);
			}
			catch(UpdateException ex) { }
			mod.oldValue = new Integer(10);
			mod.commit(false);
			testContext.assertEquals(312, setNum);

			mod.oldValue = new Integer(312);
			mod.newValue = new Integer(31);
			mod.commit(true);
			testContext.assertEquals(31, setNum);
		}
	}
}
