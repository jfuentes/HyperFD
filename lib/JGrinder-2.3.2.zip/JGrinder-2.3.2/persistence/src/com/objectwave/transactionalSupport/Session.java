package com.objectwave.transactionalSupport;

import com.objectwave.transactionalSupport.test.*;
import java.util.*;
/**
 *  A utility class to allow multiple threads share a single transaction
 *  context. All synchronization issues must explictly be handled by the
 *  developer. An easy way to use sessions is to use the static
 *  Session.createAndJoin(String name) method.
 *
 * @author  dhoag
 * @version  $Id: Session.java,v 2.2 2002/03/23 13:42:11 dave_hoag Exp $
 * @see  #createAndJoin(String)
 */
public class Session
{

	/**
	 * If one child session is rolled back, the other children will still
	 * commit.
	 */
	public final static int PARALLEL_IGNORE_SIBLINGS = 0;
	/**
	 * If one child session is rolled back, all will be set to
	 * rollback only and will not commit.
	 */
	public final static int PARALLEL_ROLLBACK_SIBLINGS = 1;
	String name;
	//Support wrappers
	Object wrap;
	TransactionLog currentTransaction;
	/**
	 * The rollback policy for a PARALLEL transaction
	 */
	int parallelRollbackPolicy = PARALLEL_IGNORE_SIBLINGS;
	/**
	 * This session's Parent Session.  This is used for parallel transactions
	 */
	Session parentSession = null;
	/**
	 * This is a list of child sessions for this session.  This is used for
	 * parallel transaction support
	 */
	Vector childSessions = new Vector();
	/**
	 * Allows the session to be marked as rollback only such that any changes
	 * to objects will be rolledback when commit is called.
	 */
	boolean rollbackOnly = false;
	/**
	 *  Session can have names. The name is just an arbitraty data type that may
	 *  help with debugging. Session is not necessarily created via the
	 *  constructor. An easy way to use sessions is to use the static
	 *  Session.createAndJoin(String name) method.
	 *
	 * @param  name
	 * @see  #createAndJoin(String)
	 */
	public Session(String name)
	{
		this.name = name;
	}
	/**
	 *  Session is not necessarily created via the constructor. An easy way to use
	 *  sessions is to use the static Session.createAndJoin(String name) method.
	 *
	 * @see  #createAndJoin(String)
	 */
	protected Session()
	{
		super();
	}
	/**
	 *  A convience method for creating and joining a session in one step. It is
	 *  currently possible to create multiple sessions with the same name. Care
	 *  should be taken by the developer to manage session instances. In the event
	 *  a session instance is 'lost', the session for the current thread can be
	 *  obtained via SessionManager.getSession();
	 *
	 * @param  name java.lang.String
	 * @return  com.objectwave.transactionalSupport.Session
	 * @author  Dave Hoag
	 */
	public static Session createAndJoin(String name)
	{
		Session ses = SessionManager.getDefaultManager().create(name);
		ses.join();
		return ses;
	}
	/**
	 *  Creates a ParallelMaster session with the given name and
	 *  the given parallelRollbackPolicy.
	 *  #see    parallelRollbackPolicy
	 *  #see    createParallelMaster(String)
	 *
	 * @param  name
	 * @param  parallelPolicy
	 * @return
	 */
	public static Session createParallelMaster(String name, int parallelPolicy)
	{
		Session session = createParallelMaster(name);
		session.parallelRollbackPolicy = parallelPolicy;
		return session;
	}
	/**
	 * This has been added simply for the uniformity of the API.
	 *
	 * @param  name The name of the session to create
	 * @return
	 * @see  #createAndJoin(String)
	 */
	public static Session createParallelMaster(String name)
	{
		return Session.createAndJoin(name);
	}
	/**
	 * This will create a parallel child with a name that is constructed
	 * from the parent name.  This DOES NOT join this session to the
	 * thread.  It is the responsiblity of the client code to properly
	 * associate it's child session to the thread it will run in.
	 *
	 * @param  parentSession
	 * @return
	 * @see  #createParallelChild(String, Session)
	 */
	public static Session createParallelChild(Session parentSession)
	{
		String parentName = parentSession.getName();
		String childName = parentName + " - child (" + parentSession.getChildSessionCount() + ")";
		return Session.createParallelChild(childName, parentSession);
	}
	/**
	 * Creates a child session for a parallel master with the given name and
	 * master session.
	 *
	 * @param  name
	 * @param  parentSession
	 * @return
	 */
	public static Session createParallelChild(String name, Session parentSession)
	{
		//System.out.println("Session::createParallelChild name=" + name + ", enter");
		Session ses = SessionManager.getDefaultManager().create(name);
		ses.setParentSession(parentSession);
		//System.out.println("Session::createParallelChild name=" + name + ", exit");
		return ses;
	}
	/**
	 * Sets the parent session of a session and adds the child to the parent
	 * in one step.
	 *
	 * @param  parentSession The parent session of the current session
	 * @see  #parentSession
	 * @see  #addChildSession(Session)
	 */
	public void setParentSession(Session parentSession)
	{
		this.parentSession = parentSession;
		this.parentSession.addChildSession(this);
	}
	/**
	 *  This method notifies a parent session that a child has
	 *  rolled back.  It is then determined by the parallel transaction
	 *  policy what is done with the other children of this transaction.
	 *
	 * @param  childSession The new ChildRolledBack value
	 * @see  parallelRollbackPolicy
	 * @see  #setRollbackOnly()
	 */
	public void setChildRolledBack(Session childSession)
	{
		//System.out.println("Session::setRollbackOnly SESSION:" + this.hashCode());
		// depending on the policy here, either notify the children to roll
		// back or let them continue;  If it's PARALLEL_IGNORE_SIBLINGS
		// then just rollback that child but let the other children update.
		if(this.parallelRollbackPolicy == this.PARALLEL_IGNORE_SIBLINGS)
		{
			return;
		}
		for(int i = 0; i < this.childSessions.size(); i++)
		{
			Session cs = (Session) childSessions.get(i);
			if(cs != childSession)
			{
				cs.setRollbackOnly();
			}
		}
	}
	/**
	 * Set a flag to cause this to be rollback only.  When this session is
	 * commited, the current transaction will rollback.
	 */
	public void setRollbackOnly()
	{
		this.rollbackOnly = true;
	}
	/**
	 * @param  newValue java.lang.Object
	 * @author  Dave Hoag
	 */
	public void setWrap(Object newValue)
	{
		this.wrap = newValue;
	}
	/**
	 *  Only the transactionalSupport.TransactionLog should use this method. Don't
	 *  use.
	 *
	 * @param  log The new CurrentTransaction value
	 */
	protected void setCurrentTransaction(final TransactionLog log)
	{
		currentTransaction = log;
	}
	/**
	 * Returns the number of child sessions currently associated to this
	 * session.
	 *
	 * @return  The ChildSessionCount value
	 */
	public int getChildSessionCount()
	{
		return this.childSessions.size();
	}
	/**
	 *  It is probably better to use the commit(), rollback(), and
	 *  startTransaction(String) methods rather than manually manipulating the
	 *  transaction. Used to obtain the transaction for the specified session.
	 *
	 * @return  The CurrentTransaction value
	 */
	public synchronized TransactionLog getCurrentTransaction()
	{
		return currentTransaction;
	}
	/**
	 *  All of the threads in the current session. This is merely a snapshot at the
	 *  time the method is invoked. An additional thread may join, or an existing
	 *  thread may leave, by the time the calling method does anything with the
	 *  result set.
	 *
	 * @return  java.util.Vector of Threads that have joined this session. No
	 *  longer supported public java.util.Vector getMembers() { return
	 *  SessionManager.getDefaultManager().getMembers(this); }
	 * @author  Dave Hoag
	 */
	public String getName()
	{
		return name;
	}
	/**
	 * @return  java.lang.Object
	 * @author  Dave Hoag
	 */
	public Object getWrap()
	{
		return wrap;
	}
	/**
	 * Adds a child session explicitly to this session.  This is done
	 * for you if you call childSession.setParent(parentSession); If a
	 * parent session has children, it's call to commit will block until
	 * all children have been removed.  Via their commit() or rollback() calls
	 *
	 * @param  s The child session to be added to this parent
	 */
	public void addChildSession(Session s)
	{
		//System.out.println("Session::addChildSession enter");
		this.childSessions.add(s);
		//System.out.println("Session::addChildSession size=" + childSessions.size());
		//System.out.println("Session::addChildSession exit");
	}
	/**
	 * Removes a child session from this parent session.  See addChildSession
	 * for information about blocking on the parent's commit() call
	 *
	 * @param  s The child session to remove.
	 */
	public void removeChildSession(Session s)
	{
		//System.out.println("Session::removeChildSession enter");
		this.childSessions.remove(s);
		//System.out.println("Session::removeChildSession size=" + childSessions.size());
		//System.out.println("Session::removeChildSession exit");
	}
	/**
	 *  Commit any changes made during this transaction.
	 *
	 * @exception  UpdateException
	 * @author  Dave Hoag
	 */
	public synchronized void commit() throws UpdateException
	{
		// this chunk of code blocks until all children sessions
		// have been commited or rolled back.  Rolling back or
		// committing a child session actually removes the session
		// from it's parent.
		while(childSessions.size() > 0)
		{
			//System.out.println("sessions.size() = " + childSessions.size());
			try
			{
				Thread.currentThread().sleep(1000);
			}
			catch(Exception e)
			{
			}
		}

		// properly handle child sessions
		if(parentSession != null)
		{
			//System.out.println("Roll changes to parent transsaction");
			TransactionLog parentTransaction = parentSession.currentTransaction;
			//System.out.println("Parent TX:" + parentTransaction.hashCode());
			// copy changes from the child session (this) to it's parent session
			if(!rollbackOnly)
			{
				// commit the TX
				currentTransaction.migrateChangesTo(parentTransaction);
				parentSession.removeChildSession(this);
			}
			else
			{
				// rollback the TX
				//System.out.println("Session::commit child rollback SESSION: " + this.hashCode());
				parentSession.removeChildSession(this);
				rollback();
			}
			//System.out.println("parent child count:" + parentSession.childSessions.size());
			return;
		}
		//----------------------------------------------------------------------
		// this following block is really for top level (non - parallel - children)
		// commits.  The above code should probably be refactored to a childCommit
		// or somewhere.
		//System.out.println("Session::commit enter");
		if(rollbackOnly)
		{
			// roll back if this session has been marked as rollback only
			this.rollback();
			return;
		}
		if(SessionManager.getDefaultManager().getSession() != this)
		{
			throw new RuntimeException("CommitFailed: Current Thread is not a member of this session.");
		}
		if(getCurrentTransaction() == null)
		{
			throw new UpdateException("No transaction in progress.");
		}
		getCurrentTransaction().commit(this);
		//System.out.println("Session::commit exit");
	}
	/**
	 *  Have the current thread join this session. If the current thread was
	 *  already in a session, it will leave that session.
	 */
	public void join()
	{
		SessionManager.getDefaultManager().join(this);
	}
	/**
	 *  Have the current thread leave a session. This is not required, however, it
	 *  is nice for garbage collection.
	 */
	public void leave()
	{
		SessionManager.getDefaultManager().leave();
	}
	/**
	 *  Undo any changes that this transaction has made to the
	 *  TransactionalObjects.
	 *
	 * @author  Dave Hoag
	 */
	public synchronized void rollback()
	{
		// if this is a parallel child session, tell the parent that it cna
		// only roll back.
		if(parentSession != null)
		{
			parentSession.removeChildSession(this);
			parentSession.setChildRolledBack(this);
		}

		if(SessionManager.getDefaultManager().getSession() != this)
		{
			throw new RuntimeException("RollbackFailed: Current Thread is not a member of this session.");
		}
		getCurrentTransaction().rollback(this);

		// reset to be able to reuse the session?  Not sure if this is necessary
		rollbackOnly = false;
	}
	/**
	 *  Start a root or subtransaction. This is not the same as a database begin. A
	 *  transaction log will be created to capture changes made during this
	 *  transaction. If a transaction is already in progress, the transaction
	 *  started via this command will be a subtransaction.
	 *
	 * @param  transactionType
	 */
	public synchronized void startTransaction(String transactionType)
	{
		if(SessionManager.getDefaultManager().getSession() != this)
		{
			throw new RuntimeException("StartFailed: Current Thread is not a member of this session.");
		}
		TransactionLog log = getCurrentTransaction();
		//For this thread, is there a transaction?
		if(log != null)
		{
			TransactionLog.startTransaction(transactionType, this, log);
		}
		else
		{
			TransactionLog.startRootTransaction(transactionType, this);
		}
	}
	/**
	 * @return
	 */
	public String toString()
	{
		StringBuffer sb = new StringBuffer();
		sb.append("---------------------------------------------");
		sb.append("\nSession Name : " + this.name);
		sb.append("\nSession, hashCode:" + this.hashCode());
		sb.append("\nChildren : " + this.childSessions.size());
		sb.append("\nParent Session HashCode:" + (parentSession != null ? String.valueOf(parentSession.hashCode()) : "n/a"));
		sb.append("---------------------------------------------");
		return sb.toString();
	}
	/**
	 *  Unit Tests
	 *
	 * @author  dhoag
	 * @version  $Id: Session.java,v 2.2 2002/03/23 13:42:11 dave_hoag Exp $
	 */
	public static class Test extends com.objectwave.test.UnitTestBaseImpl
	{
		boolean release = false;
		/**
		 *  The main program for the Test class
		 *
		 * @param  args The command line arguments
		 */
		public static void main(String[] args)
		{
			com.objectwave.test.TestRunner.run(new Test(), args);
		}
		/**
		 *  The JUnit setup method
		 *
		 * @param  testName The new Up value
		 * @param  context The new Up value
		 * @exception  Exception
		 */
		public void setUp(String testName, com.objectwave.test.TestContext context) throws Exception
		{
			super.setUp(testName, context);
			if(testName.equals("testMultipleSessions"))
			{
				release = false;
			}
		}
		/**
		 *  A unit test for JUnit
		 */
		public void testJoinAndLeave()
		{
			Session ses = Session.createAndJoin("afsd");
			Session managedSession = SessionManager.getDefaultManager().getSession();
			testContext.assertEquals("Failed to locate session in session manager", ses, managedSession);
			SessionManager.getDefaultManager().leave();
			managedSession = SessionManager.getDefaultManager().getSession();
			testContext.assertTrue("Session did not leave!", managedSession == null);
			ses.join();
			managedSession = SessionManager.getDefaultManager().getSession();
			testContext.assertEquals("Failed to locate session after a join", ses, managedSession);
		}
		/**
		 *  A unit test for JUnit
		 */
		public void testMultipleSessions()
		{
			try
			{
				Session ses = Session.createAndJoin("afsd");
				ses.startTransaction("one");
				final Test synch = this;
				Runnable r =
					new Runnable()
					{
						/**
						 *  Main processing method for the Test object
						 */
						public void run()
						{
							try
							{
								Session ses2 = Session.createAndJoin("afsd");
								Session.Test.this.assertTrue("New thread is not in its own Session!", ses2.getCurrentTransaction() == null);
								ses2.startTransaction("one");
								Session.Test.this.assertTrue("No second transaction started!", ses2.getCurrentTransaction() != null);
								ses2.rollback();
								Session.Test.this.assertTrue("Transaction not cleared!", ses2.getCurrentTransaction() == null);
							}
							finally
							{
								release = true;
								synchronized(synch)
								{
									synch.notifyAll();
								}
							}
						}
					};
				Thread t = testContext.getNewThread(r);
				t.start();
				synchronized(synch)
				{
					try
					{
						while(!release)
						{
							wait();
						}
					}
					catch(InterruptedException ex)
					{
					}
				}
				ses.commit();
				assertTrue("Transaction not cleared!", ses.getCurrentTransaction() == null);
			}
			catch(Exception e)
			{
				assertTrue(e.toString(), false);
			}
		}
		/**
		 *  A unit test for JUnit
		 */
		public void testNestedTransactions()
		{
			try
			{
				Session ses = Session.createAndJoin("afsd");
				ses.startTransaction("one");
				TransactionLog log = ses.getCurrentTransaction();
				assertTrue("No transaction started!", ses.getCurrentTransaction() != null);
				ses.startTransaction("one");

				assertTrue("Transactions have not been indicated when using sessions!", TransactionLog.hasTransactions());

				assertTrue("Sub transaction not started!", ses.getCurrentTransaction() != log);

				ses.commit();
				assertTrue("Lost original transaction!", ses.getCurrentTransaction() == log);
				ses.commit();
				assertTrue("Transaction not cleared!", ses.getCurrentTransaction() == null);

				assertTrue("HasTransactions indicated true when there are none!", !TransactionLog.hasTransactions());

				ses.startTransaction("two");
				log = ses.getCurrentTransaction();
				assertTrue("No transaction started! two ", ses.getCurrentTransaction() != null);
				ses.startTransaction("two");
				assertTrue("Sub transaction not started! two", ses.getCurrentTransaction() != log);
				ses.rollback();
				assertTrue("Lost original transaction! two", ses.getCurrentTransaction() == log);
				ses.rollback();
				assertTrue("Transaction not cleared! two", ses.getCurrentTransaction() == null);

				assertTrue("HasTransactions indicated true when there are none!", !TransactionLog.hasTransactions());

			}
			catch(Exception e)
			{
				assertTrue(e.toString(), false);
			}
		}
		/**
		 * @param  str
		 * @param  b
		 */
		protected void assertTrue(String str, boolean b)
		{
			testContext.assertTrue(str, b);
		}
	}
}
