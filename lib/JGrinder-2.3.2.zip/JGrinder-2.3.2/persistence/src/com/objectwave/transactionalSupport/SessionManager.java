package com.objectwave.transactionalSupport;

import java.util.*;
/**
 * Used to manage multiple threads.
 * It is probably better for the application programmer to use the convience methods on Session
 * rather than referencing this singleton object.
 *
 * @see com.objectwave.transactionalSupport.Session
 * @version 2.2 March 2000
 */
public class SessionManager
{
	static SessionManager instance;
	static
	{
		synchronized (SessionManager.class)
		{
			if(instance == null)
				instance = new SessionManager();
		}
	}
	ThreadLocal sessionContext;
	public SessionManager()
	{
		sessionContext = new ThreadLocal();
	}
	/**
	* Create a new session object with the provided name.
	* Update transaction log to be aware that Sessions are being used to manage transactions.
	*/
	public Session create(String name)
	{
		TransactionLog.setUsingSessions(true);
		return new Session(name);
	}
	/**
	* @return SessionManager The singleton instance.
	*/
	public final static SessionManager getDefaultManager()
	{
		return instance;
	}
	/**
	* Get the session associated with the current thread.
	* Useful if you have lost a reference to the current session.
	*/
	public Session getSession()
	{
		return (Session)sessionContext.get();
	}
	/**
	* Have the current thread join the session provided by the parameter.
	*/
	protected void join(final Session s)
	{
		sessionContext.set(s);
	}
	/**
	 * @deprecated - Only the current thread can join a session, nobody can do it for you.
	 */
	protected void join(final Thread d, final Session s)
	{
		throw new RuntimeException("Operation not supported");
		//sessionContext.set(d, s);
	}
	/**
	 * Have the current thread leave the session.
	 * This will have an effect upon the transactional view of the thread.
	 */
	public void leave()
	{
		sessionContext.set(null);
	}
	//The following is used when performing unit testing.
//	com.objectwave.appArch.organization.ActorProfile prof = new com.objectwave.appArch.organization.ActorProfile();
	/* used for unit testing */
	/*
	static Runnable getNotNiceRunnable()
	{
		return new Runnable()
		{
			public void run()
			{
				SessionManager.getDefaultManager().prof.setName("TwoDave");
				for (int i = 0; i < 10; i++)
				{
					System.out.println("Two" + SessionManager.getDefaultManager().prof.getName());
					try {
					Thread.currentThread().sleep(100);
					} catch (InterruptedException ex) {}
				}
			};
		};
	}
	*/
	/* used for unit testing */
	/*
	static Runnable getRunnable()
	{
		return new Runnable()
		{
			public void run()
			{
				Session ses = SessionManager.getDefaultManager().create("two");
				ses.join();
				ses.startTransaction(null);
				SessionManager.getDefaultManager().prof.setName("TwoDave");
				for (int i = 0; i < 10; i++)
				{
					System.out.println("Two " + SessionManager.getDefaultManager().prof.getName());
					try {
					Thread.currentThread().sleep(10);
					} catch (InterruptedException ex) {}
				}
				try {
					ses.getCurrentTransaction().commit();
				} catch( UpdateException e) { System.out.println("TEWO" + e+ "TWOEND"); }
			};
		};
	}
	*/
	/* used for unit testing */
  /*
	static Runnable getShareRunnable()
	{
		return new Runnable()
		{
			public void run()
			{
				for (int i = 0; i < 5; i++)
				{
					System.out.println("Two" + SessionManager.getDefaultManager().prof.getName());
					try {
					Thread.currentThread().sleep(10);
					} catch (InterruptedException ex) {}
				}
				SessionManager.getDefaultManager().prof.setName("New name");
				for (int i = 0; i < 5; i++)
				{
					System.out.println("shared " + SessionManager.getDefaultManager().prof.getName());
					try {
					Thread.currentThread().sleep(10);
					} catch (InterruptedException ex) {}
				}
			};
		};
	}
	*/
   /*
	public static void main(String [] args)
	{
		Session ses = SessionManager.getDefaultManager().create("One");
		ses.join();
		Runnable r = getRunnable();
		new Thread(r).start();

		r = getShareRunnable();
		Thread d = new Thread(r);
		SessionManager.getDefaultManager().join(d, ses);
		d.start();

		ses.startTransaction(null);
		SessionManager.getDefaultManager().prof.setName("MainSarah");
		String name = Thread.currentThread().getName();
		System.out.println("Session " + SessionManager.getDefaultManager().getSession());
		for (int i = 0 ; i < 10; i++)
		{
			System.out.println(name + ' ' + SessionManager.getDefaultManager().prof.getName());
				try {
				Thread.currentThread().sleep(11);
				} catch (InterruptedException ex) {}
		}
		try {
		ses.getCurrentTransaction().commit();
		} catch( UpdateException e) { System.out.println("MAIN" + e + "END"); }
	}
	*/
}
