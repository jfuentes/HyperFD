package com.objectwave.transactionalSupport;

import java.lang.reflect.*;
import java.util.Date;
/**
 *
 * @version 1.0.1
 * @author Dave Hoag
 */
public interface SetAndGetDelegateIF
{
	/**
	*/
	public byte get(Field adapt, byte val);
	/**
	*/
	public char get(Field adapt, char val);
	/**
	*/
	public double get(Field adapt, double val);
	/**
	*/
	public float get(Field adapt, float val);
	/**
	*/
	public int get(Field adapt, int oldValue);
	/**
	*/
	public long get(Field adapt, long val);
	/**
	*/
	public Object get(final Field adapt, final Object oldValue);
	/**
	*/
	public short get(Field adapt, short val);
	/**
	*/
	public boolean get(Field adapt, boolean val);
	/**
	*/
	public void set(Field adapt, byte val, byte originalVal );
	/**
	*/
	public void set(Field adapt, char val, char originalVal );
	/**
	*/
	public void set(Field adapt, double val, double originalVal );
	/**
	*/
	public void set(Field adapt, float val, float originalVal );
	/**
	*/
	public void set(Field adapt, int val, int originalVal );
	/**
	*/
	public void set(Field adapt, long val, long originalVal );
	/**
	*/
	public void set(final Field adapt, final Object val, final Object originalVal );
	/**
	*/
	public void set(Field adapt, String val, String originalVal );
	/**
	*/
	public void set(Field adapt, Date val, Date originalVal );
	/**
	*/
	public void set(Field adapt, short val, short originalVal );
	/**
	*/
	public void set(Field adapt, boolean val, boolean originalVal );
}