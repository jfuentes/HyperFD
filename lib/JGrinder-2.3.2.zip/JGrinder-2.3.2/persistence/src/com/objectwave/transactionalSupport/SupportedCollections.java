package com.objectwave.transactionalSupport;

import java.util.*;
import java.lang.reflect.*;
/**
 * This is to allow the transactional support to work well with collections.
 *
 * @author Dave Hoag
 * @version 1.3
 */
public class SupportedCollections
{
	static final Class [] emptyParams = new Class [0];
	/**
	 * So we don't have to do a search for every isCollection invocation
	 */
	static HashMap collectionCache = null;
	static Hashtable cloneMethods = new Hashtable();
	static Class [] fastCollectionCache = new Class [100]; //We should never exceed 100, but...
	static int collectionCount = 0;
	/**
	 * So we don't have to do a search for every isCollection invocation
	 */
	static HashMap failCache = null;
	static Class [] fastFailCache = new Class [100]; //We should never exceed 100, but...
	static int failCount = 0;

	static Vector collectionList;
	static
	{
		collectionList = new Vector();
		try {
			addCollectionSupport("java.util.Hashtable");
		} catch (Exception e) { System.out.println("failed to support collection : " + e); }
		try {
			addCollectionSupport("java.util.Vector");
		} catch (Exception e) { System.out.println("failed to support collection : " + e); }
		try {
			addCollectionSupport("com.objectspace.jgl.Container");
		} catch (Exception e) { System.out.println("failed to support collection : " + e); }
		addFailCache(String.class);
		addFailCache(Integer.class);
		//These values will likely never be checked against the isCollection call
//		addFailCache(Double.class);
//		addFailCache(Character.class);
//		addFailCache(Boolean.class);
//		addFailCache(Float.class);
//		addFailCache(Long.class);
	}
    /**
    * SupportedCollections constructor comment.
    */
    public SupportedCollections()
    {
	    super();
    }
    /**
    */
    public static void main(String [] args)
    {
		int length = new Integer(args[0]).intValue();
		Object [] choices = new Object [8];
		int i = 0;
		choices[i++] = "one";
		choices[i++] = new Integer(1);
		choices[i++] = new Vector();
		choices[i++] = new Double(2.0);
		choices[i++] = new Hashtable();
		choices[i++] = new TransactionLog();
		choices[i++] = new com.objectwave.persist.examples.TestEntity();
		choices[i++] = new com.objectwave.persist.examples.TestPerson();
		collectionCache = new HashMap(50);
		failCache = new HashMap(60);
		long time = System.currentTimeMillis();
		for( i = 0; i < length; ++i)
		{
			for(int j = 0; j < choices.length; ++j)
			{
				isCollectionOrig(choices[j]);
//				isCollection(choices[j]);
			}
		}
		System.out.println(System.currentTimeMillis() - time);
    }
    /**
     */
    protected final static boolean isCollectionClass(final Class clazz)
    {
    	if(collectionCache != null)
    	{
    		return collectionCache.containsKey(clazz);
    	}
    	for(int i = 0; i < collectionCount; ++i)
    	{
    		if(fastCollectionCache[i] == clazz) return true;
    	}
    	return false;
    }
    /**
     */
    protected final static boolean isFailClass(final Class clazz)
    {
    	if(failCache != null)
    	{
    		return failCache.containsKey(clazz);
    	}
    	for(int i = 0; i < failCount; ++i)
    	{
    		if(fastFailCache[i] == clazz) return true;
    	}
    	return false;
    }
	/**
	 */
	public static void addCollectionSupport(String className) throws ClassNotFoundException
	{
		collectionList.addElement(Class.forName(className));
	}
	/**
	 * Attempt to clone the collection. This may fail if the clone method is not public.
	 * In the event of a failure, that particular collection will not be transactional.
	 * @author Dave Hoag
	 * @param collection A cloneable collection.
	 */
	public static Object cloneCollection(Object collection)
	{
		try
		{
			Class clazz = collection.getClass();
			Method meth = (Method )cloneMethods.get(clazz);
			if(meth == null)
			{
				meth = clazz.getDeclaredMethod("clone", emptyParams);
				cloneMethods.put(clazz, meth);
			}
			return meth.invoke(collection, emptyParams);
		}
		catch (Exception e) { return collection; }
	}
	/**  */
	protected synchronized static void addCollectionCache(final Class clazz)
	{
		if(collectionCount < 0)
		{
		    collectionCache.put(clazz, "true");
		}
		else
		{
			if(collectionCount == 100)
			{
				HashMap tmp = new HashMap(200);
				for(int i = 0; i < 100; ++i)
				{
					tmp.put(fastCollectionCache[i], "true");
				}
				collectionCount = -1;
				collectionCache = tmp;
				return;
			}
			else
			{
				fastCollectionCache[collectionCount++] = clazz;
			}
		}
	}
	/**  */
	protected synchronized static void addFailCache(final Class clazz)
	{
		if(failCount < 0)
		{
		    failCache.put(clazz, "true");
		}
		else
		{
			if(failCount == 100)
			{
				HashMap tmp = new HashMap(200);
				for(int i = 0; i < 100; ++i)
				{
					tmp.put(fastFailCache[i], "true");
				}
				failCount = -1;
				failCache = tmp;
				return;
			}
			else
			{
				fastFailCache[failCount++] = clazz;
			}
		}
	}
	/**
	 * Determine if the object being provided is a collection that we may need to clone.
	 * We attempt to optimize this by assuming that most objects will not be collections.
	 * Most of the time, we will never even run beyond the initial isFailClass call.
	 *
	 * @param obj Any ole object - perhaps a collection.
	 */
	public final static boolean isCollection(final Object obj)
	{
		Class c = null;
		final Class theObjectClass = obj.getClass();
		if(isFailClass(theObjectClass) ) return false;

		//We should rarely reach here.
		if(isCollectionClass(theObjectClass) ) return true;
		int size = collectionList.size();
		for(int i = 0; i < size; ++i)
		{
			c = (Class)collectionList.get(i);

			if(theObjectClass == c || c.isInstance(obj))
			{
			    addCollectionCache(theObjectClass);
			    return true;
			}
		}
		addFailCache(theObjectClass);
		return false;
	}
	public static boolean isCollectionOrig(final Object obj)
	{
		Class c = null;
		if(collectionCache.get(obj.getClass()) != null) return true;
		if(failCache.get(obj.getClass()) != null) return false;
		Enumeration e = collectionList.elements();
		while(e.hasMoreElements())
		{
			c = (Class)e.nextElement();
			if(c.isInstance(obj))
			{
			    collectionCache.put(obj.getClass(), "true");
			    return true;
			}
		}
		failCache.put(obj.getClass(), "false");
		return false;
	}
}
