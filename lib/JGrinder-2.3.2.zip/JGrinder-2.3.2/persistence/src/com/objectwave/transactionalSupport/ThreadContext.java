package com.objectwave.transactionalSupport;
import java.util.Vector;
/**
 * This is used for performance optimization. We replace the Thread contextClassLoader with
 * our own implementation. This allows the ability to create Thread safe access to resources
 * without synchronization.
 * @author Dave Hoag
 * @version 1.1
 */
public class ThreadContext
{
	 /**
	  */
	 public static final int SESSION = 0;
	 public static final int ARRAYCACHE = 1;
	 public static final int MODIFIEDCACHE = 2;
	 public static final int MAX = 3;
	 /**
	  */
	 public final static ExpandingObjectModifiedArrayCache getArrayCache()
	 {
	 	return (ExpandingObjectModifiedArrayCache)initContext(Thread.currentThread())[ARRAYCACHE];
	 }
	 /**
	  */
	 public final static void setArrayCache(final ExpandingObjectModifiedArrayCache session)
	 {
	 	initContext(Thread.currentThread())[ARRAYCACHE] = session;
	 }
	 /**
	  */
	 public final static ExpandingObjectModifiedCache getModifiedCache()
	 {
	 	return (ExpandingObjectModifiedCache)initContext(Thread.currentThread())[MODIFIEDCACHE];
	 }
	 /**
	  */
	 public final static void setModifiedCache(final ExpandingObjectModifiedCache session)
	 {
	 	initContext(Thread.currentThread())[MODIFIEDCACHE] = session;
	 }
	 /**
	  */
	 public final static Session getSession()
	 {
	 	return (Session)initContext(Thread.currentThread())[SESSION];
	 }
	 public final static void setSession(final Session session)
	 {
	 	initContext(Thread.currentThread())[SESSION] = session;
	 }
	 public final static void setSession(final Thread td, final Session session)
	 {
	 	initContext(td)[SESSION] = session;
	 }
	 /**
	  */
	 private static final Object [] initContext(final Thread td)
	 {
	 	Object [] result = getContext();
		if(result == null)
		{
			result = new Object [MAX];
	 		setContext(td, result);
		}
	 	return result;
	 }
	 public static final void setContext(final Thread td, final Object [] obj)
	 {
		ClassLoader target = td.getContextClassLoader();
//System.out.println("Setting thread context " + Thread.currentThread().hashCode() + " " + obj);
//System.out.println("Target on set " + td.hashCode() + " " + target);
		if(target instanceof WrapClassLoader)
		{
			if(((WrapClassLoader)target).valid(td))
			{
//System.out.println("...actually just an update");
				((WrapClassLoader)target).context = obj;
				 return;
			}
		}
		//New thread w a new context
		target = new WrapClassLoader(target, td);
		((WrapClassLoader)target).context = obj;
		td.setContextClassLoader(target);
//System.out.println("New Target on set " + td.hashCode() + " " + target);
//hashCodes.addElement(new Integer(Thread.currentThread().hashCode()));

	 }
//	static Vector hashCodes = new Vector();
	public static final void setContext(final Object [] obj)
	{
		setContext(Thread.currentThread(), obj);
	}
	public static final Object [] getContext()
	{
		Thread td = Thread.currentThread();
		ClassLoader target = td.getContextClassLoader();
//System.out.println("Target on get " + td.hashCode() + " " + target);
		if(target instanceof WrapClassLoader)
		{
			if(((WrapClassLoader)target).valid(td))
			{
//if(hashCodes.contains(new Integer(Thread.currentThread().hashCode())))
//{
//}
//else
//{
//System.out.println("Current thread seemed to never join!! " + Thread.currentThread().hashCode());
//}
//System.out.println("Getting " + Thread.currentThread().hashCode() + " should be " + ((WrapClassLoader)target).context);
				return (Object[])((WrapClassLoader)target).context;
			}
			else { td.setContextClassLoader(null); }
//System.out.println("Was getting " + Thread.currentThread().hashCode() + " but looks like should be null not " + ((WrapClassLoader)target).context);
		}
		return null;
	}
}
