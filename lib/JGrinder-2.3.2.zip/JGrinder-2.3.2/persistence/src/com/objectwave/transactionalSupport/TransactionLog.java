/*
 *  Copyright (C) 2001 David Hoag
 *  ObjectWave Corporation
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *  For a full copy of the license see:
 *  http://www.opensource.org/licenses/lgpl-license.html
 */
package com.objectwave.transactionalSupport;
import com.objectwave.logging.MessageLog;

import java.util.*;

/**
 *  A key piece of a the TransactionalSupport is the transaction log. All
 *  changes made to an object are associated with a transaction log. If no
 *  transaction exists, changes are not logged and the transactional object is
 *  directly updated.
 *
 * @author  Dave Hoag
 * @version  $Id: TransactionLog.java,v 2.3 2002/03/23 13:42:11 dave_hoag Exp $
 */
public class TransactionLog
{
	protected static TransactionManager transactionManager = new TransactionManager();
	// Static variables
	final static boolean verbose = System.getProperty("ow.transactionVerbose") != null;
	final static boolean metrics = System.getProperty("ow.transactionMetrics") != null;
	/**
	 *  It is a requirement that the editedObjects collection contain UNIQUE
	 *  objects!!! No dups allowed.
	 */
	protected ObjectEditingView[] editedObjects;
	protected int editedObjectsCount;
	protected boolean committing;
	/**
	 *  A cache of the last object added to the editedObjects
	 */
	protected transient ObjectEditingView lastObj;
	protected TransactionLog subTransaction = null;
	protected TransactionLog parentTransaction = null;
	/**
	 *  Allow one to change the TransactionManager.
	 *
	 * @param  mgr The new TransactionManager value
	 */
	public static void setTransactionManager(final TransactionManager mgr)
	{
		if(transactionManager != null)
		{
			mgr.lookupList = transactionManager.lookupList;
			mgr.lookupListSize = transactionManager.lookupListSize;
		}
		transactionManager = mgr;
	}
	/**
	 *  Transactions can have multiple contexts. This may be driven by thread, by
	 *  window activation, or some way I haven't even dreamed of.
	 *
	 * @param  obj The new Context value
	 * @author  Dave Hoag
	 */
	public static synchronized void setContext(final Object obj)
	{
		transactionManager.setContext(obj);
	}
	/**
	 *  Use this method sparingly. Good only for root transactions. Existing
	 *  transactions could/would be lost. Actually, I now think that you shouldn't
	 *  use this method. Start transaction works MUCH better.
	 *
	 * @param  log The new DefaultInstance value
	 */
	protected static synchronized void setDefaultInstance(TransactionLog log)
	{
		transactionManager.setDefaultInstance(log);
	}
	/**
	 * @param  b The new UsingSessions value
	 */
	static synchronized void setUsingSessions(final boolean b)
	{
		transactionManager.setUsingSessions(b);
	}
	/**
	 *  Find the most nested transaction. This is the one without any
	 *  subtransactions. The defaultInstance will always be the root transaction.
	 *
	 * @return  The CurrentInstance value
	 */
	public static TransactionLog getCurrentInstance()
	{
		return transactionManager.getCurrentInstance();
	}
	/**
	 *  Attempt to create a new TransactionLog for the transaction type of 'name'.
	 *
	 * @param  name
	 * @return  The NewTransaction value
	 */
	public static TransactionLog getNewTransaction(String name)
	{
		return transactionManager.getNewTransaction(name);
	}
	/**
	 *  Find the most nested transaction. This is the one without any
	 *  subtransactions. The defaultInstance will always be the root transaction.
	 *
	 * @param  context The context pointing to the root transaction.
	 * @return  The Transaction value
	 */
	static TransactionLog getTransaction(final Object context)
	{
		return transactionManager.getTransaction(context);
	}
	/**
	 *  Register the 'name' with the class. This will allow the application to
	 *  create a transaction simply by specifying a transaction name. This
	 *  seperates implementation from usage. Similar to Java's security support.
	 *
	 * @param  transactionClass must be an instance of TransactionLog. Must also
	 *  have a default constructor.
	 * @param  name The feature to be added to the TransactionSupport attribute
	 */
	public static synchronized void addTransactionSupport(String name, Class transactionClass)
	{
		transactionManager.addTransactionSupport(name, transactionClass);
	}
	/**
	 * @return
	 */
	public static boolean hasTransactions()
	{
		return transactionManager.hasTransactions();
	}
	/**
	 *  Only use this method if you KNOW that you want the provided transaction to
	 *  be a root transaction.
	 *
	 * @param  log The transaction that is to be the root transaction for the
	 *  provided context.
	 * @param  context The context of the transaction.
	 */
	public static synchronized void startRootTransaction(TransactionLog log, Object context)
	{
		transactionManager.startRootTransaction(log, context);
	}
	/**
	 *  Used to provide seperation between a particular transaction instance and
	 *  the desire to have a transaction. The 'name' must have a registered
	 *  transaction type.
	 *
	 * @param  context The context of the transaction.
	 * @param  name The name of a registered transaction type.
	 * @return
	 * @see  #addTransactionSupport(java.lang.String, java.lang.Class)
	 */
	public static TransactionLog startRootTransaction(String name, Object context)
	{
		return transactionManager.startRootTransaction(name, context);
	}
	/**
	 *  Used to provide seperation between a particular transaction instance and
	 *  the desire to have a transaction. The 'name' must have a registered
	 *  transaction type. This implementation is specific to session support.
	 *
	 * @param  name The name of a registered transaction type.
	 * @param  session
	 * @return
	 * @see  #addTransactionSupport(java.lang.String, java.lang.Class)
	 */
	public static TransactionLog startRootTransaction(final String name, final Session session)
	{
		return transactionManager.startRootTransaction(name, session);
	}
	/**
	 *  Used to provide seperation between a particular transaction instance and
	 *  the desire to have a transaction. The 'name' must have a registered
	 *  transaction type.
	 *
	 * @param  context The context of the transaction.
	 * @param  name The name of a registered transaction type.
	 * @return
	 * @see  #addTransactionSupport(java.lang.String, java.lang.Class)
	 */
	public static synchronized TransactionLog startTransaction(String name, Object context)
	{
		return transactionManager.startTransaction(name, context);
	}
	/**
	 *  An identity contains.
	 *
	 * @param  obj java.lang.Object
	 * @param  v
	 * @param  count
	 * @return  boolean
	 * @author  Dave Hoag
	 */
	protected final static boolean contains(final Object obj, final ObjectEditingView[] v, final int count)
	{
		for(int i = 0; i < count; ++i)
		{
			if(obj == v[i])
			{
				return true;
			}
		}
		return false;
	}
	/**
	 *  Another Session specific implementation
	 *
	 * @param  name
	 * @param  session
	 * @param  parentLog
	 * @return
	 */
	static TransactionLog startTransaction(final String name, final Session session, final TransactionLog parentLog)
	{
		return transactionManager.startTransaction(name, session, parentLog);
	}
	/**
	 *  If you don't want to manage transaction levels (good for popup dialogs)
	 *  then initiate all transactions with this method.
	 *
	 * @param  context The context of the transaction.
	 * @param  log
	 * @param  defaultLog
	 */
	static synchronized void startTransaction(TransactionLog log, Object context, TransactionLog defaultLog)
	{
		transactionManager.startTransaction(log, context, defaultLog);
	}
	/**
	 *  Used by Session for thread support. Used to provide seperation between a
	 *  particular transaction instance and the desire to have a transaction. The
	 *  'name' must have a registered transaction type.
	 *
	 * @param  context The context of the transaction.
	 * @param  name The name of a registered transaction type.
	 * @param  parent The parent transaction of the provided transaction. Could be
	 *  null.
	 * @return
	 * @see  #addTransactionSupport(java.lang.String, java.lang.Class)
	 */
	static TransactionLog startTransaction(String name, Object context, TransactionLog parent)
	{
		return transactionManager.startTransaction(name, context, parent);
	}
	/**
	 *  Remove the final keyword on the allowNesting variable if this method is to
	 *  be used.
	 *
	 * @param  b The new AllowNesting value
	 */
	public void setAllowNesting(boolean b)
	{
//		allowNesting = b;
		throw new RuntimeException("This operation is currently optimized out.");
	}
	/**
	 * @return  Vector of all TransactionalObjects modified in this transaction.
	 */
	public ArrayList getEditedObjects()
	{
		ArrayList res = new ArrayList();
		if(editedObjects == null)
		{
			return res;
		}

		for(int i = 0; i < editedObjectsCount; ++i)
		{
			res.add(editedObjects[i].getDomainObject());
		}
		return res;
	}
	/**
	 *  If I am a subtransaction, then I have a parent transaction.
	 *
	 * @return  The ParentTransaction value
	 */
	public TransactionLog getParentTransaction()
	{
		return parentTransaction;
	}
	/**
	 *  As a parent, I may have a subtransaction.
	 *
	 * @return  The SubTransaction value
	 */
	public TransactionLog getSubTransaction()
	{
		return subTransaction;
	}
	/**
	 *  Similar to commit, however, the current transaction is not removed. The
	 *  changes are simple commited and a 'new' transaction continues to exist.
	 *
	 * @exception  UpdateException
	 */
	public synchronized void chainCommit() throws UpdateException
	{
		if(verbose)
		{
			MessageLog.debug(this, "Commiting Chaing Transaction. Has parent =" + parentTransaction);
		}
		if(parentTransaction == null)
		{
			actualCommit();
			clearUpChanges();
			return;
		}
		//else parent not null
		commitSubTransaction();
	}
	/**
	 *  If this is a subtransaction (created via startTransaction) don't actually
	 *  commit the changes. Just migrate them to the parent transaction.
	 *
	 * @exception  UpdateException
	 * @todo  - I should be able to send commit or rollback to a parent transaction
	 *  and have all of the subtransaction act appropriately.
	 */
	public synchronized void commit() throws UpdateException
	{
		committing = true;
		try
		{
			if(verbose)
			{
				MessageLog.debug(this, "Commiting Transaction. Has parent =" + parentTransaction);
			}
			if(transactionManager.isUsingSessions())
			{
				throw new IllegalStateException("Commit calls should be made directly upon the Session object.");
			}
			//Root level transaction
			if(parentTransaction == null)
			{
				commitRootLevelTransaction();
				reset();
			}
			else
			{
				commitSubTransaction();
				transactionManager.maintainContextList(this);
			}
		}
		finally
		{
			committing = false;
		}
	}
	/**
	 *  Can the domainObject be found in the current transaction?
	 *
	 * @param  domainObject The object in question.
	 * @return  True if domainObject was modified in this transaction.
	 */
	public boolean contains(final TransactionalObjectIF domainObject)
	{
		if(editedObjects == null)
		{
			return false;
		}
		for(int i = 0; i < editedObjectsCount; ++i)
		{
			if(editedObjects[i].getDomainObject() == (domainObject))
			{
				return true;
			}
		}
		return false;
	}
	/**
	 *  Commit the values ignoring any transaction conflicts.
	 */
	public void forceCommit()
	{
		if(editedObjects != null)
		{
			for(int i = 0; i < editedObjectsCount; ++i)
			{
				try
				{
					editedObjects[i].commit(this, true);
				}
				catch(UpdateException ex)
				{
				}
				editedObjects[i].clearChanges(this);
			}
		}
		reset();
	}
	/**
	 *  Return the object back to it's original state, but do not discard the
	 *  changes made in this transaction.
	 *
	 * @see  #rollit(boolean )
	 */
	public void limitedRollback()
	{
		rollit(false, null);
	}
	/**
	 *  Return the object back to it's original state, and discard the changes made
	 *  in this transaction.
	 */
	public synchronized void rollback()
	{
		if(transactionManager.isUsingSessions())
		{
			throw new IllegalStateException("Commit calls should be made directly upon the Session object.");
		}
		if(verbose)
		{
			MessageLog.debug(this, "Rollback " + this + " parent " + parentTransaction);
		}
		rollit(true, null);
		reset();
	}
	/**
	 *  This is a root level transaction, actually do what need to do to commit.
	 *
	 * @exception  UpdateException
	 */
	protected void commitRootLevelTransaction() throws UpdateException
	{
		int orig = editedObjectsCount;
		ObjectEditingView[] origEditedObjects = editedObjects;

		actualCommit();

		//Guarantee integrity
		if(orig != editedObjectsCount || origEditedObjects != editedObjects)
		{
			MessageLog.warn(this, "TransactionLog.commit().A change was made to the edited objects list in the middle of a commit");
			MessageLog.warn(this, "Orig " + orig + "   " + editedObjectsCount + " " + origEditedObjects.hashCode() + " " + editedObjects.hashCode());
			throw new IllegalStateException("A violation of a core assumption has been made. Address immediately");
		}
		clearUpChanges();
		lastObj = null;
	}
	/**
	 *  Remove the changes from this object.
	 */
	protected void clearUpChanges()
	{
		if(editedObjects != null)
		{
			for(int i = 0; i < editedObjectsCount; ++i)
			{
				editedObjects[i].clearChanges(this);
			}
			editedObjectsCount = 0;
		}
	}
	/**
	 *  A sub transaction just migrates changes to the parent transaction. Assumes
	 *  that the instance variable 'parentTransaction' is not null.
	 */
	protected void commitSubTransaction()
	{
		this.migrateChangesTo(this.parentTransaction);

		parentTransaction.subTransaction = null;
	}
	/**
	 *  Actually commit all of my known changes. This should only happen for Parent
	 *  (or root) transactions.
	 *
	 * @exception  UpdateException Any exception that occured during the commit.
	 */
	protected void actualCommit() throws UpdateException
	{
		if(editedObjects != null)
		{
			try
			{
				transactionManager.getLockManager().acquireLocks(editedObjects, editedObjectsCount);

				for(int i = 0; i < editedObjectsCount; ++i)
				{
					ObjectEditingView view = editedObjects[i];
					view.commit(this, false);
				}
			}
			catch(UpdateException ex)
			{
				limitedRollback();
				throw ex;
			}
			catch(RuntimeException ex)
			{
				limitedRollback();
				throw ex;
			}
			finally
			{
				transactionManager.getLockManager().releaseLocks(editedObjects, editedObjectsCount);
				lastObj = null;
			}
		}
	}
	/**
	 *  Add the object to the list of modified transactions. Note, I am using the
	 *  keys to a hashtable as way to implement a 'Set' collection. There is one
	 *  ObjectEditingView object per instance of TransactionalObject.
	 *
	 * @param  obj The feature to be added to the Object attribute
	 */
	protected final synchronized void addObject(final ObjectEditingView obj)
	{
		if(editedObjects == null)
		{
			// Should I throw the illegal state exception here?
			editedObjects = new ObjectEditingView[70];
			editedObjects[0] = obj;
			editedObjectsCount = 1;
			lastObj = obj;
		}
		else
				if(lastObj != obj && (!contains(obj, editedObjects, editedObjectsCount)))
		{
			if(committing)
			{
				throw new IllegalStateException("Adding a new object while committing a transaction! This is a race condition with unpredictable results.!");
			}
			if(editedObjectsCount == editedObjects.length)
			{
				ObjectEditingView[] tmp = new ObjectEditingView[editedObjects.length + 120];
				System.arraycopy(editedObjects, 0, tmp, 0, editedObjects.length);
				editedObjects = tmp;
			}
			editedObjects[editedObjectsCount++] = (obj);
			lastObj = obj;
		}
	}
	/**
	 *  Create a nested transaction.
	 *
	 * @param  log The feature to be added to the SubTransaction attribute
	 */
	protected synchronized void addSubTransaction(final TransactionLog log)
	{
		if(!transactionManager.isAllowingNesting())
		{
			throw new RuntimeException("Nested transactions are not allowed");
		}

		subTransaction = log;
		log.parentTransaction = this;
	}
	/**
	 *  If using sessions, there is no need to manage a contextList.
	 *
	 * @param  context
	 * @exception  UpdateException
	 */
	protected synchronized void commit(final Session context) throws UpdateException
	{
		if(!transactionManager.isUsingSessions())
		{
			commit();
			return;
		}
		try
		{
			committing = true;
			if(parentTransaction == null)
			{
				commitRootLevelTransaction();
				context.setCurrentTransaction(null);
				transactionManager.sessionTransactionComplete();
			}
			else
			{
				commitSubTransaction();
				context.setCurrentTransaction(parentTransaction);
			}
		}
		finally
		{
			committing = false;
		}
	}
	/**
	 *  Remove the obj as a modified object of this transaction. This is an
	 *  extremely rare operation. No where in the core code is method called.
	 *
	 * @param  obj The object to remove from the list of edited objects.
	 */
	protected void removeObject(final ObjectEditingView obj)
	{
		if(editedObjects == null)
		{
			return;
		}
		for(int i = 0; i < editedObjectsCount; ++i)
		{
			if(editedObjects[i] == obj)
			{
				editedObjects[i] = null;
				int size = editedObjectsCount - 1;
				for(int j = i; j < size; ++j)
				{
					editedObjects[j] = editedObjects[j + 1];
				}
				editedObjects[size] = null;
				editedObjectsCount = size;
			}
		}
		lastObj = null;
	}
	/**
	 *  When not using session context we keep a hash collection of contexts, these
	 *  need to be reset when a root level transaction is commited.
	 */
	protected void reset()
	{
		if(verbose)
		{
			MessageLog.debug(this, "Resetting Transaction Log ");
		}
		transactionManager.maintainContextList(this);
		lastObj = null;

		if(parentTransaction == null)
		{
			setDefaultInstance(null);
		}

		if(editedObjects != null)
		{
			editedObjectsCount = 0;
		}
	}
	/**
	 *  Return the object back to it's original state, and discard the changes made
	 *  in this transaction.
	 *
	 * @param  context
	 */
	protected synchronized void rollback(Session context)
	{
		if(verbose)
		{
			MessageLog.debug(this, "Rollback " + this + " parent " + parentTransaction);
		}
		rollit(true, context);
		lastObj = null;
		if(editedObjects != null)
		{
			editedObjectsCount = 0;
		}
	}
	/**
	 * This was refactored from commit subtransaction. This method takes changes
	 * in the edited objects and pushes them into the specified parent transaction
	 * log.
	 *
	 * @param  parent
	 */
	public void migrateChangesTo(TransactionLog parent)
	{
		//System.out.println("TransactionLog::migrateChangesTo enter");
		if(editedObjects != null)
		{
			parent.prepareForMigration(editedObjectsCount);
			for(int i = 0; i < editedObjectsCount; i++)
			{
				//System.out.println("TransactionLog::migrateChanges, do object migrate");
				editedObjects[i].migrateChanges(this, parent);
			}
			lastObj = null;
		}
		//System.out.println("TransactionLog::migrateChangesTo exit");
	}
	/**
	 * @param  numberOfChanges The amount of changes that will likely be added to
	 *  our list of changes.
	 */
	void prepareForMigration(final int numberOfChanges)
	{
		if(editedObjects == null)
		{
			editedObjects = new ObjectEditingView[numberOfChanges + 20];
			editedObjectsCount = 0;
		}
		else
		{
			if(editedObjectsCount + numberOfChanges >= editedObjects.length)
			{
				//then grow the collection

				ObjectEditingView[] tmp = new ObjectEditingView[editedObjectsCount + numberOfChanges + 20];
				System.arraycopy(editedObjects, 0, tmp, 0, editedObjects.length);
				editedObjects = tmp;
			}
		}
	}
	/**
	 *  Restore the transactional object back to its original state.
	 *
	 * @param  forget true if all trace of this transaction should be removed.
	 * @param  session
	 */
	private void rollit(boolean forget, Session session)
	{
		if(editedObjects != null)
		{
			for(int i = 0; i < editedObjectsCount; ++i)
			{
				editedObjects[i].rollback(this, forget);
			}
		}
		if(forget)
		{
			if(session == null)
			{
				transactionManager.managedTransactionComplete(this);
			}
			else
			{
				//A session optimization
				if(parentTransaction != null)
				{
					parentTransaction.subTransaction = null;
				}
				session.setCurrentTransaction(parentTransaction);
				transactionManager.sessionTransactionComplete();
			}
		}
	}
	/**
	 *  Unit tests for the tranasaction log.
	 *
	 * @author  dhoag
	 * @version  $Id: TransactionLog.java,v 2.3 2002/03/23 13:42:11 dave_hoag Exp $
	 */
	public static class Test extends com.objectwave.test.UnitTestBaseImpl
	{
		/**
		 *  A workaround to avoid changing access rights of the
		 *  TransactionLog.setUsingSessions
		 *
		 * @param  b The new UsingSessions value
		 */
		public static void setUsingSessions(boolean b)
		{
			TransactionLog.transactionManager.setUsingSessions(false);
		}
		/**
		 *  Help other unit tests with transactions
		 */
		public static void reset()
		{
			TransactionLog.transactionManager.setUsingSessions(false);
			TransactionLog.transactionManager.defaultInstance = null;
			TransactionLog.transactionManager.contextList = new Hashtable(15);
			//TransactionLog.lookupList = null;
		}
		/**
		 *  The main program for the Test class
		 *
		 * @param  args The command line arguments
		 */
		public static void main(String[] args)
		{
			com.objectwave.test.TestRunner.run(new Test(), args);
		}
		/**
		 *  Clear the static values from one test to the next.
		 *
		 * @param  methodName The new Up value
		 * @param  context The new Up value
		 */
		public void setUp(String methodName, com.objectwave.test.TestContext context)
		{
			TransactionLog.transactionManager.defaultInstance = null;
			TransactionLog.transactionManager.contextList = new Hashtable(15);
			//TransactionLog.lookupList = null;
			setUsingSessions(false);
		}
		/**
		 */
		public void testSubTransSession()
		{
			setUsingSessions(false);

			Session secondContext = Session.createAndJoin("two");
			Session firstContext = Session.createAndJoin("one");
			firstContext.join();
			firstContext.startTransaction("one");
			TransactionLog started = firstContext.getCurrentTransaction();
			secondContext.join();
			secondContext.startTransaction("two");
			TransactionLog startedTwo = secondContext.getCurrentTransaction();

			testContext.assertTrue("Transactions have not been indicated when using sessions!", hasTransactions());

			TransactionLog current = TransactionLog.transactionManager.getCurrentInstance(started);

			testContext.assertEquals("Root is not current, incorrectly created a sub transaction", started, current);

			secondContext.rollback();
			current = secondContext.getCurrentTransaction();
			testContext.assertTrue("No transaction should be active.", current == null);

			firstContext.join();
			firstContext.rollback();
			current = getCurrentInstance();
			testContext.assertTrue("Transaction in progress when there should be none.", current == null);
			testContext.assertTrue("Transactions shown when there should be none.", !hasTransactions());
		}
		/**
		 */
		public void testSubTransTwo()
		{
			setUsingSessions(false);
			TransactionLog started = TransactionLog.startTransaction("one", "firstContext");
			TransactionLog nested = TransactionLog.startTransaction("two", "secondContext");
			TransactionLog current = TransactionLog.transactionManager.getCurrentInstance(started);
			testContext.assertEquals("Sub is not current", nested, current);
			nested.rollback();
			current = TransactionLog.transactionManager.getCurrentInstance(started);
			testContext.assertEquals("Did not restore to started", started, current);
			testContext.assertTrue("Transactions not shown when there should be.", hasTransactions());
			started.rollback();
			current = getCurrentInstance();
			testContext.assertTrue("Transaction in progress when there should be none.", current == null);
			testContext.assertTrue("Transactions shown when there should be none.", !hasTransactions());
		}
		/**
		 */
		public void testSubTrans()
		{
			setUsingSessions(false);
			TransactionLog started = TransactionLog.startTransaction("one", "firstContext");
			TransactionLog nested = TransactionLog.startTransaction("two", "firstContext");
			TransactionLog current = TransactionLog.transactionManager.getCurrentInstance(started);
			testContext.assertEquals("Sub is not current", nested, current);
			nested.rollback();
			current = TransactionLog.transactionManager.getCurrentInstance(started);
			testContext.assertEquals("Did not restore to started", started, current);
			testContext.assertTrue("Transactions not shown when there should be.", hasTransactions());
			started.rollback();
			current = getCurrentInstance();
			testContext.assertTrue("Transaction in progress when there should be none.", current == null);
			testContext.assertTrue("Transactions shown when there should be none.", !hasTransactions());
		}
		/**
		 */
		public void testSubTransactions()
		{
			setUsingSessions(false);
			TransactionLog started = TransactionLog.startTransaction("one", "firstContext");
			TransactionLog nested = TransactionLog.startTransaction("one", "secondContext");
			TransactionLog.setContext("firstContext");
			TransactionLog nested2 = TransactionLog.startTransaction("one", "thirdContext");
			TransactionLog current = TransactionLog.transactionManager.getCurrentInstance(started);
			testContext.assertEquals("3rd sub is not current", nested2, current);
			nested2.rollback();
			current = TransactionLog.transactionManager.getCurrentInstance(started);
			testContext.assertEquals("2nd sub is not current", nested, current);
			nested.rollback();
			current = TransactionLog.transactionManager.getCurrentInstance(started);
			testContext.assertEquals("Did not restore to started", started, current);
			started.rollback();
			current = getCurrentInstance();
			testContext.assertTrue("Transaction in progress when there should be none.", current == null);
		}
		/**
		 */
		public void testTransactionSupport()
		{
			TransactionLog.addTransactionSupport("fakeName", String.class);
			Object[] obj = TransactionLog.transactionManager.lookupTransaction("fakeName");
			testContext.assertTrue("Custom transaction support not found", obj != null);
			Class c = (Class) obj[1];
			testContext.assertEquals("Incorrect class found.", String.class, c);
		}
		/**
		 */
		public void testRootContexts()
		{
			setUsingSessions(false);
			TransactionLog started = TransactionLog.startTransaction("one", "firstContext");
			TransactionLog def = TransactionLog.transactionManager.getCurrentDefaultInstance();
			testContext.assertEquals("Root transactions not set correctly", started, def);
			TransactionLog.setContext("secondContext");
			def = TransactionLog.transactionManager.getCurrentDefaultInstance();
			testContext.assertTrue("Root transactions not set correctly", def == null);
			TransactionLog.setContext("firstContext");
			def = TransactionLog.transactionManager.getCurrentDefaultInstance();
			testContext.assertEquals("Root transactions failed to switch back", started, def);
		}
	}

//*/
}
