/* Copyright (C) 2001 David Hoag
 * ObjectWave Corporation
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * For a full copy of the license see:
 * http://www.opensource.org/licenses/lgpl-license.html
 */
package com.objectwave.transactionalSupport;
import com.objectwave.logging.MessageLog;
import java.util.*;
/**
 * @author  dhoag
 * @version  $Id: TransactionManager.java,v 2.1 2001/06/15 13:46:33 dave_hoag Exp $
 */
public class TransactionManager
{
	protected final MyLockManager lockManager = new MyLockManager();
	TransactionLog defaultInstance = null;
	Hashtable contextList = new Hashtable(15);
	ArrayList lookupList;
	int lookupListSize;
	int sessionCount = 0;
	boolean usingSessions = false;
	SessionManager sessionManager;
	final boolean allowNesting = true;
	boolean verbose = false;
	/**
	 *  Constructor for the TransactionManager object
	 */
	public TransactionManager()
	{
	}
	/**
	 *  Benchmark lock manager performance
	 *
	 * @param  args The command line arguments
	 */
	public static void main(String[] args)
	{
//	LockManager mgr = new LockManager();
		MyLockManager newMgr = new MyLockManager();
		Vector v = new Vector();
		int size = new Integer(args[0]).intValue();
		int iterations = new Integer(args[1]).intValue();
		Object[] objs = new Object[size];
		for(int i = 0; i < size; i++)
		{
			v.addElement(String.valueOf(i));
			objs[i] = String.valueOf(i);
		}
		long time = System.currentTimeMillis();
		for(int i = 0; i < iterations; ++i)
		{
//		mgr.acquireLocks(v);
//		mgr.releaseLocks(v);
		}
		System.out.println(System.currentTimeMillis() - time);
		time = System.currentTimeMillis();
		for(int i = 0; i < iterations; ++i)
		{
			newMgr.acquireLocks(objs, size);
			newMgr.releaseLocks(objs, size);
		}
		System.out.println(System.currentTimeMillis() - time);
	}
	/**
	 *  Transactions can have multiple contexts. This may be driven by thread, by
	 *  window activation, or some way I haven't even dreamed of.
	 *
	 * @param  obj The new Context value
	 * @author  Dave Hoag
	 */
	public synchronized void setContext(Object obj)
	{
		TransactionLog log = (TransactionLog) contextList.get(obj);
		if(verbose)
		{
			MessageLog.debug(log, "Setting " + obj.getClass().getName() + obj.hashCode() + " transaction context: " + log);
		}
		setDefaultInstance(log);
	}
	/**
	 *  Use this method sparingly. Good only for root transactions. Existing
	 *  transactions could/would be lost. Actually, I now think that you shouldn't
	 *  use this method. Start transaction works MUCH better.
	 *
	 * @param  log The new DefaultInstance value
	 */
	protected synchronized void setDefaultInstance(final TransactionLog log)
	{
		defaultInstance = log;
	}
	/**
	 * @param  b The new UsingSessions value
	 */
	synchronized void setUsingSessions(boolean b)
	{
		usingSessions = b;
		if(usingSessions)
		{
			sessionManager = SessionManager.getDefaultManager();
		}
		else
		{
			sessionManager = null;
		}
	}
	/**
	 *  Gets the LockManager attribute of the TransactionManager object
	 *
	 * @return  The LockManager value
	 */
	public MyLockManager getLockManager()
	{
		return lockManager;
	}
	/**
	 *  Find the most nested transaction. This is the one without any
	 *  subtransactions. The defaultInstance will always be the root transaction.
	 *
	 * @return  The CurrentInstance value
	 */
	public TransactionLog getCurrentInstance()
	{
		if(usingSessions)
		{
			Session session = sessionManager.getSession();
			if(session != null)
			{
				return session.getCurrentTransaction();
			}
			return null;
		}
		TransactionLog log = getCurrentDefaultInstance();
		if(log == null)
		{
			return null;
		}
		return getCurrentInstance(log);
	}
	/**
	 *  Attempt to create a new TransactionLog for the transaction type of 'name'.
	 *
	 * @param  name
	 * @return  The NewTransaction value
	 */
	public TransactionLog getNewTransaction(String name)
	{
		if(lookupList == null)
		{
			return new TransactionLog();
		}
		Object[] obj = lookupTransaction(name);
		if(obj == null)
		{
			return new TransactionLog();
		}
		Class c = (Class) obj[1];
		try
		{
			return (TransactionLog) c.newInstance();
		}
		catch(Exception e)
		{
			throw new RuntimeException("Failed to instantiate transaction for " + name);
		}
	}
	/**
	 * @return  The DefaultInstance value
	 */
	public TransactionLog getDefaultInstance()
	{
		return defaultInstance;
	}
	/**
	 * @return  The AllowingNesting value
	 */
	public boolean isAllowingNesting()
	{
		return allowNesting;
	}
	/**
	 *  Gets the UsingSessions attribute of the TransactionManager object
	 *
	 * @return  The UsingSessions value
	 */
	protected boolean isUsingSessions()
	{
		return usingSessions;
	}
	/**
	 *  The defaultInstance is the root transaction for the current context. There
	 *  are no callers to this method that are not synchronized.
	 *
	 * @return  The CurrentDefaultInstance value
	 */
	protected final TransactionLog getCurrentDefaultInstance()
	{
		return defaultInstance;
	}
	/**
	 *  Find the most nested transaction. This is the one without any
	 *  subtransactions. The defaultInstance will always be the root transaction.
	 *
	 * @param  log
	 * @return  The CurrentInstance value
	 */
	protected TransactionLog getCurrentInstance(TransactionLog log)
	{
		while(log.subTransaction != null)
		{
			log = log.subTransaction;
		}
		return log;
	}
	/**
	 *  Find the most nested transaction. This is the one without any
	 *  subtransactions. The defaultInstance will always be the root transaction.
	 *
	 * @param  context The context pointing to the root transaction.
	 * @return  The Transaction value
	 */
	TransactionLog getTransaction(final Object context)
	{
		TransactionLog log = (TransactionLog) contextList.get(context);
		if(log == null)
		{
			return null;
		}

		while(log.subTransaction != null)
		{
			log = log.subTransaction;
		}
		return log;
	}
	/**
	 *  Register the 'name' with the class. This will allow the application to
	 *  create a transaction simply by specifying a transaction name. This
	 *  seperates implementation from usage. Similar to Java's security support.
	 *
	 * @param  transactionClass must be an instance of TransactionLog. Must also
	 *  have a default constructor.
	 * @param  name The feature to be added to the TransactionSupport attribute
	 */
	public synchronized void addTransactionSupport(String name, Class transactionClass)
	{
		if(lookupList == null)
		{
			lookupList = new ArrayList(10);
		}
		else
		{
			Object[] obj = lookupTransaction(name);
			if(obj != null)
			{
				obj[1] = transactionClass;
				return;
			}
		}
		Object[] value = new Object[2];
		value[0] = name;
		value[1] = transactionClass;
		lookupList.add(value);
		lookupListSize = lookupList.size();
	}
	/**
	 *  Used for debugging.
	 *
	 * @param  os
	 */
	public void dumpContext(java.io.OutputStream os)
	{
		dumpContext(new java.io.OutputStreamWriter(os));
	}
	/**
	 * @return
	 */
	public boolean hasTransactions()
	{
		if(!usingSessions)
		{
			sessionCount = contextList.size();
		}
		return sessionCount > 0;
	}
	/**
	 *  Used to provide seperation between a particular transaction instance and
	 *  the desire to have a transaction. The 'name' must have a registered
	 *  transaction type. This implementation is specific to session support.
	 *
	 * @param  name The name of a registered transaction type.
	 * @param  session
	 * @return
	 * @see  #addTransactionSupport(java.lang.String, java.lang.Class)
	 */
	public TransactionLog startRootTransaction(final String name, final Session session)
	{
		TransactionLog log = getNewTransaction(name);

		if(verbose)
		{
			MessageLog.debug(log, "Starting transaction " + log
                        /*
			 * + " parent " + currentInstance
			 */
					);
		}
		session.setCurrentTransaction(log);
		sessionCount++;
		return log;
	}
	/**
	 *  Used to provide seperation between a particular transaction instance and
	 *  the desire to have a transaction. The 'name' must have a registered
	 *  transaction type.
	 *
	 * @param  context The context of the transaction.
	 * @param  name The name of a registered transaction type.
	 * @return
	 * @see  #addTransactionSupport(java.lang.String, java.lang.Class)
	 */
	public synchronized TransactionLog startTransaction(String name, Object context)
	{
		TransactionLog log = getNewTransaction(name);
		startTransaction(log, context, getCurrentDefaultInstance());
		return log;
	}
	/**
	 *  Only use this method if you KNOW that you want the provided transaction to
	 *  be a root transaction.
	 *
	 * @param  log The transaction that is to be the root transaction for the
	 *  provided context.
	 * @param  context The context of the transaction.
	 */
	public synchronized void startRootTransaction(TransactionLog log, Object context)
	{
		setDefaultInstance(null);
		startTransaction(log, context, null);
	}
	/**
	 *  Used to provide seperation between a particular transaction instance and
	 *  the desire to have a transaction. The 'name' must have a registered
	 *  transaction type.
	 *
	 * @param  context The context of the transaction.
	 * @param  name The name of a registered transaction type.
	 * @return
	 * @see  #addTransactionSupport(java.lang.String, java.lang.Class)
	 */
	public TransactionLog startRootTransaction(String name, Object context)
	{
		TransactionLog log = getNewTransaction(name);
		startRootTransaction(log, context);
		return log;
	}
	/**
	 * @param  w
	 */
	public void dumpContext(java.io.Writer w)
	{
		try
		{
			Iterator iterator = contextList.entrySet().iterator();
			while(iterator.hasNext())
			{
				Map.Entry info = (Map.Entry) iterator.next();
				w.write("Key: " + info.getKey() + " \n--Value: " + info.getValue() + "\n");
			}
			w.flush();
		}
		catch(Exception e)
		{
		}
	}
	/**
	 */
	protected void sessionTransactionComplete()
	{
		sessionCount--;
	}
	/**
	 *  The non session type.
	 *
	 * @param  log
	 */
	protected void managedTransactionComplete(final TransactionLog log)
	{
		final TransactionLog parentTransaction = log.getParentTransaction();
		Object context = contextList.remove(log);
		if(context != null)
		{
			if(contextList.get(context) == log)
			{
				contextList.remove(context);
			}
			else
			{
				Object tmpContext = contextList.get(parentTransaction);
				if(!tmpContext.equals(context))
				{
					contextList.remove(context);
				}
			}

			if(parentTransaction != null)
			{
				parentTransaction.subTransaction = null;
			}
			if(context instanceof Session)
			{
				((Session) context).setCurrentTransaction(parentTransaction);
			}
		}
	}
	/**
	 *  Clean up our context list of transactions. Not used for Session support.
	 *
	 * @param  log
	 */
	protected void maintainContextList(TransactionLog log)
	{
		final Object context = contextList.remove(log);
		if(context != null && contextList.get(context) == log)
		{
			//Shouldn't happen
			contextList.remove(context);
		}
		if(context instanceof Session)
		{
			((Session) context).setCurrentTransaction(log.getParentTransaction());
		}
	}
	/**
	 *  Find the Object [] that contains the name and the class of the specified
	 *  transaction name.
	 *
	 * @param  name
	 * @return
	 */
	protected Object[] lookupTransaction(final String name)
	{
		for(int i = 0; i < lookupListSize; ++i)
		{
			Object[] objs = (Object[]) lookupList.get(i);
			if(objs[0].equals(name))
			{
				return objs;
			}
		}
		return null;
	}
	/**
	 *  Another Session specific implementation
	 *
	 * @param  name
	 * @param  session
	 * @param  parentLog
	 * @return
	 */
	TransactionLog startTransaction(final String name, final Session session, final TransactionLog parentLog)
	{
		TransactionLog log = getNewTransaction(name);

		if(verbose)
		{
			MessageLog.debug(log, "Starting transaction " + log
                        /*
			 * + " parent " + currentInstance
			 */
					);
		}

		parentLog.addSubTransaction(log);
		session.setCurrentTransaction(log);

		return log;
	}
	/**
	 *  If you don't want to manage transaction levels (good for popup dialogs)
	 *  then initiate all transactions with this method.
	 *
	 * @param  context The context of the transaction.
	 * @param  log
	 * @param  defaultLog
	 */
	synchronized void startTransaction(TransactionLog log, Object context, TransactionLog defaultLog)
	{
		if(verbose)
		{
			MessageLog.debug(log, "Starting transaction " + log
                        /*
			 * + " parent " + currentInstance
			 */
					);
		}
		TransactionLog currentInstance = null;
		contextList.put(log, context);
		if(defaultLog != null)
		{
			currentInstance = getCurrentInstance(defaultLog);
			contextList.put(context, defaultLog);
			currentInstance.addSubTransaction(log);
		}
		else
		{
			contextList.put(context, log);
			setDefaultInstance(log);
		}
	}
	/**
	 *  Used by Session for thread support. Used to provide seperation between a
	 *  particular transaction instance and the desire to have a transaction. The
	 *  'name' must have a registered transaction type.
	 *
	 * @param  context The context of the transaction.
	 * @param  name The name of a registered transaction type.
	 * @param  parent The parent transaction of the provided transaction. Could be
	 *  null.
	 * @return
	 * @see  #addTransactionSupport(java.lang.String, java.lang.Class)
	 */
	TransactionLog startTransaction(String name, Object context, TransactionLog parent)
	{
		TransactionLog log = getNewTransaction(name);
		startTransaction(log, context, parent);
		return log;
	}
	/**
	 *  A very efficient lock manager that takes advantage of the following
	 *  assumptions. 1. No thread will acquire locks twice. 2. We don't care about
	 *  'equals' comparison, just object identity '==' comparisons. 3. The 'object
	 *  []' containing the objects to lock and unlock will be the same instance.
	 *
	 * @author  dhoag
	 * @version  $Id: TransactionManager.java,v 2.1 2001/06/15 13:46:33 dave_hoag Exp $
	 */
	public static class MyLockManager
	{
		int waitCount;
		final HashMap objects = new HashMap();
		Object[][] lockedObjects = new Object[10][];
		/**
		 *  LockManager constructor comment.
		 */
		public MyLockManager()
		{
			super();
		}
		/**
		 *  Is any object in the target list taken
		 *
		 * @param  objectsToLock
		 * @param  count
		 * @return  The Taken value
		 */
		protected boolean isTaken(final Object[] objectsToLock, final int count)
		{
			for(int i = 0; i < lockedObjects.length; ++i)
			{
				if(lockedObjects[i] != null)
				{
					for(int j = 0; j < lockedObjects[i].length; ++j)
					{
						if(lockedObjects[i][j] == null)
						{
							break;
						}
						//No more objects to compare.
						for(int k = 0; k < count; k++)
						{
							if(lockedObjects[i][j] == objectsToLock[k])
							{
								return true;
							}
						}
					}
				}
			}
			return false;
		}
		/**
		 *  Aquire locks for all of the objects in the Vector, or none of them.
		 *  Attempt to acquire locks. If we can not, get in line to try again.
		 *
		 * @param  objectsToLock
		 * @param  count
		 */
		public final synchronized void acquireLocks(final Object[] objectsToLock, final int count)
		{
			boolean lookForLocks = true;
			while(lookForLocks)
			{
				int i = 0;
				lookForLocks = isTaken(objectsToLock, count);
				if(lookForLocks)
				{
					try
					{
						if(TransactionLog.metrics && (++waitCount % 10) == 0)
						{
							MessageLog.info(this, "TransactionLog.acquireLock.wait() : " + waitCount);
							MessageLog.info(this, "Attempting to get locks for " + objectsToLock.hashCode());
						}
						wait();
					}
					//Wait for a releaseLocks call to be made.
					catch(InterruptedException ex)
					{
					}
				}
				else
				{
					i = 0;
					for(i = 0; i < lockedObjects.length; ++i)
					{
						if(lockedObjects[i] == null || lockedObjects[i].length == 0)
						{
							lockedObjects[i] = objectsToLock;
							break;
						}
					}
					if(i == lockedObjects.length)
					{
						if(TransactionLog.metrics)
						{
							MessageLog.info(this, "TransactionLog.MyLockManager.acquireLocks: Growing lock list to " + (lockedObjects.length + 10));
							MessageLog.info(this, "Caused by " + objectsToLock.hashCode());
						}
						Object[][] tmp = new Object[lockedObjects.length + 10][];
						System.arraycopy(lockedObjects, 0, tmp, 0, lockedObjects.length);
						tmp[lockedObjects.length] = objectsToLock;
						lockedObjects = tmp;
					}
				}
			}
		}
		/**
		 *  Aquire locks for all of the objects in the Vector, or none of them.
		 *  Attempt to acquire locks. If we can not, get in line to try again.
		 *
		 * @param  objectsToLock
		 * @param  length
		 * @deprecated  Redesigned.
		 */
		public final synchronized void acquireLocksOrig(final Object[] objectsToLock, final int length)
		{
			boolean lookForLocks = true;
			while(lookForLocks)
			{
				int i = 0;
				for(i = 0; i < length; ++i)
				{
					//Lock every object in the collection

					Object obj = objectsToLock[i];
					if(objects.containsKey(obj))
					{
						//if already locked

						break;
						//end for loop early
					}
					else
					{
						objects.put(obj, "true");
						//Acquire the lock
					}
				}
				lookForLocks = (i != length);
				//if (i != length) then we did not get all objects locked!
				if(lookForLocks)
				{
					for(int j = 0; j < i; ++j)
					{
						//For all objects that we did lock

						objects.remove(objectsToLock[j]);
						//Remove the objects that we locked.
					}

					try
					{
						if(TransactionLog.metrics && (++waitCount % 10) == 0)
						{
							MessageLog.info(this, "TransactionLog.acquireLock.wait() : " + waitCount);
						}
						wait();
					}
					//Wait for a releaseLocks call to be made.
					catch(InterruptedException ex)
					{
					}
				}
			}
		}
		/**
		 *  Aquire locks for all of the objects in the Vector, or none of them.
		 *
		 * @param  objectsToRelease
		 * @param  length
		 */
		public final synchronized void releaseLocks(final Object[] objectsToRelease, final int length)
		{
			for(int i = 0; i < lockedObjects.length; ++i)
			{
				if(objectsToRelease == lockedObjects[i])
				{
					lockedObjects[i] = null;
					break;
				}
			}
			notifyAll();
		}
		/**
		 *  Aquire locks for all of the objects in the Vector, or none of them.
		 *
		 * @param  objectsToRelease
		 * @param  length
		 */
		public final synchronized void releaseLocksOrig(final Object[] objectsToRelease, final int length)
		{
			for(int i = 0; i < length; ++i)
			{
				objects.remove(objectsToRelease[i]);
			}
			notifyAll();
		}
	}
}
