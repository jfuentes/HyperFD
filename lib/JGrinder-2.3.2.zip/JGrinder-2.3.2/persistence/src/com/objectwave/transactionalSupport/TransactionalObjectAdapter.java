package com.objectwave.transactionalSupport;

import java.lang.*;
import java.lang.reflect.*;
import com.objectwave.logging.MessageLog;
/**
 * A sample implementation of a TransactionalObject.
 *
 * @version 1.2.1
 * @see com.objectwave.transactionalSupport.TransactionalObject
 */
public class TransactionalObjectAdapter implements TransactionalObjectIF
{
	protected ObjectEditingView editor;

	public TransactionalObjectAdapter()
	{
		setObjectEditor(initializeObjectEditor());
	}
	public ObjectEditingView getObjectEditor()
	{
		return editor;
	}
	public ObjectEditor initializeObjectEditor()
	{
		return new ObjectEditor(this);
	}
	public boolean isDirty(){  return editor.isDirty(); }
	public boolean isTransient(){ return editor.isTransient(); }
	public void setAsTransient(boolean value){ editor.setAsTransient(value); }
	public void setObjectEditor(ObjectEditingView edit)
	{
		editor = edit;
	}
	/**  This method allows me to get arounds security problems with updating
	* and object from a generic framework. This method must be implemented in EACH
	* transactional object. It is NOT simply sufficient to leave this method in
	* the adapter...If that was true, I wouldn't even need this method.
	*/
	public void update(boolean get, Object [] data, Field [] fields)
	{
		for(int i = 0; i < data.length; i++){
			try{
			if(get)
				data[i] = fields[i].get(this);
			else
				fields[i].set(this, data[i]);
			} catch(IllegalAccessException ex) { MessageLog.error(this, "Problem with persistence", ex); }
			catch(IllegalArgumentException ex) { MessageLog.error(this, "Problem with persistence", ex); }
		}
	}
}