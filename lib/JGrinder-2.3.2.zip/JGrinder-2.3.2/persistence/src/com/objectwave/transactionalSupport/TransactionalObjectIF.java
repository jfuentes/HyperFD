package com.objectwave.transactionalSupport;

import java.lang.reflect.Field;

/**
 * In order to be a transactional object it is necessary for this interface
 * to be implemented.
 *
 * @version 1.1
 */
public interface TransactionalObjectIF
{
	/**
	* This method must ALWAYS return a value.
	*/
	ObjectEditingView getObjectEditor();
	/**
	* Has this object changed?
	*/
	public boolean isDirty();
	public boolean isTransient();
	/**
	* A transient object does not maintain transactional information.
	* Any changes to a transient object are immediately made to that
	* domain object. No rollback or commit functionality is available for
	* a transient object.
	*/
	public void setAsTransient(boolean value);
	public void setObjectEditor(ObjectEditingView edit);
	/**
	* A back door method to allow updating instance variable values
	* ignoring scope issues.  This will no longer be needed in JDK 1.2
	*/
	public void update(boolean get, Object [] data, Field [] fields);
}