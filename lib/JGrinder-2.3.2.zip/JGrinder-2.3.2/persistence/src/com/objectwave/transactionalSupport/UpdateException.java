package com.objectwave.transactionalSupport;

import java.io.PrintStream;
import java.io.PrintWriter;
/**
 * This exception may be thrown when trying to commit changes to a transactional
 * object. 
 * Many of the methods within this class actually just delegate to the causing exception.
 * This should help with debugging.
 * @version 2.1
 * @author Dave Hoag
 */
public class UpdateException extends Exception
{
	//The cause of the update exception
    Exception exception;
	/**
	 */
	public UpdateException(String str)
	{
		super(str);
	}
	/**
	 */
	public UpdateException(Exception exception)
	{
		super(exception.toString());
		this.exception = exception;
	}
	/**
	 */
	public void printStackTrace(PrintStream stream)
	{
	    if(exception != null) exception.printStackTrace(stream);
	    else super.printStackTrace(stream);
	}
	/**
	 */
	public void printStackTrace(PrintWriter writer)
	{
	    if(exception != null) exception.printStackTrace(writer);
	    else super.printStackTrace(writer);
	}
	/**
	 */
	public void printStackTrace()
	{
	    if(exception != null) exception.printStackTrace();
	    else super.printStackTrace();
	}
	/**
	 */
	public String toString()
	{
	    if(exception != null) return exception.toString();
	    else return super.toString();
	}
	/**
	 * The target exception is the reason this update exception occured.
	 */
	public Exception getTargetException()
	{
	    return exception;
	}
}
