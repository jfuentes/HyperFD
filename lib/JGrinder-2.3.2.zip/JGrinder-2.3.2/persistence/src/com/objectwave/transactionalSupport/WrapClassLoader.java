package com.objectwave.transactionalSupport;
/**
 * This is used for performance optimization. We replace the Thread contextClassLoader with
 * our own implementation. This allows the ability to create Thread safe access to resources
 * without synchronization.
 * @author Dave Hoag
 * @version 1.0
 */
public class WrapClassLoader extends ClassLoader
{
	public Object context;
	ClassLoader delegate;
	Thread originalThread;
	public WrapClassLoader(ClassLoader aDelegate, Thread ori)
	{
		delegate = aDelegate;
		originalThread = ori;
	}
	public java.net.URL  getResource(String name)
	{
		return delegate.getResource(name);
	}
	public boolean valid(Thread thread)
	{
		return thread == originalThread;
	}
	public java.io.InputStream getResourceAsStream(String name)
	{
		return delegate.getResourceAsStream(name);
	}
	public Class loadClass(String name) throws ClassNotFoundException
	{
		return delegate.loadClass(name);
	}
}
