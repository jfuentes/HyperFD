package com.objectwave.transactionalSupport.test;

import com.objectwave.exception.ConfigurationException;
import com.objectwave.exception.ExceptionBuilder;
import com.objectwave.logging.MessageLog;
import com.objectwave.persist.*;
import com.objectwave.persist.mapping.*;
import com.objectwave.persist.xml.*;
import com.objectwave.transactionalSupport.ObjectEditingView;

import com.objectwave.transactionalSupport.ObjectEditor;
import com.objectwave.utility.FileFinder;
import java.io.*;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.reflect.Field;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Vector;
/**
 *  A possible root Business object for an application.
 *
 * @author  dhoag
 * @version  $Id: DomainObject.java,v 1.1 2001/10/03 14:59:03 dave_hoag Exp $
 */
public abstract class DomainObject implements Persistence
{
	//To gain efficiency, add the following
	//two variables in each and every subclass of DomainObject
	/**
	 */
	public transient ObjectEditingView editor;
	/**
	 */
	public transient RDBPersistentAdapter adapt;
	/**
	 */
	public DomainObject()
	{
		final RDBPersistentAdapter value = new RDBPersistentAdapter(this);
		value.setTableName(getTableName());
		value.setClassDescription(initDescriptor());
		this.editor = value;
		this.adapt = value;
	}
	/**
	 * @param  obj The new PrimaryKeyField value
	 */
	/*
	 *  public static Vector initDescriptor() {
	 *  classDescriptor = new Vector();
	 *  /classDescriptor.addElement(new AttributeTypeColumn("databaseIdentifier", _objectIdentifier,
	 *  /		AttributeTypeColumn.PRIMARYATT));
	 *  return classDescriptor;
	 *  }
	 */
	/**
	 *  Sets the PrimaryKeyField attribute of the DomainObject object
	 *
	 * @param  obj The new PrimaryKeyField value
	 */
	public void setPrimaryKeyField(Object obj)
	{
		System.out.println("DomainObject::setPrimarykeyField, obj=" + obj);
		getAdapter().setPrimaryKeyField(obj);
	}
	/**
	 *  Support for individual instances residing in their own brokers.
	 *
	 * @param  aValue The new BrokerName value
	 */
	public void setBrokerName(String aValue)
	{
		getAdapter().setBrokerName(aValue);
	}
	/**
	 *  Sets the AsTransient attribute of the DomainObject object
	 *
	 * @param  value The new AsTransient value
	 */
	public void setAsTransient(boolean value)
	{
		((RDBPersistentAdapter) getAdapter()).setAsTransient(value);
	}
	/**
	 *  Sets the ObjectIdentifier attribute of the DomainObject object
	 *
	 * @param  b The new RetrievedFromDatabase value
	 */
	/**
	 *  Sets the ObjectIdentifier attribute of the DomainObject object
	 *
	 *public void setObjectIdentifier(Integer aValue) {
	 *editor.set(_objectIdentifier, aValue, objectIdentifier);
	 *}
	 *
	 * @param  b The new RetrievedFromDatabase value
	 */
	/**
	 *  Sets the ObjectIdentifier attribute of the DomainObject object
	 *
	 *public void setObjectIdentifier(Integer aValue) {
	 *editor.set(_objectIdentifier, aValue, objectIdentifier);
	 *}
	 *
	 *  Sets the PrimaryKeyField attribute of the DomainObject object
	 *
	 * @param  b The new RetrievedFromDatabase value
	 */
	/**
	 *  Sets the ObjectIdentifier attribute of the DomainObject object
	 *
	 *public void setObjectIdentifier(Integer aValue) {
	 *editor.set(_objectIdentifier, aValue, objectIdentifier);
	 *}
	 *
	 *  Sets the PrimaryKeyField attribute of the DomainObject object
	 *
	 *public void setPrimaryKeyField(Object obj)
	 *{
	 *getAdapter().setPrimaryKeyField(obj);
	 *}
	 *
	 * @param  b The new RetrievedFromDatabase value
	 */
	/**
	 *  Sets the ObjectIdentifier attribute of the DomainObject object
	 *
	 *public void setObjectIdentifier(Integer aValue) {
	 *editor.set(_objectIdentifier, aValue, objectIdentifier);
	 *}
	 *
	 *  Sets the PrimaryKeyField attribute of the DomainObject object
	 *
	 *public void setPrimaryKeyField(Object obj)
	 *{
	 *getAdapter().setPrimaryKeyField(obj);
	 *}
	 *
	 *  Sets the RetrievedFromDatabase attribute of the DomainObject object
	 *
	 * @param  b The new RetrievedFromDatabase value
	 */
	public void setRetrievedFromDatabase(boolean b)
	{
		getAdapter().setRetrievedFromDatabase(b);
	}
	/**
	 *  Subclasses will override this method to return an appropriate instance of a
	 *  RDBPersistentAdapter; This method will always instantiate the inner adapter
	 *  found in DomainObject's class definition. There are two approaches to this
	 *  method the first of which is to create your own subclass of
	 *  RDBPersistentAdapter and return it as a result from this method. The
	 *  second, is to tweak the instance created by this method by setting table
	 *  name and the description.
	 *
	 * @param  view The new ObjectEditor value
	 */
	public void setObjectEditor(ObjectEditingView view)
	{
		System.out.println("DomainObject::setObjectEditor" + view);
		if(view instanceof RDBPersistentAdapter)
		{
			adapt = (RDBPersistentAdapter) view;
		}
		this.editor = view;
	}
	/**
	 *  Gets the Adapter attribute of the DomainObject object
	 *
	 * @return  The Adapter value
	 */
	public Persistence getAdapter()
	{
		if(adapt != null)
		{
			return (Persistence) adapt;
		}
		else
		{
			return (Persistence) editor;
		}
	}
	/**
	 *  Support for individual instances residing in their own brokers.
	 *
	 * @return  The BrokerName value
	 */
	public String getBrokerName()
	{
		return getAdapter().getBrokerName();
	}
	/**
	 *  Gets the ObjectEditor attribute of the DomainObject object
	 *
	 * @return  The ObjectEditor value
	 */
	public ObjectEditingView getObjectEditor()
	{
		return editor;
	}
	/**
	 *  Gets the PrimaryKeyField attribute of the DomainObject object
	 *
	 * @return  The PrimaryKeyField value
	 */
	public Object getPrimaryKeyField()
	{
		System.out.println("DomainObject::getPrimaryKeyField, return " + getAdapter().getPrimaryKeyField());
		return getAdapter().getPrimaryKeyField();
	}
	/**
	 *Gets the PrimaryKeyFields attribute of the DomainObject object
	 *
	 * @return  The PrimaryKeyFields value
	 */
	public Object[] getPrimaryKeyFields()
	{
		return adapt.getPrimaryKeyFields();
	}
	/**
	 *  Gets the Dirty attribute of the DomainObject object
	 *
	 * @return  The Dirty value
	 */
	public boolean isDirty()
	{
		return getAdapter().isDirty();
	}
	/**
	 *  Gets the RetrievedFromDatabase attribute of the DomainObject object
	 *
	 * @return  The RetrievedFromDatabase value
	 */
	public boolean isRetrievedFromDatabase()
	{
		return getAdapter().isRetrievedFromDatabase();
	}
	/**
	 *  Gets the Transient attribute of the DomainObject object
	 *
	 * @return  The Transient value
	 */
	public boolean isTransient()
	{
		return ((RDBPersistentAdapter) getAdapter()).isTransient();
	}
	/**
	 *Gets the TableName attribute of the DomainObject object
	 *
	 * @return  The TableName value
	 */
	public abstract String getTableName();
	/**
	 * @exception  QueryException
	 */
	public void delete() throws QueryException
	{
		getAdapter().delete();
	}
	/**
	 * @return
	 */
	public abstract Vector initDescriptor();
	/**
	 * @exception  QueryException
	 */
	public void insert() throws QueryException
	{
		getAdapter().insert();
	}
	/**
	 *  This method was created in VisualAge.
	 *
	 * @param  wait boolean
	 * @return  boolean
	 */
	public boolean lock(boolean wait)
	{
		if(editor == null)
		{
			return false;
		}
		return editor.lock(wait);
	}
	/**
	 *  Mark this object to be deleted in this transaction. If a transaction is not
	 *  in progress, this object will be deleted immediately.
	 *
	 * @exception  QueryException
	 */
	public void markForDelete() throws QueryException
	{
		((RDBPersistence) getAdapter()).markForDelete();
	}
	/**
	 * @exception  QueryException
	 */
	public void save() throws QueryException
	{
		getAdapter().save();
	}
	/**
	 *  This method was created in VisualAge.
	 */
	public void unlock()
	{
		if(editor != null)
		{
			editor.unlock();
		}
	}
	/**
	 *  Method no longer does anything since setAccessible solves our need for this
	 *  behavior.
	 *
	 * @param  get
	 * @param  data
	 * @param  fields
	 */
	public void update(final boolean get, final Object[] data, final Field[] fields)
	{
		//throw new UnsupportedOperationException("This method should never be called");
	}
	/**
	 * @return
	 */
	public boolean usesAdapter()
	{
		return true;
	}
	/**
	 *  Create the new ObjectEditingView instance that is to be our 'adapter' to
	 *  the persistent object.
	 *
	 * @param  persistentObject
	 * @return
	 */
	protected RDBPersistentAdapter createAdapter(final Persistence persistentObject)
	{
		RDBPersistentAdapter result = new RDBPersistentAdapter(persistentObject);
		return result;
	}
}
