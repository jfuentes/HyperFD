package com.objectwave.transactionalSupport.test;
import com.objectwave.persist.*;
import com.objectwave.persist.broker.*;
import com.objectwave.persist.properties.BrokerPropertySource;
import com.objectwave.transactionalSupport.*;
/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 *
 * @author
 * @version  1.0
 */

public class ParallelAction extends Thread
{
	int entityId = 0;
	Session parentSession = null;
	Session childSession = null;
	boolean fail = false;
	/**
	 *Constructor for the ParallelAction object
	 *
	 * @param  id
	 * @param  session
	 * @param  fail
	 */
	public ParallelAction(int id, Session session, boolean fail)
	{
		this.entityId = id;
		this.parentSession = session;
		this.fail = fail;
		// create a parallel child session.
		childSession = Session.createParallelChild(parentSession);
	}
	/**
	 *Main processing method for the ParallelAction object
	 */
	public void run()
	{
		try
		{
			// associate this child session to the current thread.
			childSession.join();
			// start the same transaction as the parallel master started.
			childSession.startTransaction("RDB");
			TestEntity teq = new TestEntity();
			teq.setId(entityId);
			SQLQuery query = new SQLQuery(teq);
			teq = (TestEntity) query.findUnique();
			for(int i = 0; i < 10; i++)
			{
				System.out.println("[" + entityId + "] name=" + teq.getName());
				teq.setName("[" + entityId + "] Name : " + i);
				teq.save();
				if(i == 5 && fail)
				{
					childSession.rollback();
					System.out.println("FAILED**********************");
					return;
				}
				try
				{
					Thread.currentThread().sleep(500);
				}
				catch(Exception e)
				{
					// do nothing
				}
			}
			childSession.commit();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
