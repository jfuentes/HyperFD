package com.objectwave.transactionalSupport.test;
import com.objectwave.logging.MessageLog;
import com.objectwave.persist.Broker;
import com.objectwave.persist.BrokerFactory;

import com.objectwave.persist.SQLQuery;
import com.objectwave.persist.broker.FileBroker;
import com.objectwave.persist.broker.RDBBroker;

import com.objectwave.transactionalSupport.*;
import com.objectwave.transactionalSupport.TransactionLog;
import java.util.Collection;
import java.util.Iterator;

/**
 * @author  cson
 * @version  $Id: ParallelTransactionTest.java,v 1.1 2001/10/03 14:59:03 dave_hoag Exp $
 */
public class ParallelTransactionTest
{

	/**
	 *The main program for the ParallelTransactionTest class
	 *
	 * @param  args The command line arguments
	 */
	public static void main(String[] args)
	{
		com.objectwave.test.TestRunner.run(new ParallelTransactionTest.Test(), new String[0]);
	}

	/**
	 * @author  cson
	 * @version  $Id: ParallelTransactionTest.java,v 1.1 2001/10/03 14:59:03 dave_hoag Exp $
	 */
	public static class Test extends com.objectwave.test.UnitTestBaseImpl
	{

		private final static String CONNECT_URL = "jdbc:hsqldb:.";
		private final static String USERNAME = "sa";
		private final static String PASSWORD = "";

		private final static String SQL_CREATE_TESTENTITY = "CREATE TABLE testentity ( id int, name varchar(20), PRIMARY KEY (id))";
		private final static String SQL_DROP_TESTENTITY = "DROP TABLE testentity";

		private final static String SQL_CREATE_RECORD_1 = "INSERT INTO testentity values (1,'name 1')";
		private final static String SQL_CREATE_RECORD_2 = "INSERT INTO testentity values (2,'name 2')";
		private final static String SQL_CREATE_RECORD_3 = "INSERT INTO testentity values (3,'name 3')";

		/**
		 *The main program for the RDBTest class
		 *
		 * @param  args The command line arguments
		 */
		public static void main(String[] args)
		{
			com.objectwave.test.TestRunner.run(new Test(), args);
		}

		/**
		 * Test Multiple Primary Key support in Hypersonic
		 *
		 * @exception  Exception
		 */
		public void testParallelTransWithHypersonic() throws Exception
		{
			//System.setProperty("ow.persistVerbose", "true");
			//System.setProperty("ow.persistConnectionVerbose", "true");
			System.setProperty("ow.persistUser", USERNAME);
			System.setProperty("ow.persistPassword", PASSWORD);
			System.setProperty("ow.persistDriver", "org.hsqldb.jdbcDriver");
			System.setProperty("ow.databaseImpl", "com.objectwave.persist.broker.HypersonicBroker");
			System.setProperty("ow.connectUrl", CONNECT_URL);
			System.setProperty("ow.useConnectionPool", "true");
			BrokerFactory.useDatabase();
			RDBBroker broker = new com.objectwave.persist.broker.HypersonicBroker();
			broker.initialize();
			BrokerFactory.setDefaultBroker(broker);
			SQLQuery.setDefaultBroker(broker);
			buildDatabase(broker);

			batchUpdate(false, Session.PARALLEL_IGNORE_SIBLINGS);
			System.out.println("these should be altered");
			showResults();
			resetValues(broker);
			System.out.println("These should be empty");
			showResults();
			batchUpdate(true, Session.PARALLEL_ROLLBACK_SIBLINGS);
			System.out.println("These should still be empty");
			showResults();

			batchUpdate(true, Session.PARALLEL_IGNORE_SIBLINGS);
			System.out.println("Id 2 should be empty, but that's it");
			showResults();

			deleteDatabase(broker);

		}
		/**
		 * @exception  Exception
		 */
		public void showResults() throws Exception
		{
			System.out.println("----------------------------------------------");
			TestEntity te = new TestEntity();
			SQLQuery query = new SQLQuery(te);
			java.util.Vector results = query.find();
			for(int i = 0; i < results.size(); System.out.println(results.get(i++)))
			{
				;
			}
			System.out.println("----------------------------------------------");
		}
		/**
		 * @param  fail
		 * @param  policy
		 * @exception  Exception
		 */
		public void batchUpdate(boolean fail, int policy) throws Exception
		{
			// create a parallel master session
			final Session ses = Session.createParallelMaster("Parallel Master", policy);
			// start the all encompassing transaction
			ses.startTransaction("RDB");
			System.out.println(ses);

			// create the worker threads.
			Thread parallelWork = new ParallelAction(1, ses, false);
			Thread parallelWork2 = new ParallelAction(2, ses, fail);
			Thread parallelWork3 = new ParallelAction(3, ses, false);

			parallelWork.start();
			parallelWork2.start();
			parallelWork3.start();

			// commit the changes, this will block until all children
			// have called commit or rollback
			ses.commit();
		}

		/**
		 *The teardown method for JUnit
		 *
		 * @param  context
		 * @exception  Exception
		 */
		public void tearDown(com.objectwave.test.TestContext context) throws Exception
		{
			if(BrokerFactory.getDefaultBroker() instanceof FileBroker)
			{
				MessageLog.debug(this, "Removing files!");
				removeFile("testentity.dbf");
			}
		}

		/**
		 * @param  broker
		 * @exception  Exception
		 */
		private void resetValues(RDBBroker broker) throws Exception
		{
			try
			{
				broker.getConnection().execSql("update testentity set name=' '");
			}
			catch(Exception e)
			{
				MessageLog.error(this, "Failed to build database", e);
				e.printStackTrace();
			}
		}

		/**
		 * @param  broker
		 * @exception  Exception
		 */
		private void buildDatabase(RDBBroker broker) throws Exception
		{
			try
			{
				broker.getConnection().execSql(SQL_CREATE_TESTENTITY);
				broker.getConnection().execSql(SQL_CREATE_RECORD_1);
				broker.getConnection().execSql(SQL_CREATE_RECORD_2);
				broker.getConnection().execSql(SQL_CREATE_RECORD_3);
			}
			catch(Exception e)
			{
				MessageLog.error(this, "Failed to build database", e);
				e.printStackTrace();
			}
		}

		/**
		 * @param  broker
		 */
		private void deleteDatabase(RDBBroker broker)
		{
			try
			{
				broker.getConnection().execSql(SQL_DROP_TESTENTITY);
			}
			catch(Exception e)
			{
				MessageLog.error(this, "Failed to build database", e);
				e.printStackTrace();
			}
		}

	}

}
