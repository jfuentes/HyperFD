package com.objectwave.transactionalSupport.test;
import com.objectwave.persist.*;
import com.objectwave.transactionalSupport.*;
import java.lang.reflect.*;

import java.util.Vector;
/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 *
 * @author
 * @version  1.0
 */

public class TestEntity extends DomainObject
{
	// -------------------------------------------------------------------------
	// JGrinder Code
	// -------------------------------------------------------------------------
	static Vector classDescriptor;
	static Field _id;
	static Field _name;
	// -------------------------------------------------------------------------

	String name;
	int id;

	/**
	 *Constructor for the TestEntity object
	 */
	public TestEntity()
	{
		super();
		adapt.setBrokerGeneratedPrimaryKeys(true);
	}


	/**
	 *The main program for the TestEntity class
	 *
	 * @param  args The command line arguments
	 */
	public static void main(String[] args)
	{
		try
		{
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	/**
	 *Sets the Name attribute of the TestEntity object
	 *
	 * @param  newName The new Name value
	 */
	public void setName(String newName)
	{
		editor.set(_name, newName, name);
	}
	/**
	 *Sets the Id attribute of the TestEntity object
	 *
	 * @param  newId The new Id value
	 */
	public void setId(int newId)
	{
		editor.set(_id, newId, id);
	}
	/**
	 *Sets the ObjectEditor attribute of the TestEntity object
	 *
	 * @param  view The new ObjectEditor value
	 */
	public void setObjectEditor(ObjectEditingView view)
	{

		super.setObjectEditor(view);
		super.adapt.setBrokerGeneratedPrimaryKeys(true);
	}
	/**
	 *Gets the Name attribute of the TestEntity object
	 *
	 * @return  The Name value
	 */
	public String getName()
	{
		return (String) editor.get(_name, name);
	}
	/**
	 *Gets the Id attribute of the TestEntity object
	 *
	 * @return  The Id value
	 */
	public int getId()
	{
		return (int) editor.get(_id, id);
	}
	// -------------------------------------------------------------------------
	// Start JGrinder Persistence Setup Code
	// -------------------------------------------------------------------------
	/**
	 *Gets the TableName attribute of the TestEntity object
	 *
	 * @return  The TableName value
	 */
	public String getTableName()
	{
		return "testentity";
	}

	/**
	 * @return
	 */
	public Vector initDescriptor()
	{

		if(classDescriptor == null)
		{
			Vector tmp = new Vector();
			tmp.addElement(new AttributeTypeColumn("id", _id, AttributeTypeColumn.PRIMARYATT));
			tmp.addElement(new AttributeTypeColumn("name", _name, AttributeTypeColumn.TYPEATT));
			classDescriptor = tmp;
		}
		return classDescriptor;
	}
	/**
	 * @return
	 */
	public String toString()
	{
		return ("Test Entity: " + getName() + ", " + getId());
	}

	static
	{
		try
		{
			_id = TestEntity.class.getDeclaredField("id");
			_id.setAccessible(true);
			_name = TestEntity.class.getDeclaredField("name");
			_name.setAccessible(true);
		}
		catch(Throwable ex)
		{
			ex.printStackTrace();
			System.exit(1);
		}
	}
}
