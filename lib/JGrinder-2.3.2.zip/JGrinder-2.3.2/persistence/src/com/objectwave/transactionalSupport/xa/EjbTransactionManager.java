/* Copyright (C) 2001 David Hoag
 * ObjectWave Corporation
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * For a full copy of the license see:
 * http://www.opensource.org/licenses/lgpl-license.html
 */
package com.objectwave.transactionalSupport.xa;
import com.objectwave.logging.MessageLog;
import com.objectwave.transactionalSupport.TransactionLog;

import com.objectwave.transactionalSupport.TransactionManager;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.transaction.RollbackException;
import javax.transaction.SystemException;
import javax.transaction.Transaction;
/**
 *  Check to see if a transaction is in progress, if so, have our resource join
 *  it.
 *
 * @author  dhoag
 * @version  $Id: EjbTransactionManager.java,v 1.1 2001/06/15 13:46:06 dave_hoag Exp $
 */
public class EjbTransactionManager extends TransactionManager
{
	/**
	 */
	public String defaultJndiName = "java:/TransactionManager";
	XaSessionManager manager = new XaSessionManager();
	javax.transaction.TransactionManager tm = null;
	/**
	 *  Constructor for the EjbTransactionManager object
	 */
	public EjbTransactionManager()
	{
	}
	/**
	 *  Enlist our XAResource as if a transaction is in progress
	 *
	 * @return  The CurrentInstance value
	 */
	public TransactionLog getCurrentInstance()
	{
		if(tm == null)
		{
			throw new IllegalStateException("Failed to initialize the TransactionManager!");
		}
		try
		{
			Transaction tran = tm.getTransaction();
			if(tran != null)
			{
				tran.enlistResource(manager);
			}
		}
		catch(RollbackException ex)
		{
			MessageLog.debug(this, "Failed to determine if a transaction is in progress", ex);
			throw new RuntimeException("Failed to determine transactional state of system : " + ex);
		}
		catch(SystemException ex)
		{
			MessageLog.debug(this, "Failed to determine if a transaction is in progress", ex);
			throw new RuntimeException("Failed to determine transactional state of system : " + ex);
		}
		TransactionLog result = super.getCurrentInstance();
		MessageLog.debug(this, "About to return super.getCurrentInstance() " + result);
		return result;
	}
	/**
	 * @exception  NamingException
	 */
	public void initializeTransactionManager() throws NamingException
	{
		initializeTransactionManager(defaultJndiName);
	}
	/**
	 * @param  jndiName
	 * @exception  NamingException
	 */
	public void initializeTransactionManager(final String jndiName) throws NamingException
	{
		tm = (javax.transaction.TransactionManager) new InitialContext().lookup(jndiName);
	}
}
