/* Copyright (C) 2001 David Hoag
 * ObjectWave Corporation
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * For a full copy of the license see:
 * http://www.opensource.org/licenses/lgpl-license.html
 */
package com.objectwave.transactionalSupport.xa;
import com.objectwave.logging.MessageLog;

import com.objectwave.transactionalSupport.Session;
import com.objectwave.transactionalSupport.SessionManager;
import com.objectwave.transactionalSupport.UpdateException;
import java.util.Hashtable;
import javax.transaction.Status;
import javax.transaction.xa.XAException;
import javax.transaction.xa.XAResource;
import javax.transaction.xa.Xid;
/**
 *  Support using Sessions as a compliant XAResource. The resources it manages
 *  are the DomainObject instances. This class is in the early stage of
 *  development - Whats important is that this resource somehow get associated
 *  with a TransactionManager transaction. Since that can be application server
 *  specific, I'll leave this as is for now. <p>
 *
 *  <pre>
 *
 *  Example of how it may look. <p>
 *
 *  XaSessionManager manager = new XaSessionManager(); <p>
 *
 *  public void doSomethingNeedingManaged() { <br>
 *  TransactionManager tm = null; <br>
 *  try { <br>
 *  tm = (TransactionManager) new InitialContext().lookup("java:/TransactionManager");
 *  <br>
 *  Transaction tran = tm.getTransaction(); <br>
 *  if( tran != null ) tran.enlistResource( manager ); <br>
 *  } <br>
 *  catch(Exception e) { <br>
 *  MessageLog.debug( this, "Failed to locate transaction manager", e); <br>
 *  }</pre>
 *
 * @author  dhoag
 * @version  $Id: XaSessionManager.java,v 1.1 2001/06/15 13:46:06 dave_hoag Exp $
 */
public class XaSessionManager implements XAResource
{
	protected Hashtable table;
	protected int timeout;
	/**
	 *  Constructor for the XaSession object
	 */
	public XaSessionManager()
	{
		table = new Hashtable();
	}
	/**
	 *  Sets the TransactionTimeout attribute of the XaSession object
	 *
	 * @param  parm1 The new TransactionTimeout value
	 * @return
	 * @exception  javax.transaction.xa.XAException
	 */
	public boolean setTransactionTimeout(int parm1) throws javax.transaction.xa.XAException
	{
		timeout = 0;
		//False indicates that we don't support this operation
		return false;
	}
	/**
	 *  Gets the TransactionTimeout attribute of the XaSession object
	 *
	 * @return  The TransactionTimeout value
	 * @exception  javax.transaction.xa.XAException
	 */
	public int getTransactionTimeout() throws javax.transaction.xa.XAException
	{
		return timeout;
	}
	/**
	 *  Gets the SameRM attribute of the XaSession object
	 *
	 * @param  parm1
	 * @return  The SameRM value
	 * @exception  javax.transaction.xa.XAException
	 */
	public boolean isSameRM(XAResource parm1) throws javax.transaction.xa.XAException
	{
		MessageLog.debug(this, "Is Same " + parm1);
		return this == parm1;
	}
	/**
	 * @param  xid
	 * @return  The Key value
	 */
	protected Object getKey(final Xid xid)
	{
		final String key = new String(xid.getGlobalTransactionId());
		return key;
	}
	/**
	 *  Do the actual commit
	 *
	 * @param  ses
	 * @exception  XAException
	 */
	protected void commit(Session ses) throws XAException
	{
		if(ses.getCurrentTransaction() != null)
		{
			try
			{
				MessageLog.debug(this, "Actually commiting transaction " + ses.getName());
				ses.commit();
			}
			catch(UpdateException ex)
			{
				MessageLog.debug(this, "Rollback! transaction " + ses.getName(), ex);
				ses.rollback();
				throw new XAException(XAException.XA_RBINTEGRITY);
			}
		}
	}
	/**
	 * @param  parm2
	 * @param  xid
	 * @exception  javax.transaction.xa.XAException
	 */
	public void commit(final Xid xid, final boolean parm2) throws javax.transaction.xa.XAException
	{
		MessageLog.debug(this, "Commit " + xid);
		Session ses = findSession(xid);
		ses.join();
		commit(ses);
	}
	/**
	 * @param  parm2
	 * @param  xid
	 * @exception  javax.transaction.xa.XAException
	 */
	public void end(final Xid xid, final int parm2) throws javax.transaction.xa.XAException
	{
		MessageLog.debug(this, "End " + xid);
		Session ses = findSession(xid);
		commit(ses);
		ses.leave();
	}
	/**
	 * @param  xid
	 * @exception  javax.transaction.xa.XAException
	 */
	public void forget(final Xid xid) throws javax.transaction.xa.XAException
	{
		MessageLog.debug(this, "Forget " + xid);
		table.remove(getKey(xid));
	}
	/**
	 * @param  xid
	 * @return
	 * @exception  javax.transaction.xa.XAException
	 */
	public int prepare(final Xid xid) throws javax.transaction.xa.XAException
	{
		MessageLog.debug(this, "Prepare " + xid);
		Session ses = findSession(xid);
		if(true)
		{
			return XA_OK;
		}
		if(ses == null || ses.getCurrentTransaction() == null)
		{
			return Status.STATUS_NO_TRANSACTION;
		}
		commit(ses);
		return Status.STATUS_COMMITTING;
	}
	/**
	 * @param  parm1
	 * @return
	 * @exception  javax.transaction.xa.XAException
	 */
	public Xid[] recover(int parm1) throws javax.transaction.xa.XAException
	{
		throw new java.lang.UnsupportedOperationException("Method recover() not yet implemented.");
	}
	/**
	 * @param  xid
	 * @exception  javax.transaction.xa.XAException
	 */
	public void rollback(final Xid xid) throws javax.transaction.xa.XAException
	{
		MessageLog.debug(this, "Rollback " + xid);
		Session ses = findSession(xid);
		ses.join();
		ses.rollback();
	}
	/**
	 * @param  parm2
	 * @param  xid
	 * @exception  javax.transaction.xa.XAException
	 */
	public void start(final Xid xid, int parm2) throws javax.transaction.xa.XAException
	{
		MessageLog.debug(this, "Start " + xid);
		Session ses = findSession(xid);
		if(ses == null)
		{
			ses = Session.createAndJoin(getKey(xid).toString());
			table.put(getKey(xid), ses);
		}
		else
		{
			ses.join();
		}
		if(ses.getCurrentTransaction() == null)
		{
			MessageLog.debug(this, "Actually starting transaction " + xid);
			ses.startTransaction("RDB");
		}
	}
	/**
	 * @param  xid
	 * @return
	 */
	protected Session findSession(final Xid xid)
	{
		final Session sess = (Session) table.get(getKey(xid));
		return sess;
	}
}
