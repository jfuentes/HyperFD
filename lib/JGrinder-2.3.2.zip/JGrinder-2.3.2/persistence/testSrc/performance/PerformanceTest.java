import java.util.*;
import java.lang.reflect.*;
import com.objectwave.persist.*;
import com.objectwave.transactionalSupport.*;
import com.objectwave.persist.broker.*;
/**
 * @author dhoag
 */
public class PerformanceTest
{
    TestEntity last;
    Random rnd = new Random();
    int queryBuildCount = 0;
    int deleteCount;
    int updateCount;
    static boolean noUpdate = System.getProperty("update") == null;
    static boolean realDatabase = System.getProperty("live") != null;
    static boolean realPool = System.getProperty("realPool") != null;
    static boolean painfull = System.getProperty("longQuery") != null;
	static int numberOfThreads = 1;
	static int numberOfOrders = 1;
	static int numberOfTransactions = 1;
    static double updateLimit = .49;
	/**
	 */
	public Vector query()
	{
	    try
	    {
            TestEntity search = new TestEntity();
            SQLQuery oq = new SQLQuery(search);
            search.setPhone("ptes%");
            oq.setAsLike(true);
            Vector v = oq.find();
            return v;
	    }
	    catch (Exception e) { e.printStackTrace(); } 
	    return new Vector();
	}
	/** */
	public void query(Vector v)
	{
		Enumeration e= v.elements();
		while(e.hasMoreElements())
	    try
	    {
	    	TestEntity orig = (TestEntity)e.nextElement();
            TestEntity search = new TestEntity();
            SQLQuery oq = new SQLQuery(search);
            search.setPrimaryKeyField(orig.getPrimaryKeyField());
            TestEntity t = (TestEntity)oq.findUnique();
	    }
	    catch (Exception ex) { ex.printStackTrace(); } 
	}
	protected static void doQueryLoad(PerformanceTest test, Vector v)
	{
		System.out.println("Doing long query with " + numberOfThreads + " number of threads.");
        int size = v.size();
        size = (size / numberOfThreads);
        v.setSize(size);
	    Thread [] threads = new Thread[ numberOfThreads ];
	    for(int i = 0; i < numberOfThreads ; ++i)
	    {
		    threads[i] = new Thread(test.getPerformanceQueryTest(v));
	    }
	    for(int i = 0; i < numberOfThreads ; ++i)
        {
		    threads[i].start();
        }
	    for(int i = numberOfThreads - 1; i >  -1; --i)
		    try
		    {
			    threads[i].join();
		    } catch (InterruptedException ex) {}

	}
    /**
     */
    protected static void dumpSql()
    {
        System.out.println("create table TestEntity (" );
        System.out.println("databaseIdentifier number (20) not null,");
        System.out.println("primaryContact number (20) ,");
        System.out.println("phone varchar (15) ,");
        System.out.println("annualIncome number (8) ,");
        System.out.println("entityType char (1) );");
        System.out.println("");
        System.out.println("create table TestPerson ( ");
        System.out.println("databaseIdentifier number (20) not null,");
        System.out.println("phone varchar (15) ,");
        System.out.println("name varchar (35));");
    }
    /**
     * This will default to
     * - ObjectPool execution only. 
     * - No updating of values.
     * Use -Dupdate to cause random updates (and exceptions)
     * Use -Dlive to go to a database.
     * Use -DrealPool to go to a database and use the object pool.
     */
    public static void main(String [] args)
    {
		System.getProperties().put( "Default.thresholdList", "com.objectwave.configuration:info" );
    	if(args.length == 0 )
    	{
    		System.out.println("Using default of 1 thread, 1 order, 1 transaction"); 
    	}
        if(args.length == 1)
        {
            if(args[0].equals("dumpSql") )
            {
                dumpSql();
                System.exit(0);
            }
        }
    		System.out.println("local= " + (System.getProperty("local") != null));
    		System.out.println("realPool= " + realPool);
    		System.out.println("live= " + realDatabase);
    		System.out.println("update=" + ! noUpdate);
            if(! noUpdate)
            try
            {
                updateLimit = .49;
                updateLimit = Double.parseDouble( System.getProperty("update"));
                System.out.println("Update percentage " + updateLimit + "%");
                updateLimit = updateLimit / 100;
            }
            catch(NumberFormatException ex)
            {
            }
            System.out.println("longQuery=" + painfull);
//        try { 
//            System.out.println("Press enter to begin");
//        new java.io.DataInputStream(System.in).readLine();        
//        } catch (Throwable t) {}


        boolean local = System.getProperty("local") != null;
        if(local)
        {
			FileBroker fb = new FileBroker();
			BrokerFactory.setDefaultBroker( fb );
			SQLQuery.setDefaultBroker( fb );
        }
		else
        if(realPool)
        {
            BrokerFactory.useDatabase(true , new ObjectPool());
        }
        else
        if(realDatabase)
		{
            BrokerFactory.useDatabase();
		}
        else
            BrokerFactory.useObjectPoolBroker(new ObjectPool());
        
        try { 
	        try
	        {
		        numberOfThreads = new Integer(args[0]).intValue();
		        numberOfOrders = new Integer(args[1]).intValue();
		        numberOfTransactions = new Integer(args[2]).intValue();
	        } catch (Exception e) {}
            
            PerformanceTest test = new PerformanceTest();
	        Thread [] threads = new Thread[ numberOfThreads ];
	        for(int i = 0; i < numberOfThreads ; ++i)
	        {
		        threads[i] = new Thread(test.getPerformanceTest());
	        }
	        long start = new java.util.Date().getTime();
	        for(int i = 0; i < numberOfThreads ; ++i)
		        threads[i].start();
	        for(int i = numberOfThreads - 1; i >  -1; --i)
		        try
		        {
			        threads[i].join();
		        } catch (InterruptedException ex) {}

	        long totalTime = System.currentTimeMillis() - start;
	        System.out.println("Insert + update time: " + totalTime + "ms");
	        int startCount = test.queryBuildCount ;
            start = System.currentTimeMillis();
            Vector v = test.query();
            if(!painfull)
            {
				test.increment(v.size());
			}
			else
			{
	            start = System.currentTimeMillis();
				doQueryLoad(test, v);
			}

            totalTime = System.currentTimeMillis() - start;
            double calc = (test.queryBuildCount - startCount) / (totalTime / 1000.0);
            System.out.println("Query time: " + totalTime + "ms for " + (test.queryBuildCount - startCount) + " objects. " + (int)calc + " objs/sec");
            start = new java.util.Date().getTime();
            test.deleteTestTestEntitys();
            totalTime = new java.util.Date().getTime() - start;
            System.out.println("Delete time: " + totalTime + "ms");
            System.out.println("UpdateCount : " + test.updateCount);
            System.out.println("QueryCount : " + test.queryBuildCount);
            System.out.println("Total Objects : " + test.deleteCount);
            BrokerFactory.getDatabaseBroker().close();
            if(System.getProperty("pause") != null)
            {
            	new java.io.DataInputStream(System.in).readLine();
            }
        }
        catch (Exception e) { e.printStackTrace(); } 
    }
    /**
     */
    public synchronized void increment(final int inc)
    {
        queryBuildCount += inc;
    }
    /**
     */
    public Runnable getPerformanceQueryTest(final Vector v)
    {
        return new Runnable()
        {
            public void run()
            {
                try
                { 
                    query(v);
                    increment(v.size());
                }
                catch (Exception e) { e.printStackTrace(); } 
            }
        };
    }
    /**
     */
    public Runnable getPerformanceTest()
    {
        return new Runnable()
        {
            public void run()
            {
                /*synchronized(System.getProperties())
                {
                    Object obj = System.getProperties().get("local");
                    if(obj == null) 
                    {
                        System.getProperties().put("local", new ThreadLocal());
                        System.out.println("Put local into system props");
                    }
                }
                */
                try
                { 
                    saveTestEntitys(numberOfOrders);
                }
                catch (Exception e) { e.printStackTrace(); } 
                //ThreadLocal loc = (ThreadLocal)System.getProperties().get("local");
                //System.out.println("Commit count " + loc.get());
            }
        };
    }
    /**
     */
    public void saveTestEntitys(int count) throws UpdateException, QueryException
    {
        for(int j = 0; j < numberOfTransactions; ++j)
        {
            Session session = Session.createAndJoin("as");
            session.startTransaction("RDB");
            for(int i = 0; i < count; ++i)
            {
                TestEntity orderId = new TestEntity();
                orderId.setPhone("ptest");
                orderId.setAnnualIncome((short)10021);
                TestPerson tp = new TestPerson();
                tp.setRetrievedFromDatabase(true);
                tp.setAsTransient(true);
                tp.setObjectIdentifier(new Integer(10201));
                tp.setAsTransient(false);
                orderId.setPrimaryContact(tp);
                last = orderId;
            } 
            session.commit();
            if(! noUpdate && (rnd.nextFloat() < updateLimit))
            {
                updateRandomAmounts();
            }
        }
    }
    /**
     */
    public void deleteTestTestEntitys() throws QueryException
    {
        TestEntity search = new TestEntity();
        SQLQuery oq = new SQLQuery(search);
        search.setPhone("ptes%");
        
        oq.setAsLike(true);
        // The original way
        /*
        Vector v = oq.find();
        deleteCount = v.size();
        System.out.println("About to delete " + deleteCount);
        Enumeration e = v.elements();
        while(e.hasMoreElements())
        {
            TestEntity obj = (TestEntity)e.nextElement();
            obj.delete();
        } 
        */
        try
        {
        	oq.deleteAll();
        }
        catch(Exception t){ t.printStackTrace(); }
    }
    /**
     */
    public void updateRandomAmounts() throws QueryException, UpdateException
    {
        Session session = Session.createAndJoin("as");
        session.startTransaction("RDB");
        increment(1);
        TestEntity obj = last;
        //    if(rnd.nextFloat() > .49)
         //   {
                updateCount++;
                obj.insert();
          //  }
        session.commit();
    }
}
