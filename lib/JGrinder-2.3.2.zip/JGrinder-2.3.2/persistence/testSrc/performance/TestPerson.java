
import java.util.*;
import com.objectwave.persist.mapping.*;
import com.objectwave.persist.*;
import com.objectwave.persist.examples.*;
import com.objectwave.transactionalSupport.*;
import java.lang.reflect.*;

public class TestPerson extends DomainObject
{
	static Field _name;

	static Field _phone;
	static Vector classDescriptor;
	
	String phone;
	String name;
	/**
	*  This method allows me to get arounds security problems with updating
	* and object from a generic framework.
	*/
	public void update(boolean get, Object [] data, Field [] fields)
	{
		for(int i = 0; i < data.length; i++)
		{
			try
			{
				if(get)
				{
					data[i] = fields[i].get(this);
				}
				else
				{
					fields[i].set(this, data[i]);
				}
			}
			catch(IllegalAccessException ex)
			{
				System.out.println(ex);
			}
			catch(IllegalArgumentException ex)
			{
				System.out.println(ex);
			}
		}
	}

	/**
	* This static block will be regenerated if persistence is regenerated. 
	*/
	static { /*NAME:fieldDefinition:*/
		try
		{
		_phone = TestPerson.class.getDeclaredField("phone");
		_name = TestPerson.class.getDeclaredField("name");

		}
		catch (NoSuchFieldException ex)
		{
			 System.out.println(ex);
		}
	}

	/**
	* Delegate the request for data ot the associated object Editor. This allows support for proxies and transactions.
	* @author JavaGrinder
	*/
	public String getPhone()
	{
		return (String)editor.get(_phone, phone);
	}
	/**
	* Delete the setting of data to the associated object editor. This allows support for proxies and transactions.
	* @author JavaGrinder
	*/
	public void setPhone(String aValue)
	{
		editor.set(_phone, aValue, phone);
	}
	/**
	* Delegate the request for data ot the associated object Editor. This allows support for proxies and transactions.
	* @author JavaGrinder
	*/
	public String getName()
	{
		return (String)editor.get(_name, name);
	}
	/**
	* Delete the setting of data to the associated object editor. This allows support for proxies and transactions.
	* @author JavaGrinder
	*/
	public void setName(String aValue)
	{
		editor.set(_name, aValue, name);
	}
	/**
	 * Describe how this class relates to the relational database.
	 */
	public void initDescriptor()
	{
		synchronized(TestPerson.class)
		{
			if(classDescriptor != null) return;
			classDescriptor = getSuperDescriptor();

 
			classDescriptor.addElement(AttributeTypeColumn.getAttributeRelation( "phone" , _phone)); 
			classDescriptor.addElement(AttributeTypeColumn.getAttributeRelation( "name" , _name));
		}
	}
	/**
	* Needed to define table name and the description of this class.
	*/
	public ObjectEditingView initializeObjectEditor()
	{
		final RDBPersistentAdapter result = (RDBPersistentAdapter)super.initializeObjectEditor();
		if(classDescriptor == null) initDescriptor();
		result.setTableName("testPerson");
		result.setClassDescription(classDescriptor);
		return result;
	}
	/**
	*/
	public static void main(String [] args)
	{
		com.objectwave.persist.BrokerFactory.useDatabase();
		TestPerson subj = new TestPerson();
		subj.setObjectIdentifier(new Integer(1));
		SQLQuery oq = new SQLQuery(subj);
		try
		{
			Vector v = oq.find();
			Enumeration e = v.elements();
			while(e.hasMoreElements())
			{
				TestPerson obj = (TestPerson)e.nextElement();
				System.out.println(obj.getName()); 
			} 
		}
		catch (Exception t)
		{
			t.printStackTrace();
		}
	} 
}
