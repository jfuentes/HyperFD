package com.objectwave.appArch.admin;

import java.lang.reflect.*;

/**
 * Holder for callback objects in the Command Callback Service
 *
 * @author  Dave Hoag
 * @version  3.1
 */
public class CallbackHolder
{
	private String externalCallName;
	private Object callbackObject;
	private String methodName;
	private String[] arguments;
	private String[] argumentDescriptions;
	private String methodDescription;
	private Method method;

	/**
	 * Should only be used by the systemsManagementService facade.
	 */
	CallbackHolder()
	{
	}
	/**
	 * Constructor that initializes the CallbackHolder.
	 *
	 * @param  callbackObject The target of the reflected invocation.
	 * @param  externalCallName String The unique name identifying this command.
	 * @param  methodName String The name of the method to invoke.
	 * @param  methodDescription String A nice description of the method.
	 * @param  arguments String [] Fully qualified class names.
	 * @param  argumentDescriptions
	 */
	public CallbackHolder(Object callbackObject, String externalCallName, String methodName, String methodDescription, String[] arguments, String[] argumentDescriptions)
	{
		setCallbackObject(callbackObject);
		setExternalCallName(externalCallName);
		setMethodName(methodName);
		setArguments(arguments);
		setArgumentDescriptions(argumentDescriptions);
		setMethodDescription(methodDescription);
		Method meth = getCallbackMethod(this);
		if(meth == null)
		{
			throw new IllegalArgumentException("Unable to reflectively locate method " + methodName + ". A Method is required.");
		}
		setMethod(meth);
	}
	/**
	 * Set the argument descriptions
	 *
	 * @param  someDescriptions The new ArgumentDescriptions value
	 */
	public void setArgumentDescriptions(String[] someDescriptions)
	{
		argumentDescriptions = someDescriptions;
	}
	/**
	 * Set the unvalidated arguments
	 *
	 * @param  someArguments The new Arguments value
	 */
	public void setArguments(String[] someArguments)
	{
		arguments = someArguments;
	}
	/**
	 * Set the callback object
	 *
	 * @param  aCallbackObject The new CallbackObject value
	 */
	public void setCallbackObject(Object aCallbackObject)
	{
		callbackObject = aCallbackObject;
	}
	/**
	 * Set the name of the external call. This is the name
	 * of the command that the remote client knows about.
	 *
	 * @param  anExternalCallName The new ExternalCallName value
	 */
	public void setExternalCallName(String anExternalCallName)
	{
		externalCallName = anExternalCallName;
	}
	/**
	 *Sets the Method attribute of the CallbackHolder object
	 *
	 * @param  aMethod The new Method value
	 */
	public void setMethod(Method aMethod)
	{
		method = aMethod;
	}
	/**
	 * Set the method description string.
	 *
	 * @param  aMethodDescription The new MethodDescription value
	 */
	public void setMethodDescription(String aMethodDescription)
	{
		methodDescription = aMethodDescription;
	}
	/**
	 * Set the mthod name
	 *
	 * @param  aMethodName The new MethodName value
	 */
	public void setMethodName(String aMethodName)
	{
		methodName = aMethodName;
	}
	/**
	 * Extract the elements of a result array into the individual elements.
	 * Each element in the array will have a corresponding data item.
	 * If the method has a return type of a 'String' instead of an array, return
	 * an array of size 1 containing that string.
	 *
	 * @param  meth The method we invoked.
	 * @param  result The result of the invocation
	 * @return  a collection of the result values.
	 */
	protected DataItem[] getResultValues(Method meth, Object result)
	{
		DataItem[] returnValues = null;
		if(meth.getReturnType() == void.class)
		{
			returnValues = new DataItem[0];
		}
		else
		{
			if(result.getClass().isArray())
			{
				int len = java.lang.reflect.Array.getLength(result);
				returnValues = new DataItem[len];
				for(int i = 0; i < len; ++i)
				{
					returnValues[i] = new DataItem("", meth.getReturnType().getComponentType().getName(), java.lang.reflect.Array.get(result, i).toString(), "");
				}
			}
			else
			{
				returnValues = new DataItem[1];
				returnValues[0] = new DataItem("", meth.getReturnType().getName(), result.toString(), "");
			}
		}
		return returnValues;
	}
	/**
	 * Return the argument descriptions as a string array object
	 *
	 * @return  The ArgumentDescriptions value
	 */
	public String[] getArgumentDescriptions()
	{
		return argumentDescriptions;
	}
	/**
	 *Gets the Arguments attribute of the CallbackHolder object
	 *
	 * @return  The Arguments value
	 */
	public String[] getArguments()
	{
		return arguments;
	}
	/**
	 * Return the correct Method object specified for the callbackObject
	 * in the CallbackHolder.  The CallbackHolder must be correctly
	 * configured.  This method acts as a validation of that specification.
	 * For instance, An exception is thrown from the getMethod
	 * method if the method is not found or an access exception is thrown if access
	 * is not public
	 *
	 * @param  callbackObj
	 * @return  java.lang.reflect.Method The reflected method.
	 */
	private Method getCallbackMethod(CallbackHolder callbackObj)
	{
		//check name of class
		Method returnVal = null;
		boolean logError = false;
		Exception error = null;
		Class callbackClass = callbackObj.getCallbackObject().getClass();
		String methodName = callbackObj.getMethodName();
		try
		{
			String[] argStrings = callbackObj.getArguments();
			Class[] arguments = new Class[argStrings.length];
			for(int i = 0; i < argStrings.length; ++i)
			{
				arguments[i] = Class.forName(argStrings[i]);
			}
			returnVal = callbackClass.getMethod(methodName, arguments);
		}
		catch(NoSuchMethodException ex)
		{
			//Could be a simply the method takes an array of strings, while the declaration individually presented the arguments.
			try
			{
				String[] emptyVar = new String[0];
				returnVal = callbackClass.getMethod(methodName, new Class[]{emptyVar.getClass()});
			}
			catch(Exception e)
			{
				logError = true;
				error = e;
			}
		}
		catch(Exception e)
		{
			logError = true;
			error = e;
		}
		if(logError)
		{
			System.out.println(error);
		}
		return returnVal;
	}
	/**
	 * @return  The object upon which this callback will be invoked.
	 */
	public Object getCallbackObject()
	{
		return callbackObject;
	}
	/**
	 * @return  String The name under which this command is registered.
	 */
	public String getExternalCallName()
	{
		return externalCallName;
	}
	/**
	 * @return  the Method object that was determined from the getCallbackMethod method.
	 * @see  #getCallbackMethod(CallbackHolder)
	 */
	public Method getMethod()
	{
		return method;
	}
	/**
	 * @return  The MethodDescription value
	 */
	public String getMethodDescription()
	{
		return methodDescription;
	}
	/**
	 * @return  The MethodName value
	 * @roseuid  365B4D400165
	 */
	public String getMethodName()
	{
		return methodName;
	}
	/**
	 * Execute the method of the callback object contained in the callbackHolder
	 *
	 * @param  command
	 * @return
	 */
	public Command executeCommand(Command command)
	{
		try
		{
			String[] arguments;
			if(command.args.length < 1)
			{
				arguments = new String[0];
			}
			else
			{
				arguments = new String[command.args.length];
				for(int i = 0; i < command.args.length; ++i)
				{
					arguments[i] = command.args[i].value;
				}
			}
			// populate the command object
			Object result;

			Class[] params = method.getParameterTypes();
			if(params.length == 1 && params[0] == arguments.getClass())
			{
				Object[] argsWrapper = new Object[]{arguments};
				result = method.invoke(getCallbackObject(), argsWrapper);
			}
			else
			{
				result = method.invoke(getCallbackObject(), arguments);
			}
			command.retValues = getResultValues(method, result);
		}
		catch(IllegalAccessException e)
		{
			System.out.println(e);
		}
		catch(InvocationTargetException e)
		{
			System.out.println(e);
		}
		return command;
	}
	/**
	 * Unit test of the ProcessDescriptor.
	 *
	 * @author  dhoag
	 * @version  $Id: CallbackHolder.java,v 1.2 2002/07/31 15:55:22 dave_hoag Exp $
	 */
	public static class Test extends com.objectwave.test.UnitTestBaseImpl
	{
		String[] complexResult = new String[]{"one", "two", "three"};
		/**
		 * No arguments will run all tests. Each argument is a test name.
		 *
		 * @param  args The command line arguments
		 */
		public static void main(String[] args)
		{
			com.objectwave.test.TestRunner.run(new Test(), args);
		}
		/**
		 * @return
		 */
		public String[] noArgsBigResult()
		{
			return complexResult;
		}
		/**
		 * @return
		 */
		public String noArgs()
		{
			return "shortOne";
		}
		/**
		 * @param  one
		 * @return
		 */
		public String oneArg(String one)
		{
			return one;
		}
		/**
		 * @param  one
		 * @param  two
		 * @return
		 */
		public String[] twoArgs(String one, String two)
		{
			return new String[]{one, two};
		}
		/**
		 * @param  vals
		 * @return
		 */
		public String[] twoArgsInOne(String[] vals)
		{
			return vals;
		}
		/**
		 *A unit test for JUnit
		 */
		public void testNoArgsSimpleReslut()
		{
			CallbackHolder holder = new CallbackHolder(this, "one", "noArgs", "A Description", new String[0], new String[0]);
			testContext.assertTrue("Method not found! ", holder.getMethod() != null);
			DataItem[] args = new DataItem[0];
			Command command = new Command("one", "", args, new DataItem[0]);
			command = holder.executeCommand(command);
			testContext.assertEquals("shortOne", command.retValues[0].value);
		}
		/**
		 *A unit test for JUnit
		 */
		public void testNoArgsComplexResult()
		{
			CallbackHolder holder = new CallbackHolder(this, "one", "noArgsBigResult", "A Description", new String[0], new String[0]);
			testContext.assertTrue("Method not found! ", holder.getMethod() != null);
			DataItem[] args = new DataItem[0];
			Command command = new Command("one", "", args, new DataItem[0]);
			command = holder.executeCommand(command);
			testContext.assertEquals(3, command.retValues.length);
			for(int i = 0; i < complexResult.length; ++i)
			{
				testContext.assertEquals(complexResult[i], command.retValues[i].value);
			}
		}
		/**
		 *A unit test for JUnit
		 */
		public void testOneArg()
		{
			CallbackHolder holder = new CallbackHolder(this, "one", "oneArg", "A Description", new String[]{"java.lang.String"}, new String[0]);
			testContext.assertTrue("Method not found! ", holder.getMethod() != null);
			DataItem[] args = new DataItem[1];
			String value = "aValue";
			args[0] = new DataItem("", "java.lang.String", value, "");
			Command command = new Command("one", "", args, new DataItem[0]);
			command = holder.executeCommand(command);
			testContext.assertEquals(value, command.retValues[0].value);
		}
		/**
		 *A unit test for JUnit
		 */
		public void testArgsArrayDecl()
		{
			String[] emptyVar = new String[0];
			CallbackHolder holder = new CallbackHolder(this, "one", "twoArgsInOne", "A Description", new String[]{emptyVar.getClass().getName()}, new String[0]);
			testContext.assertTrue("Method not found! ", holder.getMethod() != null);
			DataItem[] args = new DataItem[2];
			String value = "aValue";
			String value2 = "aValue2";
			args[0] = new DataItem("", "java.lang.String", value, "");
			args[1] = new DataItem("", "java.lang.String", value2, "");
			Command command = new Command("one", "", args, new DataItem[0]);
			command = holder.executeCommand(command);
			testContext.assertEquals(2, command.retValues.length);
			testContext.assertEquals(value, command.retValues[0].value);
			testContext.assertEquals(value2, command.retValues[1].value);
		}
		/**
		 *A unit test for JUnit
		 */
		public void testTwoArgs()
		{
			CallbackHolder holder = new CallbackHolder(this, "one", "twoArgs", "A Description", new String[]{"java.lang.String", "java.lang.String"}, new String[0]);
			testContext.assertTrue("Method not found! ", holder.getMethod() != null);
			DataItem[] args = new DataItem[2];
			String value = "aValue";
			String value2 = "aValue2";
			args[0] = new DataItem("", "java.lang.String", value, "");
			args[1] = new DataItem("", "java.lang.String", value2, "");
			Command command = new Command("one", "", args, new DataItem[0]);
			command = holder.executeCommand(command);
			testContext.assertEquals(2, command.retValues.length);
			testContext.assertEquals(value, command.retValues[0].value);
			testContext.assertEquals(value2, command.retValues[1].value);
		}
		/**
		 *A unit test for JUnit
		 */
		public void testArgsArrayIndividualDecl()
		{
			CallbackHolder holder = new CallbackHolder(this, "one", "twoArgsInOne", "A Description", new String[]{"java.lang.String"}, new String[0]);
			testContext.assertTrue("Method not found! ", holder.getMethod() != null);
			DataItem[] args = new DataItem[3];
			String value = "aValue";
			String value2 = "aValue2";
			String value3 = "aValue3";
			args[0] = new DataItem("", "java.lang.String", value, "");
			args[1] = new DataItem("", "java.lang.String", value2, "");
			args[2] = new DataItem("", "java.lang.String", value3, "");
			Command command = new Command("one", "", args, new DataItem[0]);
			command = holder.executeCommand(command);
			testContext.assertEquals(3, command.retValues.length);
			testContext.assertEquals(value, command.retValues[0].value);
			testContext.assertEquals(value2, command.retValues[1].value);
			testContext.assertEquals(value3, command.retValues[2].value);
		}
	}
}
