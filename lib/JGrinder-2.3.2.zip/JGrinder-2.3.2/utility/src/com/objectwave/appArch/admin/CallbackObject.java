package com.objectwave.appArch.admin;

import java.lang.reflect.*;
/**
 * Holder for callback objects in the Command Callback Service
 * Might make this an Inner class
 * Needs to include argument accessors
 *
 * @author  dhoag
 * @version  $Id: CallbackObject.java,v 1.1 2001/10/12 21:59:11 dave_hoag Exp $
 */
public class CallbackObject
{
	private String[] arguments;
	private String methodName;
	private Object callbackObject;
	/**
	 */
	CallbackObject()
	{
	}
	/**
	 * @param  callbackObject The new CallbackObject value
	 * @roseuid  365B4E840265
	 */
	public void setCallbackObject(Object callbackObject)
	{
		this.callbackObject = callbackObject;
	}
	/**
	 * @param  methodName The new MethodName value
	 * @roseuid  365B4E910304
	 */
	public void setMethodName(String methodName)
	{
		this.methodName = methodName;
	}
	/**
	 * @return  The CallbackObject value
	 * @roseuid  365B4DC701E1
	 */
	public Object getCallbackObject()
	{
		return callbackObject;
	}
	/**
	 * @return  The MethodName value
	 * @roseuid  365B4D400165
	 */
	public String getMethodName()
	{
		return methodName;
	}
	/**
	 * @param  command
	 * @param  parameters
	 * @return
	 * @roseuid  365C94220046
	 */
	public String[] executeCommand(String command, String[] parameters)
	{
		Class[] parms = null;
		Object[] invokeParms = null;
		if(parameters.length == 0)
		{
			parms = new Class[0];
			invokeParms = new Object[0];
		}
		else
		{
			parms = new Class[parameters.length];
			invokeParms = new Object[parameters.length];
			for(int i = 0; i < parameters.length; i++)
			{
				parms[i] = parameters[i].getClass();
				invokeParms[i] = (Object) parameters[i];
			}
		}
		// Lookup the command in the command callback list
		CallbackHolder callbackObject = CallbackService.getInstance().getRegisteredCallbackHolder(command);
		String methodName = callbackObject.getMethodName();

		try
		{
			Method method = callbackObject.getClass().getMethod(methodName, parms);
			method.invoke(callbackObject, invokeParms);
		}
		catch(IllegalAccessException e)
		{
			System.out.println(e);
		}
		catch(NoSuchMethodException e)
		{
			System.out.println(e);
		}
		catch(InvocationTargetException e)
		{
			System.out.println(e.getTargetException());
		}

		return new String[0];
	}
}
