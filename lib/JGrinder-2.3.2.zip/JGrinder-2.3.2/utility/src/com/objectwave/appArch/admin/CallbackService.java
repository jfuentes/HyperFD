/*
 *  Copyright (C) 2001 David Hoag
 *  ObjectWave Corporation
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *  For a full copy of the license see:
 *  http://www.opensource.org/licenses/lgpl-license.html
 */
package com.objectwave.appArch.admin;
import com.objectwave.logging.MessageLog;

import java.lang.reflect.*;
import java.util.*;
/**
 *  Use this service register command callbacks and properties.
 *
 * @author  dhoag
 * @version  3.1
 */
public class CallbackService
{
	final static String getItKey = "getItKey";
	final static String setItKey = "setItKey";
	private static CallbackService instance;
	private Hashtable registeredProperties;
	private Hashtable registeredCallbacks;
	/**
	 * @return  The singleton instance of the CallbackService.
	 */
	public static CallbackService getInstance()
	{
		if(instance == null)
		{
			instance = new CallbackService();
		}
		return instance;
	}
	/**
	 * Get the Command Object that will allow you to get the property or set the
	 * property value.
	 *
	 * @param  setMethod true if you want the set method.
	 * @param  propertyName
	 * @return  The PropertyCommand value
	 * @exception  UnsupportedCommand
	 * @parma  propertyName A name of a known property
	 */
	public Command getPropertyCommand(String propertyName, boolean setMethod) throws UnsupportedCommand
	{
		CallbackHolder aCallbackHolder = getPropertyCallbackHolder(propertyName, setMethod);
		if(aCallbackHolder == null)
		{
			throw new UnsupportedCommand(propertyName);
		}
		return createCommand(aCallbackHolder);
	}
	/**
	 *  Convert a registered Callback object to aCommand
	 *
	 * @param  aName A registered command name.
	 * @return  The command registered with the provided name.
	 * @exception  UnsupportedCommand
	 * @see  #registerForCommandCallback
	 */
	public Command getCommand(String aName) throws UnsupportedCommand
	{
		CallbackHolder aCallbackHolder = getRegisteredCallbackHolder(aName);
		if(aCallbackHolder == null)
		{
			throw new UnsupportedCommand(aName);
		}
		return createCommand(aCallbackHolder);
	}
	/**
	 * @return  All of the names of the currently registered callbacks.
	 */
	public Enumeration getCallbackNames()
	{
		return getRegisteredCallbacks().keys();
	}
	/**
	 *  Usefull for determining the property names.
	 *
	 * @return  All of the names of the currently registered callbacks.
	 */
	public Enumeration getPropertyNames()
	{
		final Enumeration e = getRegisteredProperties().keys();
		return
			new Enumeration()
			{
				Object next = null;
				Vector shown = new Vector();
				/**
				 * @return
				 */
				public boolean hasMoreElements()
				{
					if(!e.hasMoreElements())
					{
						return false;
					}
					if(next != null)
					{
						return true;
					}
					next = realNext();
					return (next != null);
				}
				/**
				 * @return
				 */
				public Object nextElement()
				{
					if(next != null)
					{
						Object tmp = next;
						next = null;
						return tmp;
					}
					return realNext();
				}
				/**
				 * @return
				 */
				private Object realNext()
				{
					//Generate the appropriate exception
					if(!e.hasMoreElements())
					{
						e.nextElement();
					}
					while(e.hasMoreElements())
					{
						String key = (String) e.nextElement();
						key = key.substring(8, key.length());
						if(shown.contains(key))
						{
							continue;
						}
						shown.addElement(key);
						return key;
					}
					return null;
				}
			};
	}
	/**
	 *  Return the CallbackHolder for a given name
	 *
	 * @param  aName Name of a uniquely identified command.
	 * @return  The RegisteredCallbackHolder value
	 */
	protected CallbackHolder getRegisteredCallbackHolder(String aName)
	{
		return (CallbackHolder) getRegisteredCallbacks().get(aName);
	}
	/**
	 * @return  a Hashtable containing all of the registered callbacks.
	 */
	protected Hashtable getRegisteredCallbacks()
	{
		if(registeredCallbacks == null)
		{
			registeredCallbacks = new Hashtable();
		}
		return registeredCallbacks;
	}
	/**
	 * @return  a Hashtable containing the registered properties
	 */
	protected Hashtable getRegisteredProperties()
	{
		if(registeredProperties == null)
		{
			registeredProperties = new Hashtable();
		}
		return registeredProperties;
	}
	/**
	 *  A utility method used by this implementation to obtain the callback holder
	 *  object.
	 *
	 * @param  propertyName String
	 * @param  setMethod
	 * @return  The PropertyCallbackHolder value
	 */
	protected CallbackHolder getPropertyCallbackHolder(final String propertyName, final boolean setMethod)
	{
		String key;
		if(setMethod)
		{
			key = setItKey
			/*
			 *  + target.getClass().getName()
			 */
					 + propertyName;
		}
		else
		{
			key = getItKey
			/*
			 *  + target.getClass().getName()
			 */
					 + propertyName;
		}
		Hashtable knownProps = getRegisteredProperties();
		return (CallbackHolder) knownProps.get(key);
	}
	/**
	 * @param  aCallbackHolder
	 * @return
	 */
	protected Command createCommand(CallbackHolder aCallbackHolder)
	{
		String[] argTypes = aCallbackHolder.getArguments();
		String[] argsDescriptions = aCallbackHolder.getArgumentDescriptions();
		DataItem[] args = new DataItem[argTypes.length];
		for(int i = 0; i < args.length; ++i)
		{
			String desc;
			if(i < argsDescriptions.length)
			{
				desc = argsDescriptions[i];
			}
			else
			{
				desc = "";
			}
			String type = argTypes[i];
			if(type == null)
			{
				type = "";
			}
			args[i] = new DataItem("", type, "", desc);
		}
		Method meth = aCallbackHolder.getMethod();
		DataItem[] returnType = null;
		if(meth.getReturnType() == void.class)
		{
			returnType = new DataItem[0];
		}
		else
		{
			returnType = new DataItem[1];
			returnType[0] = new DataItem("", meth.getReturnType().getName(), "", "");
		}
		return new Command(aCallbackHolder.getExternalCallName(), aCallbackHolder.getMethodDescription(), args, returnType);
	}

	/**
	 *  Execute the provided command object. Values for the arguments should be set
	 *  in the DataItems in the command object.
	 *
	 * @param  command The command object obtained via the getCommand method.
	 * @return
	 * @exception  NoSuchMethodException
	 * @see  #getCommand
	 */
	public boolean executeCommand(Command command) throws NoSuchMethodException
	{
		CallbackHolder holder = getRegisteredCallbackHolder(command.name);
		if(holder == null)
		{
			boolean setMethod = (command.name.indexOf(setItKey) == 0);
			//relies on set and get keys to have the same length
			String name = command.name.substring(setItKey.length());
			holder = getPropertyCallbackHolder(name, setMethod);
		}
		if(holder == null)
		{
			MessageLog.warn(this, "Failed to locate a CallbackHolder given command " + command.name);
			throw new NoSuchMethodException(command.name);
		}
		holder.executeCommand(command);
		return true;
	}
	/**
	 *  Initialize the CommandCallback Service and return a true value if
	 *  successful. The initialize() method uses the specification for the
	 *  CommandCallback service from the ApplicationConfigurationService.
	 *
	 * @param  callbackObject The object on which to invoke the command.
	 * @param  externalCallName
	 * @param  methodName
	 * @param  methodDescription
	 * @param  arguments
	 * @param  argumentDescriptions
	 * @exception  IllegalArgumentException
	 */
	public void registerForCommandCallback(Object callbackObject, String externalCallName, String methodName, String methodDescription, String[] arguments, String[] argumentDescriptions) throws IllegalArgumentException
	{
		if(getRegisteredCallbackHolder(externalCallName) == null)
		{
			CallbackHolder callbackHolder = new CallbackHolder(callbackObject, externalCallName, methodName, methodDescription, arguments, argumentDescriptions);
			getRegisteredCallbacks().put(externalCallName, callbackHolder);
		}
		else
		{
			throw new IllegalArgumentException("Attempt to registered a Duplicate CallbackHolder with name = " + externalCallName + " - use another Call Name");
		}
	}
	/**
	 *  Return true if registration of a property is sucessful. This method stores
	 *  the property into the list of registered properties.
	 *
	 * @param  target The object containing the property.
	 * @param  propertyName A unique property name.
	 * @param  setMethodName The name of a method to call to set the property.
	 * @param  getMethodName The name of a method to call to get the property
	 *      value.
	 * @return
	 */
	public boolean registerProperty(Object target, String propertyName, String setMethodName, String getMethodName)
	{
		Hashtable knownProps = getRegisteredProperties();
		final String[] args = {};
		final String[] desc = {};
		String key = getItKey
		/*
		 *  + target.getClass().getName()
		 */
				 + propertyName;
		CallbackHolder callback = null;
		if(getMethodName != null)
		{
			callback = new CallbackHolder(target, key, getMethodName, "", args, desc);
			if(knownProps.containsKey(key))
			{
				throw new IllegalArgumentException("Attempt to registered a Duplicate Property with name = " + propertyName + " - use another property name.");
			}
			knownProps.put(key, callback);
		}
		if(setMethodName != null)
		{
			final String[] args2 = {"java.lang.String"};
			key = setItKey
			/*
			 *  + target.getClass().getName()
			 */
					 + propertyName;
			callback = new CallbackHolder(target, key, setMethodName, "", args2, desc);
			knownProps.put(key, callback);
		}
		return true;
	}
	/**
	 * @author  dhoag
	 * @version  $Id: CallbackService.java,v 1.2 2002/07/31 15:55:22 dave_hoag Exp $
	 */
	public static class Test extends com.objectwave.test.UnitTestBaseImpl
	{
		String testVar;
		//The following is only necessary for unit testing. Hence it is not part of the actual service.
		/**
		 */
		public static void clearInstance()
		{
			CallbackService.instance = null;
		}
		/**
		 *  The main program for the Test class
		 *
		 * @param  args The command line arguments
		 */
		public static void main(String[] args)
		{
			com.objectwave.test.TestRunner.run(new Test(), args);
		}
		/**
		 *  The JUnit setup method
		 *
		 * @param  methodName The new Up value
		 * @param  context The new Up value
		 */
		public void setUp(String methodName, com.objectwave.test.TestContext context)
		{
			testVar = "returnMe";
		}
		/**
		 *  Test methods.
		 *
		 * @param  arg The new Me value
		 */
		public void setMe(String arg)
		{
			testVar = arg;
		}
		/**
		 *  Test methods.
		 *
		 * @return  The Me value
		 */
		public String getMe()
		{
			return testVar;
		}
		/**
		 *  A unit test for JUnit
		 */
		public void testProperties()
		{
			CallbackService svc = CallbackService.getInstance();
			try
			{
				svc.registerProperty(this, "me", "setMe", "getMe");
				svc.registerProperty(this, "me2", "setMe", "getMe");
				Command getCommand = svc.getPropertyCommand("me", false);
				svc.executeCommand(getCommand);
				DataItem returnVal = getCommand.retValues[0];
				testContext.assertEquals("Failed to get the proper value!", testVar, returnVal.value);
				String newVal = "newValue";
				Command setCommand = svc.getPropertyCommand("me", true);
				setCommand.args[0].value = newVal;
				svc.executeCommand(setCommand);

				Enumeration e = svc.getPropertyNames();
				int count = 0;
				while(e.hasMoreElements())
				{
					e.nextElement();
					count++;
				}
				testContext.assertEquals("Failed to find all properties", 2, count);

				svc.executeCommand(getCommand);
				returnVal = getCommand.retValues[0];
				testContext.assertEquals("Failed to get the proper value!", newVal, returnVal.value);
			}
			catch(Throwable t)
			{
				t.printStackTrace();
				testContext.assertTrue(t.toString(), false);
			}
		}

		/**
		 *  A unit test for JUnit
		 */
		public void testCommandCallback()
		{
			CallbackService svc = CallbackService.getInstance();
			try
			{
				String methodDesc = "aMethodDesc";
				String[] args = new String[]{"java.lang.String"};
				String[] argDesc = new String[]{"anArgDesc"};
				svc.registerForCommandCallback(this, "aMethodKey", "setMe", methodDesc, args, argDesc);
				Command command = svc.getCommand("aMethodKey");
				testContext.assertEquals("aMethodKey", command.name);
				testContext.assertEquals(methodDesc, command.description);
				for(int i = 0; i < command.args.length; ++i)
				{
					testContext.assertEquals(command.args[i].type, "java.lang.String");
					testContext.assertEquals(command.args[i].description, "anArgDesc");
				}
				try
				{
					svc.getCommand("aBogusCommand");
					testContext.assertTrue("UnsupportedCommandException not thrown!", false);
				}
				catch(UnsupportedCommand ex)
				{
				}
			}
			catch(Throwable t)
			{
				testContext.assertTrue(t.toString(), false);
			}
		}
		/**
		 */
		public void testCommandCallbackInheritence()
		{
			CallbackService svc = CallbackService.getInstance();
			try
			{
				String methodDesc = "aMethodDesc";
				String[] args = new String[]{};
				String[] argDesc = new String[]{};
				svc.registerForCommandCallback(this, "toString", "toString", methodDesc, args, argDesc);
				Command command = svc.getCommand("toString");
				testContext.assertEquals("toString", command.name);
				testContext.assertEquals(methodDesc, command.description);
				testContext.assertEquals(0, command.args.length);
			}
			catch(Throwable t)
			{
				testContext.assertTrue(t.toString(), false);
			}
		}
	}
}
