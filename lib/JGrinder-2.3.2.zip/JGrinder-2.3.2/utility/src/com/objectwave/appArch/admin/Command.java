package com.objectwave.appArch.admin;

/**
 * @author  dhoag
 * @version  $Id: Command.java,v 1.1 2001/10/12 21:59:11 dave_hoag Exp $
 */
public class Command implements java.io.Serializable, java.lang.Cloneable
{
	/**
	 */
	public java.lang.String name;
	/**
	 */
	public java.lang.String description;
	/**
	 */
	public DataItem[] args;
	/**
	 */
	public DataItem[] retValues;

	/**
	 *Constructor for the Command object
	 */
	public Command()
	{
	}
	/**
	 *Constructor for the Command object
	 *
	 * @param  name
	 * @param  description
	 * @param  args
	 * @param  retValues
	 */
	public Command(
	// constructor
	java.lang.String name,
			java.lang.String description,
			DataItem[] args,
			DataItem[] retValues)
	{
		this.name = name;
		this.description = description;
		this.args = args;
		this.retValues = retValues;
	}
	/**
	 * @return
	 */
	public java.lang.Object clone()
	{
		Command _dest;
		try
		{
			_dest = (Command) super.clone();
			if(null != retValues)
			{
				_dest.retValues = (DataItem[]) retValues.clone();
			}
			if(null != args)
			{
				_dest.args = (DataItem[]) args.clone();
			}
		}
		catch(java.lang.CloneNotSupportedException _ex)
		{
			throw new java.lang.Error(_ex.getMessage());
		}
		return _dest;
	}
}
