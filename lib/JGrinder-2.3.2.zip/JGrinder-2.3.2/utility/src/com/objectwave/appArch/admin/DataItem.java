package com.objectwave.appArch.admin;

/**
 * @author  dhoag
 * @version  $Id: DataItem.java,v 1.1 2001/10/12 21:59:11 dave_hoag Exp $
 */
public class DataItem implements java.io.Serializable, java.lang.Cloneable
{
	/**
	 */
	public java.lang.String name;
	/**
	 */
	public java.lang.String type;
	/**
	 */
	public java.lang.String value;
	/**
	 */
	public java.lang.String description;

	/**
	 *Constructor for the DataItem object
	 */
	public DataItem()
	{
	}
	/**
	 *Constructor for the DataItem object
	 *
	 * @param  name
	 * @param  type
	 * @param  value
	 * @param  description
	 */
	public DataItem(
	// constructor
	java.lang.String name,
			java.lang.String type,
			java.lang.String value,
			java.lang.String description)
	{
		this.name = name;
		this.type = type;
		this.value = value;
		this.description = description;
	}
	/**
	 * @return
	 */
	public Object clone()
	{
		try
		{
			return super.clone();
		}
		catch(CloneNotSupportedException ex)
		{
			return this;
		}
	}
}
