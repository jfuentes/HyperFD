<!--

var NS4 = (document.layers) ? 1 : 0;
var IE4 = (document.all) ? 1 : 0;
var ver4 = (NS4 || IE4) ? 1 : 0;
var firstEl = "";
var firstInd = -1;

if (ver4) {
    with (document) {
        write("<STYLE TYPE='text/css'>");
        if (NS4) {
            write(".parent {position:absolute; visibility:visible}");
            write(".child {position:absolute; visibility:visible}");
            write(".regular {position:absolute; visibility:visible}")
        }
        else {
            write(".child {display:none}")
        }
        write("</STYLE>");
    }
}

var isExpanded = false;

function getIndex(el) {
    ind = null;
    for (i=0; i<document.layers.length; i++) {
        whichEl = document.layers[i];
        if (whichEl.id == el) {
            ind = i;
            break;
        }
    }
    return ind;
}

function arrange() 
{
    nextY = document.layers[firstInd].pageY + document.layers[firstInd].document.height;
    for (i=firstInd+1; i<document.layers.length; i++) {
        whichEl = document.layers[i];
        if (whichEl.visibility != "hide") {
            whichEl.pageY = nextY;
            nextY += whichEl.document.height;
        }
    }
}

function initIt()
{
    if (!ver4) return;
    if (NS4)
	{
        for (i=0; i<document.layers.length; i++) {
            whichEl = document.layers[i];
        //alert(" Looking at " + whichEl.id);
            if (whichEl.id.indexOf("Child") != -1) 
			{
		//		alert("hiding it");
				whichEl.visibility = "hide";
			}
        }
        arrange();
    }
    else
	{
        divColl = document.all.tags("DIV");
        for (i=0; i<divColl.length; i++)
		{
            whichEl = divColl(i);
            if (whichEl.className == "child") whichEl.style.display = "none";
        }
    }
}
/**
 * The parameter must be the full parent name.
 */
function expandIt(el)
{
    if (!ver4) return;
	var more = true;
	var count = 0;
	while(more)
	{
    if (IE4)
	{
        whichEl = eval("document.all['" + el + "Child" + count + "']");
        //alert("document.all['" +  el + "Child" + count + "'] : " + whichEl);
		if(whichEl)
		{
			whichIm = event.srcElement;
			if (whichEl.style.display == "none") 
			{
				whichEl.style.display = "block";
				whichIm.src = "triUp.gif";        
				whichEl.theImage = whichIm;
			}
			else
			{
				whichEl.style.display = "none";
				whichIm.src = "triDown.gif";
				collapseAllChildren(el + "Child" + count);
			}
			count += 1;
		}
		else
		{
			more = false;
		}
    }
    else
	{
        whichEl = eval("document." + el + "Child" + count);
		if(whichEl)
		{
			whichIm = eval("document." + el + ".document.images['imEx']");
			if (whichEl.visibility == "hide")//If hidden, show
			{
				whichEl.visibility = "show";
				whichIm.src = "triUp.gif";
				whichEl.theImage = whichIm;
			}
			else //Must already be shown, hide
			{
				whichEl.visibility = "hide";
				whichIm.src = "triDown.gif";
				collapseAllChildren(el + "Child" + count);
			}
			arrange();
			count += 1;
		}
		else
		{
			more = false;
		}
    }
	}
}
/**
 */
function collapseAllChildren(element)
{
	var count = 0;
	var more = true;
	while(more)
	{
	var childEl;
	if(IE4)
	{
		childEl= eval("document.all['" + element + "Child" + count + "']");
	}
	else
	{
    	childEl = eval("document." + element + "Child" + count);
	}
	if(childEl)
	{
		if(childEl.visibility == "hide")
		{
			return;
		}
		if(IE4)
		{
			if(childEl.style.display == "none") return;
            childEl.style.display = "none";
		}
		else
		{
			childEl.visibility = "hide";
		}	
		if(childEl.theImage)
			childEl.theImage.src = "triDown.gif";
		collapseAllChildren(element + "Child" + count);
		count += 1;
	}
	else
	{
		more = false;
	}
	}
}
function expandAll() 
{
    if (!ver4) return;
    newSrc = (isExpanded) ? "triDown.gif" : "triUp.gif";

    if (NS4) {
        document.images["imEx"].src = newSrc;
        for (i=firstInd; i<document.layers.length; i++) {
            whichEl = document.layers[i];
            if (whichEl.id.indexOf("Parent") != -1) {
                whichEl.document.images["imEx"].src = newSrc;
            }
            if (whichEl.id.indexOf("Child") != -1) {
                whichEl.visibility = (isExpanded) ? "hide" : "show";
            }
        }

        arrange();
        if (isExpanded) scrollTo(0,document.layers[firstInd].pageY);
    }
    else {
        divColl = document.all.tags("DIV");
        for (i=0; i<divColl.length; i++) {
            if (divColl(i).className == "child") {
                divColl(i).style.display = (isExpanded) ? "none" : "block";
            }
        }
        imColl = document.images.item("imEx");
        for (i=0; i<imColl.length; i++) {
            imColl(i).src = newSrc;
        }
    }
    
    isExpanded = !isExpanded;
}

//-->
