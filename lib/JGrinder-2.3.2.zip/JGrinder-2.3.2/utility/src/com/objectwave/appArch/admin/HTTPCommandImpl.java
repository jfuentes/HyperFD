package com.objectwave.appArch.admin;
import com.objectwave.logging.MessageLog;

import com.objectwave.simpleSockets.*;
import com.objectwave.utility.TreeCollection;
import java.io.*;
import java.net.*;
import java.util.*;
/**
 *  Expose Command Callback functions through HTTP.
 *
 * @author  Dave Hoag
 * @version  1.0
 * @created  October 11, 2001
 */
public class HTTPCommandImpl implements ReplyHandler
{

	SimpleHTTP httpServer;
	/**
	 *  Start the HTML document and fill in the required fields.
	 *
	 * @param  title The title to use for the HTML document.
	 * @param  javascript The data to place in the HEAD portion of the html
	 *      document.
	 * @param  bodyAttributes A string to put within the BODY tag. Can be used to
	 *      specify an 'onLoad' event handler.
	 * @return  The DocHeader value
	 */
	public String getDocHeader(String title, String javascript, String bodyAttributes)
	{
		if(title == null)
		{
			title = "Command Console for " + System.getProperty("ow.ProcessName", "Not Named");
		}
		return "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 3.2//EN\">" +
				"<HTML>\n<HEAD>\n" + javascript +
				"<META HTTP-EQUIV='Content-Type' CONTENT='text/html;CHARSET=iso-8859-1'>" +
				"<TITLE>" + title + "</TITLE>\n</HEAD>\n<BODY " + bodyAttributes + '>';
	}

	/**
	 * @return  The Tail value
	 */
	public String getTail()
	{
		return "</BODY></HMTL>";
	}
	/**
	 *  Get the callback commands from the CallbackService.
	 *
	 * @return  The AllCommands value
	 * @see
	 */
	public Command[] getAllCommands()
	{
		Vector v = new Vector();
		Enumeration e = CallbackService.getInstance().getCallbackNames();
		while(e.hasMoreElements())
		{
			String name = (String) e.nextElement();
			try
			{
				Command c = CallbackService.getInstance().getCommand(name);
				v.addElement(c);
			}
			catch(Exception ex)
			{
				//The Command for which we are requesting is simply not part of the result set.
				//This is not a fatal exception
				System.out.println("Failed to find callback command." + ex);
			}
		}
		Command[] result = new Command[v.size()];
		v.copyInto(result);
		return result;
	}
	/**
	 *  Create an HTML body that will represent all of the regestered commands.
	 *  This body uses DIV tags and JavaScript to create a collapseable tree
	 *  like structure for displaying the commands.
	 *
	 * @return  String All of the commands in a predefined formatted HTML
	 *      document that will work with the JavaScript.
	 */
	protected String getAllCommandsHTML()
	{
		StringBuffer result = new StringBuffer(getServerInformation());
		try
		{
			Command[] commands = getAllCommands();
			String[] keys = new String[commands.length];
			for(int i = 0; i < commands.length; ++i)
			{
				keys[i] = commands[i].name;
				if(keys[i].indexOf('.') < 0)
				{
					keys[i] = System.getProperty("ow.ProcessName", "Not Named") + '.' + keys[i];
				}
			}
			//Sort it so that commands appear in some sort of order
			com.objectwave.utility.Sorter.quickSort(keys, commands);
			com.objectwave.utility.TreeCollection tree = new TreeCollection();
			for(int i = 0; i < commands.length; ++i)
			{
				StringTokenizer st = new StringTokenizer(keys[i], ".");
				String root = st.nextToken();
				while(st.hasMoreTokens())
				{
					String token = st.nextToken();
					if(st.hasMoreTokens())
					{
						//Skip the last one

						tree.put(root, token);
						root = token;
					}
				}
				tree.put(root, commands[i]);
			}
			formatCommands(tree, result);
		}
		catch(Throwable t)
		{
			t.printStackTrace();
		}
		return getDocHeader("All Commands", getSeedString(), "") + result + getTail();
		//return getDocHeader("All Commands", "",  "") + result + getTail();
	}
	/**
	 *  The seedstring will be included in the HTML header of the getAllCommands
	 *  request.
	 *
	 * @return  String JavaScript that will setup the expanding command tree.
	 */
	protected String getSeedString()
	{
		return "<SCRIPT LANGUAGE =\"JavaScript\" SRC=ExpandIt.js></SCRIPT>\n" +
				"<SCRIPT LANGUAGE =\"JavaScript\" >\n " +
				"function initialize() { \nif (NS4) { firstEl = '" + System.getProperty("ow.ProcessName", "Not Named") + "';\n " +
				"  firstInd = getIndex(firstEl);\n " +
		//  " alert(firstEl + \" FirstEl idx \" + firstInd);\n " +
				"  arrange(); }\n initIt();\n }" +
				" onload = initialize;\n " +
				"</SCRIPT>";
	}
	/**
	 *  A convience method to get the server name to put on an HTML page.
	 *
	 * @return  String The information to place at the top of the page.
	 */
	String getServerInformation()
	{
		String back = " Server: <B>";
		try
		{
			back += java.net.InetAddress.getLocalHost().getHostName();
		}
		catch(Throwable t)
		{
			/*
			 *  i don't care
			 */
		}
		back += "</B>";
		return back;
	}
	/**
	 */
	public void initialize()
	{
		String httpPort = System.getProperty("HTTPPort", "3003");
		int portNum = new Integer(httpPort).intValue();
		httpServer = new SimpleHTTP(portNum);
		ServeHTTPClient.setDefaultReplyHandler(this);
		httpServer.startServer();
	}
	/**
	 */
	public void shutdown()
	{
	}
	/**
	 *  Process an incomming URL request. This is basically anything that is
	 *  after the URL Port Number http://localhost:2003/one The command would be
	 *  '/one'.
	 *
	 * @param  urlRequest The command received from the browser.
	 * @return
	 */
	public InputStream processRequest(String urlRequest)
	{
		MessageLog.debug(this, "Processing HTTP Request: " + urlRequest);
		int idx = urlRequest.indexOf(':');
		if(idx > -1)
		{
			//The data is formatted via a custom defined way of parameter parsing
			return processRequest(urlRequest, idx);
		}
		idx = urlRequest.indexOf('?');
		if(idx > -1)
		{
			//Standard CGI form request
			return processFormRequest(urlRequest, idx);
		}
		//No args command
		return processRequest(urlRequest, -1);
	}
	/**
	 *  The URL request was the result of a Form 'get' method. Extract the
	 *  command and the arguments from the URL and pass this onto the
	 *  processCommandWork method.
	 *
	 * @param  urlRequest A URL that is a form 'get' request.
	 * @param  idx The index of the start of the arguments in the URL
	 * @return  InputStream A stream that is the result of the request.
	 * @see  #processCommandWork
	 */
	protected InputStream processFormRequest(String urlRequest, int idx)
	{
		String commandString;
		String argString = null;
		commandString = urlRequest.substring(0, idx);
		argString = urlRequest.substring(idx + 1);
		StringBuffer newArgs = new StringBuffer(argString.length());
		StringTokenizer st = new StringTokenizer(argString, "&");
		while(st.hasMoreTokens())
		{
			String paramName = st.nextToken();
			if(newArgs.length() != 0)
			{
				newArgs.append(',');
			}
			paramName = paramName.substring(paramName.indexOf('=') + 1);
			paramName = paramName.replace('+', ' ');
			newArgs.append(paramName);
//			System.out.println("Param " + paramName);
		}
		return processCommandWork(commandString, newArgs.toString());
	}
	/**
	 *  Process the urlRequest as a either a noArg request, or a request that
	 *  was formatted to a custom style. The custom style should not be used,and
	 *  is kept around for legacy reasons. Extract the command and the arguments
	 *  from the URL and pass this onto the processCommandWork method.
	 *
	 * @param  urlRequest A URL that should identify a command in the command
	 *      callback service.
	 * @param  idx int The index of a ":" in the urlRequest. This was the
	 *      original mechanism for parameter processing.
	 * @return  InputStream A stream that is the result of the request.
	 * @see  #processCommandWork
	 */
	protected InputStream processRequest(String urlRequest, int idx)
	{
		String commandString;
		String argString = null;
		if(idx > -1)
		{
			commandString = urlRequest.substring(0, idx);
			argString = urlRequest.substring(idx + 1);
		}
		else
		{
			commandString = urlRequest;
		}
		return processCommandWork(commandString, argString);
	}
	/**
	 *  Not the most efficient way to serve a file to the browser, but this
	 *  should not be used under heavy load.
	 *
	 * @param  fileName The name of resource to return as an InputStream.
	 * @return  InputStream The data found in the provided resource.
	 */
	protected InputStream fileFetch(String fileName)
	{
		try
		{
			if(fileName.startsWith("/"))
			{
				fileName = fileName.substring(1);
			}
			//First check the directory of this class.
			InputStream in = this.getClass().getResourceAsStream(fileName);
			if(in == null)
			{
				//No Check the classpath
				in = this.getClass().getResourceAsStream("/" + fileName);
			}
			else
			{
				//getResource call succeeded
				try
				{
					//The stream.available method is unreliable. Since I need an accurate size, we do the following
					ByteArrayOutputStream bos = new ByteArrayOutputStream();
					byte[] data = new byte[1024];
					for(int i = in.read(data); i > -1; i = in.read(data))
					{
						bos.write(data, 0, i);
					}
					return new ByteArrayInputStream(bos.toByteArray());
				}
				catch(Exception e)
				{
					in = null;
					System.err.println(e);
				}
			}
			if(in == null)
			{
				MessageLog.info(this, "Requested HTTP resource " + fileName + " not located, trying as command.");
				return null;
			}
			return in;
		}
		catch(Throwable t)
		{
			t.printStackTrace();
		}
		return null;
	}
	/**
	 *  Process the command and return the results. The command may not actually
	 *  be a command, it may be a resource (like an image) that the browser
	 *  needs for display.
	 *
	 * @param  commandString A known registered command or a file resource.
	 * @param  argString Comma separated arguments.
	 * @return  InputStream A stream that is the result of the request.
	 */
	protected InputStream processCommandWork(String commandString, String argString)
	{
		//Fetch and JavaScript or image files
		if(commandString.endsWith(".js") || commandString.endsWith(".gif") || commandString.endsWith(".jpg"))
		{
			InputStream result = fileFetch(commandString);
			if(result != null)
			{
				return result;
			}
			//Might be a weird command name
		}
		StringBuffer result = new StringBuffer();

		//If it is the root node, it's a getAllCommands call
		if(commandString.equals("/") || commandString.equals("/\\"))
		{
			MessageLog.debug(this, "Getting all commands.");
			return new StringBufferInputStream(getAllCommandsHTML());
		}
		else
		{
			String back = getServerInformation();
			back += ':' + System.getProperty("ow.ProcessName", "Not Named");
			back += "</B>\n<BR><A HREF=\"/\">Show All Commands</A><P>\n";
			result.append(back);
			result.append("<PRE>");
			processCommand(commandString, argString, result);
			result.append("</PRE>");
		}

		return new StringBufferInputStream(getDocHeader(null, "", "") + result + getTail());
	}
	/**
	 *  Format the BODY portion of the HTML document for all of the commands.
	 *  The commands have been placed into a Tree structure to facilitate the
	 *  building of the body.
	 *
	 * @param  tree com.objectwave.utility.TreeCollection A tree datastructure
	 *      containing all of the commands.
	 * @param  result The formatted body will be built upon this buffer provided
	 *      as this parameter.
	 */
	protected void formatCommands(TreeCollection tree, StringBuffer result)
	{
		Enumeration nodes = tree.get(null);
		while(nodes.hasMoreElements())
		{
			Object nodeElement = nodes.nextElement();
			result.append("<DIV ID=" + nodeElement + " CLASS=parent>");
			if(tree.isLeaf(nodeElement))
			{
				result.append(formatCommand((Command) nodeElement));
				result.append("\n</DIV>");
			}
			else
			{
				result.append("<A HREF='#' onClick=\"expandIt('" + nodeElement + "'); return false\">");
				result.append("\n<IMG NAME=imEx SRC=triDown.gif  WIDTH=16 HEIGHT=16 BORDER=0 ALT=\"Expand/Collapse Item\">");
				result.append("</A>");
				result.append(nodeElement);
				result.append("</DIV>");
				addCommandChildren(tree, nodeElement, nodeElement.toString(), result);
			}

		}
	}
	/**
	 *  While similar to FormatCommands, this method builds the child nodes in
	 *  the tree. This method is called recursively building all of the
	 *  commands.
	 *
	 * @param  tree com.objectwave.utility.TreeCollection A tree datastructure
	 *      containing all of the commands.
	 * @param  node The node in the TreeCollection that is being processed.
	 * @param  divName This is the name the JavaScript will use to identify this
	 *      command.
	 * @param  result The formatted child commands will be built upon this buffer
	 *      provided as this parameter.
	 */
	protected void addCommandChildren(TreeCollection tree, Object node, String divName, StringBuffer result)
	{
		Enumeration nodes = tree.get(node);
		divName = divName + "Child";
		result.append("<BLOCKQUOTE>");
		int count = 0;
		while(nodes.hasMoreElements())
		{
			Object nodeElement = nodes.nextElement();
			if(tree.isLeaf(nodeElement))
			{
				result.append("\n<DIV ID=" + divName + count + " CLASS=child>");
				if(!(nodeElement instanceof Command))
				{
					System.err.println(nodeElement);
				}
				else
				{
					result.append(formatCommand((Command) nodeElement));
				}
				result.append("</DIV>");
			}
			else
			{
				result.append("\n<DIV ID=" + divName + count + " class=child><A HREF='#' onClick=\"expandIt('" + divName + count + "'); return false\">");
				result.append("\n<IMG NAME=imEx SRC=triDown.gif  WIDTH=16 HEIGHT=16 BORDER=0 ALT=\"Expand/Collapse Item\">");
				result.append("</A>");
				result.append(nodeElement);
				result.append("</DIV>");
				addCommandChildren(tree, nodeElement, divName + count, result);
			}
			count += 1;
		}
		result.append("</BLOCKQUOTE>");
	}
	/**
	 *  Convert characters that are represented as an ascii value to the actual
	 *  character. The numeric value is assumed to be 2 characters. The numbers
	 *  0 - 9 must be represented as '01', '09', etc... ex. "A%20String" becomes
	 *  "A String"
	 *
	 * @param  str String The string that may contain numeric ASCII values.
	 * @return  The string with the numeric representations replaced with the
	 *      actual char elements.
	 */
	String fixString(String str)
	{
		StringBuffer buf = new StringBuffer();
		for(int i = 0; i < str.length(); ++i)
		{
			char c = str.charAt(i);
			if(c == '%')
			{
				String number = "" + str.charAt(++i) + str.charAt(++i);
				int val = Integer.parseInt(number, 16);
				//System.out.println("VAL '" + val + "' for number " + number);
				c = (char) val;
				//System.out.println("VAL as char " + c);
				buf.append(c);
			}
			else
			{
				buf.append(c);
			}
		}
		return buf.toString();
	}
	/**
	 *  The urlRequest was a command, this method will attempt to execute that
	 *  command. Look up the Command in the CommandCallbackService and execute
	 *  the command.
	 *
	 * @param  commandString String The command identifier of the URL request.
	 * @param  argString String The argument portion of the URL request.
	 * @param  result StringBuffer Any return results are added to the buffer
	 *      provided in this parameter.
	 */
	void processCommand(String commandString, String argString, StringBuffer result)
	{
		try
		{
			commandString = commandString.replace('/', ' ').trim();
			Command c = CallbackService.getInstance().getCommand(commandString);
			result.append("<P><I>" + commandString);
			processArguments(c, argString, result);
			result.append("</I>\n<P>");
			//At this point the command is formatted on the result string.
			MessageLog.debug(this, "Processing command: " + c.name);
			MessageLog.debug(this, "Args: " + argString);

			boolean success = CallbackService.getInstance().executeCommand(c);
			if(success)
			{
				result.append("<B>Success!<BR>ReturnValues:</B>");
				if(c.retValues.length > 0)
				{
					result.append("<UL>");
					for(int i = 0; i < c.retValues.length; ++i)
					{
						result.append("<LI>");
						String resultValue = c.retValues[i].value;
						resultValue = com.objectwave.utility.StringManipulator.replaceAllWith(resultValue, "\n", "<br>");
						result.append(resultValue);
					}
					result.append("</UL>");
				}
			}
			else
			{
				result.append("<B>Command Failed!</B><P>");
			}

		}
		catch(ThreadDeath td)
		{
			throw td;
		}
		//Allow thread to die.
		catch(Throwable t)
		{
			t.printStackTrace();
			result.append("<B>" + t + "</B><P>");
		}
	}
	/**
	 *  Format a Command Object to display nicely in a browser.
	 *
	 * @param  command The command registered with the CommandCallbackService.
	 * @return  String An HTML formatted string.
	 */
	String formatCommand(Command command)
	{
		boolean useAnchor = command.args.length == 0;
		String actualLink;
		if(useAnchor)
		{
			actualLink = "\n<P><A HREF=\"" + command.name + "\">" + command.description + "</A>";
			actualLink += "<BR><B>" + command.name + "</B>\n";
		}
		else
		{
			String actualCommand = command.name + ':';
			actualLink = "\n" + command.description + "<UL>Parameters:";
			//actualLink = "\n<BR>" + command.description + "<UL>Parameters:";
			for(int i = 0; i < command.args.length; ++i)
			{
				if(command.args[i].name == null || command.args[i].name.trim().equals(""))
				{
					command.args[i].name = " aParam" + i;
				}
				String formString = "<input type=text size=25 name=" + command.args[i].name + ">";
				actualLink += "\n<LI><I>" + command.args[i].name + formString + "</I> - " + command.args[i].description;
				//actualLink += "\n<LI><I>" + command.args[i].name + "</I> - " + command.args[i].description;
				actualCommand += command.args[i].name;
				if(i + 1 != command.args.length)
				{
					actualCommand += ",";
				}
			}
			actualLink += "</UL>\n";
			String formStart = "<form method=get action=\"/" + command.name + "\">";
			String formEnd = "<input type=submit value=\"" + command.name + "\"></form>";
			actualLink = "<P><B>" + actualCommand + "</B>\n" + formStart + actualLink + formEnd + '\n';
		}
		return actualLink;
	}
//<============================ START OLD CODE ========================>
	/**
	 *  For each argument passed on the argString, create a new DataItem. Change
	 *  the command.args field value to be a new collection of DataItems.
	 *
	 * @param  command Command
	 * @param  result StringBuffer that will eventually be the resulting HTML
	 *      page.
	 * @param  argString
	 * @argString  A list of argument values separated by a ','
	 */
	void processArguments(Command command, String argString, StringBuffer result)
	{
		if(argString != null)
		{
			Vector v = com.objectwave.utility.StringManipulator.stringToVector(argString);
			DataItem[] args = new DataItem[v.size()];
			for(int i = 0; i < args.length; ++i)
			{
				args[i] = new DataItem();
				args[i].value = (String) v.elementAt(i);
				if(i == 0)
				{
					result.append(" : ");
				}
				result.append("\'" + args[i].value + "\'");
				if(i + 1 != args.length)
				{
					result.append(", ");
				}
			}
			command.args = args;
		}
	}
	/**
	 * @author  dhoag
	 * @version  $Id: HTTPCommandImpl.java,v 1.1 2001/10/12 21:59:11 dave_hoag Exp $
	 * @created  October 11, 2001
	 */
	public static class Test
	{
		/**
		 *  The main program for the Test class
		 *
		 * @param  args The command line arguments
		 */
		public static void main(String[] args)
		{
			java.util.Properties p = new java.util.Properties();
			p.put("callbackTest.logServiceFileName", "");
			Test test = new Test();
			try
			{
				CallbackService.getInstance().registerForCommandCallback(test, "invokeMe", "callback", "Print the passed in string", new String[]{"java.lang.String", "java.lang.String"}, new String[]{"The string to print", "the string to append"});
				new HTTPCommandImpl().initialize();
			}
			catch(Throwable ex)
			{
				ex.printStackTrace();
			}
		}
		/**
		 * @param  str
		 * @param  str2
		 * @return
		 */
		public String callback(String str, String str2)
		{
			System.out.println(str + ": " + str2);
			return "Here it is '" + str + ": " + str2 + '\'';
		}
	}
}
