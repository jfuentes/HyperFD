
<!--  Hiding Script

// *****************************
// Generate Data
// *****************************
/* Usage of this class will require a generateTree javascript to exist in the calling document
* 
function generateTree()
{
	var aux1, aux2, aux3, aux4

	foldersTree = folderNode("Foundation Framework Dev Kit")
		appendChild(foldersTree, generateDocEntry(0, "Resources", "FFFaq.htm#resources", "Additional resources for the FF"))
	    aux1 = appendChild(foldersTree, folderNode("How do I?"))
				appendChild(aux1, generateDocEntry(0, "Create an Entity Object<p><I>MoreSophisticated</I>", "FFFaq.htm#entity", "Persistence Related"))
				appendChild(aux1, generateDocEntry(0, "Create a Service Object", "FFFaq.htm#service", ""))
				appendChild(aux1, generateDocEntry(0, "Use Directory Services", "FFFaq.htm#directory", "Locating and registering CORBA Objects"))
				appendChild(aux1, generateDocEntry(0, "Use the Application Management Interface", "FFFaq.htm#applicationManagement", "CommandCallbackService"));
				aux2 = appendChild(aux1, folderNode("Logging Service"));
					appendChild(aux2, generateDocEntry(0, "use Logging Services?", "FFFaq.htm#logService", "Policies and usage"));
					appendChild(aux2, generateDocEntry(0, "use the Message Categories?", "FFFaq.htm#logCategories", "Policies and usage"));
		aux1 = appendChild(foldersTree, folderNode("Setup Environment"));
				appendChild(aux1, generateDocEntry(0, "Setup", "FFFaq.htm#setUp", "Classpath, software, path, ..."));
				appendChild(aux1, generateDocEntry(0, "DLLs ", "FFFaq.htm#dlls", "Path and required dlls."));
				appendChild(aux1, generateDocEntry(0, "Classpath", "FFFaq.htm#classpath", "Classpath and Jar files."));
		appendChild(foldersTree, generateEntry(0, "NoChildren <br><B>BOLD</B>", "TestHelp"));
		appendChild(foldersTree, generateDocEntry(0, "Standards", "FFFaq.htm#standards", "Event channel names"))
}
*/
// *****************************
// Auxiliary function to create the node
// *****************************
function folderNode(name)
{
	var folderNode
	folderNode = new Object
	folderNode.isOpen = 0
	folderNode.name = name
	folderNode.children = new Array
	folderNode.isDoc = 0

	return folderNode
}

function appendChild(parent, child)
{
	var arr = parent.children
	var len = arr.length

	parent.children[len] = child
      return child
}

function generateDocEntry(icon, docDescription, link, helpText)
{
	var result = new Object
	var retString =""

	if (icon==0)
          retString = "<A href='"+link+"' target=" + theTargetFrame + "><img name=docImage alt='" + helpText + "'"
	else
          retString = "<A href='http://"+link+"' target=_blank><img name=link alt='" + helpText + "'"
	retString = retString + " border=0></A><td nowrap><font size=-1 face='Arial, Helvetica'><A HREF='" + link + "' target='"+ theTargetFrame + "'>" + docDescription + "</A></font>"

	result.value = retString
	result.isDoc = 1

	return result
}

function generateEntry(icon, docDescription, helpText)
{
	var result = new Object
	var retString =""

	if (icon==0)
          retString = "<img name=docImage alt='" + helpText + "'"
	else
          retString = "<img name=link alt='" + helpText + "'"
	retString = retString + " border=0><td nowrap><font size=-1 face='Arial, Helvetica'>" + docDescription + "</font>"

	result.value = retString
	result.isDoc = 1

	return result
}

// *****************************
// Display functions
// *****************************

function redrawTree()
{
	if(theTreeFrame)
	{
		var doc = theTreeFrame.window.document
		doc.clear()
		doc.write("<body bgcolor='white'>") 
		redrawNode(foldersTree, doc, 0, 1, "")
		doc.close()
	}
	else
	{
		var theSrc = changeTableSrc(foldersTree, 0, 1, "", "");
		jsTree.innerHTML = theSrc;
		if(document.images)
		{
			for(i = 0; i < document.images.length; i++)
			{
				var anImage = document.images[i];
				if(anImage.name == 'docImage')
				{
					anImage.src = docImage.src;
				}
				else
				if(anImage.name == 'blank')
				{
					anImage.src = blank.src;
				}
				else
				if(anImage.name == 'vertline')
				{
					anImage.src = vertline.src;
				}
				else
				if(anImage.name == 'node')
				{
					anImage.src = node.src;
				}
				else
				if(anImage.name == 'link')
				{
					anImage.src = link.src;
				}
				else
				if(anImage.name == 'openFolder')
				{
					anImage.src = openFolder.src;
				}
				else
				if(anImage.name == 'closedFolder')
				{
					anImage.src = closedFolder.src;
				}
				else
				if(anImage.name == 'lastnode')
				{
					anImage.src = lastnode.src;
				}
			}
		}
	}
}

function changeTableSrc(foldersNode, level, lastNode, leftSide, currentResult)
{
	var j=0
	var i=0

	currentResult += "<table border=0 cellspacing=0 cellpadding=0>";
	currentResult += "<tr><td valign = middle nowrap>";

	currentResult += leftSide;

	if (level>0)
	{
		if (lastNode) //the last 'brother' in the children array
		{
			currentResult += "<img name=lastnode width=16 height=22>";
			leftSide = leftSide + "<img name=blank width=16 height=22>";
		}
		else
		{
			currentResult += "<img name=node width=16 height=22>";
			leftSide = leftSide + "<img name=vertline width=16 height=22>"
		}
	}

	currentResult += changeIconAndLabel(foldersNode);
	currentResult += "</table>";

	var childs = foldersNode.children
	if (childs.length > 0 && foldersNode.isOpen) //there are sub-nodes and the folder is open
	{
		level=level+1
		for (i=0; i<childs.length;i++)
		{
			var last = i==childs.length - 1
			if(childs[i].isDoc)
			{
				currentResult += changeDocument(leftSide, last, childs[i])
			}
			else
			{
				currentResult = changeTableSrc(childs[i], level, last, leftSide, currentResult )
			}
		}
	}
	return currentResult;
}
//
function redrawNode(foldersNode, doc, level, lastNode, leftSide)
{
		var src = changeTableSrc(foldersNode, level, lastNode, leftSide, "");
		doc.write(src);
}
//
//  Display the child because it is a document!
//
function changeDocument(leftSide, last, child)
{
	var result = "<table border=0 cellspacing=0 cellpadding=0 valign=center>";
	result += "<tr><td nowrap>";
	result += leftSide;
	if (last)
	{
		result += "<img name=lastnode width=16 height=22>";
	}
	else
	{
		result += "<img name=node width=16 height=22>";
	}
	result += child.value;
	result += "</table>";
	return result;
}
// *****************************
// Creates the html code to display a folder and its label
// *****************************
function changeIconAndLabel(foldersNode)
{
	var result = "<A href='javascript:top.openBranch(\"" + foldersNode.name + "\")'>";
	if (foldersNode.isOpen)
	{
		result += "<img name=openFolder width=24 height=22 border=noborder></a>";
		//result += "images/openfolder.gif width=24 height=22 border=noborder></a>";
	}
	else
	{
		result += "<img name=closedFolder width=24 height=22 border=noborder></a>";
	}
	result += "<td valign=middle align=left nowrap>";
	result += "<font size=-1 face='Arial, Helvetica'>"+foldersNode.name+"</font>";
	return result;
}

// *****************************
// Recursive functions
// *****************************

//when a parent is closed all children also are
function closeFolders(foldersNode)
{
	var i=0
	for (i=0; i< foldersNode.children.length; i++)
	{
		if(! foldersNode.children[i].isDoc)
		{
			closeFolders(foldersNode.children[i]);
		}
	}
	foldersNode.isOpen = 0
}

//recursive over the tree structure
//called by openbranch
function clickOnFolderRec(foldersNode, folderName)
{
	var i=0

	if (foldersNode.name == folderName)
	{
		if (foldersNode.isOpen)
		{
			closeFolders(foldersNode)
		}
		else
		{
			foldersNode.isOpen = 1
		}
	}
	else
	{
		for (i=0; i< foldersNode.children.length; i++)
		{
			if(! foldersNode.children[i].isDoc)
				clickOnFolderRec(foldersNode.children[i], folderName);
		}
	}
}


// *****************************
// Event handlers
// *****************************
//called when the user clicks on a folder
function openBranch(branchName)
{
	if(branchName == "Start folder" && foldersTree.length)
		branchName = foldersTree[0].name
        clickOnFolderRec(foldersTree, branchName)
        timeOutId = setTimeout("redrawTree()",100)
}
function getOpenFolder() { return openFolder; }
//called after this html file is loaded
function initializeTree()
{
		initializeImages();
        generateTree();
        redrawTree();
}
function initializeImages()
{
		openFolder = new Image();
		openFolder.src = "images/openFolder.gif";
		closedFolder = new Image();
		closedFolder.src = "images/closedFolder.gif";
		node = new Image();
		node.src = "images/node.gif";
		lastnode = new Image();
		lastnode.src = "images/lastnode.gif";
		blank = new Image();
		blank.src = "images/blank.gif";
		vertline = new Image();
		vertline.src = "images/vertline.gif";
		docImage = new Image();
		docImage.src = "images/doc.gif";
		link = new Image();
		link.src = "images/link.gif";
}
//Use the tree frame approach if the tree is to consume the entire frame
function setTreeFrame(fr)
{
	theTreeFrame = fr
	docu = fr.window.document
}
function setTargetFrameName(fr)
{
	theTargetFrame = fr
}
function getElement(elementName)
{
	if(document.layers)
	{
		//For the <DIV tag to show up in the 'layers' attribute, the STYLE attribute must be set.
		return document.layers[elementName];
	}
	else
	{
		return document.all[elementName ];
	}
}
//Set the place where we should display the tree. This is marked
//via the DIV tag.
function setTree(tab)
{
	jsTree = tab;
}
var jsTree = 0;
var docu = 0;
var theTreeFrame = 0
var theTargetFrame = 0
var foldersTree = 0
var timeOutId = 0
//images
var link;
var node;
var blank;
var vertline;
var lastnode;
var openFolder;
var closedFoler;
var docImage;

// end hiding script  -->

