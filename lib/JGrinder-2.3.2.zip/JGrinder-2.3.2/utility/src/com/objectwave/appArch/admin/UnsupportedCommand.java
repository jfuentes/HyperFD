package com.objectwave.appArch.admin;

/**
 * @author  dhoag
 * @version  $Id: UnsupportedCommand.java,v 1.1 2001/10/12 21:59:11 dave_hoag Exp $
 */
public class UnsupportedCommand extends Exception
{
	/**
	 */
	public java.lang.String reason;

	/**
	 *Constructor for the UnsupportedCommand object
	 */
	public UnsupportedCommand()
	{
		super();
	}
	/**
	 *Constructor for the UnsupportedCommand object
	 *
	 * @param  reason
	 */
	public UnsupportedCommand(
	// full constructor
	String reason)
	{
		super(reason);
		this.reason = reason;
	}
}
