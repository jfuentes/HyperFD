package com.objectwave.classFile;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.Hashtable;
/**
 *  This class defines the generic Attribute type for Java class files. It is a
 *  little bit smart in that for some Attributes it can display them
 *  intelligently if it also has access to the constant pool of the current
 *  class.
 *
 * @author  Dave Hoag
 * @version  $Id: AttributeInfo.java,v 2.0 2001/06/11 15:46:52 dave_hoag Exp $
 * @see  ClassFile
 */
public class AttributeInfo
{
	static Hashtable classMap;
	ConstantPoolInfo name;
	// attribute name
	byte data[];
	// attribute's contents
	/**
	 */
	public AttributeInfo()
	{
	}
	/**
	 * @param  newName
	 * @param  newData
	 */
	public AttributeInfo(ConstantPoolInfo newName, byte newData[])
	{
		name = newName;
		data = newData;
	}
	/**
	 *  Allow a factory like construction of AttributeInfo objects.
	 *
	 * @param  di
	 * @param  pool
	 * @return
	 * @exception  IOException
	 */
	static AttributeInfo readAttributeInfo(DataInputStream di, ConstantPoolInfo pool[]) throws IOException
	{
		ConstantPoolInfo name = pool[di.readShort()];
		Class c = (Class) classMap.get(name.toString());
		AttributeInfo info = null;
		if(c != null)
		{
			try
			{
				info = (AttributeInfo) c.newInstance();
			}
			catch(Throwable t)
			{
			}
		}
		if(info == null)
		{
			info = new AttributeInfo();
		}
		info.name = name;
		if(!info.read(di, pool))
		{
			return null;
		}
		return info;
	}
	/**
	 * @param  di
	 * @param  pool
	 * @return
	 * @exception  IOException
	 */
	public boolean read(DataInputStream di, ConstantPoolInfo pool[]) throws IOException
	{
		int len;
		if(name == null)
		{
			name = pool[di.readShort()];
		}
		len = di.readInt();
		data = new byte[len];
		/*
		 * len  = di.read(data);
		 * if (len != data.length)
		 * {
		 * System.out.println("DATA does not equal length");
		 * return false;
		 * }
		 * return true;
		 */
		di.readFully(data);
		return true;
	}
	/**
	 * @param  pool
	 * @return
	 */
	public String toBoolean(ConstantPoolInfo pool[])
	{
		ConstantPoolInfo item = pool[indexFromBytes(data)];

		if(item.intValue == 0)
		{
			return ("= false");
		}
		return ("= true");
	}
	/**
	 * @return
	 */
	public String toString()
	{
		return (name.toString() + " <" + data.length + " bytes>");
	}
	/**
	 *  Print out an 'intelligent' version of this class. The constant pool
	 *  contains the necessary information.
	 *
	 * @param  pool
	 * @return
	 */
	public String toString(ConstantPoolInfo pool[])
	{
		StringBuffer x = new StringBuffer();
		String type = name.toString();
		ConstantPoolInfo item;

		if(type.compareTo("ConstantValue") == 0)
		{
			item = pool[indexFromBytes(data)];
			return (item.toString());
		}
		else
				if(type.compareTo("SourceFile") == 0)
		{
			item = pool[indexFromBytes(data)];
			return (item.toString());
		}
		else
		{
			x.append(type + "<" + data.length + " bytes>");

		}
		return x.toString();
	}
	/**
	 *  Write the bytes to the output stream.
	 *
	 * @param  dos The DataOutputStream upon which this is writing
	 * @param  pool The constant pool in which to index.
	 * @exception  IOException
	 * @exception  Exception
	 */
	public void write(DataOutputStream dos, ConstantPoolInfo pool[]) throws IOException, Exception
	{
		dos.writeShort(ConstantPoolInfo.indexOf(name, pool));
		dos.writeInt(data.length);
		dos.write(data, 0, data.length);
	}
	/**
	 * @param  target
	 * @param  originalPool
	 * @exception  Exception
	 */
	protected void fixUpConstants(ClassFile target, ConstantPoolInfo[] originalPool) throws Exception
	{
		name = target.recursiveAdd(name);
	}
	/**
	 *  Gets the Int attribute of the AttributeInfo object
	 *
	 * @param  a
	 * @param  start
	 * @return  The Int value
	 */
	int getInt(byte[] a, int start)
	{
		return (int) (((a[start] << 32) & (0xff << 32)) |
				((a[start + 1] << 16) & (0xff << 16))) |
				(((a[start + 2] << 8) & (0xff << 8)) |
				((a[start + 3] << 0) & (0xff << 0)));
	}
	/**
	 *  The 'data' for an optional attribute may be an index into the constant
	 *  pool. Two common examples of this are optional attributes with the names of
	 *  either 'SourceFile' and 'ConstantValue'. If the 'name', when resolved
	 *  toString(), matches either of these values, the data is assumed to be an
	 *  inded into the constant pool.
	 *
	 * @param  a
	 * @return
	 */
	short indexFromBytes(byte a[])
	{
		return (short) (((a[0] << 8) & (0xff << 8)) |
				((a[1] << 0) & (0xff << 0)));
	}
	/**
	 * @param  idx
	 * @return
	 */
	byte[] bytesFromIndex(short idx)
	{
		byte[] result = new byte[2];
		result[0] = (byte) ((idx >> 8) & (0xff));
		result[1] = (byte) (idx & 0xff);
		return result;
	}
	static
	{
		classMap = new Hashtable();
		classMap.put("Code", com.objectwave.classFile.CodeAttributeInfo.class);
		classMap.put("LocalVariableTable", com.objectwave.classFile.LocalVariableAttributeInfo.class);
		classMap.put("Exceptions", com.objectwave.classFile.ExceptionAttributeInfo.class);
		classMap.put("ConstantValue", com.objectwave.classFile.ConstantValueAttributeInfo.class);
	}
}
