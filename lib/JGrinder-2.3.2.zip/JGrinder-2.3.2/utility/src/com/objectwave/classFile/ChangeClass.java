package com.objectwave.classFile;

import java.io.*;
import java.util.*;
/**
 * A class that allows the manipulation of byte codes.
 * @author Dave Hoag
 */
public class ChangeClass
{
	public static void main(String args[])
	{
		try
		{
			ChangeClass changeClass = new ChangeClass();
			FileInputStream fi = new FileInputStream(args[0]);
			ClassFile cf = new ClassFile();

			// cf.debug = true;
			cf.dumpConstants = true;

			if (! cf.read(fi))
			{
			    System.out.println("Unable to read class file.");
			    System.exit(1);
			}
			if(args.length == 2)
			{
				if(System.getProperty("trace") != null)
				{
					changeClass.injectTrace(cf);
				}
				else
				{
					changeClass.addSimpleAttribute(cf);
					ClassFile other = new ClassFile();
					fi = new FileInputStream(args[1]);
					other.dumpConstants = true;
					if (! other.read(fi))
					{
			    		System.out.println("Unable to read second class file.");
			    		System.exit(1);
					}
					changeClass.genericCopy(cf,other );
				}
//				changeClass.copyConstantPoolFromOneToOther(cf,other );
				FileOutputStream fos = new FileOutputStream("testresult.class");
				cf.write(fos);
			}
			if(args.length == 3)
			{
				ClassFile other = new ClassFile();
				fi = new FileInputStream(args[1]);
				other.dumpConstants = true;
				if (! other.read(fi))
				{
			    	System.out.println("Unable to read second class file.");
			    	System.exit(1);
				}
				int methodIdx = new Integer(args[2]).intValue();
				changeClass.injectMethodInto(cf, other, methodIdx) ;
				FileOutputStream fos = new FileOutputStream("testresult.class");
				cf.write(fos);
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}
	/**
	 */
	public void injectTrace(ClassFile one) throws Exception
	{
        Class [] args = { java.lang.String.class , java.lang.String.class };
//        injectTrace(one, com.objectwave.tools.Tracker.class, "methodCalled", args);
        if(! one.getClassName().equals("com.objectwave.tools.Tracker"))
        {
//	        injectTrace(one, com.objectwave.tools.Tracker.class, "methodCalled", args);
        }
    }
	/**
     * Force a call to 'Tracker.trace'.
	 */
	public void injectTrace(ClassFile one, Class receiver, String methodName, Class [] args) throws Exception
	{
		MethodInfo [] meths = one.methods;
		ConstantPoolInfo callToTrace = createConstantPoolToCallMethod(receiver, methodName, args);
		callToTrace = one.recursiveAdd(callToTrace);
		ConstantPoolInfo classNameArg  = new ConstantPoolInfo();
		classNameArg.type = ConstantPoolInfo.STRING;
		classNameArg.arg1 = new ConstantPoolInfo(one.thisClass.arg1.strValue);
        classNameArg.arg1.strValue = classNameArg.arg1.strValue.replace('/','.');

		classNameArg = one.recursiveAdd(classNameArg);

		System.out.println("Injecting a trace into " + classNameArg );
		for(int i = 0; i < meths.length; ++i)
		{
			MethodInfo currentMethod = meths[i];
			if(currentMethod.name.toString().equals("<init>")) continue;

			ConstantPoolInfo methodNameArg = new ConstantPoolInfo();
			methodNameArg.type = ConstantPoolInfo.STRING;
			methodNameArg.arg1 = currentMethod.name;
			methodNameArg = one.recursiveAdd( methodNameArg);

			CodeAttributeInfo code = currentMethod.getCodeAttributeInfo();

			ByteArrayOutputStream bos = new ByteArrayOutputStream();

			int originalLength = code.data.length;
			int actualCodeLen = code.getInt(code.data, 4);
			byte [] twoBytes = new byte [2];
			twoBytes [0] = code.data[0];
		    twoBytes [1] = code.data[1];
		    short maxStack =  code.indexFromBytes(twoBytes);
		    if(maxStack < 2)
		    {
		    	twoBytes [1] = 2;
		    }
		    bos.write(twoBytes);
		    bos.write(code.data[2]); //MaxLocals
		    bos.write(code.data[3]);
		    DataOutputStream dos = new DataOutputStream(bos);
		    dos.writeInt(actualCodeLen + 9);
		    dos.flush();

            byte [] idx = null;
			code.adjustExceptionTable((short)9);
			//Total of 9 new bytes.
			bos.write(19); //ldc_w
			short constIdx = ConstantPoolInfo.indexOf(classNameArg, one.constantPool);
			System.out.println("Class Name index " + constIdx);
            dos.writeShort(constIdx);
			bos.write(19); //ldc_w
			constIdx = ConstantPoolInfo.indexOf(methodNameArg, one.constantPool);
            dos.writeShort(constIdx);
			bos.write(184); //invokestatic
			idx = code.bytesFromIndex(ConstantPoolInfo.indexOf(callToTrace, one.constantPool));
			bos.write(idx);
//Changed my mind, gotos are relative from goto op code. Should not be affected.
//            updateGotos(code.data, originalLength, 9);
			//Write the rest
			for(int j = 8; j < originalLength; ++j)
			{
				bos.write(code.data[j]);
			}
			code.data = bos.toByteArray();
		}
	}

    /**
     */
	public void updateGotos( byte data [] , int len, int adjust)
	{
        CodeAttributeInfo info = new CodeAttributeInfo();
		byte [] twoBytes = new byte [2];
		for(int i = 8; i < len; ++i)
		{
		    int idx = ((int)0xff & data[i]);
		    if(idx < info.opCodeTable.length && idx > -1)
		    {
		        if(idx == info.lookupSwitchOpCode || idx == info.tableSwitchOpCode )
		        {
		            i = info.handleLookupSwitch(idx, data, i, new StringBuffer());
		        }
		        if(idx == info.invokeInterfaceOpCode)
		        {
		            twoBytes [0] = data[++i];
		            twoBytes [1] = data[++i];
		            ++i;
		            i++;
		        }
		        if(info.shouldGetConstantFromOne(idx))
		        {
		            int barIdx = info.opCodeTable[idx].lastIndexOf('_');
		            if(barIdx < 0)
		            {
		                twoBytes [0] = 0;
		                twoBytes [1] = data[++i];
			        }
		        }
		        if(info.shouldGetConstant(idx))
		        {
		            twoBytes [0] = data[++i];
		            twoBytes [1] = data[++i];
		        }
		        if(info.localVarAccess(idx))
		        {
		            int barIdx = info.opCodeTable[idx].lastIndexOf('_');
		            if(barIdx < 0)
		            {
		            	++i;
			        }
		        }
                //If the idx is a goto
                if(idx == 167 )
                {
			            twoBytes [0] = data[++i];
			            twoBytes [1] = data[++i];
                        int value = info.indexFromBytes(twoBytes);
System.out.println("$$$$$$$$$$$original offset " + value);
                        value = (short)( value + adjust);
//                        twoBytes = info.bytesFromIndex((short)value);
//                        data [ i -2 ] = twoBytes[0];
//                        data [ i -1 ] = twoBytes[1];
//System.out.println("new offset " + value);
                }
                else //a goto_w
                if(idx == 200)
                {
                }
                else
                {
			        if(info.hasTwoByteDatum(idx))
			        {
			            twoBytes [0] = data[++i];
			            twoBytes [1] = data[++i];
			        }
			        if(info.hasOneByteDatum(idx))
			        {
			            twoBytes [1] = data[++i];
			        }
                }
		    }
		    else
		    {
		        throw new RuntimeException ("Failed to correctly process bytes!!! idx in not in allowed range.");
//		        	System.out.println("Failed to correctly process bytes!!!");
		    }
		}
    }
	/** */
	public void addSimpleAttribute(ClassFile one) throws Exception
	{
		ByteArrayOutputStream str = new ByteArrayOutputStream();
		DataOutputStream dis = new DataOutputStream(str);
		dis.writeBytes("Hey, this is a test");
		dis.close();
		byte [] b = str.toByteArray();
		one.addAttribute("MyAttribute", b);
	}
	/**
	 */
	public void injectMethodInto(ClassFile one, ClassFile other, int idxOfMethod) throws Exception
	{
		MethodInfo mi = other.methods[idxOfMethod];
		mi.fixUpConstants(one, other.constantPool);

		MethodInfo [] tmp = new MethodInfo[ one.methods.length + 1 ];
		System.arraycopy(one.methods, 0, tmp, 0, one.methods.length);
		tmp [ one.methods.length ] = mi;
		one.methods = tmp;

	}
	/**
	 * Copy all of the constants from on class to another.
	 */
	public void genericCopy(ClassFile one, ClassFile other) throws Exception
	{
		ConstantPoolInfo [] src = other.constantPool;
		for(int i = 1; i < src.length; ++i)
		{
			System.out.println("Adding " + src[i]);
			recursiveAdd(one, src[i]);
		}
	}
	/**
	 * Use recursion to ensure that ConstantPoolInfo dependecies are met.
	 */
	protected ConstantPoolInfo recursiveAdd(ClassFile one, ConstantPoolInfo cpi) throws Exception
	{
		if(isPrimitiveConstant(cpi))
		{
			short idx =  one.addConstantPoolItem(cpi);
			return one.constantPool[idx];
		}
		if(cpi.type == ConstantPoolInfo.STRING || cpi.type == ConstantPoolInfo.CLASS)
		{
			cpi.arg1 = recursiveAdd(one, cpi.arg1 );
			int idx = one.addConstantPoolItem(cpi);
			return one.constantPool[idx];
		}
		cpi.arg1 = recursiveAdd(one, cpi.arg1 );
		cpi.arg2 = recursiveAdd(one, cpi.arg2);
		int idx = one.addConstantPoolItem(cpi);
		return one.constantPool[idx];
	}
	/**
	 */
	public void copyConstantPoolFromOneToOther(ClassFile one, ClassFile other) throws Exception
	{
		ConstantPoolInfo [] src = other.constantPool;
		for(int i = 1; i < src.length; ++i)
		{
			if(isPrimitiveConstant(src[i]))
			{
				one.addConstantPoolItem(src[i]);
			}
			else
			if(src[i].type == ConstantPoolInfo.STRING || src[i].type == ConstantPoolInfo.CLASS)
			{
				ConstantPoolInfo newItem = src[i].arg1.inPool(one.constantPool);
				if(newItem != null)
					src[i].arg1 = newItem;
				one.addConstantPoolItem(src[i]);
			}
			else
			if(src[i].type == ConstantPoolInfo.NAMEANDTYPE )
			{
				//case FIELDREF:
		    	//case METHODREF:
			    //case INTERFACE:
		    	//case NAMEANDTYPE:
		    	if(src[i].arg1 != null)
		    	{
		    		System.out.println("Source arg1 ");
		    		System.out.println(src[i].arg1.toString() +  ' ' + src[i].arg1.type);
		    		ConstantPoolInfo newItem = src[i].arg1.inPool(one.constantPool);
		    		System.out.println("New Item " + newItem );
					if(newItem != null)
						src[i].arg1 = newItem;
				}
		    	if(src[i].arg2 != null)
		    	{
		    		System.out.println("Source arg2 ");
		    		System.out.println(src[i].arg2.toString() +  ' ' + src[i].arg2.type);
		    		ConstantPoolInfo newItem2 = src[i].arg2.inPool(one.constantPool);
		    		System.out.println("New Item " + newItem2 );
					if(newItem2 != null)
						src[i].arg2 = newItem2;
				}

				one.addConstantPoolItem(src[i]);
			}
		}
		for(int i = 0; i < src.length; ++i)
		{
			if(src[i].type == ConstantPoolInfo.FIELDREF ||  src[i].type == ConstantPoolInfo.METHODREF)
			{
				//case FIELDREF:
		    	//case METHODREF:
			    //case INTERFACE:
		    	//case NAMEANDTYPE:
		    	if(src[i].arg1 != null)
		    	{
		    		System.out.println("Source arg1 ");
		    		System.out.println(src[i].arg1.toString() +  ' ' + src[i].arg1.type);
		    		ConstantPoolInfo newItem = src[i].arg1.inPool(one.constantPool);
		    		System.out.println("New Item " + newItem );
					if(newItem != null)
						src[i].arg1 = newItem;
				}
		    	if(src[i].arg2 != null)
		    	{
		    		System.out.println("Source arg2 ");
		    		System.out.println(src[i].arg2.toString() +  ' ' + src[i].arg2.type);
		    		ConstantPoolInfo newItem2 = src[i].arg2.inPool(one.constantPool);
		    		System.out.println("New Item " + newItem2 );
					if(newItem2 != null)
						src[i].arg2 = newItem2;
				}

				one.addConstantPoolItem(src[i]);
			}
		}
/*
		for(int i = 0; i < src.length; ++i)
		{
		}
*/
	}
	/**
		    case FIELDREF:
		    case METHODREF:
		    case INTERFACE:
		    case NAMEANDTYPE:
			dos.writeShort(indexOf(arg1, pool));
			dos.writeShort(indexOf(arg2, pool));
	 */
	protected boolean isPrimitiveConstant(ConstantPoolInfo item)
	{
		switch(item.type)
		{
			case ConstantPoolInfo.ASCIZ:
			case ConstantPoolInfo.UNICODE:
			case ConstantPoolInfo.INTEGER:
			case ConstantPoolInfo.LONG:
			case ConstantPoolInfo.FLOAT:
			case ConstantPoolInfo.DOUBLE:
			{
				return true;
			}
		}
		return false;
	}
	/**
	 * Use this to create all the ConstantPoolInfo object necessary for a call to the specified method.
	 * @return ConstantPoolInfo of type METHODREF
	 */
	public ConstantPoolInfo createConstantPoolToCallMethod(Class c, String methodName, Class [] args) throws NoSuchMethodException
	{
//		String methodArgValue1;
//		String methodArgValue2;
//		ConstantPoolInfo argValue1 = new ConstantPoolInfo(methodArgValue1);
//		ConstantPoolInfo argValue2 = new ConstantPoolInfo(methodArgValue2);
		String className = c.getName();
		className = className.replace('.','/');
		ConstantPoolInfo classRefName = new ConstantPoolInfo(className);
		ConstantPoolInfo classRef = new ConstantPoolInfo();
		classRef.type = ConstantPoolInfo.CLASS;
		classRef.arg1 = classRefName;

		ConstantPoolInfo methodRefName = new ConstantPoolInfo(methodName);
		StringBuffer argsBuffer = new StringBuffer();
		argsBuffer.append('(');
		for(int i = 0; i < args.length; ++i)
		{
			argsBuffer.append(getArgsClassName(args[i]));
		}
		argsBuffer.append(')');
		java.lang.reflect.Method meth = c.getDeclaredMethod(methodName, args);
		if(meth.getReturnType() == void.class)
		{
			argsBuffer.append('V');
		}
		else
		{
			argsBuffer.append(getArgsClassName(meth.getReturnType()));
		}
		ConstantPoolInfo parameters = new ConstantPoolInfo(argsBuffer.toString());
		ConstantPoolInfo nameValue = new ConstantPoolInfo();
		nameValue.type = ConstantPoolInfo.NAMEANDTYPE;
		nameValue.arg1 = methodRefName;
		nameValue.arg2 = parameters;
		ConstantPoolInfo methodRef = new ConstantPoolInfo();
		methodRef.type = ConstantPoolInfo.METHODREF;
		methodRef.arg1 = classRef;
		methodRef.arg2 = nameValue;
		return methodRef;
	}
	protected String getArgsClassName(Class c)
	{
		StringBuffer buff = new StringBuffer();
		if(c.isArray())
		{
			buff.append('[');
		}
		buff.append('L');
		String argClassName = c.getName();
		argClassName = argClassName.replace('.','/');
		buff.append(argClassName);
		buff.append(';');
		return buff.toString();
	}
}
