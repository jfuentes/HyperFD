package com.objectwave.classFile;
import com.objectwave.logging.MessageLog;
import com.objectwave.utility.JarReader;
import com.objectwave.utility.StringManipulator;
import java.io.*;

import java.util.*;
/**
 *  This class is used to manipulate Java class files in strange and mysterious
 *  ways. Usage it typically to feed it an array of bytes that are a class file,
 *  manipulate the class, then convert the class back into bytes, and feed the
 *  final result to <TT>defineClass()</TT> .
 *
 * @author  dhoag
 * @version  $Id: ClassFile.java,v 2.2 2002/07/31 15:55:22 dave_hoag Exp $
 * @see  AttributeInfo
 * @see  ConstantPoolInfo
 * @see  MethodInfo
 * @see  FieldInfo
 */
public class ClassFile
{

	/**
	 *  Description of the Field
	 */
	public final static int MOD_PUBLIC = 0x1;
	/**
	 *  Description of the Field
	 */
	public final static int MOD_PRIVATE = 0x2;
	/**
	 *  Description of the Field
	 */
	public final static int MOD_PROTECTED = 0x4;
	/**
	 *  Description of the Field
	 */
	public final static int MOD_STATIC = 0x8;
	/**
	 *  Description of the Field
	 */
	public final static int MOD_FINAL = 0x10;
	/**
	 *  Description of the Field
	 */
	public final static int MOD_SYNCHRONIZED = 0x20;
	/**
	 *  Description of the Field
	 */
	public final static int MOD_THREADSAFE = 0x40;
	/**
	 *  Description of the Field
	 */
	public final static int MOD_TRANSIENT = 0x80;
	/**
	 *  Description of the Field
	 */
	public final static int MOD_NATIVE = 0x100;
	/**
	 *  Description of the Field
	 */
	public final static int MOD_INTERFACE = 0x200;
	/**
	 *  Description of the Field
	 */
	public final static int MOD_ABSTRACT = 0x400;
	static Hashtable jarReaders = new Hashtable();
	//From where did the resulting ClassFile instance come
	String sourceLocation;
	/**
	 *  Description of the Field
	 */
	public boolean debug = false;
	/**
	 *  Description of the Field
	 */
	public boolean dumpConstants = false;
	int magic;
	short majorVersion;
	short minorVersion;
	ConstantPoolInfo constantPool[];
	short accessModifiers;
	ConstantPoolInfo thisClass;
	ConstantPoolInfo superClass;
	ConstantPoolInfo interfaces[];
	FieldInfo fields[];
	MethodInfo methods[];
	AttributeInfo attributes[];
	boolean isValidClass = false;
	boolean showPoolElements = false;
	/**
	 *  Create a new instance after locating the bytes.
	 *
	 * @param  classFilePath A path to search for the provided className.
	 * @param  className Description of Parameter
	 * @return  The Instance value
	 * @exception  InvalidClassException Description of Exception
	 */
	public static ClassFile getInstance(String classFilePath, String className) throws InvalidClassException
	{
		String alteredClassName = StringManipulator.replaceAllWith(className, ".", java.io.File.separator);
		alteredClassName = alteredClassName + ".class";
		StringTokenizer tokenizer = new StringTokenizer(classFilePath, File.pathSeparator);
		if(tokenizer.hasMoreElements())
		{
			while(tokenizer.hasMoreElements())
			{
				String pathElement = tokenizer.nextToken();
				MessageLog.debug(null, "Checking path " + pathElement + " " + alteredClassName);
				ClassFile result = getInstanceWork(pathElement, alteredClassName);
				if(result != null)
				{
					result.setSourceLocation(pathElement);
					return result;
				}
			}
		}
		else
		{
			return getInstanceWork(classFilePath, alteredClassName);
		}
		throw new java.io.InvalidClassException(className, "The class could not be located on the classpath.");
	}
	/**
	 *  Requires properly formatted parameters.
	 *
	 * @param  className A file name more than a class name. Like
	 *      'com/objectwave/classFile/ClassFile.class'.
	 * @param  pathEntry An entry in a class path. Like '/home/dhoag/classes'.
	 * @return  The InstanceWork value
	 */
	public static ClassFile getInstanceWork(String pathEntry, String className)
	{
		InputStream stream = null;
		BufferedInputStream buff = null;
		try
		{
			boolean notFound = true;

			stream = getByteCodeStream(pathEntry, className);
			if(stream != null)
			{
				buff = new BufferedInputStream(stream);
				ClassFile cf = new ClassFile();
				if(!cf.read(buff))
				{
					cf.setSourceLocation(pathEntry + File.separatorChar + className);
					System.out.println("Unable to read class file: " + className);
					return null;
				}
				return cf;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			try
			{
				if(buff != null)
				{
					buff.close();
				}
				if(stream != null)
				{
					stream.close();
				}
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		return null;
	}
	/**
	 * @param  path The entry in the classpath to search
	 * @param  fName The file for which this class is searching
	 * @return  The ByteCodeStream value
	 */
	protected static InputStream getByteCodeStream(final String path, String fName)
	{
		if(path.endsWith(".jar") || path.endsWith(".zip"))
		{
			try
			{
				JarReader rdr = (JarReader) jarReaders.get(path);
				if(rdr == null)
				{
					rdr = new JarReader(path);
					jarReaders.put(path, rdr);
				}
				byte[] bytes = rdr.getResource(fName);
				if(bytes != null)
				{
					return new ByteArrayInputStream(bytes);
				}
			}
			catch(java.io.IOException ex)
			{
				System.out.println(ex);
			}
			return null;
		}
		if(path.endsWith("/") || path.endsWith("\\"))
		{
			fName = path + fName;
		}
		else
		{
			fName = path + File.separatorChar + fName;
		}
		boolean notFound = true;
		lookForFiles :
		while(notFound)
		{
			MessageLog.debug(null, "Looking for file " + fName);
			try
			{
				if(new File(fName).exists())
				{
					FileInputStream fin = new FileInputStream(fName);
					return fin;
				}
			}
			catch(java.io.IOException ex)
			{
				//Oh well, try another file
			}
			//Look for inner classes.
			int idx = fName.lastIndexOf(File.separator);
			if(idx > -1)
			{
				fName = fName.substring(0, idx) + '$' + fName.substring(idx + 1);
			}
			else
			{
				break lookForFiles;
			}
		}
		return null;
	}

	/**
	 *  Returns a string that represents what the access flags are set for. So 0x14
	 *  returns "public final "
	 *
	 * @param  flags Description of Parameter
	 * @return  Description of the Returned Value
	 */
	public static String accessString(short flags)
	{
		StringBuffer x = new StringBuffer();

		if((flags & MOD_PUBLIC) != 0)
		{
			x.append("public ");
		}

		if((flags & MOD_PRIVATE) != 0)
		{
			x.append("private ");
		}

		if((flags & MOD_PROTECTED) != 0)
		{
			x.append("protected ");
		}

		if((flags & MOD_STATIC) != 0)
		{
			x.append("static ");
		}

		if((flags & MOD_FINAL) != 0)
		{
			x.append("final ");
		}

		if((flags & MOD_SYNCHRONIZED) != 0)
		{
			x.append("synchronized ");
		}

		if((flags & MOD_THREADSAFE) != 0)
		{
			x.append("threadsafe ");
		}

		if((flags & MOD_TRANSIENT) != 0)
		{
			x.append("transient ");
		}

		if((flags & MOD_NATIVE) != 0)
		{
			x.append("native ");
		}

		if((flags & MOD_INTERFACE) != 0)
		{
			x.append("interface ");
		}

		if((flags & MOD_ABSTRACT) != 0)
		{
			x.append("abstract ");
		}

		return (x.toString());
	}
	/**
	 *  Returns the next signature from a string of concatenated signatures. For
	 *  example if the signature was "[BII", this method would return "II"
	 *
	 * @param  sig Description of Parameter
	 * @return  Description of the Returned Value
	 */
	public static String nextSig(String sig)
	{
		int ndx = 0;
		String x;

		while(sig.charAt(ndx) == '[')
		{
			ndx++;
		}

		if(sig.charAt(ndx) == 'L')
		{
			while(sig.charAt(ndx) != ';')
			{
				ndx++;
			}
		}
		ndx++;
		x = (sig.substring(ndx));
		return (x);
	}
	/**
	 *  Takes a type signature and a string representing a variable name and
	 *  returns a declaration for that variable name. For example, passing this the
	 *  strings "[B" and "myArray" will return the string "byte myArray[]"
	 *
	 * @param  typeString Description of Parameter
	 * @param  varName Description of Parameter
	 * @return  Description of the Returned Value
	 */
	public static String typeString(String typeString, String varName)
	{
		int isArray = 0;
		int ndx = 0;
		StringBuffer x = new StringBuffer();

		while(typeString.charAt(ndx) == '[')
		{
			isArray++;
			ndx++;
		}

		switch (typeString.charAt(ndx))
		{
			case 'B':
				x.append("byte ");
				break;
			case 'C':
				x.append("char ");
				break;
			case 'D':
				x.append("double ");
				break;
			case 'F':
				x.append("float ");
				break;
			case 'I':
				x.append("int ");
				break;
			case 'J':
				x.append("long ");
				break;
			case 'L':
				for(int i = ndx + 1; i < typeString.indexOf(';'); i++)
				{
					if(typeString.charAt(i) != '/')
					{
						x.append(typeString.charAt(i));
					}
					else
					{
						x.append('.');
					}
				}
				x.append(" ");
				break;
			case 'V':
				x.append("void ");
				break;
			case 'S':
				x.append("short ");
				break;
			case 'Z':
				x.append("boolean ");
				break;
		}
		x.append(varName);
		while(isArray > 0)
		{
			x.append("[]");
			isArray--;
		}
		return (x.toString());
	}
	/**
	 * The source location is the file system resource (file or from a jar)
	 * that should enable one to figure out the source of the bytes codes.
	 *
	 * @param  str The new SourceLocation value
	 */
	public void setSourceLocation(String str)
	{
		sourceLocation = str;
	}
	/**
	 * @return  The PackageName value
	 */
	public String getPackageName()
	{
		String myClassName = formatName(thisClass.arg1.strValue);
		if(myClassName.indexOf('.') > 0)
		{
			return myClassName.substring(0, myClassName.lastIndexOf('.'));
		}
		return "";
	}
	/**
	 * @param  methodName <className>. <methodName>( <parameters>
	 *
	 *      ) <returnTypeClassName>
	 * @param  otherClassNames String [] of classes to substitute in the className
	 *      arg.
	 * @return  The MethodsCalling value
	 */
	public Vector getMethodsCalling(String methodName, String[] otherClassNames)
	{
		Vector result = new Vector();
		if(!isValidClass)
		{
			System.out.println("Class file does not appear to be valid.");
			return result;
		}
//		System.out.println("MethodName '" + methodName);
		Hashtable table = allCalledMethods();
		Enumeration meths = table.keys();
		String sigNoArgs = methodName.substring(0, methodName.indexOf("("));

		String className = sigNoArgs.substring(0, sigNoArgs.lastIndexOf('.'));
		String methodSig = sigNoArgs.substring(sigNoArgs.lastIndexOf('.'));

		while(meths.hasMoreElements())
		{
			String declaredMethod = (String) meths.nextElement();
			Vector v = (Vector) table.get(declaredMethod);
			Enumeration e = v.elements();
			while(e.hasMoreElements())
			{
				Object object = e.nextElement();
				try
				{
					MethodReference obj = (MethodReference) object;
					String str = obj.toString();
					if(str.indexOf(methodSig) > -1)
					{
						if(str.startsWith(className))
						{
							result.addElement(getClassName() + " >> " + declaredMethod);
							break;
						}
						else if(otherClassNames != null)
						{
							for(int i = 0; i < otherClassNames.length; ++i)
							{
								if(str.startsWith(otherClassNames[i]))
								{
									result.addElement(getClassName() + " >> " + declaredMethod);
									break;
								}
							}
						}
					}
				}
				catch(ClassCastException ex)
				{
					System.out.println("Not a method ref " + ((ConstantPoolInfo) object).type);
				}
			}
		}
		return result;
	}
	/**
	 *  Return the attribute named 'name' from the class file.
	 *
	 * @param  name Description of Parameter
	 * @return  The Attribute value
	 */
	public AttributeInfo getAttribute(String name)
	{
		if(attributes == null)
		{
			return null;
		}
		for(int i = 0; i < attributes.length; i++)
		{
			if(name.compareTo(attributes[i].name.toString()) == 0)
			{
				return attributes[i];
			}
		}
		return (null);
	}
	/**
	 * @return  The ClassDependencies value
	 * @exception  Exception Description of Exception
	 */
	public String[] getClassDependencies() throws Exception
	{
		java.util.Vector v = new java.util.Vector();

		for(int i = 1; i < constantPool.length; i++)
		{
			if(constantPool[i] == null)
			{
				continue;
			}
			if((constantPool[i] == thisClass) ||
					(constantPool[i] == superClass))
			{
				continue;
			}
			if(constantPool[i].type == ConstantPoolInfo.CLASS)
			{
				String s = constantPool[i].arg1.strValue;
				if(s.charAt(0) == '[')
				{
					continue;
				}
				s = formatName(constantPool[i].arg1.strValue);
				v.addElement(formatName(s));
			}
		}
		if(!superClass.arg1.strValue.equals("java.lang.Object"))
		{
			v.addElement(formatName(superClass.arg1.strValue));
		}

		String[] result = new String[v.size()];
		v.copyInto(result);
		return result;
	}
	/**
	 * @return  The ClassName value
	 */
	public String getClassName()
	{
		return formatName(thisClass.arg1.strValue);
	}
	/**
	 *  Return a constant pool item from this class. (note does fixup of indexes to
	 *  facilitate extracting nested or linked items.
	 *
	 * @param  index Description of Parameter
	 * @return  The ConstantPoolItem value
	 * @exception  Exception Description of Exception
	 */
	public ConstantPoolInfo getConstantPoolItem(short index) throws Exception
	{
		ConstantPoolInfo cp;

		if((index <= 0) || (index > (constantPool.length - 1)))
		{
			return (null);
		}
		cp = constantPool[index];
		if(cp.arg1 != null)
		{
			cp.index1 = ConstantPoolInfo.indexOf(cp.arg1, constantPool);
		}
		if(cp.arg2 != null)
		{
			cp.index2 = ConstantPoolInfo.indexOf(cp.arg2, constantPool);
		}
		return cp;
	}
	/**
	 *  Gets the ConstantRef attribute of the ClassFile object
	 *
	 * @param  index Description of Parameter
	 * @return  The ConstantRef value
	 */
	public ConstantPoolInfo getConstantRef(short index)
	{
		return (constantPool[index]);
	}
	/**
	 * @param  item Description of Parameter
	 * @return  The PrimitiveConstant value
	 */
	protected boolean isPrimitiveConstant(ConstantPoolInfo item)
	{
		switch (item.type)
		{
			case ConstantPoolInfo.ASCIZ:
			case ConstantPoolInfo.UNICODE:
			case ConstantPoolInfo.INTEGER:
			case ConstantPoolInfo.LONG:
			case ConstantPoolInfo.FLOAT:
			case ConstantPoolInfo.DOUBLE:
			{
				return true;
			}
		}
		return false;
	}
	/**
	 *  Is this class file an interface?
	 *
	 * @return  The Interface value
	 */
	boolean isInterface()
	{
		return ((accessModifiers & MOD_INTERFACE) != 0);
	}
	/**
	 * The source location is the file system resource (file or from a jar)
	 * that should enable one to figure out the source of the bytes codes.
	 *
	 * @return  The SourceLocation value
	 */
	public String getSourceLocation()
	{
		return sourceLocation;
	}
	/**
	 *  Add a new optional class Attribute.
	 *
	 * @param  newAttribute The feature to be added to the Attribute attribute
	 */
	public void addAttribute(AttributeInfo newAttribute)
	{
		if(attributes == null)
		{
			attributes = new AttributeInfo[1];
			attributes[0] = newAttribute;
		}
		else
		{
			AttributeInfo newAttrList[] = new AttributeInfo[1 + attributes.length];
			for(int i = 0; i < attributes.length; i++)
			{
				newAttrList[i] = attributes[i];
			}
			newAttrList[attributes.length] = newAttribute;
			attributes = newAttrList;
		}
	}
	/*
	 *  Examples of mysterious things you can do to a class file before
	 *  writing it back out. These methods are not currently functional.
	 *  (that would be too easy :-)
	 */
	/**
	 *  We have to add an item and then get the item so we get the correct
	 *  ConstantPoolInfo instance.
	 *
	 * @param  name The feature to be added to the Attribute attribute
	 * @param  newData The feature to be added to the Attribute attribute
	 * @exception  IOException Description of Exception
	 * @exception  Exception Description of Exception
	 */
	public void addAttribute(String name, byte newData[]) throws IOException, Exception
	{
		ConstantPoolInfo constantName = new ConstantPoolInfo(name);
		short idx = addConstantPoolItem(constantName);

		constantName = getConstantRef(idx);
		AttributeInfo info = new AttributeInfo(constantName, newData);
		addAttribute(info);
	}
	/**
	 *  Use recursion to ensure that ConstantPoolInfo dependecies are met.
	 *
	 * @param  cpi Description of Parameter
	 * @return  Description of the Returned Value
	 * @exception  Exception Description of Exception
	 */
	public ConstantPoolInfo recursiveAdd(ConstantPoolInfo cpi) throws Exception
	{
		if(isPrimitiveConstant(cpi))
		{
			short idx = addConstantPoolItem(cpi);
			return constantPool[idx];
		}
		if(cpi.type == ConstantPoolInfo.STRING || cpi.type == ConstantPoolInfo.CLASS)
		{
			cpi.arg1 = recursiveAdd(cpi.arg1);
			int idx = addConstantPoolItem(cpi);
			return constantPool[idx];
		}
		cpi.arg1 = recursiveAdd(cpi.arg1);
		cpi.arg2 = recursiveAdd(cpi.arg2);
		int idx = addConstantPoolItem(cpi);
		return constantPool[idx];
	}
	/**
	 *  Add a single constant pool item and return its index. If the item is
	 *  already in the pool then the index of the <i>preexisting</i> item is
	 *  returned. Thus you cannot assume that a pointer to your item will be
	 *  useful.
	 *
	 * @param  item The feature to be added to the ConstantPoolItem attribute
	 * @return  Description of the Returned Value
	 * @exception  Exception Description of Exception
	 */
	public short addConstantPoolItem(ConstantPoolInfo item) throws Exception
	{
		ConstantPoolInfo newConstantPool[];
		ConstantPoolInfo cp;

		cp = item.inPool(constantPool);
		if(cp != null)
		{
			return ConstantPoolInfo.indexOf(cp, constantPool);
		}

		newConstantPool = new ConstantPoolInfo[constantPool.length + 1];
		for(int i = 1; i < constantPool.length; i++)
		{
			newConstantPool[i] = constantPool[i];
		}
		newConstantPool[constantPool.length] = item;
		constantPool = newConstantPool;
		return ConstantPoolInfo.indexOf(item, constantPool);
	}
	/**
	 *  Add some items to the constant pool. This is used to add new items to the
	 *  constant pool. The items references in arg1 and arg2 are expected to be
	 *  valid pointers (if necessary). Pruning is done to prevent adding redundant
	 *  items to the list and to preserve string space. The algorithm is simple,
	 *  first identify pool items containing constants in the list of items to be
	 *  added that are already in the constant pool. If any are found to already
	 *  exist, change the pointers in the non-constant items to point to the ones
	 *  in the pool rather than the ones in the list. Next check to see if any of
	 *  the non-constant items are already in the pool and if so fix up the others
	 *  in the list to point to the ones in the pool. Finally, add any items (there
	 *  must be at least one) from the item list that aren't already in the pool,
	 *  all of the pointers will already be fixed. NOTE: Since constants in the
	 *  constant pool may be referenced <i>inside</i> the opaque portion of
	 *  attributes the constant table cannot be re-ordered, only extended.
	 *
	 * @param  items The feature to be added to the ConstantPoolItems attribute
	 */
	public void addConstantPoolItems(ConstantPoolInfo items[])
	{
		ConstantPoolInfo newArg;
		ConstantPoolInfo newConstantPool[];
		boolean delete[] = new boolean[items.length];

		/*
		 *  Step one, look for matching constants
		 */
		for(int j = 0; j < items.length; j++)
		{
			if((items[j].type == ConstantPoolInfo.ASCIZ) ||
					(items[j].type == ConstantPoolInfo.UNICODE) ||
					(items[j].type == ConstantPoolInfo.INTEGER) ||
					(items[j].type == ConstantPoolInfo.LONG) ||
					(items[j].type == ConstantPoolInfo.FLOAT) ||
					(items[j].type == ConstantPoolInfo.DOUBLE))
			{

				// Look for this item in the constant pool
				delete[j] = false;
				newArg = items[j].inPool(constantPool);
				if(newArg != null)
				{
					// replace the references in our list.
					delete[j] = true;
					// mark it for deletion
					for(int i = 0; i < items.length; i++)
					{
						if(items[i].arg1 == items[j])
						{
							items[i].arg1 = newArg;
						}
						if(items[i].arg2 == items[j])
						{
							items[i].arg2 = newArg;
						}
					}
				}
			}
		}

		/*
		 *  Step two : now match everything else
		 */
		for(int j = 0; j < items.length; j++)
		{
			if((items[j].type == ConstantPoolInfo.CLASS) ||
					(items[j].type == ConstantPoolInfo.FIELDREF) ||
					(items[j].type == ConstantPoolInfo.METHODREF) ||
					(items[j].type == ConstantPoolInfo.STRING) ||
					(items[j].type == ConstantPoolInfo.INTERFACE) ||
					(items[j].type == ConstantPoolInfo.NAMEANDTYPE))
			{

				// Look for this item in the constant pool
				delete[j] = false;
				newArg = items[j].inPool(constantPool);
				if(newArg != null)
				{
					// replace the references in our list.
					delete[j] = true;
					// mark it for deletion
					for(int i = 0; i < items.length; i++)
					{
						if(items[i].arg1 == items[j])
						{
							items[i].arg1 = newArg;
						}
						if(items[i].arg2 == items[j])
						{
							items[i].arg2 = newArg;
						}
					}
				}
			}
		}

		/*
		 *  Step three: Add the surviving items to the pool
		 */
		int count = 0;
		for(int i = 0; i < items.length; i++)
		{
			if(!delete[i])
			{
				count++;
			}
		}
		// count == # of survivors
		newConstantPool = new ConstantPoolInfo[constantPool.length + count];
		for(int i = 1; i < constantPool.length; i++)
		{
			newConstantPool[i] = constantPool[i];
		}
		// newConstantPool == existing constantPool

		int ndx = 0;
		for(int i = constantPool.length; i < newConstantPool.length; i++)
		{
			while(delete[ndx])
			{
				ndx++;
			}
			newConstantPool[i] = items[ndx];
			ndx++;
		}
		// newConstantPool == existing + new
		constantPool = newConstantPool;
		// all done.
	}
	/**
	 * @param  di Description of Parameter
	 * @return  Description of the Returned Value
	 * @exception  IOException Description of Exception
	 */
	public boolean checkMagic(DataInputStream di) throws IOException
	{
		magic = di.readInt();
		if(magic != (int) 0xCAFEBABE)
		{
			return (false);
		}

		return true;
	}
	/**
	 *  Delete a named method from this class. This method is used to excise
	 *  specific methods from the loaded class. The actual method code remains,
	 *  however the method signature is deleted from the constant pool. If this
	 *  method is called by a class the exception IncompatibleClassChangeException
	 *  is generated by the runtime.
	 *
	 * @param  name Description of Parameter
	 * @param  signature Description of Parameter
	 */
	public void deleteMethod(String name, String signature)
	{
		for(int i = 0; i < constantPool.length; i++)
		{
			if(constantPool[i].type == ConstantPoolInfo.CLASS)
			{
			}
		}
	}
	/**
	 * @return  Description of the Returned Value
	 */
	public Hashtable allCalledMethods()
	{
		Hashtable result = new Hashtable();
		if(methods != null)
		{
			for(int i = 0; i < methods.length; i++)
			{
				try
				{
					Vector v = new Vector();
					methods[i].addCalledMethods(v, constantPool);
					result.put(methods[i].toString(getClassName(), constantPool), v);
				}
				catch(RuntimeException ex)
				{
					System.out.println("EXCEPTION PARSING CLASS FILE: " + getClassName());
					System.out.println(ex);
				}
			}
		}
		return result;
	}
	/**
	 *  Write out a text version of this class.
	 *
	 * @param  ps Description of Parameter
	 * @exception  Exception Description of Exception
	 */
	public void display(PrintStream ps) throws Exception
	{
		int i;
		String myClassName;
		String mySuperClassName;
		String packageName = null;

		if(!isValidClass)
		{
			ps.println("Not a valid class");
		}

		myClassName = formatName(thisClass.arg1.strValue);
		mySuperClassName = formatName(superClass.arg1.strValue);
		int idx = myClassName.lastIndexOf('.');
		if(idx > 0)
		{
			packageName =
					myClassName.substring(0, idx);
			myClassName = myClassName.substring(idx + 1);
			ps.println("package " + packageName + ";\n");
		}

		for(i = 1; i < constantPool.length; i++)
		{
			if(constantPool[i] == null)
			{
				continue;
			}
			if((constantPool[i] == thisClass) ||
					(constantPool[i] == superClass))
			{
				continue;
			}
			if(constantPool[i].type == ConstantPoolInfo.CLASS)
			{
				String s = constantPool[i].arg1.strValue;
				if(s.charAt(0) == '[')
				{
					continue;
				}
				s = formatName(constantPool[i].arg1.strValue);
				if((packageName != null) && (s.startsWith(packageName)))
				{
					continue;
				}
				ps.println("import " + formatName(s) + ";");
			}
		}
		ps.println();
		ps.println("/*");
		DataInputStream dis;
		ConstantPoolInfo cpi;

		if(attributes != null)
		{
			ps.println(" * This class has " + attributes.length +
					" optional class attributes.");
			ps.println(" * These attributes are: ");
			for(i = 0; i < attributes.length; i++)
			{
				String attrName = attributes[i].name.strValue;
				dis = new DataInputStream(new ByteArrayInputStream(attributes[i].data));

				ps.println(" * Attribute " + (i + 1) + " is of type " + attributes[i].name);
				if(attrName.compareTo("SourceFile") == 0)
				{
					cpi = null;
					try
					{
						cpi = constantPool[dis.readShort()];
					}
					catch(IOException e)
					{
					}
					ps.println(" *	SourceFile : " + cpi);
				}
				else
				{
					ps.println(" *	TYPE (" + attrName + ")");
				}
			}
		}
		else
		{
			ps.println(" * This class has NO optional class attributes.");
		}
		ps.println(" */\n");
		ps.print(accessString(accessModifiers));
		if(!isInterface())
		{
			ps.print("class ");
		}
		ps.print(myClassName + " extends " +
				mySuperClassName);
		if(interfaces != null)
		{
			ps.print(" implements ");
			for(i = 0; i < interfaces.length - 1; i++)
			{
				ps.print(formatName(interfaces[i].arg1.strValue) + ", ");
			}
			ps.print(formatName(interfaces[interfaces.length - 1].arg1.strValue));
		}
		ps.println(" {\n");
		if(fields != null)
		{
			ps.println("/* Instance Variables */");
			for(i = 0; i < fields.length; i++)
			{
				ps.println("    " + fields[i].toString(constantPool) + ";");
			}
		}

		if(methods != null)
		{
			ps.println("\n/* Methods */");
			for(i = 0; i < methods.length; i++)
			{
				ps.println("    " + methods[i].toString(myClassName, constantPool));
			}
		}
		ps.println("\n}");
	}
	/**
	 * @param  di Description of Parameter
	 * @param  constPool Description of Parameter
	 * @return  Description of the Returned Value
	 * @exception  IOException Description of Exception
	 */
	public AttributeInfo[] identifyAttributes(DataInputStream di, ConstantPoolInfo[] constPool) throws IOException
	{
		AttributeInfo[] infos = null;
		int count = di.readShort();
		if(count != 0)
		{
			infos = new AttributeInfo[count];
			for(int i = 0; i < count; i++)
			{
				infos[i] = AttributeInfo.readAttributeInfo(di, constPool);
				if(infos[i] == null)
				{
					return new AttributeInfo[0];
				}
			}
		}
		if(debug)
		{
			System.out.println("read(): Read attribute info...");
			System.out.println("done.");
		}
		return infos;
	}
	/**
	 * @param  di Description of Parameter
	 * @param  constPool Description of Parameter
	 * @return  Description of the Returned Value
	 * @exception  IOException Description of Exception
	 */
	public boolean identifyClassParts(DataInputStream di, ConstantPoolInfo[] constPool) throws IOException
	{
		interfaces = identifyInterfaces(di, constPool);
		if(interfaces != null && interfaces.length == 0)
		{
			return false;
		}

		fields = identifyFields(di, constPool);
		if(fields != null && fields.length == 0)
		{
			return false;
		}

		methods = identifyMethods(di, constPool);
		if(methods != null && methods.length == 0)
		{
			return false;
		}

		attributes = identifyAttributes(di, constPool);
		if(attributes != null && attributes.length == 0)
		{
			return false;
		}
		return true;
	}
	/**
	 * @param  di Description of Parameter
	 * @param  constPool Description of Parameter
	 * @return  Description of the Returned Value
	 * @exception  IOException Description of Exception
	 */
	public FieldInfo[] identifyFields(DataInputStream di, ConstantPoolInfo[] constPool) throws IOException
	{
		int count = di.readShort();
		FieldInfo[] result = null;
		if(debug)
		{
			System.out.println("This class has " + count + " fields.");
		}
		if(count != 0)
		{
			result = new FieldInfo[count];
			for(int i = 0; i < count; i++)
			{
				result[i] = new FieldInfo();
				if(!result[i].read(di, constPool))
				{
					return new FieldInfo[0];
				}
				if(debug)
				{
					System.out.println("F" + i + ": " +
							result[i].toString(constPool));
				}
			}
		}
		if(debug)
		{
			System.out.println("read(): Read field info...");
		}
		return result;
	}
	/**
	 * @param  di Description of Parameter
	 * @param  constPool Description of Parameter
	 * @return  Description of the Returned Value
	 * @exception  IOException Description of Exception
	 */
	public ConstantPoolInfo[] identifyInterfaces(DataInputStream di, ConstantPoolInfo[] constPool) throws IOException
	{
		int count = di.readShort();
		ConstantPoolInfo[] faces = null;
		if(count != 0)
		{
			if(debug)
			{
				System.out.println("Class implements " + count + " interfaces.");
			}
			faces = new ConstantPoolInfo[count];
			for(int i = 0; i < count; i++)
			{
				int iindex = di.readShort();
				if((iindex < 1) || (iindex > constPool.length - 1))
				{
					return new ConstantPoolInfo[0];
				}
				faces[i] = constPool[iindex];
				if(debug)
				{
					System.out.println("I" + i + ": " + interfaces[i]);
				}
			}
		}
		if(debug)
		{
			System.out.println("read(): Read interface info...");
		}
		return faces;
	}
	/**
	 * @param  di Description of Parameter
	 * @param  constPool Description of Parameter
	 * @return  Description of the Returned Value
	 * @exception  IOException Description of Exception
	 */
	public MethodInfo[] identifyMethods(DataInputStream di, ConstantPoolInfo[] constPool) throws IOException
	{
		int count = di.readShort();
		MethodInfo[] infos = null;
		if(count != 0)
		{
			infos = new MethodInfo[count];
			for(int i = 0; i < count; i++)
			{
				infos[i] = new MethodInfo();
				if(!infos[i].read(di, constPool))
				{
					return new MethodInfo[0];
				}
				if(debug)
				{
					System.out.println("M" + i + ": " + infos[i].toString());
				}
			}
		}
		if(debug)
		{
			System.out.println("read(): Read method info...");
		}
		return infos;
	}
	/**
	 *  Map occurences of class <i>oldClass</i> to occurrences of class <i>newClass
	 *  </i>. This method is used to retarget accesses to one class, seamlessly to
	 *  another. The format for the class name is slash (/) separated so the class
	 *  <tt>util.ClassFile</tt> would be represented as <tt>util/ClassFile</tt>
	 *
	 * @param  oldClass Description of Parameter
	 * @param  newClass Description of Parameter
	 */
	public void mapClass(String oldClass, String newClass)
	{
		if(debug)
		{
			System.out.println("Mapping class name " + oldClass + " ==> " +
					newClass + " for class " + thisClass.arg1);
		}
		for(int i = 0; i < constantPool.length; i++)
		{
			if(constantPool[i].type == ConstantPoolInfo.CLASS)
			{
				String cname = constantPool[i].arg1.strValue;
				if(cname.compareTo(oldClass) == 0)
				{
					if(debug)
					{
						System.out.println("REPLACING " + cname + " with " + newClass);
					}
					constantPool[i].arg1.strValue = newClass;
				}
			}
		}
	}
	/**
	 *  Map occurences of package <i>oldPackage</i> to package <i>newPackage</i> .
	 *  The format for the package name is slash (/) separated so the package <tt>
	 *  java.util</tt> would be represented as <tt>java/util</tt>
	 *
	 * @param  oldPackage Description of Parameter
	 * @param  newPackage Description of Parameter
	 */
	public void mapPackage(String oldPackage, String newPackage)
	{
		for(int i = 0; i < constantPool.length; i++)
		{
			if(constantPool[i].type == ConstantPoolInfo.CLASS)
			{
				String cname = constantPool[i].arg1.strValue;
				if(cname.startsWith(oldPackage))
				{
					constantPool[i].arg1.strValue = newPackage +
							cname.substring(cname.lastIndexOf('/'));
				}
			}
		}
	}
	/**
	 *  Take an InputStream and read in what is believed to be a class file.
	 *
	 * @param  in Description of Parameter
	 * @return  boolean True if sucessfully read, False if we failed for some
	 *      reason.
	 * @exception  IOException Description of Exception
	 */
	public boolean read(InputStream in) throws IOException
	{
		DataInputStream di = new DataInputStream(in);
		int count;

		if(!checkMagic(di))
		{
			System.out.println("Magic fails.");
			return false;
		}
		readVersion(di);

		constantPool = readConstantPoolInfo(di);
		if(constantPool == null)
		{
			System.out.println("Constant pool is null!");
			return false;
		}

		updatePointers(constantPool);

		accessModifiers = di.readShort();

		short idx = di.readShort();
		thisClass = constantPool[idx];
		superClass = constantPool[di.readShort()];
		if(debug)
		{
			System.out.println("read(): Read class info...");
		}

		if(!identifyClassParts(di, constantPool))
		{
			System.out.println("Could not identify parts!");
			return false;
		}

		isValidClass = true;

		return (true);
	}
	/**
	 * @param  di Description of Parameter
	 * @return  Description of the Returned Value
	 * @exception  IOException Description of Exception
	 */
	public ConstantPoolInfo[] readConstantPoolInfo(DataInputStream di) throws IOException
	{
		int count;
		count = di.readShort();
		ConstantPoolInfo[] constPool = new ConstantPoolInfo[count];
		if(debug)
		{
			System.out.println("read(): Read header...");
		}
		constPool[0] = new ConstantPoolInfo();
		for(int i = 1; i < constPool.length; i++)
		{
			int type = di.readByte();
			constPool[i] = ConstantPoolInfo.create(type);

			if(!constPool[i].read(di, type))
			{
				return null;
			}
			if(showPoolElements)
			{
				System.out.println("Pool " + constPool[i]);
			}
			// These two types take up "two" spots in the table
			if((constPool[i].type == ConstantPoolInfo.LONG) ||
					(constPool[i].type == ConstantPoolInfo.DOUBLE))
			{
				i++;
			}
		}
		return constPool;
	}
	/**
	 * @param  di Description of Parameter
	 * @exception  IOException Description of Exception
	 */
	public void readVersion(DataInputStream di) throws IOException
	{
		majorVersion = di.readShort();
		minorVersion = di.readShort();
	}
	/**
	 * @return  Description of the Returned Value
	 */
	public String toString()
	{
		return ("Class File (Version " + majorVersion + "." + minorVersion +
				") for class " + thisClass.arg1);
	}
	/**
	 *  When we read in the class file, we read the 'index' of the constant pool.
	 *  This is index1 and index2. Once the entire pool is read in, we can
	 *  'updatePointers' to provide references to ConstantPoolInfo objects. This
	 *  method resolves those instances.
	 *
	 * @param  constPool Description of Parameter
	 * @fixme  - Have it verify that the right arguments are present
	 */
	public void updatePointers(ConstantPoolInfo[] constPool)
	{
		for(int i = 1; i < constPool.length; i++)
		{
			if(constPool[i] == null)
			{
				continue;
			}
			if(constPool[i].index1 > 0)
			{
				constPool[i].arg1 = constPool[constPool[i].index1];
			}
			if(constPool[i].index2 > 0)
			{
				constPool[i].arg2 = constPool[constPool[i].index2];
			}
		}
		if(dumpConstants)
		{
			for(int i = 1; i < constPool.length; i++)
			{
				System.out.println("C" + i + " - " + constPool[i].type + " - " + constPool[i]);
			}
		}
	}
	/**
	 *  Write the class out as a stream of bytes to the output stream. Generally
	 *  you will read a class file, manipulate it in some way, and then write it
	 *  out again before passing it to <TT>defineClass</TT> in some class loader.
	 *
	 * @param  out Description of Parameter
	 * @exception  IOException Description of Exception
	 * @exception  Exception Description of Exception
	 */
	public void write(OutputStream out) throws IOException, Exception
	{
		DataOutputStream dos = new DataOutputStream(out);

		if(!isValidClass)
		{
			throw new Exception("ClassFile::write() - Invalid Class");
		}

		dos.writeInt(magic);
		dos.writeShort(majorVersion);
		dos.writeShort(minorVersion);
		dos.writeShort(constantPool.length);
		for(int i = 1; i < constantPool.length; i++)
		{
			if(showPoolElements)
			{
				System.out.println("Writing Constant Pool " + constantPool[i]);
			}
			if(constantPool[i] != null)
			{
				constantPool[i].write(dos, constantPool);
			}
		}
		dos.writeShort(accessModifiers);
		System.out.println("Writing this class " + ConstantPoolInfo.indexOf(thisClass, constantPool));

		dos.writeShort(ConstantPoolInfo.indexOf(thisClass, constantPool));
		dos.writeShort(ConstantPoolInfo.indexOf(superClass, constantPool));

		if(interfaces == null)
		{
			dos.writeShort(0);
		}
		else
		{
			dos.writeShort(interfaces.length);
			for(int i = 0; i < interfaces.length; i++)
			{
				dos.writeShort(ConstantPoolInfo.indexOf(interfaces[i],
						constantPool));
			}
		}

		if(fields == null)
		{
			dos.writeShort(0);
		}
		else
		{
			dos.writeShort(fields.length);
			for(int i = 0; i < fields.length; i++)
			{
				fields[i].write(dos, constantPool);
			}
		}

		if(methods == null)
		{
			dos.writeShort(0);
		}
		else
		{
			dos.writeShort(methods.length);
			for(int i = 0; i < methods.length; i++)
			{
				methods[i].write(dos, constantPool);
			}
		}

		if(attributes == null)
		{
			dos.writeShort(0);
		}
		else
		{
			dos.writeShort(attributes.length);
			for(int i = 0; i < attributes.length; i++)
			{
				attributes[i].write(dos, constantPool);
			}
		}
	}
	/**
	 * @param  in Description of Parameter
	 * @exception  IOException Description of Exception
	 * @exception  Exception Description of Exception
	 */
	protected void insertMethod(InputStream in) throws IOException, Exception
	{
		DataInputStream din = new DataInputStream(in);
		String methodName = din.readUTF();
		System.out.println("Inserting method " + methodName);
		String methodSig = din.readUTF();
		String code = din.readUTF();
		short accessModifiers = din.readShort();
		short count = din.readShort();
		ConstantPoolInfo[] pool = new ConstantPoolInfo[1];
		pool[0] = findConstantPoolInfo("Code");

		AttributeInfo[] attributes = new AttributeInfo[count];
		if(count != 0)
		{
			for(int i = 0; i < count; i++)
			{
				attributes[i] = AttributeInfo.readAttributeInfo(din, pool);
				// "code"
				if(attributes[i] == null)
				{
					return;
				}
				System.out.println("Code attribute name " + attributes[i].name);
			}
		}
		MethodInfo newMethod = new MethodInfo();
		newMethod.accessModifiers = accessModifiers;
		newMethod.name = findConstantPoolInfo(methodName);
		newMethod.signature = findConstantPoolInfo(methodSig);
		newMethod.attributes = attributes;
		MethodInfo[] tmp = new MethodInfo[methods.length + 1];
		System.arraycopy(methods, 0, tmp, 0, methods.length);
		tmp[methods.length] = newMethod;
		methods = tmp;
	}
	/**
	 * @param  methodName Description of Parameter
	 * @param  out Description of Parameter
	 * @exception  IOException Description of Exception
	 * @exception  Exception Description of Exception
	 */
	protected void writeMethod(String methodName, OutputStream out) throws IOException, Exception
	{
		DataOutputStream dos = new DataOutputStream(out);
		if(methods == null)
		{
			throw new Exception("No method " + methodName + " found. ");
		}
		else
		{
			for(int i = 0; i < methods.length; i++)
			{
				if(methods[i].name.strValue.equals(methodName))
				{
					System.out.println("Writing method " + methodName);
					dos.writeUTF(methods[i].name.strValue);
					dos.writeUTF(methods[i].signature.strValue);
					dos.writeUTF("Code");
					dos.writeShort(methods[i].accessModifiers);
					if(methods[i].attributes == null)
					{
						dos.writeShort(0);
					}
					else
					{
						dos.writeShort(methods[i].attributes.length);
						for(int j = 0; j < methods[i].attributes.length; j++)
						{
							dos.writeShort((short) 0);
							dos.writeInt(methods[i].attributes[j].data.length);
							dos.write(methods[i].attributes[j].data, 0, methods[i].attributes[j].data.length);
						}
					}
					break;
				}
			}
		}
	}
	/**
	 * @param  str Description of Parameter
	 * @return  Description of the Returned Value
	 */
	ConstantPoolInfo findConstantPoolInfo(String str)
	{
		ConstantPoolInfo code = new ConstantPoolInfo(str);
		code = code.inPool(constantPool);

		if(code == null)
		{
			code = new ConstantPoolInfo(str);
			ConstantPoolInfo[] tmp = new ConstantPoolInfo[constantPool.length + 1];
			System.arraycopy(constantPool, 0, tmp, 0, constantPool.length);
			tmp[constantPool.length] = code;
			constantPool = tmp;
			updatePointers(constantPool);
		}
		return code;
	}
	/**
	 * @param  s Description of Parameter
	 * @return  Description of the Returned Value
	 */
	private String formatName(String s)
	{
		StringBuffer x;

		if(s.charAt(0) == '[')
		{
			return (typeString(s, ""));
		}

		x = new StringBuffer();
		for(int j = 0; j < s.length(); j++)
		{
			if(s.charAt(j) == '/')
			{
				x.append('.');
			}
			else
			{
				x.append(s.charAt(j));
			}
		}
		return (x.toString());
	}
	/**
	 * @author  dhoag
	 * @version  $Id: ClassFile.java,v 2.2 2002/07/31 15:55:22 dave_hoag Exp $
	 */
	public static class Test extends com.objectwave.test.UnitTestBaseImpl
	{
		/**
		 * @param  args The command line arguments
		 */
		public static void main(String[] args)
		{
			com.objectwave.test.TestRunner.run(new Test(), args);
		}
		/**
		 * @exception  InvalidClassException Description of Exception
		 */
		public void testGetInstance() throws InvalidClassException
		{
			String className = "com.objectwave.classFile.ClassFile";
			ClassFile file = ClassFile.getInstance(System.getProperty("java.class.path"), className);
			testContext.assertTrue("Failed to create class file for TestCase", file != null);
			testContext.assertEquals(className, file.getClassName());
			try
			{
				ClassFile.getInstance(System.getProperty("java.class.path"), "test.BogusTestCase");
			}
			catch(InvalidClassException ex)
			{
				file = null;
			}
			testContext.assertTrue("Exception not thrown even though class could not be found!", file == null);
		}
	}
}
