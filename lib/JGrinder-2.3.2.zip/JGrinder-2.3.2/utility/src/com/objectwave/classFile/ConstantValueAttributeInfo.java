package com.objectwave.classFile;
    
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
/**
 * A specific attribute info. 
 * Used as an optional attribute on FieldInfos.
 * Can also be used to represent a source file attribute.
 * @see		ClassFile
 * @version 1.2
 */
public class ConstantValueAttributeInfo extends AttributeInfo
{
	ConstantPoolInfo constantValue;
	/**
	 */
	public ConstantValueAttributeInfo()
	{
	}
	/**
	 */
	public ConstantValueAttributeInfo(ConstantPoolInfo newName, byte newData[])
	{
	    super(newName, newData);
	}
	/**
        ConstantValue_attribute {
                u2 attribute_name_index;
                u4 attribute_length;
                u2 constantvalue_index;
        }
	 */
	public boolean read(DataInputStream di, ConstantPoolInfo pool[]) throws IOException
	{
		int len;
        //The name should already be set!
        if(name == null)
        {
    		name = pool[di.readShort()];
    	}

		len = di.readInt();
		data = new byte[len];
		if(len != 2) throw new IllegalStateException("A ConstantValueAttribute must have a length of 2!");
		len  = di.read(data);
		if (len != data.length) return false;
		constantValue = pool[indexFromBytes(data)];
		return true;
	}
	/**
	 * Write the bytes to the output stream.
	 * @param dos The DataOutputStream upon which this is writing
	 * @param pool The constant pool in which to index.
	 */
	public void write(DataOutputStream dos, ConstantPoolInfo pool[]) throws IOException, Exception
	{
		dos.writeShort(ConstantPoolInfo.indexOf(name, pool));
		dos.writeInt(data.length);
		
		//dos.write(data, 0, data.length);

		short idx = constantValue.indexOf(constantValue, pool);
		dos.writeShort(idx);
	}
	/**
	 */
	protected void fixUpConstants(ClassFile target, ConstantPoolInfo [] originalPool) throws Exception
	{
		super.fixUpConstants(target, originalPool);
		constantValue = target.recursiveAdd(constantValue);
    }
}