/* Copyright (C) 2001 David Hoag
 * ObjectWave Corporation
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * For a full copy of the license see:
 * http://www.opensource.org/licenses/lgpl-license.html
 */
package com.objectwave.classFile;
import com.objectwave.utility.JarReader;

import java.io.*;
import java.text.*;
import java.util.*;
import java.util.zip.*;

/**
 *  Display information about class files.
 *
 * @author  Dave Hoag
 * @version  $Id: DumpClass.java,v 2.0 2001/06/11 15:46:53 dave_hoag Exp $
 */
public class DumpClass
{
	final static boolean verbose = false;
	/**
	 * @param  fileName
	 * @param  args
	 */
	public static void dumpFile(String fileName, String[] args)
	{
		File file = new File(fileName);
		try
		{
			ClassFile cf = new ClassFile();
			if(file.exists())
			{
				FileInputStream fi = new FileInputStream(fileName);

				// cf.debug = true;
				cf.dumpConstants = System.getProperty("dumpConstants") != null;

				if(!cf.read(fi))
				{
					System.out.println("Unable to read class file.");
					System.exit(1);
				}
			}
			else
			{
				cf = ClassFile.getInstance(System.getProperty("java.class.path"), fileName);
				System.out.println("// Source: " + cf.getSourceLocation());
			}
			cf.display(System.out);
			if(args.length == 2)
			{
				FileOutputStream stream = new FileOutputStream(args[1] + ".meth");
				cf.writeMethod(args[1], stream);
				stream.flush();
				stream.close();
			}
			if(args.length > 2)
			{
				FileInputStream stream = new FileInputStream(args[1]);
				cf.insertMethod(stream);
				stream.close();
				FileOutputStream stream2 = new FileOutputStream(args[2]);
				cf.write(stream2);
				stream2.flush();
				stream2.close();
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	/**
	 * @param  args
	 */
	public static void main(String args[])
	{
		if(args.length < 1)
		{
			System.out.println("Usage: [-DdumpConstants] [-Dow.showAttributes ] DumpClass < fileName | fullyQualifiedClassName>");
		}
		else
		{
			String str = args[0];
			if(str.endsWith(".jar"))
			{
				parseJar(args[0]);
			}
			else
			{
				dumpFile(args[0], args);
			}
		}
	}
	/**
	 * @param  jarFileName
	 */
	public static void parseJar(String jarFileName)
	{
		printTime();
		try
		{
			JarReader jar = new JarReader(jarFileName);
			Enumeration e = jar.elements();
			while(e.hasMoreElements())
			{
				ZipEntry zipEntry = (ZipEntry) e.nextElement();
				if(verbose)
				{
					System.out.println(zipEntry.getName());
				}
				if(zipEntry.getName().endsWith(".class"))
				{
					byte[] data = jar.getData(e);
					ClassFile cf = new ClassFile();
					if(!cf.read(new ByteArrayInputStream(data)))
					{
						System.out.println("Unable to read class file.");
						System.exit(1);
					}
				}
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		printTime();
	}
	/**
	 *  used by the test routine.
	 */
	public static void printTime()
	{
		Calendar rightNow = Calendar.getInstance();
		Date tm = rightNow.getTime();
		DateFormat format = DateFormat.getTimeInstance();
		System.out.println(format.format(tm));
	}
}
