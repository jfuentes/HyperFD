package com.objectwave.classFile;
    
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
/**
 * A specific attribute info. 
 *
 * @see		ClassFile
 * @version 1.2
 */
public class ExceptionAttributeInfo extends AttributeInfo
{
	ConstantPoolInfo [] exceptionList;
	/**
	 */
	public ConstantPoolInfo [] getExceptionList()
	{
		return exceptionList;
	}
	/**
	 */
	public ExceptionAttributeInfo()
	{
	}
	/**
	 */
	public ExceptionAttributeInfo(ConstantPoolInfo newName, byte newData[])
	{
	    super(newName, newData);
	}
	/**
	 */
	public boolean read(DataInputStream di, ConstantPoolInfo pool[]) throws IOException
	{
		int len;
        //The name should already be set!
        if(name == null)
    		name = pool[di.readShort()];
		len = di.readInt();
		data = new byte[len];
		len  = di.read(data);
		if (len != data.length) return false;
        
		readTableAttributes(pool);
		return true;
	}
	/**
		Exceptions_attribute {

        		u2 attribute_name_index;
        		u4 attribute_length;
        		u2 number_of_exceptions;
        		u2 exception_index_table[number_of_exceptions];
		}
	 */
	protected void readTableAttributes(ConstantPoolInfo pool[]) throws IOException
	{
	    int len = data.length;
		byte [] twoBytes = new byte [2];
		int i = 0;
		twoBytes [0] = data[ i++];
		twoBytes [1] = data[ i++];
        int localVarCount = indexFromBytes(twoBytes);
        exceptionList = new ConstantPoolInfo[ localVarCount ];
        for(int j = 0; j < localVarCount; ++j)
        {
			twoBytes [0] = data[ i++];
			twoBytes [1] = data[ i++];
	        int nameIndex = indexFromBytes(twoBytes);
	        exceptionList[j] = pool[nameIndex];
        } 
	}
	/**
	 * Write the bytes to the output stream.
	 * @param dos The DataOutputStream upon which this is writing
	 * @param pool The constant pool in which to index.
	 */
	public void write(DataOutputStream dos, ConstantPoolInfo pool[]) throws IOException, Exception
	{
		dos.writeShort(ConstantPoolInfo.indexOf(name, pool));
		dos.writeInt(data.length);
		//dos.write(data, 0, data.length);
	    int len = data.length;
		byte [] twoBytes = new byte [2];
		int i = 0;
		twoBytes [0] = data[ i++];
		twoBytes [1] = data[ i++];
		dos.write(twoBytes);
        int localVarCount = indexFromBytes(twoBytes);
        for(int j = 0; j < localVarCount; ++j)
        {
			twoBytes [0] = data[ i++];
			twoBytes [1] = data[ i++];
			if(exceptionList == null || exceptionList.length == 0)
			{
				dos.write(twoBytes);
			}
			else
			{
				short idx = exceptionList[j].indexOf(exceptionList[j], pool);
				twoBytes = bytesFromIndex(idx);
				dos.write(twoBytes);
			}
        } 
	}
	/**
	 */
	protected void fixUpConstants(ClassFile target, ConstantPoolInfo [] originalPool) throws Exception
	{
		super.fixUpConstants(target, originalPool);
		if(exceptionList != null)
		{
			for(int i = 0; i < exceptionList.length; ++i)
			{
				exceptionList[i] = target.recursiveAdd(exceptionList[i]);
			} 
		}
    }
}