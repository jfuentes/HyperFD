package com.objectwave.classFile;
    
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
/**
 * A specific attribute info. 
 *
 * @see		ClassFile
 * @version 1.2
 */
public class LocalVariableAttributeInfo extends AttributeInfo
{
    String [ ] localVarNames = null;
    ConstantPoolInfo [] locals;
    int [] indicies ;
    /**
     */
    public ConstantPoolInfo [] getLocals()
    {
    	return locals;
    }
    /** */
    public String getLocalVarName(int idx)
    {
    	if(indicies == null) 
    	{
    		System.out.println("Null indicies");
    		return null;
    	}
    	for(int i = 0; i < indicies.length; ++i)
    	{
    		if(indicies[i] == idx)
    		{
    			return localVarNames[i];
    		}
    	} 
    	System.out.println("-----##########-------Local var not found " + idx + " in " + indicies[indicies.length - 1] );
    	return null;
    }
    /**
     */
    public String [] getLocalVarNames()
    {
        return localVarNames;
    }
	/**
	 */
	public LocalVariableAttributeInfo()
	{
	}
	/**
	 */
	public LocalVariableAttributeInfo(ConstantPoolInfo newName, byte newData[])
	{
	    super(newName, newData);
	}
	/**
	 */
	public boolean read(DataInputStream di, ConstantPoolInfo pool[]) throws IOException
	{
		int len;
        //The name should already be set!
        if(name == null)
    		name = pool[di.readShort()];
		len = di.readInt();
		data = new byte[len];
		len  = di.read(data);
		if (len != data.length) return false;
        
		readTableAttributes(pool);
		return true;
	}
	/**
     * LocalVariableTable_attribute {
    *          u2 attribute_name_index;  - reference to "LocalVariableTable"
    *          u4 attribute_length;  -  indicates the length of the attribute, excluding the initial six bytes. 
    *          u2 local_variable_table_length;  - the number of entries in the local_variable_table array
    *          {  u2 start_pc;
    *              u2 length;
    *              u2 name_index;  - must be a valid index into the constant_pool
    *              u2 descriptor_index;
    *              u2 index;
    *          } local_variable_table[
    *                          local_variable_table_length];
    *  } 
	 */
	protected void readTableAttributes(ConstantPoolInfo pool[]) throws IOException
	{
	    int len = data.length;
		byte [] twoBytes = new byte [2];
		int i = 0;
		twoBytes [0] = data[ i++];
		twoBytes [1] = data[ i++];
        int localVarCount = indexFromBytes(twoBytes);
        localVarNames = new String [ localVarCount ];
		indicies = new int [ localVarCount ];

        locals = new ConstantPoolInfo [ localVarCount ];
        for(int j = 0; j < localVarCount; ++j)
        {
			twoBytes [0] = data[ i++];
			twoBytes [1] = data[ i++];
	        int startPc = indexFromBytes(twoBytes);
//	        System.out.tln("StartPC " + startPc);
			twoBytes [0] = data[ i++];
			twoBytes [1] = data[ i++];
	        int length = indexFromBytes(twoBytes);
//	        System.out.println("Length " + length);
			twoBytes [0] = data[ i++];
			twoBytes [1] = data[ i++];
	        int nameIndex = indexFromBytes(twoBytes);
//	        System.out.println("Name idx:  " + nameIndex + " : " + pool[nameIndex]);
			twoBytes [0] = data[ i++];
			twoBytes [1] = data[ i++];
	        int descriptorIndex = indexFromBytes(twoBytes);
//	        System.out.println("Descriptor idx:  " + descriptorIndex );
			twoBytes [0] = data[ i++];
			twoBytes [1] = data[ i++];
	        int index = indexFromBytes(twoBytes);
	        indicies[j] = index;
//       System.out.println("Index " + index + " ==? " + j );
			
			// Index does NOT necessarily match 'j'.
        	//some var must be a two-word type ( double or long ), which takes two 'index' entries.

	        if(localVarNames[j] == null)
	        {
	        	localVarNames[j] = pool[nameIndex].toString();
	        	locals[j] = pool[nameIndex];
	        }
        } 
	}
	/**
	 * Write the bytes to the output stream.
	 * @param dos The DataOutputStream upon which this is writing
	 * @param pool The constant pool in which to index.
	 */
	public void write(DataOutputStream dos, ConstantPoolInfo pool[]) throws IOException, Exception
	{
		dos.writeShort(ConstantPoolInfo.indexOf(name, pool));
		dos.writeInt(data.length);
		
	    int len = data.length;
		byte [] twoBytes = new byte [2];
		int i = 0;
		twoBytes [0] = data[ i++];
		twoBytes [1] = data[ i++];
		dos.write(twoBytes);
        int localVarCount = indexFromBytes(twoBytes);
        for(int j = 0; j < localVarCount; ++j)
        {
			twoBytes [0] = data[ i++];
			twoBytes [1] = data[ i++];
			dos.write(twoBytes);
	        int startPc = indexFromBytes(twoBytes);
//	        System.out.println("StartPC " + startPc);
			twoBytes [0] = data[ i++];
			dos.writeByte(twoBytes [0]);
			twoBytes [1] = data[ i++];
			dos.writeByte(twoBytes [1]);
	        int length = indexFromBytes(twoBytes);
	        
//	        System.out.println("Length " + length);
			twoBytes [0] = data[ i++];
			twoBytes [1] = data[ i++];
	        int nameIndex = indexFromBytes(twoBytes);
	        if(locals == null || locals.length ==0)
	        {
				dos.writeByte(twoBytes [0]);
				dos.writeByte(twoBytes [1]);
	        }
	        else
	        {
	        	short idx = locals[j].indexOf(locals[j], pool);
	        	twoBytes = bytesFromIndex(idx);
				dos.writeByte(twoBytes [0]);
				dos.writeByte(twoBytes [1]);
	        }

	        
//	        System.out.println("Name idx:  " + nameIndex + " : " + pool[nameIndex]);
			twoBytes [0] = data[ i++];
			dos.writeByte(twoBytes [0]);
			twoBytes [1] = data[ i++];
			dos.writeByte(twoBytes [1]);
	        int descriptorIndex = indexFromBytes(twoBytes);
//	        System.out.println("Descriptor idx:  " + descriptorIndex );

			twoBytes [0] = data[ i++];
			dos.writeByte(twoBytes [0]);
			twoBytes [1] = data[ i++];
			dos.writeByte(twoBytes [1]);
		}

//		dos.write(data, 0, data.length);
	}
	/**
	 */
	protected void fixUpConstants(ClassFile target, ConstantPoolInfo [] originalPool) throws Exception
	{
		super.fixUpConstants(target, originalPool);

		if(locals != null)
		{
			for(int i = 0; i < locals .length; ++i)
			{
				locals [i] = target.recursiveAdd(locals [i]);
			} 
		}
    }
}