package com.objectwave.classFile;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

/**
* This class describes a Method as it is stored in the class file.
* The attribute associated with method is the code that actually implements
* the method. Since we don't need to manipulate the byte codes directly
* we leave them as an opaque chunk in the attributes[] array. References
* in the code are all references into the constant table so when we are
* modifing a class to use a different object we needn't get into the code
* level.
*
* @see		ClassFile
* @author Dave Hoag
*/
public class MethodInfo
{
	short 		accessModifiers;
	ConstantPoolInfo 	name;
	ConstantPoolInfo 	signature;
	AttributeInfo	attributes[]; //The actual implementation
	boolean displayAttributes = System.getProperty("ow.showAttributes") != null;

	boolean isAbstract()
	{
	    return ((accessModifiers & ClassFile.MOD_ABSTRACT) != 0);
	}
	/**
	* Read a method_info from the data stream.
	*/
	public boolean read(DataInputStream di, ConstantPoolInfo pool[]) throws IOException
	{
		int	count;

		accessModifiers = di.readShort();
		short idx = di.readShort();
		name = pool[idx];
		idx = di.readShort();
		signature = pool[idx];
		count = di.readShort();

		if (count != 0)
		{
		    attributes = new AttributeInfo[count];
		    for (int i = 0; i < count; i++)
			{
				attributes[i] = AttributeInfo.readAttributeInfo(di, pool); // "code"
				if (attributes[i] == null)
				{
					System.out.println("No code for method info!");
				    return false;
				}
		    }
		}
		return true;
	}
	/**
	 * Generic toString method, init method is unchanged.
	 */
	public String toString()
	{
		return toString((String)null, null);
	}
	/**
	 */

	/**
	* print out the method, much as you would see it in the source
	* file. The string ClassName is substituted for &LTinit&GT when
	* printing.
	*/
	public String toString(String className, ConstantPoolInfo pool[])
	{
		StringBuffer x = new StringBuffer();
		try
		{
			boolean isArray = false;
			String paramSig;
			String returnSig;
			int ndx = 0;
			StringBuffer parameterList = new StringBuffer();
			char	initialParameter = 'a';
			StringBuffer varName = new StringBuffer();


			String s = signature.strValue;
			paramSig = s.substring(s.indexOf('(')+1, s.indexOf(')')).trim();
			returnSig = s.substring(s.indexOf(')')+1);

			x.append(ClassFile.accessString(accessModifiers));
			boolean isInitializer = name.toString().startsWith("<init>");
			/* catch constructors */
			if ((className != null) && isInitializer)
			{
		    	parameterList.append(className);
			}
			else
			{
		    	parameterList.append(name.toString());
			}
			parameterList.append("(");
			int idx = 1;
			String aParamString = "";
			if ((paramSig.length() > 0) && paramSig.charAt(0) != 'V')
			{
		    	while (paramSig.length() > 0)
				{
					varName.setLength(0);
					if(ClassFile.accessString(accessModifiers).indexOf("static") > -1)
					{
						aParamString = getNextParameter(idx++ -1 , initialParameter);
					}
					else
					{
						aParamString = getNextParameter(idx++, initialParameter);
					}
					varName.append(aParamString );
					initialParameter++;
					String parameterString = ClassFile.typeString(paramSig, varName.toString());
					if(parameterString.startsWith("long")) idx++; //These take two spots in the var table.
					if(parameterString.startsWith("double")) idx++;
					parameterList.append( parameterString );
					
					paramSig = ClassFile.nextSig(paramSig);
					if (paramSig.length() > 0)
					{
			    		parameterList.append(", ");
			    	}
		    	}
			}
			parameterList.append(")");
			x.append(ClassFile.typeString(returnSig, parameterList.toString()));
			
			displayThrowsClause(x);

			if(isAbstract())
			{
				x.append(";");
			}
			else
			{
		    	if(displayAttributes && attributes != null && pool != null)
		    	{
		        	x.append("{\n");
		        	for(int i = 0; i < attributes.length; ++i)
		        	{
		            	x.append(attributes[i].toString(pool));
		            	x.append("\n");
		        	} 
		        	x.append("}");
		    	}
		    	else
		    	{
			    	x.append("{}");
				}
			}
			if(aParamString == null) System.out.println(x); 
			return (x.toString());
		}
		catch (ArrayIndexOutOfBoundsException ex)
		{
			System.out.println(this + " : " + ex);
			System.out.println(x);
		}
		return toString();
	}
	/**
	 * If the MethodInfo has exceptions declared, put them in the 'throws' clause.
	 * @param x The buffer on which to write the 'throws' clause.
	 */
	protected void displayThrowsClause(StringBuffer x)
	{
		if(attributes == null || attributes.length == 0)
		{
			return;
		}
		ExceptionAttributeInfo code = null;
		for(int i = 0; i < attributes.length; ++i)
		{
			if(attributes[i] instanceof ExceptionAttributeInfo)
			{
				code = (ExceptionAttributeInfo) attributes[i];
				break;
			}
		} 
		if(code == null) return;
		ConstantPoolInfo [] exceptions = code.getExceptionList();
		if(exceptions.length != 0)
		{
			x.append(" throws " );
			for(int i = 0; i < exceptions.length; ++i)
			{
				String className = exceptions[i].arg1.toString();
				x.append(formatName(className));
				if(i < exceptions.length - 1)
				{
					x.append(", ");
				}
			} 
		}
	}
	/**
	 * Strip the '/' characters and replace them with '.'.
	 * @param s The string to convert.
	 */
	protected String formatName(String s)
	{
	    StringBuffer x;
	    x = new StringBuffer();
	    for (int j = 0; j < s.length(); j++)
		{
	        if (s.charAt(j) == '/')
	    	    x.append('.');
	        else
	    	    x.append(s.charAt(j));
	    }
	    return x.toString();
    }
    /**
     * Populate the Vector 'result' with all of the methods that this method invokes.
     */
    public void addCalledMethods(java.util.Vector result, ConstantPoolInfo  pool[])
    {
    	CodeAttributeInfo info = getCodeAttributeInfo();
    	if(info == null) return;
    	info.addCalledMethods(result, pool);
    }
    /**
     * A null value as a result means that the code could not be located. Very odd.
     *
     */
    public CodeAttributeInfo getCodeAttributeInfo()
    {
		CodeAttributeInfo code = null;
		if(attributes != null)
		{
			for(int i = 0; i < attributes.length; ++i)
			{
				if(attributes[i] instanceof CodeAttributeInfo)
				{
					code = (CodeAttributeInfo) attributes[i];
					break;
				}
			} 
		}
		return code;
    }
	/**
	 * Attempt to determine the 'string' value that was used when writing the code.
	 * This is stored in the local variable table, but it is not required to be there.
	 * @param idx The index of the parameter starting at 1
	 * @param c The current random character to use as the parameter.
	 */
	public String getNextParameter(int idx, char c)
	{
		if(attributes == null || attributes.length == 0)
		{
			return String.valueOf(c);
		}
		CodeAttributeInfo code = getCodeAttributeInfo();
		if(code == null) return String.valueOf(c);
		String result = code.getLocalVar(idx );
		if(result == null || result.equals("null") || result.equals("") )
		{
			return String.valueOf(c);
		}
		else
		{
			return result;
		}
	}
	/**
	* Write out a method_info, do constant table fixups on the write.
	*/
	public void write(DataOutputStream dos, ConstantPoolInfo pool[]) throws IOException, Exception
	{
		dos.writeShort(accessModifiers);
		dos.writeShort(ConstantPoolInfo.indexOf(name, pool));
		dos.writeShort(ConstantPoolInfo.indexOf(signature, pool));
		if (attributes == null)
		{
		    dos.writeShort(0);
		}
		else
		{
		    dos.writeShort(attributes.length);
		    for (int i = 0; i < attributes.length; i++)
		    {
				attributes[i].write(dos, pool);
			}
		}
	}
	/**
	 */
	protected void fixUpConstants(ClassFile target, ConstantPoolInfo [] originalPool) throws Exception
	{
		name = target.recursiveAdd(name);
		signature = target.recursiveAdd(signature);
		if (attributes != null)
		{
		    for (int i = 0; i < attributes.length; i++)
		    {
				attributes[i].fixUpConstants(target, originalPool);
			}
		}
	}
}
