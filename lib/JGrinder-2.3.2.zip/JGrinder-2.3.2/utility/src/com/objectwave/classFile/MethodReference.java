package com.objectwave.classFile;

import java.io.DataInputStream;
import java.io.IOException;
/**
 * A ConstantPoolItem that is known to be a MethodReference.
 * @author Dave Hoag
 * @version 1.0
 */
public class MethodReference extends ConstantPoolInfo
{
	/**
	 */
	public MethodReference()
	{
		type = METHODREF;
	}
	/**
	*/
	public boolean read(DataInputStream dis, int type) throws IOException
	{
		name = "Method Reference";
		index1 = dis.readShort(); //The className
		index2 = dis.readShort(); //The Name and Type of method.
		return true;
	}
	/**
	 */
	public String toString()
	{
		String methodName = getMethodName();
		if(methodName.indexOf("(") == 0 ) return "new " + getClassName() + methodName;
		return getClassName() + '.' + methodName;
	}
	/**
	 */
	public String getClassName()
	{
		ConstantPoolInfo classRef = arg1;
		return classRef.arg1.toString().replace('/', '.');
	}
	/**
	 */
	public String getMethodName()
	{
		ConstantPoolInfo nameAndType = arg2;
		String result = nameAndType.arg1.toString();
		if(result.equals("<init>")) result = "";
		String parameterString = nameAndType.arg2.strValue;
		parameterString = parameterString.replace('/', '.');
		
		result += parameterString;
		return result;
	}
}