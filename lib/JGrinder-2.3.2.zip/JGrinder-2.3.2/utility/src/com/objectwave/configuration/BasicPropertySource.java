/* Copyright (C) 2001 David Hoag
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * For a full copy of the license see:
 * http://www.opensource.org/licenses/lgpl-license.html
 */
package com.objectwave.configuration;
import com.objectwave.exception.ConfigurationException;
import com.objectwave.logging.MessageLog;
/**
 *  Common behavior that should help all PropertySource concrete classes.
 *
 * @author  David Hoag
 * @version  $Id: BasicPropertySource.java,v 2.3 2002/02/28 17:03:44 dave_hoag Exp $
 */
public abstract class BasicPropertySource implements PropertySource
{
	protected ConfigurationService configurationService;
	protected String name;
	/**
	 *  Constructor for the BasicPropertySource object
	 */
	public BasicPropertySource() { }
	/**
	 *  Get the default category id that would be generated for this object.
	 *
	 * @return  A category id as defined by the specific configuration service
	 */
	public String getCategoryId()
	{
		return getConfigurationService().getCategoryId(this);
	}
	/**
	 *  A convience method. You may not want to deal with configuration exceptions.
	 *  In which case, you'll certainly want the error logged.
	 *
	 * @return  The configObject value
	 */
	public Object getConfigObject()
	{
		try
		{
			return getConfigurationInstance();
		}
		catch(ConfigurationException ex)
		{
			MessageLog.error(this, "Failed to get the config object. Returning a null object.", ex);
		}
		return null;
	}
	/**
	 *  The result of this method will be cast the appropriate type by the concrete
	 *  subclass implementations.
	 *
	 * @param  category Get the configuration instance that is specific to this
	 *      class and the specified category.
	 * @return  The configurationInstance value
	 * @exception  ConfigurationException
	 */
	public Object getConfigurationInstance(final String category) throws ConfigurationException
	{
		ConfigurationService service = getConfigurationService();
		Object result = service.getPropertyHolder(this, category);
		return result;
	}
	/**
	 *  The result of this method will be cast the appropriate type by the concrete
	 *  subclass implementations.
	 *
	 * @return  The configurationInstance value
	 * @exception  ConfigurationException
	 */
	public Object getConfigurationInstance() throws ConfigurationException
	{
		Object result = getConfigurationService().getPropertyHolder(this);
		return result;
	}
	/**
	 *  Either get the default service, or the one overridden in my instance var.
	 *
	 * @return  The configurationService value
	 */
	protected ConfigurationService getConfigurationService()
	{
		ConfigurationService service = configurationService;
		if(service == null)
		{
			//Do NOT cache the result of the factory call.
			service = ConfigurationServiceFactory.getConfigurationService(this);
		}
		return service;
	}
	/**
	 *  A single property source may be used to managed a list several instances of
	 *  property detail. Each instance is a 'named' instance. When a detail is
	 *  being located, the name of the desired instance will be requested.
	 *
	 * @return  String null If your source needs to manage multiple detail objects,
	 *      you'll need to provide a name.
	 */
	public String getName()
	{
		return name;
	}
	/**
	 * Support named instances. 
	 * @param nameValue null is legal value
	 */
	public void setName( String nameValue )
	{
		name = nameValue;
	}
	/**
	 *  Set this value to force this property source to use the specified
	 *  configuration service, otherwise use the default configuration service.
	 *  This is NOT required to be set
	 *
	 * @param  config The new ConfigurationService value
	 */
	public void setConfigurationService(ConfigurationService config)
	{
		configurationService = config;
	}
}
