/* Copyright (C) 2001 David Hoag
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * For a full copy of the license see:
 * http://www.opensource.org/licenses/lgpl-license.html
 */
package com.objectwave.configuration;
import com.objectwave.exception.ConfigurationException;
/**
 * The abstract set of features provided by the configuration service. It's pretty
 * much one way for now.
 *
 * @author  David Hoag
 * @version  $Id: ConfigurationService.java,v 2.1 2002/02/28 04:19:56 dave_hoag Exp $
 */
public interface ConfigurationService
{
	/**
	 *  Gets the PropertyHolder attribute of the ConfigurationService object
	 *
	 * @param  context
	 * @return  The actual object holding the configuration properties
	 * @exception  ConfigurationException
	 */
	public Object getPropertyHolder(PropertySource context) throws ConfigurationException;
	/**
	 *  Gets the PropertyHolder attribute of the ConfigurationService object
	 *
	 * @param  context
	 * @param  customCategory
	 * @return  The actual object holding the configuration properties
	 * @exception  ConfigurationException
	 */
	public Object getPropertyHolder(PropertySource context, String customCategory) throws ConfigurationException;
	/**
	 *  Gets the CategoryId attribute of the ConfigurationService object
	 *
	 * @param  context
	 * @return  A string identifier relating to the provided context and the
	 *      selected configuration service
	 */
	public String getCategoryId(PropertySource context);
}
