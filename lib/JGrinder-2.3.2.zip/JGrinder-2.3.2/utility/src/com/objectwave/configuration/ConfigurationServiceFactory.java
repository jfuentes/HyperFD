package com.objectwave.configuration;
/**
 *  Usage of these classes are hidden within a finder object created for your
 *  properties. You begin by creating a PropertySource ( easily done by
 *  extending BasicPropertySource ). A property source will know how to locate
 *  property detail. A property detail is a 'struct' that will hold the raw
 *  property values for your application
 *
 * @author  dhoag
 * @version  $Id: ConfigurationServiceFactory.java,v 2.0 2001/06/11 15:46:53 dave_hoag Exp $
 */
public class ConfigurationServiceFactory
{
	protected static ConfigurationService defaultConfigurationService;
	/**
	 *  Constructor for the ConfigurationServiceFactory object
	 */
	public ConfigurationServiceFactory()
	{
	}
	/**
	 *  Sets the DefaultConfigurationService attribute of the
	 *  ConfigurationServiceFactory class
	 *
	 * @param  service The new DefaultConfigurationService value
	 */
	public static void setDefaultConfigurationService(final ConfigurationService service)
	{
		defaultConfigurationService = service;
	}
	/**
	 *  Gets the ConfigurationService that is appropriate for the provided context.
	 *
	 * @param  context
	 * @return  The ConfigurationService value
	 */
	public static ConfigurationService getConfigurationService(final Object context)
	{
		if(defaultConfigurationService == null)
		{
			initConfigService();
		}
		return defaultConfigurationService;
	}
	/**
	 *  Create a new instance of DefaultConfigurationService if one does not
	 *  already exist.
	 */
	public static synchronized void initConfigService()
	{
		if(defaultConfigurationService == null)
		{
			defaultConfigurationService = new DefaultConfigurationService();
		}
	}
}
