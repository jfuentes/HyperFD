package com.objectwave.configuration;
import java.util.Properties;
/**
 *  Different ways to get a Properties object.
 *
 * @author  dhoag
 * @version  $Id: CreationStrategy.java,v 2.0 2001/06/11 15:46:53 dave_hoag Exp $
 */
public interface CreationStrategy
{
	/**
	 *  Gets the OrCreateProperties attribute of the CreationStrategy object
	 *
	 * @param  categoryId
	 * @param  context
	 * @return  The OrCreateProperties value
	 */
	public Properties getOrCreateProperties(final String categoryId, final Object context);
}
