/*
 *  Copyright (C) 2001 David Hoag
 *  ObjectWave Corporation
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *  For a full copy of the license see:
 *  http://www.opensource.org/licenses/lgpl-license.html
 */
package com.objectwave.configuration;
import com.objectwave.exception.ConfigurationException;
import com.objectwave.exception.ExceptionBuilder;
import com.objectwave.exception.NotFoundException;
import com.objectwave.logging.MessageLog;
import com.objectwave.utility.ReflectiveHelper;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.util.Properties;
/**
 *  Set the values of the property object from the properties provided by the
 *  property factory. By default it uses System.properties for configuration
 *  but this could be overridden by other configuration services. <br />
 *  The rules for finding values from the properties object
 *  is documented in the method definition of findValueToSet.
 *
 * @author  dhoag
 * @version  $Id: DefaultConfigurationService.java,v 2.4 2002/02/28 04:19:56 dave_hoag Exp $
 * @see  #findValueToSet
 * @see  com.objectwave.configuration.DefaultCreationStrategy
 */
public class DefaultConfigurationService implements ConfigurationService
{
	protected ReflectiveHelper reflectiveHelper;
	protected PropertyObjects propertyObjects;
	/**
	 *  Constructor for the DefaultConfigurationService object
	 */
	public DefaultConfigurationService()
	{
		initialize();
	}
	/**
	 *  Populate the object with the values found in the property object provided
	 *  by the PropertyFactory.
	 *
	 * @param  categoryId String a '.' delimited path. Like a package name.
	 * @param  obj The PropertyDetail object that is being populated
	 * @exception  InvocationTargetException
	 * @exception  IllegalAccessException
	 */
	public void setValues(final String categoryId, final Object obj) throws InvocationTargetException, IllegalAccessException
	{
		Properties props = PropertyFactory.getInstance().getOrCreateProperties(categoryId, obj);
		setValues(props, categoryId, obj);
	}
	/**
	 *  Set all non null values on the provided object.
	 *
	 * @param  props Properties The properties object from which we are looking for
	 *      values.
	 * @param  categoryId String a '.' delimited path. Like a package name.
	 * @param  obj The PropertyDetail object that is being populated
	 * @exception  InvocationTargetException
	 * @exception  IllegalAccessException
	 */
	public void setValues(final Properties props, final String categoryId, final Object obj) throws InvocationTargetException, IllegalAccessException
	{
		Class c = obj.getClass();
		//Find all of the fields.
		while(c != Object.class)
		{
			Field[] fields = obj.getClass().getDeclaredFields();
			for(int i = 0; i < fields.length; i++)
			{
				//Check for compiler generated fields, and ignore them
				if(!fields[i].getName().startsWith("class$"))
				{
					final String valueToSet = findValueToSet(fields[i].getName(), props, categoryId);
					if(MessageLog.isDebugEnabled(this))
					{
						MessageLog.debug(this, "Looking for a value to set with name " + fields[i].getName() + " category " + categoryId + " yielded : " + valueToSet);
					}
					if(valueToSet != null)
					{
						reflectiveHelper.setValue(fields[i], valueToSet, obj);
					}
				}
			}
			c = c.getSuperclass();
		}
	}
	/**
	 *  Create and return an instance of the PropertyDetail. The instance will have
	 *  its values set from the configuration service.
	 *
	 * @param  context We locate property holder by looking at the PropertySource
	 * @return  The actual object containing the property values, Property Detail.
	 * @exception  ConfigurationException
	 */
	public Object getPropertyHolder(final PropertySource context) throws ConfigurationException
	{
		final String categoryId = getCategoryId(context);
		return this.getPropertyHolder(context, categoryId);
	}
	/**
	 *  Create and return an instance of the PropertyDetail. The instance will have
	 *  its values set from the configuration service.
	 *
	 * @param  context The context we'll use to locate the property values and
	 *      PropertyDetail
	 * @param  categoryId A dot '.' separated list that will be used to lookup
	 *      values in a property object.
	 * @return  An object that will have the property values set - Property Detail
	 * @exception  ConfigurationException
	 * @see  #setValues( java.lang.String, java.lang.Object)
	 */
	public Object getPropertyHolder(final PropertySource context, final String categoryId) throws ConfigurationException
	{
		Object result;
		if(isCachingDetail())
		{
			//look for an exisiting instance at this context and category
			result = getOrCreateDetail(context, categoryId);
		}
		else
		{
			result = propertyObjects.createDetail(context, categoryId);
		}
		try
		{
			setValues(categoryId, result);
			return result;
		}
		catch(InvocationTargetException ex)
		{
			MessageLog.warn(this, "Failed to set values on configuration class : " + result.getClass(), ex.getTargetException());
			throw ExceptionBuilder.configuration("Failed to set values on configuration class : " + result.getClass());
		}
		catch(IllegalAccessException ex)
		{
			MessageLog.warn(this, "Failed to set values on configuration class : " + result.getClass(), ex);
			throw ExceptionBuilder.configuration("Failed to set values on configuration class : " + result.getClass());
		}
	}
	/**
	 *  Categories are identified by the full name of the property source object.
	 *
	 * @param  source
	 * @return  The CategoryId value
	 */
	public String getCategoryId(final PropertySource source)
	{
		if(source == null)
		{
			return "Default";
		}
		String namedInstance = source.getName();
		if( namedInstance != null )
		{
			return source.getClass().getName() + "#" + namedInstance;
		}
		else
		{
			return source.getClass().getName();
		}
		//PackageNames may have use in the future.
//		final String packageName = getPackageName(source.getClass().getName());
//		return packageName;
	}
	/**
	 * @return  The CachingDetail value
	 */
	protected boolean isCachingDetail()
	{
		return true;
	}
	/**
	 *  Either find the existing detail object, or create a new instance if an
	 *  exsting one is not found.
	 *
	 * @param  context The object that will want this property information.
	 * @param  categoryId The id that should uniquely identify the desired
	 *      properties.
	 * @return  An object that will have all of its declared fields set to values.
	 * @exception  ConfigurationException
	 */
	protected synchronized Object getOrCreateDetail(final PropertySource context, final String categoryId) throws ConfigurationException
	{
		Object result;
		if(propertyObjects.hasDetail(context, categoryId))
		{
			MessageLog.debug(this, "Retrieving existing property detail for context " + context + " category " + categoryId);
			try
			{
				result = propertyObjects.getDetail(context, categoryId);
			}
			catch(NotFoundException ex)
			{
				MessageLog.error(this, "The impossible has occured! Says we have, and then throws not found exception!", ex);
				return null;
			}
		}
		else
		{
			result = propertyObjects.createDetail(context, categoryId);
		}
		return result;
	}
	/**
	 *  Get the 'package name' from the class full name.
	 *
	 * @param  className
	 * @return  String of containing just the package name of the class.
	 */
	protected String getPackageName(final String className)
	{
		int idx = className.lastIndexOf('.');
		String result = null;
		if(idx > -1)
		{
			return className.substring(0, idx);
		}
		return result;
	}
	/**
	 *  In the following example assume an attributeName of 'host' and a categoryId
	 *  of 'com.objectwave.configuration.MyClass'. For each attribute the system
	 *  properties will be searched as follows:
	 *  com.objectwave.configuration.MyClass.host com.objectwave.configuration.host
	 *  com.objectwave.host com.host Default.host
	 *
	 * @param  name The attribute name.
	 * @param  props The potential source of the property value.
	 * @param  categoryId Likely the class name of the PropertySource instance
	 * @return  Find the property value that is to be set for a given property from
	 *      the props parameter.
	 */
	public String findValueToSet(final String name, final Properties props, final String categoryId)
	{
		if(categoryId == null)
		{
			return props.getProperty("Default." + name, null);
		}
		else
		{
			String possibleResult = props.getProperty(categoryId + '.' + name, null);
			if(possibleResult != null)
			{
				return possibleResult;
			}
			int lastIdx = categoryId.lastIndexOf('.');
			String shorterId = null;
			if(lastIdx > -1)
			{
				shorterId = categoryId.substring(0, lastIdx);
			}
			return findValueToSet(name, props, shorterId);
		}
	}
	/**
	 *  Instantiate the object that will allow me to call the setMethods.
	 */
	protected void initialize()
	{
		reflectiveHelper = new ReflectiveHelper();
		propertyObjects = PropertyObjects.getInstance();
	}
	/**
	 * @author  dhoag
	 */
	public static class Test extends com.objectwave.test.UnitTestBaseImpl implements PropertySource
	{
		String name = null;
		/**
		 */
		public int testValue = 2;
		/**
		 *  The main program for the Test class
		 *
		 * @param  args The command line arguments
		 */
		public static void main(String[] args)
		{
			com.objectwave.test.TestRunner.run(new Test(), args);
		}
		/**
		 *  Sets the TestValue attribute of the Test object
		 *
		 * @param  usedForTesting The new TestValue value
		 */
		public void setTestValue(int usedForTesting)
		{
			testValue = usedForTesting;
		}
		//used for testing. This class is both the property source and the property detail
		/**
		 *  Gets the ExpectedClass attribute of the Test object
		 *
		 * @return  The ExpectedClass value
		 */
		public Class getExpectedClass()
		{
			return this.getClass();
		}
		public String getName(){ return name; }
		/**
		 *  A unit test for JUnit
		 *
		 * @exception  Exception
		 */
		public void testGetPropertyHolder() throws Exception
		{
			DefaultConfigurationService def = new DefaultConfigurationService();
			Test propDetail = (Test) def.getPropertyHolder(this);
			testContext.assertEquals(2, propDetail.testValue);

			Properties props = new Properties();
			props.put(this.getClass().getName() + ".testValue", "12");
			System.getProperties().put(this.getClass().getName() + ".properties", props);

			propDetail = (Test) def.getPropertyHolder(this);
			testContext.assertEquals(12, propDetail.testValue);

			Test propDetail2 = (Test) def.getPropertyHolder(this);
			testContext.assertEquals("Instances should be identical", propDetail, propDetail2);
		}
		/**
		 *  A unit test for JUnit
		 *
		 * @exception  ConfigurationException
		 */
		public void testGetOrCreate() throws ConfigurationException
		{
			DefaultConfigurationService def = new DefaultConfigurationService();
			Test tst = (Test) def.getOrCreateDetail(this, "ow");
			Test tst2 = (Test) def.getOrCreateDetail(this, "ow");
			testContext.assertEquals("Instances should be identical!", tst, tst2);
		}
		/**
		 *  A unit test for JUnit
		 *
		 * @exception  Exception
		 */
		public void testSetValues() throws Exception
		{
			DefaultConfigurationService def = new DefaultConfigurationService();
			Properties props = new Properties();
			props.put("com.ow.tst.Pack.testValue", "12");
			System.getProperties().put("com.ow.tst.Pack.properties", props);

			def.setValues("com.ow.tst.Pack", this);
			testContext.assertEquals(12, testValue);
			testValue = 10;
			System.getProperties().remove("com.ow.tst.Pack.properties");
			def.setValues("com.ow.tst.Pack", this);
			testContext.assertEquals(10, testValue);
			System.setProperty("com.ow.tst.Pack.testValue", "12");
			def.setValues("com.ow.tst.Pack", this);
			testContext.assertEquals(12, testValue);
		}
		/**
		 *  A unit test for JUnit
		 */
		public void testGetCategoryId()
		{
			String cat = new DefaultConfigurationService().getCategoryId( this );
			testContext.assertEquals("com.objectwave.configuration.DefaultConfigurationService$Test", cat);
			name = "namedInstance";
			cat = new DefaultConfigurationService().getCategoryId( this );
			testContext.assertEquals("com.objectwave.configuration.DefaultConfigurationService$Test#namedInstance", cat);
		}
		/**
		 *  A unit test for JUnit
		 */
		public void testFindValueToSet()
		{
			DefaultConfigurationService def = new DefaultConfigurationService();
			Properties props = new Properties();
			props.put("com.ow.tst.Pack.my", "full");
			props.put("com.some", "some");
			props.put("Default.no", "No");
			String result = def.findValueToSet("my", props, "com.ow.tst.Pack");
			testContext.assertEquals("full", result);
			result = def.findValueToSet("some", props, "com.ow.tst.Pack");
			testContext.assertEquals("some", result);
			result = def.findValueToSet("no", props, "com.ow.tst.Pack");
			testContext.assertEquals("No", result);
			result = def.findValueToSet("notEntered", props, "com.ow.tst.Pack");
			testContext.assertTrue("There should be no property for notEntered!", result == null);
		}
	}
}
