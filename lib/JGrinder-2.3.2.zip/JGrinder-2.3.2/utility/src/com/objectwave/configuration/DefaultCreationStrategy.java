/*
 *  Copyright (C) 2001 David Hoag
 *  ObjectWave Corporation
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *  For a full copy of the license see:
 *  http://www.opensource.org/licenses/lgpl-license.html
 */
package com.objectwave.configuration;

import java.util.Properties;
/**
 *  This class will first look for a system property called <categoryId>
 *  .properties. If a Properties object exist at this key, the values will be
 *  used from that object. If no Properites object is found, the
 *  System.properties will be explored for values. <br>
 *
 * @author  dhoag
 * @version  $Id: DefaultCreationStrategy.java,v 2.1 2001/11/12 17:11:58 dave_hoag Exp $
 */
public class DefaultCreationStrategy implements CreationStrategy
{
	/**
	 *  Constructor for the DefaultCreationStrategy object
	 */
	public DefaultCreationStrategy()
	{
	}
	/**
	 * Get a properties object found at categoryId.properties. If not found
	 * then return the System.properties
	 *
	 * @param  categoryId
	 * @param  context
	 * @return  Either a registered properties object in System.properties, or System.properties
	 */
	public Properties getOrCreateProperties(String categoryId, Object context)
	{
		Properties props = (Properties) System.getProperties().get(categoryId + ".properties");
		if(props == null)
		{
			props = System.getProperties();
		}
		return props;
	}
}
