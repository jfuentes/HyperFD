/* Copyright (C) 2001 David Hoag
 * ObjectWave Corporation
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * For a full copy of the license see:
 * http://www.opensource.org/licenses/lgpl-license.html
 */
package com.objectwave.configuration;
import java.util.Properties;
/**
 *  Locate and use the appropriate Properties source for values.
 *
 * @author  dhoag
 * @version  $Id: PropertyFactory.java,v 2.0 2001/06/11 15:46:53 dave_hoag Exp $
 */
public class PropertyFactory
{
	protected static PropertyFactory instance;
	/**
	 */
	public CreationStrategy creationStrategy;
	/**
	 *  Constructor for the PropertyFactory object
	 */
	public PropertyFactory()
	{
		initialize();
	}
	/**
	 *  Gets the Instance attribute of the PropertyFactory class
	 *
	 * @return  The Instance value
	 */
	public static PropertyFactory getInstance()
	{
		return instance;
	}
	/**
	 *  Sets the CreationStrategy attribute of the PropertyFactory object
	 *
	 * @param  strat The new CreationStrategy value
	 */
	public void setCreationStrategy(CreationStrategy strat)
	{
		creationStrategy = strat;
	}
	/**
	 * @param  context
	 * @param  categoryId
	 * @return  The OrCreateProperties value
	 */
	public Properties getOrCreateProperties(final String categoryId, final Object context)
	{
		return creationStrategy.getOrCreateProperties(categoryId, context);
	}
	/**
	 *  For now, this only sets the default creationStrategy
	 */
	public void initialize()
	{
		creationStrategy = new DefaultCreationStrategy();
	}

	static
	{
		instance = new PropertyFactory();
	}
}
