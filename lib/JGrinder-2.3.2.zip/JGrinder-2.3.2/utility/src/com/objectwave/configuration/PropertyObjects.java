/* Copyright (C) 2001 David Hoag
 * ObjectWave Corporation
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * For a full copy of the license see:
 * http://www.opensource.org/licenses/lgpl-license.html
 */
package com.objectwave.configuration;
import com.objectwave.exception.ConfigurationException;
import com.objectwave.exception.ExceptionBuilder;
import com.objectwave.exception.NotFoundException;
import com.objectwave.logging.MessageLog;
import java.util.ArrayList;
import java.util.HashMap;
/**
 *  Hold on to the list of property that we create.
 *
 * @author  dhoag
 * @version  $Id: PropertyObjects.java,v 2.2 2002/07/31 15:55:22 dave_hoag Exp $
 */
public class PropertyObjects
{
	static PropertyObjects defaultInstance;
	HashMap map;
	/**
	 *  Constructor for the PropertyObjects object
	 */
	public PropertyObjects()
	{
		initialize();
	}
	/**
	 *  Gets
	 *
	 * @return  The Instance value
	 */
	public static PropertyObjects getInstance()
	{
		return defaultInstance;
	}
	/**
	 *  Gets
	 *
	 * @param  context
	 * @param  categoryId
	 * @return  The Detail value
	 * @exception  NotFoundException
	 * @exception  ConfigurationException
	 */
	public synchronized Object getDetail(final PropertySource context, final String categoryId) throws NotFoundException, ConfigurationException
	{
		Class configurationClass = getConfigurationClass(context, categoryId);
		int idx = indexOfDetail(configurationClass, categoryId);
		if(idx < 0)
		{
			throw ExceptionBuilder.notFound("The detail does not exist for context " + context + " and category: " + categoryId);
		}
		ArrayList values = (ArrayList) map.get(configurationClass);
		return values.get(idx + 1);
	}
	/**
	 *  Gets the type to create for the specified categoryId
	 *
	 * @param  context
	 * @param  categoryId
	 * @return  The ConfigurationClass value
	 * @exception  ConfigurationException
	 */
	protected Class getConfigurationClass(final PropertySource context, final String categoryId) throws ConfigurationException
	{
		String commandLineSpecifiedClass = null;
		try
		{
			commandLineSpecifiedClass = System.getProperty(categoryId + ".configurationDetail");
		}
		catch(Exception ex)
		{
			MessageLog.debug(this, "Skipping command line override. Probably don't have access rights to system properties", ex);
		}
		//Get the hard coded configuration class
		Class configurationClass = context.getExpectedClass();
		if(commandLineSpecifiedClass != null)
		{
			try
			{
				configurationClass = Class.forName(commandLineSpecifiedClass);
			}
			catch(ClassNotFoundException ex)
			{
				MessageLog.warn(this, "Failed to locate configuration class : " + commandLineSpecifiedClass, ex);
				throw ExceptionBuilder.configuration("Failed to locate configuration class : " + commandLineSpecifiedClass);
			}
		}
		return configurationClass;
	}
	/**
	 * @param  context
	 * @param  categoryId
	 * @return
	 * @exception  ConfigurationException
	 */
	public boolean hasDetail(final PropertySource context, final String categoryId) throws ConfigurationException
	{
		Class configurationClass = getConfigurationClass(context, categoryId);
		int idx = indexOfDetail(configurationClass, categoryId);
		return idx > -1;
	}
	/**
	 */
	protected void initialize()
	{
		map = new HashMap();
	}
	/**
	 * @param  context
	 * @param  categoryId
	 * @return
	 * @exception  ConfigurationException
	 */
	protected Object createDetail(final PropertySource context, final String categoryId) throws ConfigurationException
	{
		final Class configurationClass = getConfigurationClass(context, categoryId);
		try
		{
			final Object result = configurationClass.newInstance();
			addDetail(configurationClass, categoryId, result);
			return result;
		}
		catch(InstantiationException ex)
		{
			MessageLog.warn(this, "Failed to load configuration class : " + configurationClass.getName(), ex);
			throw ExceptionBuilder.configuration("Failed to load configuration class : " + configurationClass.getName());
		}
		catch(IllegalAccessException ex)
		{
			MessageLog.warn(this, "Failed to load configuration class : " + configurationClass.getName(), ex);
			throw ExceptionBuilder.configuration("Failed to load configuration class : " + configurationClass.getName());
		}
	}
	/**
	 *  Allow configuration services to add detail objects that are not created
	 *  by this instance.
	 *
	 * @param  context The feature to be added to the Detail attribute
	 * @param  categoryId The feature to be added to the Detail attribute
	 * @param  propertyDetail The feature to be added to the Detail attribute
	 * @exception  ConfigurationException
	 */
	public synchronized void addDetail(final PropertySource context, final String categoryId, final Object propertyDetail) throws ConfigurationException
	{
		final Class configurationClass = getConfigurationClass(context, categoryId);
		addDetail(configurationClass, categoryId, propertyDetail);
	}
	/**
	 *  Add the propertyDetail parameter to some internal collection using the
	 *  context and categoryId as keys.
	 *
	 * @param  context Likely the class of the property object.
	 * @param  categoryId The category for which we are an instance.
	 * @param  propertyDetail The object to remember.
	 */
	protected synchronized void addDetail(final Class context, final String categoryId, final Object propertyDetail)
	{
		int idx = indexOfDetail(context, categoryId);
		ArrayList values = (ArrayList) map.get(context);
		if(values == null)
		{
			values = new ArrayList();
			map.put(context, values);
		}
		//increment by 2
		if(idx > -1)
		{
			values.set(idx + 1, propertyDetail);
		}
		else
		{
			//Not found in current list, must be a new entry
			values.add(categoryId);
			values.add(propertyDetail);
		}
	}
	/**
	 *  Return the index in the array list of the matching categoryId...if it
	 *  exits.
	 *
	 * @param  context
	 * @param  categoryId
	 * @return
	 */
	private int indexOfDetail(final Class context, final String categoryId)
	{
		ArrayList values = (ArrayList) map.get(context);
		if(values == null)
		{
			MessageLog.debug(this, "No values found for class context : " + context);
			return -1;
		}
		//increment by 2
		for(int i = 0; i < values.size(); i += 2)
		{
			String storedCategory = (String) values.get(i);
			if(storedCategory.equals(categoryId))
			{
				return i;
			}
		}
		MessageLog.debug(this, "No values found for category : " + categoryId);
		return -1;
	}
	/**
	 * @author  dhoag
	 * @version  $Id: PropertyObjects.java,v 2.2 2002/07/31 15:55:22 dave_hoag Exp $
	 */
	public static class Test extends com.objectwave.test.UnitTestBaseImpl implements PropertySource
	{
		/**
		 *  The main program for the Test class
		 *
		 * @param  args The command line arguments
		 */
		public static void main(String[] args)
		{
			com.objectwave.test.TestRunner.run(new Test(), args);
		}
		/**
		 *  Gets the ExpectedClass attribute of the Test object
		 *
		 * @return  The ExpectedClass value
		 */
		public Class getExpectedClass()
		{
			return this.getClass();
		}
		public String getName(){ return null; }
		/**
		 *  Most of the testing of getDetail is done elsewhere, just make sure it
		 *  won't blow up on a new PropertyObjects
		 *
		 * @exception  Exception
		 */
		public void testGetDetail() throws Exception
		{
			PropertyObjects tst = new PropertyObjects();
			try
			{
				tst.getDetail(this, "Anew Cat");
				testContext.assertTrue("Failed to generate not found exception", false);
			}
			catch(NotFoundException ex)
			{
				//Expected this exception
			}
		}
		/**
		 *  A unit test for JUnit
		 *
		 * @exception  Exception
		 */
		public void testAddDetail() throws Exception
		{
			PropertyObjects tst = new PropertyObjects();
			tst.addDetail(this.getClass(), "category", "MyDetail");
			String details = (String) tst.getDetail(this, "category");
			testContext.assertEquals("MyDetail", details);

			tst.addDetail(this.getClass(), "category2", "MyDetail2");
			details = (String) tst.getDetail(this, "category2");
			testContext.assertEquals("MyDetail2", details);

			details = (String) tst.getDetail(this, "category");
			testContext.assertEquals("MyDetail", details);
		}
		/**
		 * @exception  Exception
		 */
		public void testGetConfigClass() throws Exception
		{
			PropertyObjects tst = new PropertyObjects();
			System.setProperty("myConfig.configurationDetail", "java.lang.String");
			Class c = tst.getConfigurationClass(this, "myConfig");
			System.getProperties().remove("myConfig");
			testContext.assertTrue("Failed to get String instance!", c == String.class);
		}
		/**
		 * @exception  Exception
		 */
		public void testCreate() throws Exception
		{
			PropertyObjects tst = new PropertyObjects();
			tst.createDetail(this, "myCat");
			Test details = (Test) tst.getDetail(this, "myCat");
			Test details2 = (Test) tst.getDetail(this, "myCat");
			testContext.assertTrue("Failed to get the identical instance ", details == details2);
		}
	}

	static
	{
		defaultInstance = new PropertyObjects();
	}
}
