/* Copyright (C) 2001 David Hoag
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * For a full copy of the license see:
 * http://www.opensource.org/licenses/lgpl-license.html
 */
package com.objectwave.configuration;
/**
 *  The basic interface of the bridge between the user of properties, and the
 *  object that actually holds the property values.
 *
 * @author  David Hoag
 * @version  $Id: PropertySource.java,v 2.1 2002/02/28 04:19:56 dave_hoag Exp $
 */
public interface PropertySource
{
	/**
	 *  A property source is used by an application to get properties that may be
	 *  configured.
	 *
	 * @return  The expectedClass value
	 */
	public Class getExpectedClass();
	/**
	 *  A single property source may be used to managed a list several instances of
	 *  property detail. Each instance is a 'named' instance. When a detail is
	 *  being located, the name of the desired instance will be requested.
	 *
	 * @return  The name value
	 */
	public String getName();
}
