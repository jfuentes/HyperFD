package com.objectwave.configuration.bean;

import java.rmi.*;
import javax.ejb.*;
/**
 * For details on the Ejb supported configuration service, please see
 * com.objectwave.configuration.bean.SetupEjbConfigurationService.
 *
 * @author  dhoag
 * @version  $Id: ConfigurationService.java,v 2.1 2001/11/12 17:11:58 dave_hoag Exp $
 * @see  com.objectwave.configuration.bean.SetupEjbConfigurationService
 */
public interface ConfigurationService extends EJBObject
{
	/**
	 *  Gets the Property attribute of the ConfigurationService object
	 *
	 * @param  propName
	 * @param  defaultValue
	 * @return  The Property value
	 * @exception  RemoteException
	 */
	public java.lang.String getProperty(java.lang.String propName, java.lang.String defaultValue) throws RemoteException;
	/**
	 *  Gets the Property attribute of the ConfigurationService object
	 *
	 * @param  propName
	 * @return  The Property value
	 * @exception  RemoteException
	 */
	public java.lang.String getProperty(java.lang.String propName) throws RemoteException;
}
