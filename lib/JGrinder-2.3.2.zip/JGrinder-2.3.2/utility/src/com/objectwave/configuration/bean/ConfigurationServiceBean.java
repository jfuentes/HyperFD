package com.objectwave.configuration.bean;

import java.rmi.*;
import java.util.Properties;
import javax.ejb.*;
/**
 * @author  dhoag
 * @version  $Id: ConfigurationServiceBean.java,v 2.0 2001/06/11 15:46:53 dave_hoag Exp $
 */
public class ConfigurationServiceBean implements SessionBean
{
	protected Properties propLookup;
	private SessionContext sessionContext;
	/**
	 *  Sets the SessionContext attribute of the ConfigurationServiceBean object
	 *
	 * @param  context The new SessionContext value
	 */
	public void setSessionContext(SessionContext context)
	{
		sessionContext = context;
	}
	/**
	 *  Gets the Property attribute of the ConfigurationServiceBean object
	 *
	 * @param  propName
	 * @return  The Property value
	 */
	public String getProperty(final String propName)
	{
		return propLookup.getProperty(propName);
	}
	/**
	 *  Gets the Property attribute of the ConfigurationServiceBean object
	 *
	 * @param  propName
	 * @param  defaultValue
	 * @return  The Property value
	 */
	public String getProperty(final String propName, final String defaultValue)
	{
		return propLookup.getProperty(propName, defaultValue);
	}
	/**
	 */
	public void ejbCreate()
	{
		propLookup = new JndiPropertyLookup().getOrCreateProperties(null, null);
	}
	/**
	 */
	public void ejbRemove()
	{
	}
	/**
	 */
	public void ejbActivate()
	{
	}
	/**
	 */
	public void ejbPassivate()
	{
	}
}
