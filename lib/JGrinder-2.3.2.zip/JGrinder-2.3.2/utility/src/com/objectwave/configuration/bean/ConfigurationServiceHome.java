package com.objectwave.configuration.bean;

import java.rmi.*;
import javax.ejb.*;

/**
 * @author  dhoag
 * @version  $Id: ConfigurationServiceHome.java,v 2.0 2001/06/11 15:46:53 dave_hoag Exp $
 */
public interface ConfigurationServiceHome extends EJBHome
{
	/**
	 * @return
	 * @exception  RemoteException
	 * @exception  CreateException
	 */
	public ConfigurationService create() throws RemoteException, CreateException;
}
