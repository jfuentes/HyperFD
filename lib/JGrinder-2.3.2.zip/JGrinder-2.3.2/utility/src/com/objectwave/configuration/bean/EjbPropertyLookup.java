/*
 *  Copyright (C) 2001 David Hoag
 *  ObjectWave Corporation
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *  For a full copy of the license see:
 *  http://www.opensource.org/licenses/lgpl-license.html
 */
package com.objectwave.configuration.bean;
import com.objectwave.configuration.CreationStrategy;
import com.objectwave.logging.MessageLog;
import java.rmi.RemoteException;
import java.util.Properties;
import java.util.Properties;
import javax.ejb.CreateException;
import javax.naming.*;
import javax.rmi.PortableRemoteObject;
/**
 *  Attempt to find configuration property values from a ConfigurationService
 *  enterprise bean. By default it will look for a bean called
 *  "/ejb/ConfigurationService", but this can be changed by setting an
 *  enviroment entry in a deployment descriptor. The environment property is
 *  "ConfigurationServiceName". The value found (if any) will be the complete
 *  JNDI name used to find the configuration service.
 *
 * @author  dhoag
 * @version  $Id: EjbPropertyLookup.java,v 2.1 2001/12/21 20:27:54 dave_hoag Exp $
 */
public class EjbPropertyLookup implements CreationStrategy
{
	/**
	 *  Access ejb locally java:comp/env/ejb/ConfigurationService
	 */
	public final static String ejbConfigServiceJndiName = "/ejb/ConfigurationService";
	/**
	 */
	public final static String ejbConfigServicePropertyName = "ConfigurationServiceName";
	ConfigurationServiceHome ejbConfigServiceHome;
	/**
	 *  Constructor for the EjbPropertyLookup object
	 */
	public EjbPropertyLookup()
	{
	}
	/**
	 * Attempt to locate the central Enterprise ConfigurationService home.
	 *
	 * @return  The ConfigurationServiceHome value
	 * @exception  NamingException
	 */
	public ConfigurationServiceHome getConfigurationServiceHome() throws NamingException
	{
		if(ejbConfigServiceHome == null)
		{
			initServiceHome();
		}
		return ejbConfigServiceHome;
	}
	/**
	 *  Return an new 'Property' object that will query the ConfigurationService
	 *  enterprise bean for property values.
	 *
	 * @param  categoryId
	 * @param  context
	 * @return  The OrCreateProperties value
	 */
	public Properties getOrCreateProperties(String categoryId, Object context)
	{
		return new FakeProperty();
	}
	/**
	 *  Gets the Context attribute of the FakeProperty object
	 *
	 * @return  The Context value
	 * @exception  NamingException
	 */
	public Context getContext() throws NamingException
	{
		return new InitialContext();
	}
	/**
	 *  Use JNDI to locate the ConfigurationService enterprise bean. The JNDI
	 *  name is either configured by the ConfigurationServiceName env-entry
	 *  in the deployment descriptor, or a default value.
	 *
	 * @exception  NamingException
	 */
	public synchronized void initServiceHome() throws NamingException
	{
		if(ejbConfigServiceHome == null)
		{
			Object lookupName = null;
			try
			{
				lookupName = getContext().lookup("java:comp/env/" + ejbConfigServicePropertyName);
				MessageLog.debug(this, "Using configured name '" + lookupName + "' to locate configuration service ");
			}
			catch(javax.naming.NameNotFoundException ex)
			{
			}

			if(lookupName == null)
			{
				lookupName = ejbConfigServiceJndiName;
				MessageLog.debug(this, "Using default name '" + lookupName + "' to locate configuration service ");
			}

			Object ref = getContext().lookup(lookupName.toString());
			ejbConfigServiceHome = (ConfigurationServiceHome) PortableRemoteObject.narrow(ref, ConfigurationServiceHome.class);
			MessageLog.info(this, "Using centralized ConfigurationService session bean for configuration information!");
		}
	}
	/**
	 * An object that pretends to be a Properties object. When the getProperty
	 * methods are invoked, a request is delegated to the ConfigurationService
	 * enterprise bean.
	 *
	 * @author  dhoag
	 * @version  $Id: EjbPropertyLookup.java,v 2.1 2001/12/21 20:27:54 dave_hoag Exp $
	 */
	public class FakeProperty extends Properties
	{
		/**
		 *  Gets the Property attribute of the FakeProperty object
		 *
		 * @param  propName
		 * @return  The Property value
		 */
		public String getProperty(final String propName)
		{
			return getProperty(propName, true);
		}
		/**
		 *  Gets the Property attribute of the FakeProperty object
		 *
		 * @param  propName
		 * @param  defaultValue
		 * @return  The Property value
		 */
		public String getProperty(final String propName, final String defaultValue)
		{
			String result = getProperty(propName, false);
			if(result == null)
			{
				result = defaultValue;
			}
			return result;
		}
		/**
		 *  Gets the Property attribute of the FakeProperty object
		 *
		 * @param  propName
		 * @param  rethrowException
		 * @return  The Property value
		 */
		protected String getProperty(final String propName, boolean rethrowException)
		{
			try
			{

				ConfigurationService service = getConfigurationServiceHome().create();

				String result;
				if(rethrowException)
				{
					result = service.getProperty(propName);
				}
				else
				{
					result = service.getProperty(propName, null);
				}
				return result;
			}
			catch(NamingException ne)
			{
				MessageLog.debug(this, "Exception locating the ConfigSvc Session Bean ", ne);
				if(rethrowException)
				{
					throw new RuntimeException("Specified property " + propName + " is not found: " + ne);
				}
			}
			catch(CreateException ex)
			{
				MessageLog.debug(this, "Exception in the creation and lookup of the property " + propName, ex);
				if(rethrowException)
				{
					throw new RuntimeException("Specified property " + propName + " is not found: " + ex);
				}
			}
			catch(RemoteException ex)
			{
				MessageLog.debug(this, "Exception in the creation and lookup of the property " + propName, ex);
				if(rethrowException)
				{
					throw new RuntimeException("Specified property " + propName + " is not found: " + ex);
				}
			}
			return null;
		}
	}
}
