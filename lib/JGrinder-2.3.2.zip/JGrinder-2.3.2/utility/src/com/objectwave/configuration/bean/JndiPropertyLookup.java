package com.objectwave.configuration.bean;
import com.objectwave.configuration.CreationStrategy;
import com.objectwave.logging.MessageLog;

import java.util.Properties;
import java.util.Properties;
import javax.naming.*;
/**
 * @author  dhoag
 * @version  $Id: JndiPropertyLookup.java,v 2.0 2001/06/11 15:46:53 dave_hoag Exp $
 */
public class JndiPropertyLookup implements CreationStrategy
{
	/**
	 *  Constructor for the JndiPropertyLookup object
	 */
	public JndiPropertyLookup()
	{
	}
	/**
	 *  Gets the OrCreateProperties attribute of the JndiPropertyLookup object
	 *
	 * @param  categoryId
	 * @param  context
	 * @return  The OrCreateProperties value
	 */
	public Properties getOrCreateProperties(String categoryId, Object context)
	{
		return new FakeProperty();
	}
	/**
	 * @author  dhoag
	 * @version  $Id: JndiPropertyLookup.java,v 2.0 2001/06/11 15:46:53 dave_hoag Exp $
	 */
	public class FakeProperty extends Properties
	{
		/**
		 *  Gets the Context attribute of the FakeProperty object
		 *
		 * @return  The Context value
		 * @exception  NamingException
		 */
		public Context getContext() throws NamingException
		{
			return new InitialContext();
		}
		/**
		 *  Gets the Property attribute of the FakeProperty object
		 *
		 * @param  propName
		 * @return  The Property value
		 */
		public String getProperty(final String propName)
		{
			try
			{
				Object value = getContext().lookup("java:comp/env/" + propName);
				return String.valueOf(value);
			}
			catch(NamingException ne)
			{
				MessageLog.debug(this, "Exception looking up EJB property " + propName, ne);
				throw new RuntimeException("Specified property " + propName + " is not found: " + ne);
			}
		}
		/**
		 *  Gets the Property attribute of the FakeProperty object
		 *
		 * @param  propName
		 * @param  defaultValue
		 * @return  The Property value
		 */
		public String getProperty(final String propName, final String defaultValue)
		{
			try
			{
				Object value = getContext().lookup("java:comp/env/" + propName);
				return String.valueOf(value);
			}
			catch(NamingException ne)
			{
				MessageLog.debug(this, "Failed to locate EJB property java:comp/env/" + propName + " returning default of " + defaultValue);
			}
			return defaultValue;
		}
	}
}
