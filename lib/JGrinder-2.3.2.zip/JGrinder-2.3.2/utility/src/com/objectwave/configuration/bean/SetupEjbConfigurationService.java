/*
 *  Copyright (C) 2001 David Hoag
 *  ObjectWave Corporation
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *  For a full copy of the license see:
 *  http://www.opensource.org/licenses/lgpl-license.html
 */
package com.objectwave.configuration.bean;
import com.objectwave.configuration.ConfigurationService;
import com.objectwave.configuration.DefaultConfigurationService;
import com.objectwave.configuration.PropertyFactory;

import com.objectwave.configuration.PropertySource;
import com.objectwave.exception.ConfigurationException;
import com.objectwave.exception.ExceptionBuilder;
import com.objectwave.logging.MessageLog;
import java.lang.reflect.InvocationTargetException;
import java.util.Properties;
import javax.naming.*;
/**
 *  Simply creating an instance of this class will cause the default
 *  configuration service to use JDNI lookup to find property values. There are
 *  two possible ways JNDI will be used to locate the values. The default
 *  mechanism will pull properties from the java:comp JNDI location for
 *  properties defined in the bean's deployment descriptor. <p />
 *
 *  You can use a 'central' configuration service by deploying the
 *  ConfigurationService session bean found in this package. If deployed, all
 *  property request will be delegated to this session bean. The deployment
 *  descriptor of that session bean will be the source of property values.<p />
 *
 *  For details about resolving the property to a value, see the documentation
 *  for the com.objectwave.configuration.DefaultConfigurationService.
 *
 * @author  dhoag
 * @version  $Id: SetupEjbConfigurationService.java,v 2.1 2001/11/12 17:11:58 dave_hoag Exp $
 */
public class SetupEjbConfigurationService
{
	static boolean initialized = false;
	/**
	 *  Constructor for the EjbConfigurationService object
	 */
	public SetupEjbConfigurationService()
	{
		if(!initialized)
		{
			initialize();
		}
	}
	/**
	 * Determine if a session bean has been deployed that will contain all of
	 * the configuration information.
	 *
	 * @return  The ConfigSvcSessionBeanExists value
	 */
	protected boolean isConfigSvcSessionBeanExists()
	{
		try
		{
			if(new EjbPropertyLookup().getConfigurationServiceHome() != null)
			{
				return true;
			}
		}
		catch(NamingException ex)
		{
			MessageLog.debug(this, "Not using ConfigSvcSession bean, home is not reachable", ex);
		}
		return false;
	}
	/**
	 *  Modify the PropertyFactory CreationFactory based upon our investigation.
	 *  If a ConfigServiceSessionBean exists, use that as the source of the
	 *  property values, otherwise, use each Ejb's own deployment descriptor.
	 */
	public synchronized void initialize()
	{
		if(isConfigSvcSessionBeanExists())
		{
			PropertyFactory.getInstance().setCreationStrategy(new EjbPropertyLookup());
		}
		else
		{
			PropertyFactory.getInstance().setCreationStrategy(new JndiPropertyLookup());
		}
		initialized = true;
	}
}
