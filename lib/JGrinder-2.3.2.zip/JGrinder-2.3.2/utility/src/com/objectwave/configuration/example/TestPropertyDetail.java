/* Copyright (C) 2001 David Hoag
 * ObjectWave Corporation
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * For a full copy of the license see:
 * http://www.opensource.org/licenses/lgpl-license.html
 */
package com.objectwave.configuration.example;

/**
 * @author  dhoag
 * @version  $Id: TestPropertyDetail.java,v 2.0 2001/06/11 15:46:53 dave_hoag Exp $
 */
public class TestPropertyDetail
{
	/**
	 */
	public int testInt;
	/**
	 */
	public boolean testBoolean;
	/**
	 */
	public String testString;
	/**
	 *  Constructor for the TestPropertyDetail object
	 */
	public TestPropertyDetail()
	{
	}
	/**
	 *  Sets the TestString attribute of the TestPropertyDetail object
	 *
	 * @param  tes The new TestString value
	 */
	public void setTestString(String tes)
	{
		testString = tes;
	}
	/**
	 *  Sets the TestBoolean attribute of the TestPropertyDetail object
	 *
	 * @param  b The new TestBoolean value
	 */
	public void setTestBoolean(boolean b)
	{
		testBoolean = b;
	}
	/**
	 *  Sets the TestInt attribute of the TestPropertyDetail object
	 *
	 * @param  intVa The new TestInt value
	 */
	public void setTestInt(int intVa)
	{
		testInt = intVa;
	}
}
