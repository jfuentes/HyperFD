/* Copyright (C) 2001 David Hoag
 * ObjectWave Corporation
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * For a full copy of the license see:
 * http://www.opensource.org/licenses/lgpl-license.html
 */
package com.objectwave.configuration.xml;
import com.objectwave.exception.ExceptionBuilder;
import com.objectwave.exception.NotFoundException;
import com.objectwave.logging.MessageLog;
import com.objectwave.utility.ObjectFormatter;
import java.lang.reflect.*;
import org.xml.sax.*;
import org.xml.sax.helpers.*;
import java.util.Map;
import java.util.HashMap;
import java.util.ArrayList;
/**
 *  Look for a method of the set'VariableName' style. If the parameter type of
 *  the source object does not match the parameter type in the method, an
 *  attempt is made to convert tye type to the proper type.
 *
 *  This class does not use ANY features from the inherited class (other than
 *  the constructor).
 *
 * @author  David Hoag
 * @version  $Id: ObjectBuilder.java,v 1.1 2002/08/12 20:14:57 dave_hoag Exp $
 */
public class ObjectBuilder extends DefaultHandler
{
	Map tagToClass;
	ObjectFormatter objectFormatter;
	ArrayList result;
	/**
	 *  Constructor for the ObjectBuilder object
	 *
	 * @param  factory
	 */
	public ObjectBuilder()
	{
		tagToClass = new HashMap();
		objectFormatter = new ObjectFormatter();
		result = new ArrayList();
	}
	/**
	 */
	public void setTagToClassMap( Map map )
	{
		tagToClass = map;
	}
	/**
	 */
	public Object getResult()
	{
		if( result.size() == 1 )
		{
			return result.get(0);
		}
		if( result.size() == 0)
		{
			return null;
		}
		return result;
	}

	public void associate( String key, String fullyQualifiedClassName )
	{
		tagToClass.put( key, fullyQualifiedClassName );
	}
	/**
	 */
	public void startElement( String uri, String localName, String qName, Attributes atts ) throws SAXException
	{
		if( tagToClass.containsKey( qName ) )
		try
		{
			String className = (String)tagToClass.get( qName );
			Object obj = createObject( className, atts );
			result.add( obj );
		}
		catch( Exception ex )
		{
			MessageLog.debug( this, "Skipping tag [" + qName + "] due to exception.",ex );
		}
		else
		{
			MessageLog.warn( this, "Skipping tag [" + qName + "]since we don't know what to do with it." );
		}
	}
	/**
	 * @todo Add the bit about checking current thread class loader
	 */
	protected Object createObject(String className, Attributes atts ) throws SAXException, IllegalAccessException, ClassNotFoundException, InstantiationException
	{
		Class c = Class.forName( className );
		Object newObj = c.newInstance();
		for(int i = 0; i < atts.getLength(); i++)
		{
			String attribute = atts.getQName( i);
			String attributeValue = atts.getValue( i );
			try
			{
				connect(newObj, attribute, attributeValue); 
			}
			catch(Exception ex)
			{
				MessageLog.debug(this, "Skipping attribute " + attribute, ex);
			}
		}
		return newObj;
	}
	/**
	 *  Sets the ObjectFormatter attribute of the ObjectBuilder object
	 *
	 * @param  value The new ObjectFormatter value
	 */
	public void setObjectFormatter(final ObjectFormatter value)
	{
		objectFormatter = value;
	}
	/**
	 *  Set the parameter value on the source object using the method methodName.
	 *
	 * @param  source The object being changed.
	 * @param  parameter A value to set on source.
	 * @param  methodName A name of the method that should exist on source.
	 * @exception  NotFoundException The method specified could not be found.
	 * @exception  InvocationTargetException Trouble setting the value
	 * @exception  IllegalAccessException No access rights to the method.
	 */
	protected void setValueWithMethod(final Object source, final Object parameter, final String methodName) throws NotFoundException, InvocationTargetException, IllegalAccessException
	{
		Method mutator = findMutatorMethod(source, methodName);
		Object[] values = getParameterValues(mutator, parameter);
		mutator.invoke(source, values);
	}
	/**
	 *  Assumes that the method takes 1 and only 1 parameter on the provided
	 *  method. Convert the parameter to a class of the correct type.
	 *
	 * @param  method A single argument method
	 * @param  parameter The original parameter that is to be provided to the
	 *  method.
	 * @return  An Object [] that can be used as a parameter to the reflected invoke method.
	 */
	protected Object[] getParameterValues(final Method method, final Object parameter)
	{
		Object[] result = new Object[1];
		Class[] types = method.getParameterTypes();
		if(types[0].isAssignableFrom(parameter.getClass()))
		{
			result[0] = parameter;
		}
		else
		{
			Object newValue = objectFormatter.convertType(types[0], parameter);
			result[0] = newValue;
		}
		return result;
	}
	/**
	 *  Connects the child to the parent object
	 *
	 * @param  parentObject - The root object (ex. FruitBasket)
	 * @param  childObject - The sub object of the root object (ex. Apple)
	 * @param  childName - The logical name of the childObject
	 */
	public void connect(final Object parentObject, final String childName, final Object childObject)
	{
		StringBuffer buffer = new StringBuffer( childName );
		buffer.setCharAt( 0, Character.toUpperCase( buffer.charAt(0)) );
		String methodName = "set" + buffer;
		try
		{
			setValueWithMethod(parentObject, childObject, methodName);
		}
		catch(Exception ex)
		{
			MessageLog.warn(this, "Could not set value " + childObject + " on " + parentObject, ex);
			throw new RuntimeException("Could not set value " + childObject + " on " + parentObject);
		}
	}
	/**
	 *  Find a method called methodName.
	 *
	 * @param  source
	 * @param  methodName
	 * @return
	 * @exception  NotFoundException
	 */
	protected Method findMutatorMethod(final Object source, final String methodName) throws NotFoundException
	{
		Class onClass = source.getClass();
		Method[] methods = onClass.getMethods();
		Method ret = null;
		for(int i = 0; i < methods.length; i++)
		{
			ret = methods[i];
			Class[] argTypes = ret.getParameterTypes();
			if(ret.getName().equalsIgnoreCase(methodName) && argTypes.length == 1)
			{
				break;
			}
		}
		if(ret == null)
		{
			throw ExceptionBuilder.notFound("No method could be located to set the value! source: " + onClass + " methodName " + methodName);
		}
		return ret;
	}
}
