/*
 *  Copyright (C) 2001 David Hoag
 *  ObjectWave Corporation
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *  For a full copy of the license see:
 *  http://www.opensource.org/licenses/lgpl-license.html
 */
package com.objectwave.configuration.xml;
import com.objectwave.configuration.PropertySource;
import com.objectwave.exception.ConfigurationException;
import com.objectwave.exception.ExceptionBuilder;
import com.objectwave.logging.MessageLog;
import com.objectwave.utility.FileFinder;
import java.io.FileNotFoundException;
import java.net.URL;
/**
 * The core feature of this class is the ability to lookup an XML document
 * for the XmlConfigurationService.
 *
 * @author  dhoag
 * @version  $Id: XmlBootstrap.java,v 1.1 2002/08/12 20:14:57 dave_hoag Exp $
 * @see  #locateXmlMap
 */
public class XmlBootstrap
{
	/**
	 *  Constructor for the XmlBootstrap object
	 */
	public XmlBootstrap()
	{
	}
	/**
	 *  Gets the DocumentSource attribute of the XmlBootstrap object.
	 *
	 * @param  context
	 * @param  categoryId
	 * @return  The DocumentSource value
	 * @exception  ConfigurationException
	 * @exception  FileNotFoundException
	 * @see  #locateXmlMap
	 */
	public URL getDocumentSource(final PropertySource context, final String categoryId) throws ConfigurationException, FileNotFoundException
	{
		return locateXmlMap(context, categoryId);
	}
	/**
	 *  Find the XML document that contains the configuration information. Use a
	 *  couple of ways to attempt to locate and XML document. The name of the
	 *  document is either the class name of the context.getExpectedClass or the
	 *  value found in System.properties at the categoryId.
	 *  <ul>
	 *    <li> Look in location of the context class file for the xml document.
	 *    </li>
	 *    <li> Look for a resource on the class path matching the fully qualified
	 *    class name of the expected class </li>
	 *  </ul>
	 *  If the PropertySource class is test.this.PropertySource & the exected class
	 *  for this PropertySource is another.way.PropertyDetail. The default lookup
	 *  will first search for an XML document called PropertyDetail.xml in the
	 *  test.this.PropertySource class location. Next it searches for a system
	 *  resource on the classpath in the path /another/way/PropertyDetail.xml
	 *
	 * @param  categoryId String The tag name for the xml resource.
	 * @param  context
	 * @return  The URL for the XML file
	 * @exception  ConfigurationException
	 * @exception  FileNotFoundException
	 */
	protected URL locateXmlMap(final PropertySource context, final String categoryId) throws ConfigurationException, FileNotFoundException
	{
		String xmlName = null;
		URL url = null;
		FileFinder ff = new FileFinder();
		if(categoryId != null)
		{
			xmlName = deriveXmlFileName( categoryId, context );
			try
			{
				//let system properties override the xml default xml file name
				xmlName = System.getProperty(categoryId, xmlName );
			}
			catch(Exception ex)
			{
				MessageLog.debug(this, "Tried SystemProperties for xml file, probably don't have access rights", ex);
			}
			try
			{
				url = ff.getUrl(context.getClass(), xmlName);
			}
			catch(java.net.MalformedURLException ex)
			{
				throw ExceptionBuilder.configuration("Exception locating xml resource : " + categoryId + " -> " + xmlName);
			}
		}
		try
		{
			//Don't give up yet. Try the simple default way of having a file name match class name
			if(url == null)
			{
				String defaultName = context.getExpectedClass().getName();
				defaultName = "/" + defaultName.replace('.', '/') + ".xml";
				MessageLog.debug(this, "Looking for default xml resource of " + defaultName);
				url = ff.getUrl(context.getExpectedClass(), defaultName);
			}
		}
		catch(java.net.MalformedURLException ex)
		{
			throw ExceptionBuilder.configuration("Exception locating xml resource : " + categoryId + " -> " + xmlName);
		}
		if(url == null)
		{
			throw new FileNotFoundException("Exception locating xml resource : " + categoryId + " -> " + xmlName);
		}
		MessageLog.info(this, "Url for XML data : " + categoryId + " -> " + url);
		return url;
	}
	/**
	 * 
	 */
	protected String deriveXmlFileName( final String categoryId, final PropertySource context )
	{
		String className = context.getExpectedClass().getName();
		int idx = className.lastIndexOf('.');
		if(idx > -1)
		{
			className = className.substring(idx + 1);
		}
		int separatorIndex = categoryId.indexOf( '#' );
		if( separatorIndex > 0 )
		{
			String instanceName = categoryId.substring( separatorIndex + 1 ).trim();
			if( ! instanceName.equals( "" )  )
			{
				return className + '-' + instanceName + ".xml";
			}
		}
		return className + ".xml";
	}
}
