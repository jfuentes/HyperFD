/*
 *  Copyright (C) 2001 David Hoag
 *  ObjectWave Corporation
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *  For a full copy of the license see:
 *  http://www.opensource.org/licenses/lgpl-license.html
 */
package com.objectwave.configuration.xml;
import com.objectwave.configuration.ConfigurationService;
import com.objectwave.configuration.PropertyObjects;
import com.objectwave.configuration.PropertySource;
import com.objectwave.exception.ConfigurationException;
import com.objectwave.exception.ExceptionBuilder;
import com.objectwave.exception.NotFoundException;
import com.objectwave.logging.MessageLog;

import java.io.FileNotFoundException;
import java.util.HashMap;
import javax.xml.parsers.*;
import org.xml.sax.*;
/**
 *  To use XML to configure your application, use this class as the default
 *  configuration service. <br>
 *  To use simply do the following <pre>
 * ConfigurationService srvc = new XmlConfigurationService();
 * ConfigurationServiceFactory.setDefaultConfigurationService( srvc );
 * </pre>
 *
 * @author  David Hoag
 * @version  $Id: XmlConfigurationService.java,v 1.1 2002/08/12 20:14:57 dave_hoag Exp $
 */
public class XmlConfigurationService implements ConfigurationService
{
	static SAXParserFactory saxParserFactory;
	protected PropertyObjects propertyObjects;
	HashMap factoryMap;
	/**
	 *  Constructor for the XmlConfigurationService object
	 */
	public XmlConfigurationService()
	{
		initialize();
	}
	/**
	 */
	protected static void initializeSaxParser()
	{
		saxParserFactory = SAXParserFactory.newInstance();
		saxParserFactory.setValidating(false);
	}
	/**
	 *  Categories are identified by the full name of the property source.
	 *
	 * @param  source
	 * @return  The CategoryId value
	 */
	public String getCategoryId(final PropertySource source)
	{
		if(source == null)
		{
			return "Default";
		}
		String namedInstance = source.getName();
		if( namedInstance != null )
		{
			return source.getClass().getName() + "#" + namedInstance;
		}
		else
		{
			return source.getClass().getName();
		}
	}
	/**
	 *  Create and return an instance of the PropertyDetail. The instance will have
	 *  its values set from the configuration service.
	 *
	 * @param  context The PropertySource attempting to locate the property detail.
	 * @return  An instance of the context.getExpectClass filled with configured
	 *      values.
	 * @exception  ConfigurationException
	 */
	public Object getPropertyHolder(final PropertySource context) throws ConfigurationException
	{
		final String categoryId = getCategoryId(context);
		return this.getPropertyHolder(context, categoryId);
	}
	/**
	 *  For the provided property source and category, locate & populate the
	 *  PropertyDetail.
	 *
	 * @param  context The PropertySource attempting to locate the property detail.
	 * @param  categoryId Likely the full class name of the property source.
	 * @return  An instance of the context.getExpectClass filled with configured
	 *      values.
	 * @exception  ConfigurationException
	 */
	public Object getPropertyHolder(final PropertySource context, final String categoryId) throws ConfigurationException
	{
		try
		{
			Object result = null;
			if(isCachingDetail())
			{
				//Check the cache for an existing instance
				result = getDetail(context, categoryId);
			}
			if(result == null)
			{
				SAXParser saxParser = saxParserFactory.newSAXParser();
				//Parse an XML document (if it exists) to create a new property detail
				result = getPropertyHolderFromParser(context, categoryId, saxParser);
				//Cache the result for this context and category
				propertyObjects.addDetail(context, categoryId, result);
			}
			return result;
		}
		catch(SAXException ex)
		{
			MessageLog.debug(this, "Exception while setting up configuration", ex);
			throw ExceptionBuilder.configuration("Problem with XML parsing : " + ex);
		}
		catch(ParserConfigurationException ex)
		{
			MessageLog.debug(this, "Exception while setting up configuration", ex);
			throw ExceptionBuilder.configuration("Problem with XML parser configuration : " + ex);
		}
		catch(Exception ex)
		{
			MessageLog.debug(this, "Exception while setting up configuration", ex);
			throw ExceptionBuilder.configuration("Failed to configure " + context + " categoryId " + categoryId + " : " + ex);
		}
	}
	/**
	 *  Find the existing detail object.
	 *
	 * @param  context The object that will want this property information.
	 * @param  categoryId The id that should uniquely identify the desired
	 *      properties.
	 * @return  An object that will have all of its declared fields set to values.
	 * @exception  ConfigurationException
	 */
	protected Object getDetail(final PropertySource context, final String categoryId) throws ConfigurationException
	{
		Object result = null;
		if(propertyObjects.hasDetail(context, categoryId))
		{
			MessageLog.debug(this, "Retrieving existing property detail for context " + context + " category " + categoryId);
			try
			{
				result = propertyObjects.getDetail(context, categoryId);
			}
			catch(NotFoundException ex)
			{
				MessageLog.error(this, "The impossible has occured! Says we have, and then throws not found exception!", ex);
				return null;
			}
		}
		return result;
	}
	/**
	 *  Locate the XML document for the context and category, parse it, and set
	 *  values on a new PropertyDetail.
	 *
	 * @param  context
	 * @param  categoryId
	 * @param  saxParser
	 * @return  An instance of the context.getExpectClass filled with configured
	 *      values.
	 * @exception  Exception There are MANY ways we can fail
	 */
	protected Object getPropertyHolderFromParser(final PropertySource context, final String categoryId, final SAXParser saxParser) throws Exception
	{
		ObjectBuilder builder = new ObjectBuilder();
		HashMap map = initDefaultStrategy(context);
		builder.setTagToClassMap( map );

		try
		{
			//Locate the XML
			InputSource is = getXmlInputSource(context, categoryId);
			XMLReader reader = saxParser.getXMLReader();
			reader.setContentHandler( builder );
			reader.parse( is );
			return builder.getResult();
		}
		catch(FileNotFoundException ex)
		{
			MessageLog.warn(this, "Failed to locate XML file for context " + context + ". Attempting to use defaults.", ex);
		}

		//If we get here, no XML file was found - return empty object with defaults
		String className = context.getExpectedClass().getName();
		Class clazz = Class.forName(className);
		return clazz.newInstance();
	}
	/**
	 *  Gets the default key. This assumes that the root node of the XML property
	 *  file matches the Class name of the expected class.
	 *
	 * @param  context
	 * @return  The DerrivedKey value
	 */
	protected String getDefaultKey(final PropertySource context)
	{
		String className = context.getExpectedClass().getName();
		int idx = className.lastIndexOf('.');
		if(idx > -1)
		{
			className = className.substring(idx + 1);
		}
		return className;
	}
	/**
	 * Use an instance of XmlBootstrap to locate an XML document for the specified
	 * context and category.
	 *
	 * @param  context The Object looking for a PropertyDetails.
	 * @param  categoryId Likely the full class name of the context.getExpectedClass
	 * @return  The value provide the XML parser to get property values.
	 * @exception  Exception
	 * @see  com.objectwave.configuration.xml.XmlBootstrap#locateXmlMap
	 */
	protected InputSource getXmlInputSource(final PropertySource context, final String categoryId) throws Exception
	{
		java.net.URL url = new XmlBootstrap().getDocumentSource(context, categoryId);
		InputSource is = new InputSource(url.toString());
		return is;
	}
	/**
	 * @return  The CachingDetail value
	 */
	protected boolean isCachingDetail()
	{
		return true;
	}
	/**
	 * A unique cache of details per Configuration service instance.
	 */
	public void initialize()
	{
		propertyObjects = new PropertyObjects();
		factoryMap = new HashMap();
	}
	/**
	 * @param  path The XML nodes that should translate to a Java class
	 * @param  className The class to instantiate for each XML node of type path
	 */
	public synchronized void addSupport(String path, String className)
	{
		factoryMap.put(path, className);
	}
	/**
	 *  This allows users of the configuration service to not specify Xml path to
	 *  class mappings. It assumes that the Path will be the Class name (sans the
	 *  package portion) of the expected class on the property source context.<br>
	 *  Xml of <ClassName> will map to class context.getExpectedClass().getName().
	 *
	 * @param  context The source attempting to locate property detail.
	 * @return
	 */
	protected HashMap initDefaultStrategy(final PropertySource context)
	{
		String key = getDefaultKey(context);
		//Support already defined, no need to determine
		if(!factoryMap.containsKey(key))
		{
			addSupport(key, context.getExpectedClass().getName());
		}
		return factoryMap;
	}
	/**
	 */
	public static class Test extends com.objectwave.test.UnitTestBaseImpl
	{
		String xmlContents = "<?xml version='1.0'?> \n" +
		/*
		 *  "<!DOCTYPE Holder SYSTEM 'logging.dtd'> \n" +
		 */
				"<TestPropertyDetail \n" +
				"	TestInt='15' \n" +
				"/>";
		/**
		 *  The main program for the Test class
		 *
		 * @param  args The command line arguments
		 */
		public static void main(String[] args)
		{
			com.objectwave.test.TestRunner.run(new Test(), args);
		}
		/**
		 *  The JUnit setup method
		 *
		 * @param  testName The new Up value
		 * @param  context The new Up value
		 * @exception  Exception
		 */
		public void setUp(String testName, com.objectwave.test.TestContext context) throws Exception
		{
			writeFile("test.xml", xmlContents);
		}
		/**
		 *  The teardown method for JUnit
		 *
		 * @param  context
		 */
		public void tearDown(com.objectwave.test.TestContext context)
		{
			removeFile("test.xml");
		}
		/**
		 *  Final test of default approach
		 *
		 * @exception  Exception
		 */
		public void testDefaultBootstrap() throws Exception
		{
			XmlConfigurationService svc = new XmlConfigurationService();
			PropertySource source = new com.objectwave.configuration.example.TestPropertySource();

			writeFile("TestPropertyDetail.xml", xmlContents);
			try
			{
				com.objectwave.configuration.example.TestPropertyDetail detail = (com.objectwave.configuration.example.TestPropertyDetail) svc.getPropertyHolder(source, "cat.two");
				testContext.assertEquals(15, detail.testInt);

				com.objectwave.configuration.example.TestPropertyDetail detail2 = (com.objectwave.configuration.example.TestPropertyDetail) svc.getPropertyHolder(source, "cat.two");
				testContext.assertEquals("Cache should return the same instance!", detail2, detail);
			}
			finally
			{
				removeFile("TestPropertyDetail.xml");
			}
		}
		/**
		 *  A unit test for JUnit
		 *
		 * @exception  Exception
		 */
		public void testDefaultInSourceLocation() throws Exception
		{
			XmlConfigurationService svc = new XmlConfigurationService();
			PropertySource source = new com.objectwave.configuration.example.TestPropertySource();

			String newContent = xmlContents.replace('5', '6');
			System.out.println(newContent);
			java.io.File f = writeFileResource("TestPropertyDetail.xml", source.getClass(), newContent);
			System.out.println("WROTE " + f.getAbsolutePath());

			try
			{
				com.objectwave.configuration.example.TestPropertyDetail detail = (com.objectwave.configuration.example.TestPropertyDetail) svc.getPropertyHolder(source, "cat.noCache");
				testContext.assertEquals(16, detail.testInt);
			}
			finally
			{
				removeFile(f.getAbsolutePath());
			}
		}
		/**
		 *  A unit test for JUnit
		 *
		 * @exception  Exception
		 */
		public void testSmartGetPropHolder() throws Exception
		{
			XmlConfigurationService svc = new XmlConfigurationService();
			PropertySource source = new com.objectwave.configuration.example.TestPropertySource();
			System.setProperty("cat.two", "test.xml");

			com.objectwave.configuration.example.TestPropertyDetail detail = (com.objectwave.configuration.example.TestPropertyDetail) svc.getPropertyHolder(source, "cat.two");
			testContext.assertEquals(15, detail.testInt);
		}
		/**
		 *  A unit test for JUnit
		 *
		 * @exception  Exception
		 */
		public void testGetPropHolder() throws Exception
		{
			XmlConfigurationService svc = new XmlConfigurationService();
			PropertySource source = new com.objectwave.configuration.example.TestPropertySource();
			System.setProperty("cat", "test.xml");
			svc.addSupport("TestPropertyDetail", "com.objectwave.configuration.example.TestPropertyDetail");
			com.objectwave.configuration.example.TestPropertyDetail detail = (com.objectwave.configuration.example.TestPropertyDetail) svc.getPropertyHolder(source, "cat");
			testContext.assertEquals(15, detail.testInt);
		}
		/**
		 *  Test the case where there is no XML file to locate. Configuration should
		 *  NOT require XML files.
		 *
		 * @exception  Exception
		 */
		public void testNoInputSource() throws Exception
		{
			removeFile("test.xml");
			XmlConfigurationService svc = new XmlConfigurationService();
			PropertySource source = new com.objectwave.configuration.example.TestPropertySource();
			System.setProperty("noInput", "test.xml");
			try
			{
				InputSource input = svc.getXmlInputSource(source, "noInput");
				testContext.assertTrue("The file should not exist! ", false);
			}
			catch(FileNotFoundException ex)
			{
			}
			com.objectwave.configuration.example.TestPropertyDetail detail = (com.objectwave.configuration.example.TestPropertyDetail) svc.getPropertyHolder(source, "noInput");
			testContext.assertEquals("Detail should have default values!", 0, detail.testInt);
		}
		/**
		 *  A unit test for JUnit
		 *
		 * @exception  Exception
		 */
		public void testGetXmlInputSource() throws Exception
		{
			XmlConfigurationService svc = new XmlConfigurationService();
			PropertySource source = new com.objectwave.configuration.example.TestPropertySource();
			System.setProperty("cat", "test.xml");
			InputSource input = svc.getXmlInputSource(source, "cat");
			/*
			 *  java.io.Reader rdr = input.getCharacterStream();
			 *  testContext.assert(  rdr != null );
			 *  int read = -1;
			 *  char []  chars = new char [1024];
			 *  StringBuffer result = new StringBuffer();
			 *  do
			 *  {
			 *  read = rdr.read( chars );
			 *  result.append( chars, 0, read );
			 *  }
			 *  while( read > -1 );
			 *  System.out.println(result);
			 */
			testContext.assertTrue("Did not locate our XML file!", input.getSystemId().endsWith("test.xml"));
		}
		public void testGetXmlInputSourceWithName() throws Exception
		{
			try
			{
				writeFile("TestPropertyDetail-name.xml", xmlContents);
				XmlConfigurationService svc = new XmlConfigurationService();
				com.objectwave.configuration.example.TestPropertySource source = new com.objectwave.configuration.example.TestPropertySource();
				source.setName("name");
				InputSource input = svc.getXmlInputSource(source, source.getCategoryId() );
			}
			finally
			{
				removeFile("TestPropertyDetail-name.xml");
			}
		}
	}
	static
	{
		try
		{
			initializeSaxParser();
		}
		catch(Throwable t)
		{
			t.printStackTrace();
		}
	}
}
