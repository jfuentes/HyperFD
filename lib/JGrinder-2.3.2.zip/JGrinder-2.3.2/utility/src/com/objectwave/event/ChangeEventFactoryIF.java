package com.objectwave.event;

/**
 * Any object may wish to install property change listeners on objects at runtime.
 * This interface allows the specification of a property change listener factory
 * at run time, and then it can retrieve the property change listener implementation.
 * @verion 1.0
 */
public interface ChangeEventFactoryIF
{
	/**
	 * Get or create a propery change listener.
	 */
	java.beans.PropertyChangeListener getListener();
}