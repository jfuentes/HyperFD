package com.objectwave.event;

/**
* Largely used to indicate that new data is available and is being
* introduced to the system.
*/
public class DataAvailable extends PacketEvent
{
	Object value;
	public DataAvailable(Object source, String dataName, Object data)
	{
	    super(source, dataName);
	    this.value = data;
	}
	public Object getValue(){ return value; }
}