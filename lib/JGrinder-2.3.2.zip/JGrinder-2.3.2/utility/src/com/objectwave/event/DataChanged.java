package com.objectwave.event;

/**
* Existing data that was previously introduced with 'DataAvailable' has
* changed.
*/
public class DataChanged extends PacketEvent
{
	Object oldValue;
	Object newValue;
	public DataChanged(Object source, String dataName, Object oldData, Object newData)
	{
	    super(source, dataName);
	    oldValue = oldData;
	    newValue = newData;
	}
	public Object getNewValue(){ return newValue; }
	public Object getOldValue(){ return oldValue; }
}