package com.objectwave.event;

/**
* I want specific data.  This is usually issued when I wish any screens
* to fill up the business objects with their values.
*/
public class DataRequest extends PacketEvent
{
	Object value;
	public DataRequest(Object source, String dataName, Object data)
	{
	    super(source, dataName);
	    value = data;
	}
	public Object getValue(){ return value; }
}