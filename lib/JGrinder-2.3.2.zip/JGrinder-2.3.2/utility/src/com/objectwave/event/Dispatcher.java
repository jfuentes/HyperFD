package com.objectwave.event;

import java.util.EventListener;
import java.util.EventObject;
/**
* Used in conjunction with SimplePacketSupport. This allows the class
* using SimplePacketSupport to call what ever message dispatch it so wishes.
* Used to provide support for any event listener list.
* @version 2.0
*/
public interface Dispatcher
{
	void dispatch(EventListener listener, EventObject packet);
}