package com.objectwave.event;

import java.lang.reflect.Method;
import java.lang.reflect.InvocationTargetException;

class ObjectElements
{
	ObjectElements nextElement;
	Object element;

	ObjectElements(ObjectElements next, Object elem)
	{
		nextElement = next;
		element = elem;
	}
	public void invoke(Method method, Object [] values) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException
	{
		method.invoke(element, values);
		if(nextElement != null) nextElement.invoke(method, values);
	}
}