package com.objectwave.event;

import java.lang.reflect.Method;
import java.lang.reflect.InvocationTargetException;

/** Slow at adding and removing, but fast for dispatching.
*/
public class ObjectListenerList
{
	Object [] listeners;
	int count = 0;

	/* Test Methods
	public void testMethod(String val){
		System.out.println(val);
	}

	public static void main(String [] args){
		ObjectListenerList list = new ObjectListenerList();
		list.add(ObjectListenerList.class, list);
		list.add(ObjectListenerList.class, list);
		try {
		list.fireEvent(ObjectListenerList.class, "testMethod", new Integer(3));
		list.remove(ObjectListenerList.class, list);
		list.fireEvent(ObjectListenerList.class, "testMethod", "HelloAgain!");
		} catch (Exception e){ System.err.println(e); }
	}
	*/
	public ObjectListenerList()
	{
		listeners = new Object [100];
	}
	public ObjectListenerList(int initial)
	{
		listeners = new Object [Math.abs(initial)];
	}
	public synchronized void add(Class cl, Object list)
	{
		if(listeners.length - count > (listeners.length / 10)){
			Object [] tmp = new Object[listeners.length + ((listeners.length / 10) * 3) + 10 ];
			System.arraycopy(listeners,0,tmp,0,count);
			listeners = tmp;
		}
		for(int i = count - 2; i > -1; i-= 2){
			if (listeners[i]== cl) {
				ObjectElements control = (ObjectElements)listeners[i+1];
				while(control != null){
					if(control.element == list) return;
					if(control.nextElement == null){
						control.nextElement = new ObjectElements(null, list);
						return;
					}
					control = control.nextElement;
				}
				return;
			}
		}
		listeners[count++] = cl;
		listeners[count++] = new ObjectElements(null, list);
	}
	/** Basically, find any Object of type listenerClass.
	* Invoke the method of 'methodName' with the one parameter 'event'.
	* @fixme - Remove == for the event listener class comparison.
	*/
	public void fireEvent(Class listenerClass, String methodName, Object event)
					throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException
	{
		final Method method;
		Class [] params = new Class [1];
		params[0] = event.getClass();
		method = listenerClass.getDeclaredMethod(methodName, params);
		Object [] values = new Object [1];
		values[0] = event;
		// Process the listeners last to first, notifying
		// those that are interested in this event
		for (int i = count - 2; i >= -1; i -= 2){
			if (listeners[i]== listenerClass){
				ObjectElements target = (ObjectElements)listeners[i+1];
				target.invoke(method, values);
			}
		}
	}
	public synchronized void remove(Class cl, Object list)
	{
		for(int i = count - 2; i > -1; i-= 2){
			if (listeners[i]== cl) {
				boolean first = true;
				ObjectElements control = (ObjectElements)listeners[i+1];
				ObjectElements prev = control;
				while(control != null){
					if(control.element == list){
						prev.nextElement = control.nextElement;
						break;
					}
					prev = control;
					control = control.nextElement;
					first = false;
				}
				if(first) {
					Object newClass = null;
					Object newValue = null;
					if(count > 2){
						newClass = listeners[count - 2];
						newValue = listeners[count - 1];
					}
					listeners [i] = newClass;
					listeners [i+1] = newValue;
					count -= 2;
				}
				return;
			}
		}
	}
}