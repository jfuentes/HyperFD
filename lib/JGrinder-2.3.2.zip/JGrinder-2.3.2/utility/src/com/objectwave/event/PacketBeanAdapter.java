package com.objectwave.event;

import java.beans.*;

class PacketBeanAdapter implements PacketListener
{
	PropertyChangeListener list;
	PacketBeanAdapter(PropertyChangeListener changeListener)
	{
		list = changeListener;
	}
	public void packetAvailable(DataAvailable e) {}
	public void packetAvailable(DataChanged e)
	{
		if(e instanceof DataChanged){
			DataChanged evt = (DataChanged)e;
			list.propertyChange(new PropertyChangeEvent(evt.getSource(), evt.getPropertyName(), evt.getOldValue(), evt.getNewValue()));
		}
	}
	public void packetAvailable(DataRequest e) {}
}