package com.objectwave.event;

import java.util.EventObject;

/**
*/
public class PacketEvent extends java.util.EventObject
{
	String propertyName;
	int propagationID;
	public PacketEvent(Object source, String dataName)
	{
	    super(source);
	    propertyName = dataName;
	}
	public int getPropagationID(){ return propagationID; }
	public String getPropertyName(){ return propertyName; }
	public void setPropagationID(int value){ propagationID = value; }
}