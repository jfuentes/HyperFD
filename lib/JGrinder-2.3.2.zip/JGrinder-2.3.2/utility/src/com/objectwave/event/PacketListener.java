package com.objectwave.event;

import java.util.EventListener;

/** 
*/
public interface PacketListener extends EventListener
{
	public void packetAvailable(DataAvailable d);
	public void packetAvailable(DataChanged d);
	public void packetAvailable(DataRequest r);
}