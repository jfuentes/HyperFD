package com.objectwave.event;

/**
* Friendly class that is implemented for efficient list handling.
*/
class PacketListenerList implements Cloneable
{
	PacketListenerList next = null;
	PacketListener listener = null;
	final static boolean eventVerbose = System.getProperty("ow.eventVerbose") != null;

	PacketListenerList addPacketListener(PacketListener list)
	{
		PacketListenerList result = new PacketListenerList();
		result.next = this;
		result.listener = list;
		return result;
	}
	public Object clone()
	{
		PacketListenerList result = new PacketListenerList();
		result.listener = listener;
		PacketListenerList nextElement = next;
		PacketListenerList newResult = result;
		while(nextElement != null){
			PacketListenerList newNext = new PacketListenerList();
			newNext.listener = nextElement.listener;
			newResult.next = newNext;
			nextElement = nextElement.next;
			newResult = newNext;
		}
		return result;
	}
	void firePacket(DataAvailable packet)
	{
		//The last entry will never have a listener.
		if(next != null){
		    if(listener != packet.getSource()) { 
			    if(eventVerbose)
			        System.out.println("DataAvailable" + packet.hashCode() + " -> " + listener );
				listener.packetAvailable(packet);
			}
			next.firePacket(packet);
		}
	}
	void firePacket(DataChanged packet)
	{
		//The last entry will never have a listener.
		if(next != null){
		    if(listener != packet.getSource()) { 
			    if(eventVerbose)
			        System.out.println("DataChanged" + packet.hashCode() + " -> " + listener );
				listener.packetAvailable(packet);
			}
			next.firePacket(packet);
		}
	}
	void firePacket(DataRequest packet)
	{
		//The last entry will never have a listener.
		if(next != null){
		    if(listener != packet.getSource()) { 
			    if(eventVerbose)
	//		        System.out.println(" " + listener + " ->DataRequest " + packet);
			        System.out.println("DataRequest" + packet.hashCode() + " -> " + listener );
				listener.packetAvailable(packet);
			}
			next.firePacket(packet);
		}
	}
	void firePacket(PacketEvent packet)
	{
	    if(packet instanceof DataAvailable)
	        firePacket((DataAvailable)packet);
	    else
	    if(packet instanceof DataChanged)
	        firePacket((DataChanged)packet);
	    else
	        firePacket((DataRequest)packet);
	}
	PacketListenerList removePacketListener(PacketListener list)
	{
		PacketListenerList head = this;
		if(listener == list){ return next; }
		if(next == null)
			next = next.removePacketListener(list);
		return head;
	}
}