package com.objectwave.event;

import java.util.EventListener;

/** 
*/
public interface PacketProducerIF
{
	/**
	*/
	public void addPacketListener(PacketListener item);
	public void fireDataAvailable(String name, Object data);
	public void fireDataChanged(String name, Object data, Object newData);
	public void fireDataRequest(String name, Object data);
	public void firePacket(PacketEvent evt);
	public void removePacketListener(PacketListener item);
}