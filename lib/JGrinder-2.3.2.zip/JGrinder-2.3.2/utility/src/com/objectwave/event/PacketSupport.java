package com.objectwave.event;

/**
* Events will NOT be sent to the originator of the event.  
* This is for consistency sake. When we use a component and it is not connected to an event pool,
* you do not get the 'echo' of the event. To prevent coding for these
* situations, make the event pool behave like all other circumstances.
*/
public class PacketSupport
{
	Object source;
	PacketListenerList list;
	java.util.Hashtable beanToAdapter = new java.util.Hashtable();
	final static boolean eventVerbose = System.getProperty("ow.eventVerbose") != null;

	public PacketSupport(Object source)
	{
		this.source = source;
		list = new PacketListenerList();
	}
	/**
	*/
	public void addPacketListener(PacketListener item)
	{
		list = list.addPacketListener(item);
	}
	public void addPropertyChangeListener(java.beans.PropertyChangeListener list)
	{
		PacketListener packList = new PacketBeanAdapter(list);
		beanToAdapter.put(list, packList);
		addPacketListener(packList);
	}
	public void fireDataAvailable(String name, Object data)
	{
	    if(eventVerbose)
	        System.out.println(">>> " + source +  " new DataAvailable" + name + " " + data);
	    firePacket(new DataAvailable(source, name, data));
	}
	public void fireDataChanged(String name, Object data, Object newData)
	{
	    if(eventVerbose)
	        System.out.println("Trying to initiate date changed " + name);
		if (data != null && newData != null && data.equals(newData)) {
		    return;
		}
	    if(eventVerbose)
	        System.out.println(">>> " + source + " new DataChanged " + name + " " + newData);
	    firePacket(new DataChanged(source, name, data, newData));
	}
	public void fireDataRequest(String name, Object data)
	{
	    if(eventVerbose)
	        System.out.println(">>> " + source + " new DataRequest" + name + " " + data);
	    firePacket(new DataRequest(source, name, data));
	}
	/**
	* Thread safe dispatching of an event.
	*/
	public void firePacket(PacketEvent evt)
	{
	    PacketListenerList dispatch;
	    synchronized (this) {
	        dispatch = (PacketListenerList)list.clone();
	    }
		dispatch.firePacket(evt);
	}
	public Object getSource(){ return source; }
	/**
	*/
	public void removePacketListener(PacketListener item)
	{
		list = list.removePacketListener(item);
	}
	public void removePropertyChangeListener(java.beans.PropertyChangeListener list)
	{
		PacketListener packList = (PacketListener)beanToAdapter.get(list);
		if(packList == null) return;
		removePacketListener(packList);
		beanToAdapter.remove(list);
	}
}