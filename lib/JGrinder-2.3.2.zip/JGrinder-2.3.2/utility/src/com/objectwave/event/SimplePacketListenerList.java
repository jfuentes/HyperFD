package com.objectwave.event;

import java.util.EventListener;
import java.util.EventObject;
/**
* Friendly class that is implemented for efficient list handling.
* This works in conjunction with SimplePacketSupport to provide support
* for generic event dispatching.
* @see com.objectwave.event.SimplePacketSupport
*/
class SimplePacketListenerList implements Cloneable
{
	SimplePacketListenerList next = null;
	EventListener listener = null;
	final static boolean eventVerbose = System.getProperty("ow.eventVerbose") != null;
	Dispatcher target;

	public SimplePacketListenerList(Dispatcher dispatch)
	{
		target = dispatch;
	}
	SimplePacketListenerList addPacketListener(EventListener list)
	{
		SimplePacketListenerList result = new SimplePacketListenerList(target);
		result.next = this;
		result.listener = list;
		return result;
	}
	public Object clone()
	{
		SimplePacketListenerList result = new SimplePacketListenerList(target);
		result.listener = listener;
		SimplePacketListenerList nextElement = next;
		SimplePacketListenerList newResult = result;
		while(nextElement != null){
			SimplePacketListenerList newNext = new SimplePacketListenerList(target);
			newNext.listener = nextElement.listener;
			newResult.next = newNext;
			nextElement = nextElement.next;
			newResult = newNext;
		}
		return result;
	}
	void fireEvent(EventObject packet)
	{
		//The last entry will never have a listener.
		if(next != null)
		{
		    if(listener != packet.getSource())
		    { 
				target.dispatch(listener, packet);
			}
			next.fireEvent(packet);
		}
	}
	SimplePacketListenerList removePacketListener(EventListener list)
	{
		SimplePacketListenerList head = this;
		if(listener == list){ return next; }
		if(next == null)
			next = next.removePacketListener(list);
		return head;
	}
}