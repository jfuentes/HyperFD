package com.objectwave.event;

import java.util.EventListener;
import java.util.EventObject;
/**
* This class facilitates the use of Event handling.
* To use this class requires a couple of steps. First, the using
* class must implement the Dispatcher interface. This is how the event
* is actually delivered. Next, a reference to this class must be placed
* in the using class. Third, the using class needs to add the addListener
* and removeListener methods. This, hopefully, makes it real easy to
* add event handling to a class.
*
* This uses the DoulbeDispatch pattern to achieve event dispatching.
* 
* NOTE: Events will NOT be sent to the originator of the event.  
* @version 2.0
*/
public class SimplePacketSupport 
{
	Dispatcher source;
	SimplePacketListenerList list;
	final static boolean eventVerbose = System.getProperty("ow.eventVerbose") != null;

	public SimplePacketSupport(Dispatcher source)
	{
		this.source = source;
		list = new SimplePacketListenerList(source);
	}
	/**
	 * @deprecated 
	 */
	public void addPacketListener(EventListener item)
	{
		list = list.addPacketListener(item);
	}
	/**
	*/
	public void addEventListener(EventListener item)
	{
		list = list.addPacketListener(item);
	}
	/**
	* Thread safe dispatching of an event.
	*/
	public void fireEvent(EventObject evt)
	{
	    SimplePacketListenerList dispatch;
	    synchronized (this) {
	        dispatch = (SimplePacketListenerList)list.clone();
	    }
		dispatch.fireEvent(evt);
	}
	public Dispatcher getSource(){ return source; }
	/**
	 * @deprecated 
	 */
	public void removePacketListener(EventListener item)
	{
		list = list.removePacketListener(item);
	}
	/**
	 */
	public void removeEventListener(EventListener item)
	{
		list = list.removePacketListener(item);
	}
}