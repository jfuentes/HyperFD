package com.objectwave.event;

/**
*/
public class StatusEvent extends java.util.EventObject
{
	String text;
	StatusType type;
	
	public StatusEvent(Object source, String message)
	{
		super(source);
		text = message;
		type = StatusType.INFORMATIONAL;
	}
	public String getText() { return text; }
	public StatusType getType()
	{
		return type;
	}
	public void setType(StatusType l)
	{
		type = l;
	}
}