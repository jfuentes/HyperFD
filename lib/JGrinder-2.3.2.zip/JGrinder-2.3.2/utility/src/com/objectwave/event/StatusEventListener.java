package com.objectwave.event;

public interface StatusEventListener extends java.util.EventListener {
	public void updateStatus(StatusEvent evt);
}