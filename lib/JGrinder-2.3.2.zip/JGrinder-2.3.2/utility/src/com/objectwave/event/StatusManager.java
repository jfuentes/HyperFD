package com.objectwave.event;
import java.awt.event.*;
import java.lang.reflect.*;

import java.util.EventListener;
import java.util.EventObject;

/**
 *  Intended to be used as a generic shared event dispatcher.
 *
 * @author  dhoag
 * @version  $Id: StatusManager.java,v 2.0 2001/06/11 15:46:53 dave_hoag Exp $
 */
public class StatusManager
{
	SimplePacketSupport listenerList = new SimplePacketSupport(new Delegator());
	static StatusManager defaultManager;
	/**
	 * @param  l The feature to be added to the StatusEventListener attribute
	 */
	public void addStatusEventListener(StatusEventListener l)
	{
		listenerList.addEventListener(l);
	}
	/**
	 * @param  evt Description of Parameter
	 */
	public void fireStatusEvent(StatusEvent evt)
	{
		listenerList.fireEvent(evt);
	}
	/**
	 *  Convience method to fire an informational status event.
	 *
	 * @param  source Description of Parameter
	 * @param  text Description of Parameter
	 */
	public void fireStatusEvent(Object source, String text)
	{
		fireStatusEvent(new StatusEvent(source, text));
	}
	/**
	 *  Description of the Method
	 *
	 * @param  l Description of Parameter
	 */
	public void removeStatusEventListener(StatusEventListener l)
	{
		listenerList.removeEventListener(l);
	}
	/**
	 *  Sets the DefaultManager attribute of the StatusManager class
	 *
	 * @param  gr The new DefaultManager value
	 */
	public static void setDefaultManager(StatusManager gr)
	{
		defaultManager = gr;
	}
	/**
	 *  Gets the DefaultManager attribute of the StatusManager class
	 *
	 * @return  The DefaultManager value
	 */
	public static StatusManager getDefaultManager()
	{
		if(defaultManager == null)
		{
			defaultManager = new StatusManager();
		}
		return defaultManager;
	}
	/**
	 *  The MOST convient method in the bunch.
	 *
	 * @param  text Description of Parameter
	 */
	public static void fireStatusEvent(String text)
	{
		getDefaultManager().fireStatusEvent(text, text);
	}
	/**
	 * @author  dhoag
	 * @version  $Id: StatusManager.java,v 2.0 2001/06/11 15:46:53 dave_hoag Exp $
	 */
	public static class Test extends com.objectwave.test.UnitTestBaseImpl
	{
		/**
		 *  Test Cases
		 */
		public void testDispatch()
		{
			StatusManager mgr = StatusManager.getDefaultManager();
			final java.util.Vector one = new java.util.Vector();
			StatusEventListener l =
				new StatusEventListener()
				{
					/**
					 *  Description of the Method
					 *
					 * @param  e Description of Parameter
					 */
					public void updateStatus(StatusEvent e)
					{
						one.addElement(e.getText());
					}
				};
			mgr.addStatusEventListener(l);
			mgr.fireStatusEvent(mgr, "One");
			testContext.assertEquals("One", one.firstElement().toString());
			mgr.fireStatusEvent(mgr, "Two");
			testContext.assertEquals(2, one.size());
		}
		/**
		 *  The main program for the Test class
		 *
		 * @param  args The command line arguments
		 */
		public static void main(String[] args)
		{
			com.objectwave.test.TestRunner.run(new Test(), args);
		}

	}
	static class Delegator implements Dispatcher
	{
		/**
		 *  Description of the Method
		 *
		 * @param  listener Description of Parameter
		 * @param  packet Description of Parameter
		 */
		public void dispatch(EventListener listener, EventObject packet)
		{
			((StatusEventListener) listener).updateStatus((StatusEvent) packet);
		}
	}
}
