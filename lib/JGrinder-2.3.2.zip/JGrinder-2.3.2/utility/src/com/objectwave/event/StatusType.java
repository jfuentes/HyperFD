package com.objectwave.event;

/**
*/
public class StatusType
{
	final public static StatusType INFORMATIONAL = new StatusType("Informational");
	final public static StatusType WARNING = new StatusType("Warning");
	final public static StatusType CRITICAL = new StatusType("Critical");

	/**
	*/
	String level;
	/** Private so that no one generates instances of this class.
	*/
	private StatusType(String txt) { level = txt; }
	public String toString(){ return level; }
}