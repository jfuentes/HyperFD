package com.objectwave.exception;
/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */
public class ConfigurationException extends Exception
{
	public ConfigurationException(String message)
	{
		super(message);
	}
}