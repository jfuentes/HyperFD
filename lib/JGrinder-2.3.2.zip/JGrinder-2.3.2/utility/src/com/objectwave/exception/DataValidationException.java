package com.objectwave.exception;
/** 
 * A generic exception to represent any situation that
 * where the provided data is incorrect.
 * @version $Id: DataValidationException.java,v 2.0 2001/06/11 15:46:53 dave_hoag Exp $
 */
public class DataValidationException extends Exception
{
	public DataValidationException( String message)
	{
		super(message);
	}
}
