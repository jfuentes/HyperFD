package com.objectwave.exception;
/**
 * A factory for creating exceptions.
 * @version $Id: ExceptionBuilder.java,v 2.0 2001/06/11 15:46:53 dave_hoag Exp $
 */
public class ExceptionBuilder
{
	/**
	 * Create a SystemException.
	 * @param supportingEvidence If this exception is being translated from
	 * a throwable to a system exception, provide the causing exception.
	 */
	public static SystemException system(Throwable supportingEvidence, String details)
	{
		return new SystemException( supportingEvidence, details );
	}
	public static NotFoundException notFound(String details)
	{
		return new NotFoundException( details );
	}
	public static DataValidationException dataValidation(String details)
	{
		return new DataValidationException( details );
	}
	/**
	 * Throw this exception if there was some problem with the application
	 * was configured.
	 */
	public static ConfigurationException configuration(String details)
	{
		return new ConfigurationException( details );
	}
}
