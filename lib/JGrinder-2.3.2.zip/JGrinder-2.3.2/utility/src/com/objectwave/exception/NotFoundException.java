package com.objectwave.exception;
/** 
 * Generic exception to represent situations when the requested
 * data could not be located.
 *
 * @version $Id: NotFoundException.java,v 2.0 2001/06/11 15:46:53 dave_hoag Exp $
 */
public class NotFoundException extends Exception
{
	public NotFoundException( String message )
	{
		super( message );
	}
}
