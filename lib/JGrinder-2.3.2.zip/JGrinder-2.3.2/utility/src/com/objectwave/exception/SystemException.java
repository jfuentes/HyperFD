package com.objectwave.exception;
/** 
 * Should almost never be used, most system exceptions should 
 * probably really be runtime exceptions of some type. 
 * 
 * @version $Id: SystemException.java,v 2.0 2001/06/11 15:46:53 dave_hoag Exp $
 */
public class SystemException extends Exception
{
	Throwable rootCause;
	public SystemException(String message)
	{
		super(message);
	}
	public SystemException( Throwable cause, String details)
	{
		this( details );
		rootCause = cause;
	}
	/**
	 */
	public Throwable getRootCause()
	{
		return rootCause;
	}
}
