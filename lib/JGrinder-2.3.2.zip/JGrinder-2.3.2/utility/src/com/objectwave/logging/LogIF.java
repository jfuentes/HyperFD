package com.objectwave.logging;
/**
 *  The interface that any 3rd party logging system adapter must implement.
 *
 * @author  Dave Hoag
 * @version  $Id: LogIF.java,v 2.2 2001/10/19 14:15:13 dave_hoag Exp $
 */
public interface LogIF
{
	/**
	 * Run the provided code block and decorate any resulting log messages with
	 * specified category.
	 *
	 * @param  categoryName The 'tracking' name that will be used to follow the call path.
	 * @param  codeBlock The code to execute.
	 * @exception  Exception Any exception could occur while running code!
	 */
	public void track(final String categoryName, final Trace codeBlock) throws Exception;
	/**
	 *  Returns true if "debug" is enabled for the given source object.
	 *
	 * @param  source
	 * @return  The DebugEnabled value
	 */
	public boolean isDebugEnabled(final Object source);
	/**
	 * @param  source
	 * @param  message
	 */
	public void info(final Object source, final String message);
	/**
	 * @param  source
	 * @param  message
	 */
	public void warn(final Object source, final String message);
	/**
	 * @param  source
	 * @param  message
	 * @param  cause
	 */
	public void warn(final Object source, final String message, final Throwable cause);
	/**
	 * @param  source
	 * @param  message
	 */
	public void debug(final Object source, final String message);
	/**
	 * @param  source
	 * @param  message
	 * @param  cause
	 */
	public void debug(final Object source, final String message, final Throwable cause);
	/**
	 * @param  source
	 * @param  message
	 * @param  cause
	 */
	public void error(final Object source, final String message, final Throwable cause);
}
