/*
 *  Copyright (C) 2001 David Hoag
 *  ObjectWave Corporation
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *  For a full copy of the license see:
 *  http://www.opensource.org/licenses/lgpl-license.html
 */
package com.objectwave.logging;

/**
 *  Used within the logging system to "trace" method invocation on
 *  a specific thread by decorating logging messages with a "trace category".
 *  This can be created as an anonymous inner class which is submitted
 *  to the MessageLog class and that executes code to be traced within
 *  it's run() method.
 *
 * @author  dhoag
 * @version  $Id: Trace.java,v 1.2 2001/10/19 14:15:13 dave_hoag Exp $
 */
public interface Trace
{
	/**
	 *  Code to execute that will have all log messages decorated with information.
	 *
	 * @exception  Exception
	 * @see  com.objectwave.logging.MessageLog#track(String,Trace)
	 */
	public void run() throws Exception;
}
