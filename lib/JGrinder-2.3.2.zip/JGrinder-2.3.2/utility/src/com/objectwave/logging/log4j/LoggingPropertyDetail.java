/* Copyright (C) 2001 David Hoag
 * ObjectWave Corporation
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * For a full copy of the license see:
 * http://www.opensource.org/licenses/lgpl-license.html
 */
package com.objectwave.logging.log4j;
import java.io.*;
import java.util.Properties;
import java.util.StringTokenizer;
import org.apache.log4j.Category;
import org.apache.log4j.Priority;
/**
 *  Hold properties related to the configuration of Log4j. If you happen to be
 *  using the default configuration support, a system property of
 *  com.objectwave.logging.log4j.LoggingPropertyDetail.useDefault=false will
 *  result in properties being used for the configuration of log4j. <br>
 *  com.objectwave.logging.log4j.LoggingPropertyDetail.logFileName=fileName will
 *  load the log4j configuration from the specified property file.
 *
 * @author  dhoag
 * @version  $Id: LoggingPropertyDetail.java,v 2.0 2001/06/11 15:46:53 dave_hoag Exp $
 */
public class LoggingPropertyDetail
{
	boolean useDefault = true;
	String fileName;
	String thresholdList;
	Properties props = null;
	boolean initializingLog4j = true;
	/**
	 *  Constructor for the LoggingPropertyDetail object
	 */
	public LoggingPropertyDetail()
	{
		initialize();
	}
	/**
	 *  Must implement this method so that the configuration service will set
	 *  value. Without this method, the configuration service will NOT set property
	 *  values.
	 *
	 * @param  b The new UseDefault value
	 */
	public void setUseDefault(boolean b)
	{
		useDefault = b;
	}
	/**
	 *  Log4j may be initialized by a process other than our MessageLog
	 *  implementation. If that is true, the initializingLog4j property should be
	 *  set to false. By default the MessageLog support in ObjectWave code will
	 *  initialize Log4j.
	 *
	 * @param  b The new InitializingLog4j value
	 */
	public void setInitializingLog4j(boolean b)
	{
		initializingLog4j = b;
	}
	/**
	 *  Set the priority thresholds for the specified categories. ex.
	 *  com.objectwave:debug,com.objectwave.persist:info <br>
	 *  will result in debug being logged for all objectwave packages, except
	 *  persist. Persist will require a minimum of info for the information to be
	 *  logged.
	 *
	 * @param  list A common seperated list of category priority thresholds.
	 */
	public void setThresholdList(final String list)
	{
		thresholdList = list;
		StringTokenizer st = new StringTokenizer(list, ",");
		while(st.hasMoreElements())
		{
			String cat = st.nextToken();
			int idx = cat.indexOf(':');
			if(idx < 1)
			{
				continue;
			}
			//skip this token
			String pri = cat.substring(idx + 1);
			cat = cat.substring(0, idx);
			Priority priority = Priority.toPriority(pri);
			Category category = Category.getInstance(cat);
			category.setPriority(priority);
		}
	}
	/**
	 * @param  file The new FileName value
	 * @exception  IOException
	 */
	public void setFileName(String file) throws IOException
	{
		Properties pr = new Properties();
		FileInputStream fin = new FileInputStream(file);
		BufferedInputStream bin = new BufferedInputStream(fin);
		try
		{
			pr.load(bin);
			props = pr;
		}
		finally
		{
			bin.close();
			fin.close();
		}
	}
	/**
	 *  Get the value of the FileName property
	 *
	 * @return  The FileName value
	 */
	public String getFileName()
	{
		return fileName;
	}
	/**
	 *  Get the Logging threshold configuration
	 *
	 * @return  The ThresholdList value
	 */
	public String getThresholdList()
	{
		return thresholdList;
	}
	/**
	 *  Gets the UsingDefault attribute of the LoggingPropertyDetail object
	 *
	 * @return  The UsingDefault value
	 */
	public boolean isUsingDefault()
	{
		return useDefault;
	}
	/**
	 *  Gets the InitializingLog4j attribute of the LoggingPropertyDetail object
	 *
	 * @return  The InitializingLog4j value
	 */
	public boolean isInitializingLog4j()
	{
		return initializingLog4j;
	}
	/**
	 *  There is no 'set' method for the properties object since the configuration
	 *  service can't set this value.
	 *
	 * @return  The Properties value
	 */
	public Properties getProperties()
	{
		return props;
	}
	/**
	 */
	public void initialize()
	{
		props = System.getProperties();
	}
	/**
	 * @author  dhoag
	 * @version  $Id: LoggingPropertyDetail.java,v 1.2 2001/04/05 22:15:47 dhoag
	 *  Exp $
	 */
	public static class Test extends com.objectwave.test.UnitTestBaseImpl
	{
		/**
		 *  The main program for the Test class
		 *
		 * @param  args The command line arguments
		 */
		public static void main(String[] args)
		{
			com.objectwave.test.TestRunner.run(new Test(), args);
		}
		/**
		 *  A unit test for JUnit
		 */
		public void testBadDataList()
		{
			LoggingPropertyDetail detail = new LoggingPropertyDetail();
			String testList = "com:,com.objectwave,com.objectwave.test:fj,com.good:info, ";
			detail.setThresholdList(testList);
			Category cat = Category.getInstance("com");
			testContext.assertEquals("Default not set to debug.!", Priority.DEBUG, cat.getPriority());
			cat = Category.getInstance("com.objectwave");
			testContext.assertEquals("Skipped not null!", null, cat.getPriority());
			cat = Category.getInstance("com.good");
			testContext.assertEquals("Incorrect Priority!", Priority.INFO, cat.getPriority());
		}
		/**
		 *  A unit test for JUnit
		 */
		public void testSetThresholdList()
		{
			LoggingPropertyDetail detail = new LoggingPropertyDetail();
			String testList = "com:info,com.objectwave:debug";
			detail.setThresholdList(testList);
			Category cat = Category.getInstance("com");
			testContext.assertEquals("Incorrect Priority!", Priority.INFO, cat.getPriority());
			cat = Category.getInstance("com.objectwave");
			testContext.assertEquals("Incorrect Priority!", Priority.DEBUG, cat.getPriority());
		}
	}
}
