/* Copyright (C) 2001 David Hoag
 * ObjectWave Corporation
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * For a full copy of the license see:
 * http://www.opensource.org/licenses/lgpl-license.html
 */
package com.objectwave.logging.log4j;

import com.objectwave.configuration.BasicPropertySource;
import java.util.Properties;
/**
 *  This class is stateless and really acts like a finder for property support.
 *
 * @author  dhoag
 * @version  $Id: LoggingPropertySource.java,v 2.0 2001/06/11 15:46:53 dave_hoag Exp $
 */
public class LoggingPropertySource extends BasicPropertySource
{
	LoggingPropertyDetail propertyDetail;
	/**
	 *  Constructor for the LoggingPropertySource object
	 */
	public LoggingPropertySource()
	{
		initialize();
	}
	/**
	 *  Gets the ExpectedClass attribute of the LoggingPropertySource object
	 *
	 * @return  The ExpectedClass value
	 */
	public Class getExpectedClass()
	{
		return LoggingPropertyDetail.class;
	}
	/**
	 * @return  The Properties value
	 */
	public Properties getProperties()
	{
		return propertyDetail.getProperties();
	}
	/**
	 *  Gets the InitializingLog4j attribute of the LoggingPropertySource object.
	 *  If true, the MessageLog code should initialize the Log4j loggine engine.
	 *
	 * @return  The InitializingLog4j value
	 */
	public boolean isInitializingLog4j()
	{
		return propertyDetail.isInitializingLog4j();
	}
	/**
	 * @return
	 */
	public boolean useDefault()
	{
		return propertyDetail.isUsingDefault();
	}
	/**
	 *  Find our LoggingPropertySourceDetail instance. The PropertyDetail object
	 *  will actually contain the property values.
	 */
	protected void initialize()
	{
		propertyDetail = (LoggingPropertyDetail) getConfigObject();
	}
}
