package com.objectwave.naming;
import com.objectwave.logging.MessageLog;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Properties;
import javax.ejb.EJBHome;
import javax.ejb.EJBObject;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.rmi.PortableRemoteObject;

/**
 * @author  cson
 * @version  $Id: ContextFactory.java,v 1.3 2001/12/21 20:27:54 dave_hoag Exp $
 */
public class ContextFactory
{

	/**
	 */
	public final static String FACTORY_INITIAL = "java.naming.factory.initial";
	/**
	 */
	public final static String PROVIDER_URL = "java.naming.provider.url";
	/**
	 */
	public final static String FACTORY_URL_PKG = "java.naming.factory.url.pkgs";

	private static ContextFactory instance = null;

	private Properties map = null;

	/**
	 *Constructor for the ContextFactory object
	 */
	private ContextFactory()
	{
		map = (Properties) System.getProperties().clone();
	}

	/**
	 *Gets the Instance attribute of the ContextFactory class
	 *
	 * @return  The Instance value
	 */
	public static ContextFactory getInstance()
	{
		if(instance == null)
		{
			instance = new ContextFactory();
		}
		return instance;
	}

	/**
	 *Sets the Property attribute of the ContextFactory object
	 *
	 * @param  name The new Property value
	 * @param  value The new Property value
	 */
	public void setProperty(String name, String value)
	{
		map.put(name, value);
	}

	/**
	 *Gets the InitialContext attribute of the ContextFactory object
	 *
	 * @return  The InitialContext value
	 * @exception  NamingException
	 */
	public Context getInitialContext() throws NamingException
	{
		return new InitialContext(map);
	}

	/**
	 * @param  refName Name of the reference in JNDI
	 * @return  The referenced object
	 * @exception  NamingException
	 */
	public Object lookup(String refName) throws NamingException
	{
		if(refName == null)
		{
			throw new IllegalArgumentException("ejbName cannot be null");
		}

		Context context = getInitialContext();
		return context.lookup(refName);
	}

	/**
	 * @param  refName Name of the reference in JNDI
	 * @param  refClass Class of the referenced object.
	 * @return  The referenced object
	 * @exception  NamingException
	 */
	public Object narrow(String refName, Class refClass) throws NamingException
	{
		if(refName == null)
		{
			throw new IllegalArgumentException("ejbName cannot be null");
		}
		if(refClass == null)
		{
			throw new IllegalArgumentException("ejbClass cannot be null");
		}

		Object ref = lookup(refName);
		return PortableRemoteObject.narrow(ref, refClass);
	}

	/**
	 * @param  refName Name of the reference in JNDI
	 * @param  homeClass Class of the referenced object.
	 * @return  The referenced object
	 * @exception  NamingException
	 */
	public Object create(String refName, Class homeClass) throws NamingException
	{
		if(refName == null)
		{
			throw new IllegalArgumentException("ejbName cannot be null");
		}
		if(homeClass == null)
		{
			throw new IllegalArgumentException("ejbClass cannot be null");
		}

		try
		{
			EJBHome home = (EJBHome) narrow(refName, homeClass);
			Method createMethod = home.getClass().getMethod("create", null);
			return createMethod.invoke(home, null);
		}
		catch(NoSuchMethodException nsme)
		{
			MessageLog.error(this, "NoSuchMethodException trying to execute create() in class " + homeClass.getName() + " :" + nsme.getMessage(), nsme);
			throw new RuntimeException("NoSuchMethodException trying to execute create() in class " + homeClass.getName() + " :" + nsme.getMessage());
		}
		catch(IllegalAccessException iae)
		{
			MessageLog.error(this, "IllegalAccessException trying to execute create() in class " + homeClass.getName() + " :" + iae.getMessage(), iae);
			throw new RuntimeException("IllegalAccessException trying to execute create() in class " + homeClass.getName() + " :" + iae.getMessage());
		}
		catch(InvocationTargetException ite)
		{
			MessageLog.error(this, "InvocationTargetException trying to execute create() in class " + homeClass.getName() + " :" + ite.getMessage(), ite);
			throw new RuntimeException("InvocationTargetException trying to execute create() in class " + homeClass.getName() + " :" + ite.getMessage());
		}
	}

	/**
	 * @param  refName Name of the reference in JNDI
	 * @param  homeClassName
	 * @return  The referenced object
	 * @exception  NamingException
	 */
	public Object create(String refName, String homeClassName) throws NamingException
	{
		if(homeClassName == null)
		{
			throw new IllegalArgumentException("ejbName cannot be null");
		}

		try
		{
			Class homeClass = Class.forName(homeClassName);
			return create(refName, homeClass);
		}
		catch(ClassNotFoundException cnfe)
		{
			MessageLog.error(this, "ClassNotFoundExceptiontrying to execute create() in class " + homeClassName + " :" + cnfe.getMessage(), cnfe);
			throw new RuntimeException("NoSuchMethodException trying to execute create() in class " + homeClassName + " :" + cnfe.getMessage());
		}
	}

}
