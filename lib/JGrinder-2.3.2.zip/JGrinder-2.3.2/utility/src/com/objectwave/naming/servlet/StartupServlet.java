package com.objectwave.naming.servlet;

import com.objectwave.naming.ContextFactory;

/**
 *<servlet>
 *<servlet-name>NamingServlet</servlet-name>
 *<servlet-class>com.objectwave.naming.servlet.StartupServlet</servlet-class>
 *<init-param>
 *<param-name>java.naming.factory.initial</param-name>
 *<param-value>org.jnp.interfaces.NamingContextFactory</param-value>
 *</init-param>
 *<init-param>
 *<param-name>java.naming.provider.url</param-name>
 *<param-value>jnp://localhost:1099</param-value>
 *</init-param>
 *<init-param>
 *<param-name>java.naming.factory.url.pkgs</param-name>
 *<param-value>org.jboss.naming:org.jnp.interfaces</param-value>
 *</init-param>
 *<load-on-startup>1</load-on-startup>
 *</servlet>
 *
 * @author  cson
 * @version  $Id: StartupServlet.java,v 1.1 2001/10/03 14:48:20 dave_hoag Exp $
 */
public class StartupServlet extends javax.servlet.http.HttpServlet
{

	/**
	 */
	public void init()
	{

		ContextFactory cf = ContextFactory.getInstance();
		cf.setProperty(ContextFactory.FACTORY_INITIAL, getInitParameter("java.naming.factory.initial"));
		cf.setProperty(ContextFactory.PROVIDER_URL, getInitParameter("java.naming.provider.url"));
		cf.setProperty(ContextFactory.FACTORY_URL_PKG, getInitParameter("java.naming.factory.url.pkgs"));
	}

}
