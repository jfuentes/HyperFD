package com.objectwave.printerSupport;

import java.awt.*;
import java.awt.event.*;
import java.util.Vector;
import javax.swing.*;

/**
* A generic class that should aid with printing.
*/
public class Printer extends JComponent
{
	Frame f;          //parent frame
	PrintJob pjob;    //printjob object
	Graphics pg;      //printer graphics handle
	Vector objects;   //array of printer instructions
	Point pt;         //current printer position
	Font fnt;         //current font
	Font tabFont;     //font to use in tab calcns

	Graphics gp = null;
	/**
	*/
	public Printer(Frame frm)
	{
		f = frm;          //save form
//        f.add(this);      //add this object to form
		setVisible(false);//but do not show it
		pjob = null;      //no print job yet
		pt =new Point( 0,  0);  //initialize print posn
		objects = new Vector(); //and print objects
		tabFont = new Font("MonoSpaced", Font.PLAIN, 12);
		fnt = new Font("SansSerif", Font.PLAIN, 12);
		setBackground(Color.white);
	}
	/**
	*/
	public void endJob(){   pjob.end();}
	/**
	*/
	public void finalize()
	{
		if (objects.size() > 0)
			newPage();
		endJob();
	}
	/**
	*/
	public Dimension getPreviewPageSize()
	{
		if(pjob != null)
			pjob.end();
		pjob = getToolkit().getPrintJob(f, "Printer", null);
		return pageSize();
	}
	/**
	*/
	public void newLine()
	{
		objects.addElement(new newLine());
	}
	/**  Print the current page and initialize this for a new page.
	*/
	public void newPage()
	{
		if (pjob == null)
		   pjob = getToolkit().getPrintJob(f, "Printer", null);
		pg = pjob.getGraphics();
		print(pg);
		pg.dispose();
		pt = new Point( -10,  0);  //initialize print posn
		objects = new Vector(); //and print objects
	}
	/**
	*/
	public Dimension pageSize()
	{
		if (pjob == null)
			return new Dimension(612, 792);
		else   {
//           pjob = getToolkit().getPrintJob(f, "Printer", null);
		if(true)        return pjob.getPageDimension();
				int pageResolution = getToolkit().getScreenResolution();
				int width = new Double(8.5 * pageResolution).intValue();
				int height = new Double(11 * pageResolution).intValue();
				return new Dimension(width, height);
		   }
	}
	public void paint(Graphics g)
	{
		preview(g);
	}
	/**
	*/
	public void preview()
	{
		new previewFrame(this);
	}
	/**
	*/
	public void preview(Graphics g)
	{
		pt = new Point(0, 0);
		Dimension pageSize = pageSize();
		Image offImage = this.createImage(pageSize.width, pageSize.height);
		Graphics offGraphics = offImage.getGraphics();
		print(offGraphics);      //displays text as preview
		Rectangle r = getBounds();
		g.setColor(Color.black);
		g.fillRect(0,0,r.width, r.height);
		offImage = offImage.getScaledInstance(- 3, r.height-15 , Image.SCALE_FAST);
		g.drawImage(offImage, 5, 5,f);
	}
	/**
	*/
	public void print(Component c)
	{
		objects.addElement(new printComponent(c));
	}
	/**
	*/
	public void print(Graphics g)
	{
		printerObject p;
		f.setFont(fnt);      //always start with some font
		for (int i = 0; i < objects.size(); i ++)  {
			p = (printerObject)objects.elementAt(i);
//            System.out.println("Drawing " + pt);
			p.draw(g, pt);
		}
	}
	/**
	*/
	public void print(Image i)
	{
		objects.addElement(new printImage(i, this));
	}
	/**
	*/
	public void print(String s)
	{
		objects.addElement(new printString(s));
	}
	/**
	*/
	public void print(String s, int limit)
	{
		objects.addElement(new printString(s, tabFont, limit));
	}
	/**
	*/
	public void println(String s)
	{
		print(s);
		newLine();
	}
	/**
	*/
	public void setFont(Font f)
	{
		objects.addElement(new printFont(f));
	}
	/**
	*/
	public void tab(int tabstop)
	{
		objects.addElement(new printTab(tabFont, tabstop));
	}
}  //end class
