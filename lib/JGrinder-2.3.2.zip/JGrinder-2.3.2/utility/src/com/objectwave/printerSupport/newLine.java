package com.objectwave.printerSupport;

import java.awt.Graphics;
import java.awt.Point;

//===================================================
public class newLine extends printerObject{
 //---------------------------------------------------
   public void draw(Graphics g, Point p){
		p.x = 0;
		p.y += g.getFontMetrics(g.getFont()).getHeight();
	}
}