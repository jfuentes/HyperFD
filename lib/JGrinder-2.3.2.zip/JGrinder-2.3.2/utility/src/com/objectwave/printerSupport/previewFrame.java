package com.objectwave.printerSupport;

import java.awt.*;
import java.awt.event.*;
import java.util.Vector;
import javax.swing.*;

/******************************************************************************
*
*  Class for previewing a print job.
*
*******************************************************************************/
class previewFrame extends JFrame implements ActionListener, WindowListener
{
	JButton b, close;
	Printer printer;
	/**
	*/
	public previewFrame(Printer print)
	{
		super("print test");           //frame title;
		addWindowListener(this);
		JPanel p = new JPanel();         //spaces buttons
		getContentPane().add("South", p);
		b = new JButton("Print");               //2 buttons
		p.add("South", b);
		b.addActionListener(this);
		close = new JButton("Close");
		p.add(close);
		close.addActionListener(this);
		printer = print;   //printer added
		getContentPane().add("Center", printer);
		setBounds(100,100,200,300);
		setVisible(true);

		showPreview(); //or on screen
	}
	/**
	*/
	public void actionPerformed(ActionEvent ev)
	{
		Object obj = ev.getSource();
		if (obj == b) {
			printer.pt =new Point( 0,  0);  //initialize print posn
			printer.newPage();     //print on page
			printer.endJob();
			close();
		}
		if (obj == close) {
			close();
		}
	}
	/**
	*/
	public void close()
	{
		processWindowEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING));
	}
	/**
	*/
	private void showPreview()
	{
		Dimension d = printer.pageSize();
//        setBounds(0 , 0, d.width / 2, d.height / 2);
//        printer.setBounds(0, 0, d.width / 2, d.height / 2);
		printer.setVisible(true);
		printer.revalidate();
		repaint();
	}
	public void windowActivated(WindowEvent wEvt){}
	public void windowClosed(WindowEvent wEvt){}
	/**
	*/
	public void windowClosing(WindowEvent wEvt)
	{
//        System.exit(0);   //exit on System exit box clicked
		setVisible(false);
		dispose();
	}
	public void windowDeactivated(WindowEvent wEvt){}
	public void windowDeiconified(WindowEvent wEvt){}
	public void windowIconified(WindowEvent wEvt){}
	public void windowOpened(WindowEvent wEvt){}
}
