package com.objectwave.printerSupport;

import java.awt.Graphics;
import java.awt.Point;
import java.awt.Component;
import java.awt.Rectangle;
import java.awt.Color;

/** 
* IT IS VERY IMPORTANT THAT A COMPONENT'S BOUNDS BE SET CORRECTLY.
* Failure to do so will cause this to fail.
*/
class printComponent extends printerObject
{
	Component comp;
	
	/**
	*/
	public printComponent(Component s)
	{
		comp = s;
	}
	/**
	* Do not attempt to print components. It is not working as you would
	* hope.
	*/
	public void draw(Graphics g, Point p)
	{
		Rectangle r = comp.getBounds();
		Rectangle origClip = g.getClipBounds();
		g.translate(p.x, p.y);
		g.setClip(0, 0, r.width, r.height);

		java.awt.Frame f = null;
		if(! comp.isValid())
		{
			f = new java.awt.Frame();
//            f.setBounds(100,100, r.width, r.height);
			f.setBounds(-r.width,-r.height, r.width, r.height);
			f.setLayout(new java.awt.BorderLayout());
			f.add(comp, java.awt.BorderLayout.CENTER);
			f.setVisible(true);
		}

		comp.paint(g);
		if(f != null)
			f.setVisible(false);

		g.translate(-p.x, -p.y);
		p.x += r.width;
		p.y += r.height;
		if(origClip == null)
			g.setClip(null);
		else
			g.setClip(origClip.x, origClip.y, origClip.width, origClip.height);
	}
}