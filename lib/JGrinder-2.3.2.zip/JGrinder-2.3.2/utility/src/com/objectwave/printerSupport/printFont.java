package com.objectwave.printerSupport;

import java.awt.Graphics;
import java.awt.Point;
import java.awt.Font;

//===================================================
class printFont extends printerObject{
	Font fnt;
	public printFont(Font f){
		fnt = f;
	}
	//--------------------------------------------------
	public void draw(Graphics g, Point p) {
		g.setFont(fnt);
		if (p.y <= 0)
			p.y = g.getFontMetrics(fnt).getHeight();
	}
}