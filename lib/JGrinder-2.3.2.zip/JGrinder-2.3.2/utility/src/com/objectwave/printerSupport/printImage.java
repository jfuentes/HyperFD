package com.objectwave.printerSupport;

import java.awt.Graphics;
import java.awt.Point;
import java.awt.Image;
import java.awt.image.ImageObserver;
import java.awt.Color;

//=====================================================
class printImage extends printerObject{
	Image i;
	ImageObserver observer;
	public printImage(Image s, ImageObserver f)   {
		i = s;
		observer = f;
	}
   //-------------------------------------------------
	public void draw(Graphics g, Point p) {
		g.drawImage(i, p.x, p.y, observer);
		while(i.getHeight(observer) < 0){}
		p.x += i.getWidth(observer);
		p.y += i.getHeight(observer);
	}
}