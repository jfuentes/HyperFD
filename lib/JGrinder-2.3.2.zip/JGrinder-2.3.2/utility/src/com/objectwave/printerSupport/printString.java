package com.objectwave.printerSupport;

import java.awt.Graphics;
import java.awt.Point;
import java.awt.Font;

/**
*/
class printString extends printerObject
{
	String st;
	int limit = -1;
	static int tab_width = 0;
	java.awt.Font tabFont;

	/**
	*/
	public printString(String s)
	{
		st = s;
	}
	/**
	*/
	public printString(String s, Font fnt, int limit)
	{
		this(s);
		this.limit = limit;
		this.tabFont = fnt;
	}
	/**
	*/
	public void draw(Graphics g, Point p)
	{
		String output = st;
		if(limit > 0)
		{
			if (tab_width == 0)
				tab_width = g.getFontMetrics(tabFont).stringWidth("W");
			int endAt = p.x + g.getFontMetrics(g.getFont()).stringWidth(output);
			int tab_distance = limit * tab_width;
			if(p.x > tab_distance) return;//We've exceeded our limit. Just return.
			if(endAt > tab_distance)
			{
				output = output.trim();
				endAt = p.x + g.getFontMetrics(g.getFont()).stringWidth(output);
			}
			while(endAt > tab_distance)
			{
				output = output.substring(0, output.length() -1);
				endAt = p.x + g.getFontMetrics(g.getFont()).stringWidth(output);
			}
		}
		g.drawString(output, p.x, p.y);
		p.x += g.getFontMetrics(g.getFont()).stringWidth(output);
	}
}