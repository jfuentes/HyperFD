package com.objectwave.printerSupport;

import java.awt.Graphics;
import java.awt.Font;
import java.awt.Point;

/**
*/
class printTab extends printerObject
{
	static int tab_width = 0;
	int tab_dist;
	Font tabFnt;

	/**
	*/
	public printTab(Font tbFont, int tabdist)
	{
	   tabFnt = tbFont;
	   tab_dist = tabdist;
	}
	/**
	*/
	public void draw(Graphics g, Point p)
	{
		if (tab_width == 0)
			tab_width = g.getFontMetrics(tabFnt).stringWidth("W");
//System.out.println("Tabbing " + tab_dist + " tab_width: " + tab_width + " total: "  +  tab_dist*tab_width);
		if (p.x < (tab_dist*tab_width))
		{
//System.out.println("Advancing p.x " + p.x + " " + (tab_dist * tab_width));
			p.x = tab_dist * tab_width;
		}
//        else
//            System.out.println("Keeping p.x " + p.x + " " + (tab_dist * tab_width));
	}
}