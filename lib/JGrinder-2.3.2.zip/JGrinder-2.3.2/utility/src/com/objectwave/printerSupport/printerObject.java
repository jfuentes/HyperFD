package com.objectwave.printerSupport;

import java.awt.Graphics;
import java.awt.Point;

//===================================================
public abstract class printerObject{
	abstract void draw(Graphics g, Point p);
}