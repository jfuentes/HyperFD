package com.objectwave.printerSupport;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
//import com.objectwave.drawPad.OWConnectorFrame;
//import com.objectwave.drawPad.OWDiagrammer;

public class printing extends Frame  implements ActionListener, WindowListener
{
   Button b, show;
   Printer printer;
   JButton test;
//   OWConnectorFrame fff = new OWConnectorFrame();
//---------------------------------------------------
	public printing()   {
		super("print test");           //frame title;
		addWindowListener(this);
		Panel p = new Panel();         //spaces buttons
		add("South", p);
		b = new Button("Print");               //2 buttons
		p.add("South", b);
		b.addActionListener(this);
		show = new Button("Show");
		p.add(show);
		show.addActionListener(this);
		printer = new Printer(this);   //printer added
		add("Center", printer);
		setBounds(100,100,100,100);
		setVisible(true);
		loadStrings();                 //do printing here
	}
//---------------------------------------------------
	public void actionPerformed(ActionEvent ev) {
		Object obj = ev.getSource();
		if (obj == b) {
			printer.newPage();     //print on page
			printer.endJob();
		}
		if (obj == show) {
			showPreview(); //or on screen
		}
   }
//---------------------------------------------------
private void loadStrings(){ //puts the text into the Printer object
	int i = 1;
	printer.setFont(new Font("SanSerif", Font.PLAIN, 12));
	printer.print(i++ +".");
	printer.tab(10);
	printer.println("Hello printer");
	printer.print(i++ +".");
	printer.tab(10);
	printer.setFont(new Font("SanSerif", Font.BOLD, 12));
	printer.println("A bold stroke");
	printer.print(i++ +".");
	printer.tab(10);
	printer.setFont(new Font("SanSerif", Font.ITALIC, 18));
//	OWDiagrammer diag = new OWDiagrammer();
//	diag.show();
//	diag.setSize(100, 100);
//	diag._diagrammer.add(diag.createTestFrame());
	printer.newLine();
//	printer.print(diag._diagrammer);
	printer.println("but emphatic");
}
//---------------------------------------------------
	static public void main(String argv[])   {
		new printing();
	}
//---------------------------------------------------
	private void showPreview()   {
		Dimension d = printer.pageSize();
//        setBounds(0 , 0, d.width / 2, d.height / 2);
//        printer.setBounds(0, 0, d.width / 2, d.height / 2);
		printer.setVisible(true);
		doLayout();
		repaint();
	}
	public void windowActivated(WindowEvent wEvt){}
	public void windowClosed(WindowEvent wEvt){}
   //-------------------------------------------------
	public void windowClosing(WindowEvent wEvt)   {
		System.exit(0);   //exit on System exit box clicked
	}
	public void windowDeactivated(WindowEvent wEvt){}
	public void windowDeiconified(WindowEvent wEvt){}
	public void windowIconified(WindowEvent wEvt){}
	public void windowOpened(WindowEvent wEvt){}
}