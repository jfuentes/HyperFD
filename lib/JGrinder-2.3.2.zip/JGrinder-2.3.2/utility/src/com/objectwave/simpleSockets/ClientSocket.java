package com.objectwave.simpleSockets;

import java.awt.*;
import java.io.*;
import java.net.*;

/**
* A Socket Wrapper class.
* @version 1.5.1
*/
public class ClientSocket
{

	int port = 3000;  // Default port of 3000
	private DataInputStream dis = null;
	private BufferedInputStream bufin = null;
	private Socket socket;
	private BufferedOutputStream bufout = null;
	private DataOutputStream output;
	boolean debug = System.getProperty("ow.serverVerbose") != null;
	private ObjectOutputStream oos = null;
	private ObjectInputStream ois = null;

	/**
	 * There just may be a need to get to the actual socket.
	 */
	public Socket getSocket()
	{
		return socket;
	}
	/**
	 */
	public BufferedOutputStream getBufferedOutputStream()
	{
		return bufout;
	}
	/**
	 */
	public BufferedInputStream getBufferedInputStream()
	{
		return bufin;
	}
	/**
	 */
	public ClientSocket(String host, int port) throws IOException
	{
		this(new Socket(host, port));
		this.port = port;
	}
	/**
	 */
	public ClientSocket(InetAddress addr, int port) throws IOException
	{
		this(new Socket(addr, port));
		this.port = port;
	}
	/** 
	 */
	public ClientSocket(Socket sock) throws IOException
	{
		this.socket = sock;
		dis = new DataInputStream(bufin = new BufferedInputStream
							(sock.getInputStream()));
		output  = new DataOutputStream
					(bufout = new BufferedOutputStream
							(sock.getOutputStream()));
	}
	public ClientSocket(URL url, int port) throws IOException
	{
		if( url.getProtocol().equals("file"))
			setSocket("localhost", port);
		else
			setSocket(url.getHost(), port);
	}
	public void close() throws IOException
	{
		if(output != null)
			//Try to be nice and notify of disconnect.
			try {
				output.writeInt(0);
				output.flush();
			} catch(Exception e) {}
		if(socket != null)
			socket.close();
	}
	protected void finalize() throws IOException
	{
		this.close();
	}
	/**
	* Methods to test client socket.
	*/
	public static void main(String args[])
	{

		System.out.println("simple console application");
		System.out.println("");
		System.out.println("(About to establish socket)");
		try{
			ClientSocket cs;
			if(args.length < 1)
				cs = new ClientSocket("localhost", 3000);
			else
				cs = new ClientSocket(args[0], 3000);
			cs.testSocketStuff();
		} catch(IOException e) { System.err.println(e); }
	}
	/**
	*/
	public int readInt() throws IOException
	{
		return dis.readInt();
	}
	/**
	*/
	public Object readObject() throws IOException, ClassNotFoundException
	{
		if(ois == null) {
			ois = new ObjectInputStream(dis);
		}
		return ois.readObject();
	}
	/**
	 * Read an unknown amount of bytes from the socket and write them onto the
	 * provided output stream.
	 */
	public synchronized void readOntoStream(OutputStream outStream) throws IOException
	{
		for(int res = dis.readInt(); res > 0; res = dis.readInt())
		{
			byte [] b = new byte [res];
			if(debug) System.out.println("Reading bytes " + res);
			dis.readFully(b);
			outStream.write(b);
			outStream.flush();
		}
	}
	/**  I could have used readUTF, but this implementation allows for lengths
	* requiring 4 bytes.
	*/
	public String readString() throws IOException
	{
   // This method will retrieve information from the socket.
   // The assumption is that every request starts with a 4 byte
   // description of the length of the record followed by the
   // string record.
/*        byte b[] = new byte[4];
		int a = dis.available();
		while(a  < 4)
			a = dis.available();
		dis.read(b);

		int res  = b[3] & 0xFF;
		res |= ((b[2] << 8) & 0xFF00);
	    res |= ((b[1] << 16) & 0xFF0000);
		res |= ((b[0] << 24) & 0xFF000000);
*/
		int res = dis.readInt();
		if(debug) System.out.println("Read string length " + res );

		// No data to retrieve.  Used to signal terminating connection.
		if(res == 0){
//Throw exception. 2/12/98            
			throw new EOFException("No more data to retrieve");
//            return null;
		}
		StringBuffer buf = new StringBuffer(res);
//FIXME: DAH - Is this the most efficient? Probably not.
		for(int i = 0; i < res; i++){
//FIXME: DAH -  I should probably time out this loop.
			while(dis.available() < 0) {};
			buf.append(dis.readChar());
		}
		String result = buf.toString();
		if(debug) System.out.println("String: " + result );
		return result;
	}
	private void setSocket(String host, int port) throws IOException
	{
		this.socket = new Socket(host, port);
		dis = new DataInputStream(bufin = new BufferedInputStream
							(socket.getInputStream()));
		output  = new DataOutputStream
					(bufout = new BufferedOutputStream
							(socket.getOutputStream()));
		ois = null;
		oos = null;
	}
	public void testSocketStuff()
	{
		String dataString = "This is a test";

		try {
			this.writeString(dataString);
			String res = this.readString();
			System.out.println(res);
			this.close();
		} catch (Exception e) { System.err.println(e.toString()); }

	}
	public synchronized void write(byte b[], int off, int len) throws IOException
	{
		output.writeInt(len);
		if(debug) System.out.println("Writing " + len + " Bytes");
		output.write(b, off, len);
		output.flush();
	}
	public void writeByte(int data) throws IOException
	{
		output.writeByte(data);
		output.flush();
	}
	/**
	* Read from the provided input stream and write the results on the socket.
	*/
	public synchronized void writeFromStream(InputStream inStream) throws IOException 
	{
		BufferedInputStream buffi = new BufferedInputStream(inStream);
		byte [] b = new byte [1024];
		for(int i = buffi.read(b); i > 0;  i = buffi.read(b) ){
			write(b, 0, i);
		}
		output.writeInt(0); // Let him know I am done.
		output.flush();
	}
	public void writeInt(int data) throws IOException
	{
		output.writeInt(data);
		output.flush();
	}
	/**
	*/
	public void writeObject(Object obj)throws IOException
	{
		if(oos == null) oos = new ObjectOutputStream(output);
		oos.writeObject(obj);
		oos.flush();
	}
	public void writeString(String dataString) throws IOException
	{
		output.writeInt(dataString.length());
		if(debug) System.out.println("Writing string length " + dataString.length() + ": \"" + dataString + "\"");
		output.writeChars(dataString);
		output.flush();
	}
}