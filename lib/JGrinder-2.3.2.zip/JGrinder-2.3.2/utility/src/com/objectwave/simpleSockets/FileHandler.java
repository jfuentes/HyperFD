package com.objectwave.simpleSockets;
import java.io.*;
/**
 * Use the class as a parameter to SimpleHTTP to create a trivial web server.
 * 
 * @author Dave Hoag
 * @version 1.1
 */
public class FileHandler implements ReplyHandler
{
	/**
	 * A convienence method to start the SimpleHTTP server.
	 * A single parameter of the port number could be provided as an argument.
	 */
	public static void main(String [] args)
	{
		int portNum = 80;
		if(args.length == 1)
		try
		{
			portNum = Integer.valueOf(args[0]).intValue();
		}
		catch(Throwable t) {} //don't really care
		String [] newArgs = new String [2];
		newArgs[0] = String.valueOf(portNum);
		newArgs[1] = "com.objectwave.simpleSockets.FileHandler";
		SimpleHTTP.main(newArgs);
	}
	/**
	 * Implement the ReplyHandler interface to return a file that matches the request.
	 * @param request String A file name
	 * @return InputStream The file as an input stream.
	 */
    public InputStream processRequest(String request)
	{
		try
		{
			File file = new File(".", request);
			return  new FileInputStream(file);
		}
		catch(Throwable t) { t.printStackTrace(); }
		return new StringBufferInputStream("");
	}
}
