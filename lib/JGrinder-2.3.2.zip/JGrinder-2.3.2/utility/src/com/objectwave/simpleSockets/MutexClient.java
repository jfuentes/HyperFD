package com.objectwave.simpleSockets;

import java.net.*;
import java.io.*;
import java.util.*;
import com.objectwave.utility.ObjectHolder;
import javax.swing.JOptionPane;
/**
*/
public class MutexClient extends WatchdogClient
{
	private static ObjectHolder staticInstance = new ObjectHolder(); //MutexClient staticInstance = null;
	
	public MutexClient() throws IOException
	{
		this("127.1.1.1", MutexServer.getDefaultPort());
	}
	public MutexClient(String host) throws IOException
	{
		this(host, MutexServer.getDefaultPort());
	}
	public MutexClient(String host, int port) throws IOException
	{
		super(host, port);
	}
	public static MutexClient getStaticInstance()
	{
		synchronized(staticInstance)
		{
			System.out.println("Return the static MutexClient (is it null?) " + (staticInstance.getObject()==null));
			System.out.println("This is thread \"" + Thread.currentThread().getName() + "\"");
			return (MutexClient)staticInstance.getObject();
		}
	}
	public boolean goodbye() throws IOException
	{
		return super.goodbye();
	}
	public static void main(String args[])
	{
		System.out.println("We expect a MutexServer to @ localhost,port#" + MutexServer.getDefaultPort());
		try
		{
			MutexClient mutex2 = new MutexClient();
			System.out.println("Created another mutex client, id = " + mutex2.getId());
			System.out.println("Requesting ownership of string \"hello\".");
			if (mutex2.request("hello"))
				System.out.println("Request was granted.");
			else
				System.out.println("Request was denied.");
			System.out.println("Sleep for 10 seconds.");
			try { Thread.sleep(10000); } catch (InterruptedException e) {}
			
			if (args.length > 0 && args[0].equalsIgnoreCase("die"))
			{
				System.out.println("Abort.");
				return;
			}
			
			System.out.println("Release the string \"hello\".");
			mutex2.release("hello");
			System.out.println("Sleep for 10 seconds.");
			try { Thread.sleep(10000); } catch (InterruptedException e) {}
			System.out.println("Say goodbye!");
			if (!mutex2.goodbye())
				System.out.println("Saying goodbye failed.");
		}
		catch (IOException ex)
		{
			System.out.println("Error: " + ex);
		}
	}
	public void release(String string) throws IOException
	{
		synchronized(clientSock)
		{
			if (sock == null)
				return;
			clientSock.writeString("release:" + string);
		}
	}
	public void releaseAll() throws IOException
	{
		synchronized(clientSock)
		{
			if (sock == null)
				return;
			clientSock.writeString("releaseAll");
		}
	}
	public boolean request(String string) throws IOException
	{
		return request(string, 0);
	}
	protected boolean request(String string, int strike) throws IOException
	{
		if (sock == null)
			return false;
		synchronized(clientSock)
		{
			clientSock.writeString("request:" + string);
			String response = "";
			try { Thread.sleep(750); }  // give the server .75s to respond.
			catch (InterruptedException e) {}
			try
			{
				response = clientSock.readString();
			}
			catch (java.io.EOFException ex)
			{
				++strike;
				System.err.println("Mutex server response error (strike " + strike + "): " + ex);
				System.out.println("(response = \"" + response + "\")");
				if (strike == 3)
				{
					JOptionPane.showMessageDialog(
						null, "Communications error w/ mutex server. (try again)", 
						"Couldn't gain access to quote", JOptionPane.ERROR_MESSAGE);
					try { release(string); } // We try to release.
					catch (IOException e) { }
					throw ex;
				}
				try { Thread.sleep((strike*1000)); } 
				catch (InterruptedException e) {}
				return request(string, strike);
			}
			if (response.equalsIgnoreCase("granted"))
				return true;
			if (response.equalsIgnoreCase("denied"))
				return false;
			throw new IOException("Unknown response from server: \"" + response + "\"");
		}
	}
	public static void setStaticInstance(MutexClient client)
	{
		synchronized(staticInstance)
		{
			System.out.println("The static instance is null? " + (client==null));
			System.out.println("This is thread \"" + Thread.currentThread().getName() + "\"");
			staticInstance.setObject(client);
		}
	}
}
