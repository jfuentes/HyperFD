package com.objectwave.simpleSockets;
/**
 * Implementers of this interface can plug into the SimpleServer framework.
 * @version 1.0
 */
public interface ReplyHandler
{
    public java.io.InputStream processRequest(String request);
    
}
