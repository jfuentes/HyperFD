package com.objectwave.simpleSockets;

import java.net.*;
import java.util.*;
import java.io.*;
/**
 * A VERY simple server.
 * @author Dave Hoag
 * @version 2.0
 */
public class SimpleHTTP extends SimpleServer
{
    static ReplyHandler replyHandler;
	Socket boundSocket;
	private Vector clients = new Vector();
	/**
	 */
	public SimpleHTTP()
	{
		boundSocket = null;
	}
	/**
	 */
	public SimpleHTTP(int port)
	{
		this();
		if(port > 0)
		{
			port(port);
			return;
		}
		String str = (String)System.getProperty("ow.serverPort");
		if(str != null)
		{
			port(new Integer(str).intValue());
		}
	}
	/**
	 * Override this method if you don't want to do anything special with the
	 * handling of clients.  Just return your ServerClient object.
	 */
	public ServeClient getClientServer(SimpleServer svr, int count, Thread thread)
	{
		try
		{
			ServeHTTPClient serveHTTPClient = new ServeHTTPClient(svr, count, thread);
			if(replyHandler != null) //Don't want to corrupt the ServeHTTPClient value
			{
				serveHTTPClient.setReplyHandler(replyHandler);
			}
			return serveHTTPClient;
		}
		catch (Throwable t) { t.printStackTrace(); return null; }
	}
	/**
	 * This method should be overriden to create an instance
	 * of your SimpleServer.  It should look the same xcept it should
	 * Specify new <YourServer>.startServer();
	 */
	public static void main(String args[])
	{
		System.out.println("SimpleHTTP server");
		System.out.println("");
		if(args.length > 0)
        {
            if(args.length > 1)
            try
            {
                Class c = Class.forName(args[1]);
                replyHandler = (ReplyHandler)c.newInstance();
            }
            catch(Exception e) { e.printStackTrace(); }
			new SimpleHTTP(new Integer(args[0]).intValue()).startServer();
        }
		else
			new SimpleHTTP().startServer();
	}
}
