package com.objectwave.simpleSockets;

import com.objectwave.utility.ThreadPoolManager;
import java.awt.*;
import java.io.*;
import java.net.*;
import com.objectwave.logging.MessageLog;
/**
 *  A Server shell for providing multithreaded application servers.
 *
 * @author  dhoag
 * @version  $Id: SimpleServer.java,v 2.0 2001/06/11 15:46:53 dave_hoag Exp $
 */
public class SimpleServer implements Runnable
{
	public static int count = 1;
	static int numberOfThreads = 20;
	final static String version = "1.5.2";
	static int QUEUELENGTH = 128;
//	final static boolean verbose = System.getProperty("ow.serverVerbose") != null;
	SocketProperty props;
	ThreadPoolManager threadPool;

	ServerSocket socket = null;
	int port = 3000;
	Thread thread = null;
	boolean finishing = false;

	/**
	 */
	public SimpleServer()
	{
		threadPool = new ThreadPoolManager(20);
		props = new SocketProperty();
	}
	/**
	 *  This method should be overriden to create an instance of your SimpleServer.
	 *  It should look the same xcept it should Specify new <YourServer>
	 *  .startServer();
	 *
	 * @param  args
	 */
	public static void main(String args[])
	{
		System.out.println("simple console application");
		System.out.println("");
		new SimpleServer().startServer();
	}
	/**
	 *  Override this method if you don't want to do anything special with the
	 *  handling of clients. Just return your ServerClient object.
	 *
	 * @param  svr
	 * @param  count
	 * @return  The ClientServer value
	 */
	public ServeClient getClientServer(SimpleServer svr, int count)
	{
		return new ServeClient(svr, count);
	}
	/**
	 * @param  svr
	 * @param  count
	 * @param  t
	 * @return  The ClientServer value
	 */
	public ServeClient getClientServer(SimpleServer svr, int count, Thread t)
	{
		return new ServeClient(svr, count, t);
	}
	/**
	 *  handleConnection: Key method for starting server clients.
	 *
	 * @param  newSocket
	 */
	public void handleConnection(Socket newSocket)
	{
		if( props.getServerVerbose() )
		{
			System.out.println("Handling connection request " + Thread.currentThread());
		}
		Runnable r = getHandleConnectionRunnable(newSocket);
		threadPool.start(r);
	}
	/**
	 *  Use the thread pool to start a thread.
	 *
	 * @param  r
	 */
	public void startThread(Runnable r)
	{
		threadPool.start(r);
	}
	/**
	 *  Change the default port of 3000 to the value provided by the parameter.
	 *
	 * @param  port
	 */
	public void port(int port)
	{
		this.port = port;
	}
	/**
	 *  Just loop and listen for client requests.
	 */
	public void run()
	{
		// Emit some traces before starting up:
		try
		{
			InetAddress addr = InetAddress.getLocalHost();
			String hostName = addr.toString();
			System.out.println("Simple Server[" + version + "]" + ": serving at " + hostName + " on port " + port);
		}
		catch(UnknownHostException e)
		{
		}
		// No big deal. Just ignore it.
		System.out.flush();
		errorlog("started at: " + new java.util.Date() + " on thread: " + Thread.currentThread());

		try
		{
			this.initializeServerSocket();
		}
		catch(IOException e)
		{
			return;
		}

		// Enter the evil loop:
		while((!finishing) && (socket != null))
		{
			Socket ns = null;
			try
			{
				ns = socket.accept();
			}
			catch(IOException e)
			{
				e.printStackTrace();
				errorlog("failed to accept incoming connection on " + socket);
			}

			if((socket != null) && (ns != null))
			{
				this.handleConnection(ns);
			}

			if( props.getServerVerbose() )
			{
				MessageLog.info(this, "Waiting for next connection request");
			}
		}
		MessageLog.info(this, "Completed serving duties.");
	}
	/**
	 * Start up the socket server.
	 */
	public void startServer()
	{
		if( props.getServerVerbose() )
		{
			MessageLog.info(this, "(Starting Server)");
		}
		try
		{
			this.initializeThread();
		}
		catch(Exception e)
		{
			return;
		}
	}
	/**
	 *  Gets the ClientThreadPriority attribute of the SimpleServer object
	 *
	 * @return  The ClientThreadPriority value
	 */
	protected int getClientThreadPriority()
	{
		return Thread.NORM_PRIORITY;
	}
	/**
	 * @param  aString
	 */
	protected void errorlog(String aString)
	{
		System.err.println(aString);
	}
	/**
	 * @param  newSocket
	 * @return  The HandleConnectionRunnable value
	 */
	Runnable getHandleConnectionRunnable(final Socket newSocket)
	{
		return
			new Runnable()
			{
				/**
				 *  Main processing method for the SimpleServer object
				 */
				public void run()
				{
					ServeClient cs = getClientServer(SimpleServer.this, count++, Thread.currentThread());
					try
					{
						cs.bind(newSocket);
					}
					catch(IOException e)
					{
						System.err.println(e);
					}
					cs.run();
				}
			};
	}
	/**
	 * @exception  IOException
	 */
	private void initializeServerSocket() throws IOException
	{
		try
		{
			this.socket = new ServerSocket(port, QUEUELENGTH);
		}
		catch(IOException ex)
		{
			String err = ("Unable to create server socket on port " + port
					 + " details:\r\n" + ex.getMessage());
			System.err.println(err);
			throw ex;
		}
	}
	/**
	 */
	private void initializeThread()
	{
		this.thread = new Thread(this);
		this.thread.setName("MainThread");
		this.thread.setPriority(Thread.MAX_PRIORITY);
		this.thread.start();
	}
	static
	{
		try
		{
			String count = System.getProperty("ow.serverThreadCount");
			if(count != null)
			{
				numberOfThreads = Integer.parseInt(count);
			}
		}
		catch(Exception e)
		{
		}
	}
}
