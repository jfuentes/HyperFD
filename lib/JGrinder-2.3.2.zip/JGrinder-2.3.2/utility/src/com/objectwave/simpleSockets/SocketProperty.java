package com.objectwave.simpleSockets;
import com.objectwave.configuration.BasicPropertySource;
/**
 * This is the class from which our simpleSocket server will get properties.
 * This class is stateless and really acts like a finder for property support.
 *
 * @author  dhoag
 * @version  $Id: SocketProperty.java,v 2.0 2001/06/11 15:46:53 dave_hoag Exp $
 */
public class SocketProperty extends BasicPropertySource
{
	SocketPropertyDetail socketPropertyDetail;
	public Class getExpectedClass()
	{
		return SocketPropertyDetail.class;
	}
	/**
	 *  Constructor for the SocketProperty object
	 */
	public SocketProperty()
	{
		initialize();
	}
	/**
	 * Find our SocketPropertyDetail instance.
	 * The PropertyDetail object will actually contain the property values.
	 */
	protected void initialize()
	{
		socketPropertyDetail = (SocketPropertyDetail)getConfigObject();
	}
	/**
	 * Should the server log lots of messages?
	 */
	public boolean getServerVerbose()
	{
		return socketPropertyDetail.getServerVerbose();
	}
}