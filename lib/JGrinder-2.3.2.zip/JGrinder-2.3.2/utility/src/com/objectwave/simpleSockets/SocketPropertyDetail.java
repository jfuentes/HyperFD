package com.objectwave.simpleSockets;
/**
 *  This may be a generated class.
 *
 * @author  dhoag
 * @version  $Id: SocketPropertyDetail.java,v 2.0 2001/06/11 15:46:53 dave_hoag Exp $
 */
public class SocketPropertyDetail
{
	protected boolean serverVerbose;
	/**
	 *  Constructor for the SocketPropertyDetail object
	 */
	public SocketPropertyDetail()
	{
	}
	/**
	 *  Gets the ServerVerbose attribute of the SocketPropertyDetail object
	 *
	 * @return  The ServerVerbose value
	 */
	public boolean getServerVerbose()
	{
		return serverVerbose;
	}
	public void setServerVerbose( boolean bValue )
	{
		serverVerbose = bValue;
	}
}
