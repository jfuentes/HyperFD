package com.objectwave.simpleSockets;

import java.net.*;
import java.io.*;
import java.util.*;

class WatchdogClient
{
	protected Random random = new Random(new Date().getTime());
	protected int port = -1;
	protected Socket sock = null;
	protected ClientSocket clientSock = null;
	private   long id=-1;
	private   Thread pongThread;
	private   Boolean stopPongThread = new Boolean(false);

	private class Pong implements Runnable
	{
		public void run()
		{
			System.out.println("Started ping/pong thread for the remote mutex server.");
			for (;;)
			{
				try { Thread.sleep(10000); } 
				catch (InterruptedException e) { }
				synchronized(stopPongThread)
				{
					if (stopPongThread.booleanValue())
					{
						break;
					}
					if (sock != null)
					{
//                        System.out.println("Sending \"pong\" to remote mutex server.");
						synchronized(clientSock)
						{
							try { clientSock.writeString("pong"); }
							catch (IOException e)
							{
								System.out.println("Exception sending \"pong\" to remote mutex server: " + e); 
							}
						}
					}
				}
			}
			System.out.println("Closing ping/pong thread for the remote mutex server.");            
		}
	}
	public WatchdogClient() throws IOException
	{
		this("127.1.1.1", WatchdogServer.getDefaultPort());
	}
	public WatchdogClient(String host) throws IOException
	{
		this(host, WatchdogServer.getDefaultPort());
	}
	public WatchdogClient(String host, int port) throws IOException
	{
		genId();
		System.out.println("This process's remote server id is " + id + ".");
		this.port = port;
		try
		{
			sock = new Socket(host, this.port);
			clientSock = new ClientSocket(sock);

			String idStr = Long.toString(getId());
			synchronized(clientSock)
			{
				clientSock.writeString(idStr);
			}
//            System.out.println("Finished writing.");
		}
		catch (IOException ex)
		{
			sock = null;
			throw ex;
		}
		pongThread = new Thread(new Pong());
		pongThread.start();
	}
	/** For now, just a randomly-generated number (always positive, though).
	*/
	protected long genId()
	{
		id = random.nextLong();
		try
		{
			InetAddress localAddr = java.net.InetAddress.getLocalHost();
			byte bytes[] = localAddr.getAddress();
			long l = 0;
			for (int i=0; i < bytes.length; ++i)
			{
				l *= 256;
				l += bytes[i];
			}
			id ^= l; // XOR the addr bits into id.
		}
		catch (UnknownHostException e)
		{
		}
		id = Math.abs(id);
		return id;
	}
	/**
	 *  Access the unique identifier that this client uses on the server side.
	 */
	public long getId() { return id; }
	/**
	 *  If this isn't called before the application ends, then the
	 *  watchdog will consider that a client death.  Always say goodbye
	 *  before you leave!
	 */
	public boolean goodbye() throws IOException
	{
		if (sock == null)
			return false;
		synchronized(clientSock)
		{
			clientSock.writeString("goodbye");
		}
		sock.close(); // maybe have to get rid of this one.
		synchronized(stopPongThread)
		{
			stopPongThread = new Boolean(true);
			pongThread.interrupt();
		}
		sock = null;
		return true;
	}
	/**
	 *  see if you're connected.
	 */
	public boolean isConnected() { return sock != null; }
	public static void main(String args[])
	{
		System.out.println("We expect a WatchdogServer to @ localhost,port#" + WatchdogServer.getDefaultPort());
		try
		{
			System.out.println("Creating watchdog client...");
			WatchdogClient watcher = new WatchdogClient();
			System.out.println("Created watchdog client, id = " + watcher.getId());
			System.out.println("Sleep for 10 seconds.");
			try { Thread.sleep(10000); } catch (InterruptedException e) {}
			System.out.println("Say goodbye!");
			if (!watcher.goodbye())
				System.out.println("Saying goodbye failed.");
			WatchdogClient watcher2 = new WatchdogClient();
			System.out.println("Created another watchdog client, id = " + watcher2.getId());
			System.out.println("Sleep for 10 seconds.");
			try { Thread.sleep(10000); } catch (InterruptedException e) {}
			System.out.println("Exit application without saying goodbye!");
		}
		catch (IOException ex)
		{
			System.out.println("Error: " + ex);
		}
	}
}