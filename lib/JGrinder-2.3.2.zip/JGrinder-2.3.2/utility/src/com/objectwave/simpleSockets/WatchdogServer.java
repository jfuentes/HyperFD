package com.objectwave.simpleSockets;

import java.awt.*;
import java.io.*;
import java.net.*;
import java.util.*;
import com.objectwave.utility.ThreadPoolManager;

/**
 * A Watchdog server to watch for unexpected client deaths.  Clients register
 * by opening a socket with the server.  If the client's socket closes without
 * the client saying goodbye, then the clientDied(long id) method is called.
 * if the client said goodbye and *then* the socket closed, then the
 * clientLeft(long id) method is called.  Override these methods to provide
 * your own behaviour in these events.  Note that there's also a threadsafe
 * vector accessed via addClient(long), removeClient(long), and isClient(long).
 *
 */
public class WatchdogServer extends SimpleServer
{
	private Vector clients = new Vector();
	ThreadPoolManager mgr = new ThreadPoolManager(20);

	private class WatchdogServeClient extends ServeClient
	{
		WatchdogServeClient(SimpleServer svr, int count, Thread t)
		{
			super(svr, count, t);
			System.out.println("new WatchdogServeClient");
			mgr.start(new Ping());
		}

		private long id = -1;
		private boolean goodbye = false;

		protected void handleSocketException(Exception ex)
		{
			System.out.println("handleSocketException");
			if (id == -1)
			{
				System.err.println("Warning: lost an unkown client.");
			}
			else if (goodbye)
			{
				System.out.println("handleSocketException: clientLeft");
				clientLeft(id);
			}
			else
			{
				System.out.println("handleSocketException: clientDied");
				clientDied(id);
			}
			synchronized(stopPingThread)
			{
				System.out.println("Telling ping thread to stop.");
				stopPingThread = new Boolean(true);
			}
			kill(true);
		}
		protected String processRequest(String message)
		{
			//System.out.println("processRequest");
			if (message == null || message.length() == 0)
				return null;
			if (message.equals("pong"))
			{
				synchronized(pong)
				{
					pong = new Boolean(true);
				}
				return null;
			}
			if (message.equals("goodbye"))
			{
				if (goodbye)
					System.err.println("Warning: " + id + " received goodbye twice.");
				processGoodbye(id);
				goodbye = true;
				synchronized(stopPingThread)
				{
					System.out.println("Telling ping thread to stop.");
					stopPingThread = new Boolean(true);
				}
				return null;
			}
			try
			{
				long num = Long.parseLong(message);
				if (id != -1)
					System.err.println("Warning: " + id + " received another (ignored) id message: " + id);
				else
				{
					id = num;
					newClient(id);
				}
			}
			catch(NumberFormatException ex)
			{
				return processMessage(id, message);
			}
			return null;
		}

		Boolean stopPingThread = new Boolean(false);
		Boolean pong = new Boolean(false);
		int strike = 0;

		class Ping implements Runnable
		{
			public void run()
			{
				System.out.println("Ping thread started.");
				
				for (;;)
				{
					try { Thread.sleep(20000); } // check ping every twenty seconds.
					catch (InterruptedException  e) { }
					synchronized(stopPingThread)
					{
						if (stopPingThread.booleanValue())
							break;
					}
					synchronized(pong)
					{
						if (!pong.booleanValue())
						{
							System.out.println("Ping thread for id " + id + ": strike " + (++strike));
							if (strike == 3)
							{
								System.out.println("Strike 3!");
								clientDied(id);
								System.out.println("Ping thread for id " + id + " ending.");
								return; // end ping thread.
							}
						}
						else
						{
 //                           System.out.println("Pong check: everything's ok for id " + id + ".");
							pong = new Boolean(false); // reset, wait for next pong.
						}
					}
				}
				
				System.out.println("Ping thread for id " + id + " ending normally.");
			}
		} // end class Ping
	}
	public WatchdogServer()
	{
		port(getDefaultPort());
	}
	public WatchdogServer(int port)
	{
		port(port);
	}
	public void addClient(long id)
	{
		synchronized(clients)
		{
			clients.addElement(new Long(id));
		}
	}
	protected void clientDied(long id)
	{
		removeClient(id);
	}
	protected void clientLeft(long id)
	{
		removeClient(id);
	}
	/**  Override this method if you don't want to do anything special with the
	* handling of clients.  Just return your ServerClient object.
	*/
	public ServeClient getClientServer(SimpleServer svr, int count, Thread thread)
	{
		return new WatchdogServeClient(svr, count, thread);
	}
	public static final int getDefaultPort() { return 16000; }
	public boolean isClient(long id)
	{
		synchronized(clients)
		{
			for (int i=0; i<clients.size(); ++i)
				if (((Long)clients.elementAt(i)).longValue() == id)
					return true;
			return false;
		}
	}
	/*
	ServerSocket socket = null;
	int port = 3000;
	static final String version = "0.02";
	static int QUEUELENGTH = 128;
	public static int count = 1;
	Thread thread = null;
	boolean finishing = false;
	*/

	/**
	* This method should be overriden to create an instance
	* of your SimpleServer.  It should look the same xcept it should
	* Specify new <YourServer>.startServer();
	*/
	public static void main(String args[])
	{
		System.out.println("remote watchdog server");
		System.out.println("");
		if(args.length > 0)
			new WatchdogServer(new Integer(args[0]).intValue()).startServer();
		else
			new WatchdogServer().startServer();
	}
	protected void newClient(long id)
	{
		addClient(id);
	}
	protected void processGoodbye(long id)
	{
		System.out.println("WatchdogServer.processGoodbye(" + id + ")");
	}
	protected String processMessage(long id, String message)
	{
		System.err.println("Error: unknown message from " + id + ": " + message);
		return "error";
	}
	protected boolean removeClient(long id)
	{
		synchronized(clients)
		{
			for (int i=0; i<clients.size(); ++i)
			{
				if (((Long)clients.elementAt(i)).longValue() == id)
				{
					clients.removeElementAt(i);
					return true;
				}
			}
		}
		return false;
	}
} // end class WatchdogServer
