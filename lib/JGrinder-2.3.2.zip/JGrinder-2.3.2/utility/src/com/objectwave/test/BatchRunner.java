package com.objectwave.test;
import com.objectwave.classFile.*;
import com.objectwave.utility.*;
import com.objectwave.test.*;
import java.io.*;
/**
 *  Recurse from the current user directory and find all .class files that are
 *  UnitTest and add to our list of tests.
 *
 * @author  Dave Hoag
 * @version  $Id: BatchRunner.java,v 2.2 2003/11/27 21:08:45 dave_hoag Exp $
 */
public class BatchRunner
{
	final static String defaultPattern = "*$Test.class";
	/**
	 *  Search the current directory, and subdirectories, for class files, and jars
	 *  containing class files, that are UnitTests as defined by the JUnit test
	 *  framework. A pattern can be provided that class files much match in order
	 *  to investigate the nature of those classes.
	 *
	 * @param  args The arguments passed on the command line. Only the first
	 *      argument is used and it is optional.
	 */
	public static void main(String args[])
	{
		long startTime = System.currentTimeMillis();

		BatchRunner runIt = new BatchRunner();
		TestRunner testRunner = runIt.getTestRunner( args );
		System.out.println("Running " + testRunner.countTestCases() + " test cases.");
		int errorCount = testRunner.run();

		System.out.println("Finished in " + (System.currentTimeMillis() - startTime) + "ms");
		System.exit( errorCount );
	}
	/**
	 *  Search the current directory, and subdirectories, for class files, and jars
	 *  containing class files, that are UnitTests as defined by the JUnit test
	 *  framework. A pattern can be provided that class files much match in order
	 *  to investigate the nature of those classes.
	 *
	 * @param  fileNames optional argument that is a list of file names
	 */
	public TestRunner getTestRunner(String [] fileNames)
	{
		String pattern = System.getProperty("pattern", defaultPattern);
		TestRunner testRunner = new TestRunner();
		
		if(fileNames != null && fileNames.length > 0)
		{
			for(int i = 0; i < fileNames.length; i++)
			{
				//list of files
				try
				{
					File f = new File(fileNames[i]);
					if(f.isDirectory())
					{
						addClassFiles(fileNames[i], testRunner, pattern);
					}
					else
					{
						addTestFromFile(fileNames[i], testRunner);
					}
				}
				catch(Throwable t)
				{
					System.out.println("Exception adding file " + fileNames[i] + " " + t);
				}
			}
		}
		else
		{
			try
			{
				addClassFiles(".", testRunner, pattern);
				addClassFilesFromJars(testRunner, pattern);
			}
			catch(Throwable ex)
			{
				System.out.println("Exception identifying tests");
				ex.printStackTrace();
			}
		}
		return testRunner;
	}
	/**
	 *  Similar but different than the other jar method. This will look at every
	 *  class in the jar file as a potential test, patterns are ignored.
	 *
	 * @param  fileName The feature to be added to the TestFromFile attribute
	 * @param  suite The feature to be added to the TestFromFile attribute
	 * @exception  IOException Description of Exception
	 */
	protected void addTestFromFile(final String fileName, final TestRunner testRunner) throws IOException
	{
		if(fileName.endsWith(".jar"))
		{
			JarReader jar = new JarReader(fileName);
			java.util.Enumeration e = jar.elements();
			while(e.hasMoreElements())
			{
				java.util.zip.ZipEntry ent = (java.util.zip.ZipEntry) e.nextElement();
				String name = ent.getName();
				byte[] data = jar.getData(e);
				if(data != null)
				{
					addClass(new ByteArrayInputStream(data), name, testRunner);
				}
			}
		}
		else
		{
			FileInputStream fin = new FileInputStream(fileName);
			addClass(fin, fileName, testRunner);
		}
	}
	/*
	 *  Get the TestSuite from the TestClass. There are many things that can
	 *  happend to cause this to return null.
	 *
	 * @param  testClass Description of Parameter
	 * @return  The reflected suite or null.
	static Test getSuite(Class testClass)
	{
		java.lang.reflect.Method suiteMethod;

		try
		{
			suiteMethod = testClass.getMethod("suite", new Class[0]);
		}
		catch(Exception e)
		{
			System.out.println("The TestCase class " + testClass + " should have a method named \"suite()\"");
			return null;
		}

		try
		{
			return (Test) suiteMethod.invoke(null, new Class[0]);
			// static method
		}
		catch(Exception e)
		{
			System.out.println("Could not invoke the suite() method on " + testClass);
			return null;
		}
	}
	*/
	/**
	 *  Add class files found in Jar files this directory and subdirectories that
	 *  match the pattern string.
	 *
	 * @param  suite The test suite that is being built.
	 * @param  pattern A pattern that will be applied to file names to consider the
	 *      file as a test.
	 * @exception  FileNotFoundException Description of Exception
	 * @exception  IOException Description of Exception
	 */
	void addClassFilesFromJars(TestRunner testRunner, String pattern) throws FileNotFoundException, IOException
	{
		FileFinder f = new FileFinder();
		f.setPatternString("*.jar");
		boolean recurse = true;
		String[] names = f.getAllFilenames(new File("."), recurse);
		for(int i = 0; i < names.length; ++i)
		{
			JarReader jar = new JarReader(names[i]);
			java.util.Enumeration e = jar.elements();
			while(e.hasMoreElements())
			{
				java.util.zip.ZipEntry ent = (java.util.zip.ZipEntry) e.nextElement();
				String name = ent.getName();
				if(StringManipulator.isPatternMatch(pattern, name))
				{
					byte[] data = jar.getData(e);
					if(data != null)
					{
						addClass(new ByteArrayInputStream(data), name, testRunner);
					}
				}
			}
		}
	}
	/**
	 *  Read in the class as defined by the input stream to get the class name. Try
	 *  to Class.forName that class to get a reference to the class. This may fail
	 *  if the class is not on the classpath. If the class is an subclass of
	 *  TestCase, reflectively look for a suite() method as defined by junit and
	 *  get the test suite.
	 *
	 * @param  in The source of bytes for the class file.
	 * @param  name The name of the file we are adding.
	 * @param  suite The TestSuite being built.
	 * @exception  IOException An error occured reading the parameter input stream.
	 */
	void addClass(InputStream in, String name, TestRunner testRunner) throws IOException
	{
		ClassFile cf = new ClassFile();
		cf.read(in);
		in.close();
		String className = cf.getClassName();
		try
		{
			Class c = Class.forName(className);
/*			if(TestCase.class.isAssignableFrom(c))
			{
				Test t = getSuite(c);
				if(t != null)
				{
					System.out.println("Adding test: " + name);
					suite.addTest(t);
				}
			}
			else
			*/
			if(com.objectwave.test.UnitTest.class.isAssignableFrom(c))
			{
				try
				{
					com.objectwave.test.UnitTest unit = (com.objectwave.test.UnitTest)c.newInstance();
					if(unit != null)
					{
						System.out.println("Adding test: " + name);
						testRunner.add( unit );
					}
				}
				catch(Throwable t)
				{
					t.printStackTrace();
					System.out.println("Failed to load " + c + " " + t);
				}
			}
		}
		catch(ClassNotFoundException ex)
		{
			System.out.println(ex);
		}
		catch(Throwable t)
		{
			System.out.println("Exception adding class " + name + "\n" + t);
		}
	}
	/**
	 *  Add class files found in this directory and subdirectories that match the
	 *  pattern string.
	 *
	 * @param  suite The test suite that is being built.
	 * @param  pattern A pattern that will be applied to file names to consider the
	 *      file as a test.
	 * @param  startDir The feature to be added to the ClassFiles attribute
	 * @exception  FileNotFoundException Description of Exception
	 * @exception  IOException Description of Exception
	 */
	void addClassFiles(String startDir, TestRunner testRunner, String pattern) throws FileNotFoundException, IOException
	{
		FileFinder f = new FileFinder();
		f.setPatternString(pattern);
		boolean recurse = true;
		String[] names = f.getAllFilenames(new File(startDir), recurse);
		for(int i = 0; i < names.length; ++i)
		{
			FileInputStream fin = new FileInputStream(names[i]);
			addClass(fin, names[i], testRunner);
		}
	}
}

