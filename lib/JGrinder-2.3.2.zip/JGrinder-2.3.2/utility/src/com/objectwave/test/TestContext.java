/* Copyright (C) 2001 David Hoag
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * For a full copy of the license see:
 * http://www.opensource.org/licenses/lgpl-license.html
 */
package com.objectwave.test;
/**
 *  The interface that is to provide support to the unit tests.
 *
 * @author  David Hoag
 * @version  $Id: TestContext.java,v 2.2 2002/07/31 15:55:22 dave_hoag Exp $
 */
public interface TestContext
{
	/**
	 *  Gets the NewThread attribute of the TestContext object
	 *
	 * @param  r
	 * @return  The NewThread value
	 */
	public Thread getNewThread(Runnable r);
	/**
	 *  Gets the Name attribute of the TestContext object
	 *
	 * @return  The Name value
	 */
	public String getName();
	/**
	 *  Asserts that a condition is true. If it isn't it throws an
	 *  AssertionFailedError.
	 *
	 * @param  condition
	 */
	public void assertTrue(boolean condition);
	/**
	 *  Asserts that a condition is true. If it isn't it throws an
	 *  AssertionFailedError with the given message.
	 *
	 * @param  message
	 * @param  condition
	 */
	public void assertTrue(String message, boolean condition);
	/**
	 *  Asserts that two objects are equal. If they are not an AssertionFailedError
	 *  is thrown.
	 *
	 * @param  expected the expected value of an object
	 * @param  actual the actual value of an object
	 */
	public void assertEquals(Object expected, Object actual);
	/**
	 *  Asserts that two longs are equal.
	 *
	 * @param  expected the expected value of an object
	 * @param  actual the actual value of an object
	 */
	public void assertEquals(long expected, long actual);
	/**
	 *  Asserts that two doubles are equal.
	 *
	 * @param  expected the expected value of an object
	 * @param  actual the actual value of an object
	 * @param  delta tolerated delta
	 */
	public void assertEquals(double expected, double actual, double delta);
	/**
	 *  Asserts that two objects are equal. If they are not an AssertionFailedError
	 *  is thrown.
	 *
	 * @param  message the detail message for this assertion
	 * @param  expected the expected value of an object
	 * @param  actual the actual value of an object
	 */
	public void assertEquals(String message, Object expected, Object actual);
	/**
	 *  Asserts that two longs are equal.
	 *
	 * @param  message the detail message for this assertion
	 * @param  expected the expected value of an object
	 * @param  actual the actual value of an object
	 */
	public void assertEquals(String message, long expected, long actual);
	/**
	 *  Asserts that two doubles are equal.
	 *
	 * @param  message the detail message for this assertion
	 * @param  expected the expected value of an object
	 * @param  actual the actual value of an object
	 * @param  delta tolerated delta
	 */
	public void assertEquals(String message, double expected, double actual, double delta);
}
