package com.objectwave.test;
import java.lang.reflect.*;
/**
 *  Hide the details of the JUnit test framework. This level of indirection will
 *  allow the development of and integration with new test frameworks without
 *  changing the system under test.
 *
 * @author  Dave Hoag
 * @version  $Id: TestImpl.java,v 2.3 2002/07/31 15:55:23 dave_hoag Exp $
 */
public class TestImpl extends junit.framework.TestCase
{
	UnitTest unitTest;
	String methodName;
	MyTestContext context;
	/**
	 * @param  str
	 */
	public TestImpl(String str)
	{
		super(str);
		context = new MyTestContext();
	}
	/**
	 * @param  test The new UnitTest value
	 */
	public void setUnitTest(UnitTest test)
	{
		unitTest = test;
	}
	/**
	 * @return
	 */
	public String toString()
	{
		if(unitTest != null)
		{
			return unitTest.getClass().getName() + "." + methodName;
		}
		return super.toString();
	}
	/**
	 * @exception  Exception
	 */
	protected void setUp() throws Exception
	{
		unitTest.setUp(getName(), context);
	}
	/**
	 *  Override the junit implementation to delegate to my implementation.
	 *
	 * @exception  Throwable
	 */
	protected void runTest() throws Throwable
	{
		String fName = getName();
		methodName = fName;
		Method runMethod = null;
		try
		{
			runMethod = unitTest.getClass().getMethod(fName, new Class[]{TestContext.class});
			Object[] contextData = new Object[]{context};
			runMethod.invoke(unitTest, contextData);
		}
		catch(NoSuchMethodException e)
		{
		}
		catch(InvocationTargetException e)
		{
			e.fillInStackTrace();
			throw e.getTargetException();
		}
		if(runMethod == null)
		{
			try
			{
				runMethod = unitTest.getClass().getMethod(fName, new Class[0]);
				runMethod.invoke(unitTest, new Class[0]);
			}
			catch(NoSuchMethodException e)
			{
				e.fillInStackTrace();
				throw e;
			}
			catch(InvocationTargetException e)
			{
				e.fillInStackTrace();
				throw e.getTargetException();
			}
		}
		if(context.getException() != null)
		{
			throw context.getException();
		}
	}
	/**
	 * @exception  Exception
	 */
	protected void tearDown() throws Exception
	{
		unitTest.tearDown(context);
	}
	/**
	 * @author  dhoag
	 * @version  $Id: TestImpl.java,v 2.3 2002/07/31 15:55:23 dave_hoag Exp $
	 */
	class MyTestContext implements TestContext
	{
		Throwable exception;
		/**
		 *  Sets the Exception attribute of the MyTestContext object
		 *
		 * @param  el The new Exception value
		 */
		public void setException(Throwable el)
		{
			exception = el;
		}
		/**
		 *  Gets the Exception attribute of the MyTestContext object
		 *
		 * @return  The Exception value
		 */
		public Throwable getException()
		{
			return exception;
		}
		/**
		 * @param  r
		 * @return  The NewThread value
		 */
		public Thread getNewThread(Runnable r)
		{
			return new Thread(new WrapRunnable(r));
		}
		/**
		 *  Asserts that a condition is true. If it isn't it throws an
		 *  AssertionFailedError.
		 *
		 * @param  condition
		 */
		public void assertTrue(boolean condition)
		{
			TestImpl.this.assertTrue(condition);
		}
		public String getName()
		{
			return TestImpl.this.getName();
		}
		/**
		 *  Asserts that a condition is true. If it isn't it throws an
		 *  AssertionFailedError with the given message.
		 *
		 * @param  message
		 * @param  condition
		 */
		public void assertTrue(String message, boolean condition)
		{
			TestImpl.this.assertTrue(message, condition);
		}
		/**
		 *  Asserts that two objects are equal. If they are not an
		 *  AssertionFailedError is thrown.
		 *
		 * @param  expected the expected value of an object
		 * @param  actual the actual value of an object
		 */
		public void assertEquals(Object expected, Object actual)
		{
			TestImpl.this.assertEquals(expected, actual);
		}
		/**
		 *  Asserts that two longs are equal.
		 *
		 * @param  expected the expected value of an object
		 * @param  actual the actual value of an object
		 */
		public void assertEquals(long expected, long actual)
		{
			TestImpl.this.assertEquals(expected, actual);
		}

		/**
		 *  Asserts that two doubles are equal.
		 *
		 * @param  expected the expected value of an object
		 * @param  actual the actual value of an object
		 * @param  delta tolerated delta
		 */
		public void assertEquals(double expected, double actual, double delta)
		{
			TestImpl.this.assertEquals(expected, actual, delta);
		}

		/**
		 *  Asserts that two objects are equal. If they are not an
		 *  AssertionFailedError is thrown.
		 *
		 * @param  message the detail message for this assertion
		 * @param  expected the expected value of an object
		 * @param  actual the actual value of an object
		 */
		public void assertEquals(String message, Object expected, Object actual)
		{
			TestImpl.this.assertEquals(message, expected, actual);
		}

		/**
		 *  Asserts that two longs are equal.
		 *
		 * @param  message the detail message for this assertion
		 * @param  expected the expected value of an object
		 * @param  actual the actual value of an object
		 */
		public void assertEquals(String message, long expected, long actual)
		{
			TestImpl.this.assertEquals(message, expected, actual);
		}
		/**
		 *  Asserts that two doubles are equal.
		 *
		 * @param  message the detail message for this assertion
		 * @param  expected the expected value of an object
		 * @param  actual the actual value of an object
		 * @param  delta tolerated delta
		 */
		public void assertEquals(String message, double expected, double actual, double delta)
		{
			TestImpl.this.assertEquals(message, expected, actual, delta);
		}
		class WrapRunnable implements Runnable
		{
			Runnable subj;
			/**
			 *  Constructor for the WrapRunnable object
			 *
			 * @param  runner
			 */
			WrapRunnable(Runnable runner)
			{
				subj = runner;
			}
			/**
			 *  Main processing method for the WrapRunnable object
			 */
			public void run()
			{
				try
				{
					subj.run();
				}
				catch(Throwable t)
				{
					setException(t);
				}
			}
		}
	}
}
