package com.objectwave.test;
import java.lang.reflect.*;
import junit.framework.*;
/**
 *  Hide the details of the JUnit test framework. This level of indirection will
 *  allow the development of and integration with new test frameworks without
 *  changing the system under test.
 *
 * @author  Dave Hoag
 * @version  $Id: TestRunner.java,v 2.3 2003/11/27 21:08:45 dave_hoag Exp $
 */
public class TestRunner
{
	junit.framework.TestSuite masterSuite;
	/**
	 *  Use reflection to create all of the tests. Every method that begins with
	 *  the work "test" will automatically be included in the suite.
	 *
	 * @param  unitTestFactory The object from which all public "test" methods will
	 *      be identified.
	 * @return
	 */
	public static junit.framework.TestSuite createSuite(UnitTest unitTestFactory)
	{
		junit.framework.TestSuite suite = new junit.framework.TestSuite();
		Method[] methods = unitTestFactory.getClass().getMethods();
		java.util.Arrays.sort(methods, new MethodComparator());
		for(int i = 0; i < methods.length; i++)
		{
			Method meth = methods[i];
			if(meth.getName().startsWith("test"))
			{
				TestImpl testImpl = new TestImpl(meth.getName());
				UnitTest test = unitTestFactory.createTest(meth.getName(), testImpl.context);
				testImpl.setUnitTest(test);
				suite.addTest(testImpl);
			}
		}
		return suite;
	}
	/**
	 * @param  unitTestFactory The object from which all public "test" methods will
	 *      be identified.
	 * @param  args
	 */
	public static void run(UnitTest unitTestFactory, String[] args)
	{
		try
		{
			junit.framework.TestSuite suite = new junit.framework.TestSuite();
			if(args.length == 0)
			{
				suite = createSuite(unitTestFactory);
			}
			else
			{
				for(int i = 0; i < args.length; i++)
				{
					TestImpl testImpl = new TestImpl(args[i]);
					UnitTest test = unitTestFactory.createTest(args[i], testImpl.context);
					testImpl.setUnitTest(test);
					suite.addTest(testImpl);
				}
			}
			ExposeApiRunner runner = new ExposeApiRunner();
			junit.framework.TestResult result = runner.doRun(suite, false);
			if(result.errorCount() + result.failureCount() > 0)
			{
				System.exit(1);
			}
		}
		catch(Throwable t)
		{
			t.printStackTrace();
			System.exit(1);
		}
		System.exit(0);
	}
	/**
	 *  Assemble a list of tests from the provided testFactory.
	 *
	 * @param  testFactory
	 */
	public void add(UnitTest testFactory)
	{
		if(masterSuite == null)
		{
			masterSuite = new junit.framework.TestSuite();
		}
		masterSuite.addTest(createSuite(testFactory));
	}
	public junit.framework.TestSuite getMasterSuite()
	{
		return masterSuite;
	}
	/**
	 *  Main processing method for the TestRunner object
	 */
	public int run()
	{
		if(masterSuite != null)
		{
			ExposeApiRunner runner = new ExposeApiRunner();
			junit.framework.TestResult result = runner.doRun(masterSuite, false);
			return result.errorCount() + result.failureCount();
		}
//		junit.textui.TestRunner.run(masterSuite);
		return 0;
	}
	/**
	 * @return
	 */
	public int countTestCases()
	{
		if(masterSuite == null)
		{
			return 0;
		}
		return masterSuite.countTestCases();
	}
	/**
	 *  Extend TestRunner to expose the doRun api.
	 *
	 * @author  dhoag
	 * @version  $Id: TestRunner.java,v 2.3 2003/11/27 21:08:45 dave_hoag Exp $
	 */
	static class ExposeApiRunner extends junit.textui.TestRunner
	{
		/**
		 * @param  test
		 * @param  b
		 * @return
		 */
		public junit.framework.TestResult doRun(junit.framework.Test test, boolean b)
		{
			return super.doRun(test, b);
		}
	}

	/**
	 * Comparator for java.lang.reflect.Method. Sorts by method name.
	 *
	 * @author  cson
	 * @version  $Id: TestRunner.java,v 2.3 2003/11/27 21:08:45 dave_hoag Exp $
	 */
	private static class MethodComparator implements java.util.Comparator
	{
		/**
		 * @param  o1
		 * @param  o2
		 * @return
		 */
		public int compare(Object o1, Object o2)
		{
			if(o1 instanceof java.lang.reflect.Method && o2 instanceof java.lang.reflect.Method)
			{
				Method m1 = (Method) o1;
				Method m2 = (Method) o2;
				return m1.getName().compareTo(m2.getName());
			}
			return 0;
		}
		/**
		 * @param  obj
		 * @return
		 */
		public boolean equals(Object obj)
		{
			if(obj != null && obj instanceof MethodComparator)
			{
				return true;
			}
			return false;
		}
	}
}
