package com.objectwave.test;
/**
 * @author  dhoag
 * @version  $Id: UnitTest.java,v 2.0 2001/06/11 15:46:53 dave_hoag Exp $
 */
public interface UnitTest
{
	/**
	 *  The teardown method for JUnit
	 *
	 * @param  context
	 * @exception  Exception
	 */
	public void tearDown(TestContext context) throws Exception;
	/**
	 * @param  methodName
	 * @param  context
	 * @return
	 */
	public UnitTest createTest(String methodName, TestContext context);
	/**
	 *  The JUnit setup method
	 *
	 * @param  methodName The new Up value
	 * @param  context The new Up value
	 * @exception  Exception
	 */
	public void setUp(String methodName, TestContext context) throws Exception;
}
