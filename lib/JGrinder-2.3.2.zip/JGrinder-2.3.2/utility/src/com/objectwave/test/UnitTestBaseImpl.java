/* Copyright (C) 2001 David Hoag
 * ObjectWave Corporation
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * For a full copy of the license see:
 * http://www.opensource.org/licenses/lgpl-license.html
 */
package com.objectwave.test;
import java.io.*;
/**
 *  Provide all of the default implementation code. All a subclass needs to do
 *  is extend this and provide a main method.
 *
 * @author  dhoag
 * @version  $Id: UnitTestBaseImpl.java,v 2.0 2001/06/11 15:46:53 dave_hoag Exp $
 */
public class UnitTestBaseImpl implements UnitTest
{
	/**
	 */
	public TestContext testContext;
	/**
	 *  The JUnit setup method
	 *
	 * @param  methodName The new Up value
	 * @param  context The new Up value
	 * @exception  Exception
	 */
	public void setUp(String methodName, TestContext context) throws Exception
	{
		testContext = context;
		//do nothing
	}
	/**
	 *  The teardown method for JUnit
	 *
	 * @param  context
	 * @exception  Exception
	 */
	public void tearDown(TestContext context) throws Exception
	{
		//do noting
	}
	/**
	 * @param  methodName
	 * @param  context
	 * @return
	 */
	public UnitTest createTest(String methodName, TestContext context)
	{
		UnitTestBaseImpl test = null;
		try
		{
			Class c = this.getClass();
			test = (UnitTestBaseImpl) c.newInstance();
			test.testContext = context;
			//in case someone overrides setup
		}
		catch(Throwable t)
		{
			t.printStackTrace();
		}
		return test;
	}
	/**
	 * @param  fileName
	 * @param  resourceTarget
	 * @param  contents
	 * @return
	 * @exception  IOException
	 */
	public File writeFileResource(String fileName, Class resourceTarget, String contents) throws IOException
	{
		String className = resourceTarget.getName();
		int idx = className.lastIndexOf('.');
		if(idx > -1)
		{
			className = className.substring(idx + 1);
		}
		className += ".class";

		java.net.URL url = resourceTarget.getResource(className);
		//Get the file and remove the leading '/'
		String tmpFileName = url.getFile().substring(1);
		String path = tmpFileName.substring(0, tmpFileName.length() - className.length());
		if(path.charAt(1) != ':')
		{
			path = "/" + path;
		}
		fileName = path + File.separatorChar + fileName;
		writeFile(fileName, contents);
		return new File(fileName);
	}
	/**
	 *  Helper method to allow a quick creation of a file.
	 *
	 * @param  fileName
	 * @param  contents
	 * @exception  java.io.IOException
	 */
	public void writeFile(String fileName, String contents) throws java.io.IOException
	{
		java.io.File file = new java.io.File(fileName);
		file.createNewFile();
		java.io.FileWriter fos = new java.io.FileWriter(file);
		fos.write(contents);
		fos.flush();
		fos.close();
	}
	/**
	 *  If the file provided exists, remove it from the system.
	 *
	 * @param  fileName
	 */
	public void removeFile(String fileName)
	{
		java.io.File f = new java.io.File(fileName);
		if(f.exists())
		{
			try
			{
				f.delete();
			}
			catch(Throwable t)
			{
				System.out.println("Failed to remove old db file " + t);
			}
		}
		else
		{
			//Don't really care
			System.out.println(" File " + fileName + " does not exist");
		}
	}
}
