package com.objectwave.uiControl;

import com.objectwave.utility.StringManipulator;
import java.awt.Choice;
import java.awt.Container;
import java.util.Vector;
import java.util.Enumeration;

public class ChoiceControl extends ControllerItem
	{
		Vector objectsInList;


	public ChoiceControl(Choice lst, Container aController){
		super(lst, aController);
		this.objectsInList(new Vector());
	}
	public void add(String [] str){
		for(int i = 0; i < str.length; i++)
			this.add(str[i]);
	}
	public void add(Object aValue) {
		this.addObject(aValue);
	}
	public void add(String aValue) {
		Choice aList = (Choice)this.getComponent();
		this.addObjectToList(aValue);
		aList.add(aValue);
	}
	public void addObject(Object aValue) {
		Choice aList = (Choice)this.getComponent();
		this.addObjectToList(aValue);
		String str = aValue.toString();
		str = StringManipulator.oneLine(str);
		aList.add(str);
	}
	public void addObjects(Vector aVector){
	    Enumeration enum = aVector.elements();
	    while(enum.hasMoreElements())
	        this.addObject(enum.nextElement());
	}
	protected void addObjectToList(Object aValue) {
	    this.objectsInList().addElement(aValue);
	}
	protected void addObjectToList(String aValue) {
	    this.objectsInList().addElement(aValue);
	}
	public void clear(){
		Choice aList = (Choice)this.getComponent();
		aList.removeAll();
	}
	public String getItem(int idx){
		/**
		If the item is a printable object, convert it to a string.
		*/
	    if ( (this.objectsInList().elementAt(idx) instanceof String) )
	        return (String)this.objectsInList().elementAt(idx);
	    else
	        {
	        Object obj = this.objectsInList().elementAt(idx);
		    return obj.toString();
		    }
	}
	public int getItemCount(){
	    /**
	    */
	    Choice aList = (Choice)this.getComponent();
	    return aList.getItemCount();
	}
	public Object getObject(int idx){
   	    return this.objectsInList().elementAt(idx);
   	}   
	public int getSelectedIndex(){
	    Choice aList = (Choice)this.getComponent();
	    return aList.getSelectedIndex();
	}
	public String getSelectedItem(){
	    /**
	    Like the interface to the actual choice object, this will always return
	    a string.
	    */
	    Choice aList = (Choice)this.getComponent();
	    int idx = aList.getSelectedIndex();
	    return this.getItem(idx);
	}
	public Object getSelectedObject(){
	    /**
	    Lets work in Object Land.
	    */
	    Choice aList = (Choice)this.getComponent();
	    int idx = aList.getSelectedIndex();
	    return this.getObject(idx);
	}
	public Vector objectsInList(){
		return objectsInList;
	}
	protected void objectsInList(Vector list){
	        objectsInList = list;
	}
	public void put(String [] str){
		this.clear();
		this.add(str);
	}
	public void putObjects(Vector aVector){
	    this.clear();
	    this.addObjects(aVector);
	}
	public synchronized void select(int idx){
	    Choice aList = (Choice)this.getComponent();
	    aList.select(idx);
	}
	public synchronized void select(Object obj){
	    Choice aList = (Choice)this.getComponent();
	    int idx = this.objectsInList().indexOf(obj);
	    this.select(idx);
	}
	public void select(String aString){
	    Choice aList = (Choice)this.getComponent();
	    aList.select(aString);
	}
}