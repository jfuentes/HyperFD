package com.objectwave.uiControl;

import java.awt.Component;
import java.awt.Container;

class ControllerItem
	{
		Component comp;
		Container controllingWindow;

	ControllerItem(Component cmp, Container controller){
		this.setControllingWindow(controller);
		this.setComponent(cmp);
	}
	public Component getComponent(){
		return comp;
	}
	public Container getControllingWindow(){
		return controllingWindow;
	}
	public void setComponent(Component relatedComponent){
	        comp = relatedComponent;
	}
	public void setControllingWindow(Container newControllingWindow){
	        controllingWindow = newControllingWindow;
	}
}