package com.objectwave.uiControl;

import java.awt.List;
import java.awt.Container;
import java.util.Vector;
import java.util.Enumeration;
import com.objectwave.utility.StringManipulator;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ListControl extends ControllerItem implements ActionListener
	{
		Vector objectsInList;


	public ListControl(List lst, Container aController){
		super(lst, aController);
		this.setObjectsInList(new Vector());
	}
	public void actionPerformed(ActionEvent e){
		// Overload if needed
	}
	public void add(String[] aValue) {
		List aList = (List)this.getComponent();
		for(int i = 0; i < aValue.length; i++){
			this.addObjectToList(aValue[i]);
			aList.add(aValue[i]);
		}
	}
	public void add(String aValue) {
		List aList = (List)this.getComponent();
		this.addObjectToList(aValue);
		aList.add(aValue);
	}
	public void addItem(Object aValue) {
	    this.addObject(aValue);
	}
	public void addObject(Object aValue) {
		List aList = (List)this.getComponent();
		this.addObjectToList(aValue);
		String str  = StringManipulator.oneLine(aValue.toString());
		str = StringManipulator.oneLine(str);
		aList.add(str);
	}
	public void addObjects(Object [] objArray){
	    for(int i = 0; i < objArray.length; i++)
	        this.addObject(objArray[i]);
	}
	public void addObjects(Enumeration enum){
	    while(enum.hasMoreElements())
	        this.addObject(enum.nextElement());
	}
	public void addObjects(Vector aVector){
	    Enumeration enum = aVector.elements();
	    this.addObjects(enum);
	}
	protected void addObjectToList(Object aValue) {
	    this.getObjectsInList().addElement(aValue);
	}
	protected void addObjectToList(String aValue) {
	    this.getObjectsInList().addElement(aValue);
	}
	public void clear(){
	   	List aList = (List)this.getComponent();
	   	aList.removeAll();
	   	this.setObjectsInList(new Vector());
	}
	public boolean contains(Object anObject){
		return objectsInList.contains(anObject);
	}
	public String [] getItems(){
		List aList = (List)this.getComponent();
		return aList.getItems();
	}
	public Object getObject(int idx){
   	    return this.getObjectsInList().elementAt(idx);
   	}   
	public Vector getObjectsInList(){
		return objectsInList;
	}
	public int getSelectedIndex(){
	    List aList = (List)this.getComponent();
	    return aList.getSelectedIndex();
	}
	public String getSelectedItem(){
		List aList = (List)this.getComponent();
		return aList.getSelectedItem();
	}
	public Object getSelectedObject(){
	    /**
	    Lets work in Object Land.
	    */
	    List aList = (List)this.getComponent();
	    int idx = aList.getSelectedIndex();
	    if(idx < 0) return null;
	    return this.getObject(idx);
	}
	public void put(String[] aValue) {
		this.clear();
		this.add(aValue);
	}
   	public void putObjects(Object [] objArray){
	   	this.clear();
	   	if(objArray == null) return;
	   	this.addObjects(objArray);
	}
   	public void putObjects(Enumeration anEnumeration){
	   	this.clear();
	   	this.addObjects(anEnumeration);
	}
   	public void putObjects(Vector aVector){
	   	this.clear();
	   	if(aVector == null) return;
	   	this.addObjects(aVector);
	}
	public void remove(int index){
	    List aList = (List)this.getComponent();
	    aList.remove(index);
	    this.getObjectsInList().removeElementAt(index);
	}
	public void remove(String obj){
		List aList = (List)this.getComponent();
		String [] items = aList.getItems();
		int idx = -1;
		for(int i = 0; i < items.length; i++)
			if(items[i].equals(obj)) idx = i;
		if(idx < 0) return;
		aList.remove(idx);
		this.getObjectsInList().removeElementAt(idx);
	}
	public void removeSelection(){
	    List aList = (List)this.getComponent();
	    int idx = aList.getSelectedIndex();
	    remove(idx);
	}
	protected void setObjectsInList(Vector list){
	        objectsInList = list;
	}
}