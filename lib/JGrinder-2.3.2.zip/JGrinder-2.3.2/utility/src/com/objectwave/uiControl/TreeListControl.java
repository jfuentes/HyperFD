package com.objectwave.uiControl;

import java.awt.List;
import java.awt.Window;
import java.awt.Component;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.Event;
import com.objectwave.utility.TreeCollection;

import java.util.Vector;
import java.util.Enumeration;
/**
* Before there was the JFC, I had a VERY simple version of a tree control.
*/
public class TreeListControl extends ListControl
{
	TreeCollection tree;
	Vector expandedList;
	Vector objectList;

	public TreeListControl(List comp, Container w)
	{
		super(comp, w);
		comp.addActionListener(this);
	}
	/**
	* Dispatch request.
	*/
	public void actionPerformed(ActionEvent e)
	{
		doubleClickList();
	}
	public void collapseAt(Object obj)
	{
	   expandedList.removeElement(obj);
	}
	private void displayLine(Object element, Vector strArr, int depth)
	{
		int size = tree.getChildCount(element);
		String str = new String();
		for (int i = 0; i < depth; i++) str += "   ";
		objectList.addElement(element);
		if(size == 0){
			str += "  " + element.toString();
			strArr.addElement(str);
		}
		else {
			if(expandedList.contains(element)){
				str += "-" + element.toString();
				strArr.addElement(str);
				Enumeration contents = tree.get(element);
				while(contents.hasMoreElements()){
					Object childElement = contents.nextElement();
					displayLine(childElement, strArr, depth + 1);
				}
			}
			else {
				str += "+" + element.toString();
				strArr.addElement(str);
			}
		}
	}
	private void displayTree()
	{
		Vector objs = new Vector ( tree.size() );
		objectList = new Vector ( tree.size() );
		Enumeration contents = tree.get(null);
		while(contents.hasMoreElements()){
			Object element = contents.nextElement();
			this.displayLine(element, objs, 1);
		}
		String [] strArr = new String [objs.size() ];
		for(int i = 0; i < objs.size(); i++)
			strArr[i] = (String)objs.elementAt(i);
		put(strArr);
		this.setObjectsInList(objectList);
	}
	public void doubleClickList()
	{
		Object obj = this.getSelectedObject();
		if(obj == null) return;
		if(tree.getChildCount(obj) == 0) return;
		if(expandedList.contains(obj))
			expandedList.removeElement(obj);
		else expandedList.addElement(obj);
		this.refresh();
	}
	public void expandAt(Object obj)
	{
		if(expandedList.contains(obj)) return;
		expandedList.addElement(obj);
	}
	public void put(TreeCollection tree)
	{
		this.tree = tree;
		expandedList = new Vector();
		displayTree();
	}
	public void refresh()
	{
		this.displayTree();
	}
}