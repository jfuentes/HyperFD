package com.objectwave.uiWidget;

import java.awt.*;
import java.awt.event.*;
import java.util.*;

/**
* Widget for displaying bar charts.
*/
public class BarChart extends Graph
{

	int position;
	int increment;

	/** To space the items evenly, we keep an increment variable to indicate
	the amount we will shift to the right for each item. The position
	variable is the current position, and the increment value is added
	to it each time. The constructor simply takes in values for the super
	constructor (Graph), which we call explicitly.
	*/
	public BarChart(String title, int min, int max)
	{
		super(title, min, max);
	} // end constructor
	public void paint(Graphics g)
	{
		super.paint(g);

		increment = (right - left)/(items.size());
		position = left;
		Color temp = g.getColor();

		for (int i = 0; i < items.size(); i++) {
			GraphItem item = (GraphItem)items.elementAt(i);
			int adjustedValue = bottom - (((item.value - min)*(bottom - top))
									   /(max - min));
			g.drawString(item.title, position + (increment -
					  fm.stringWidth(item.title))/2, adjustedValue - 2);
			g.setColor(item.color);
			g.fillRect(position, adjustedValue, increment,
					bottom - adjustedValue);
			position+=increment;
			g.setColor(temp);
		}
	} // end paint
}