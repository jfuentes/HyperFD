package com.objectwave.uiWidget;

import javax.swing.*;

import java.beans.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import com.objectwave.utility.Pair;
/**
 * A utiltiy class for creating a panel of buttons.
 * @author Dave Hoag
 * @version 1.0
 */
public class ButtonPanel extends javax.swing.JPanel implements SwingConstants, PropertyChangeListener
{
    JPanel buttonPanel;
    Vector actions;
    /**
     * @param buttonPosition A valid swing constant.
     */
    public void setHorizontalPosition(int buttonPosition)
    {
        checkKey(buttonPosition, "Horizontal Position is not CENTER, LEFT, or RIGHT");
        switch (buttonPosition)
        {
            case CENTER:
                remove(buttonPanel);
                add("Center", buttonPanel);
                break;
            case LEFT:
                remove(buttonPanel);
                add("West", buttonPanel);
                break;
            case RIGHT:
                remove(buttonPanel);
                add("East", buttonPanel);
                break;
        }
        revalidate();
    }
    /**
     * Ensures that the key is a valid. Throws an IllegalArgument exception
     * exception otherwise.
     */
    protected int checkKey(int key, String exception)
    {
        if ((key == LEFT) || (key == CENTER) || (key == RIGHT))
        {
            return key;
        } else {
            throw new IllegalArgumentException(exception);
        }
    }
    /**
     */
	public ButtonPanel()
	{
		setLayout(new BorderLayout());
		buttonPanel = new JPanel();
		add("Center", buttonPanel);
		actions = new Vector();
		addPropertyChangeListener(this);
	}
    /**
     * Append a new menuitem to the end of the menu which 
     * dispatches the specified Action object.
     *
     * @see javax.swing.Action
     */
    public JButton add(Action act)
    {
        JButton mi;
        mi = new JButton((String)act.getValue(Action.NAME),
                                    (Icon)act.getValue(Action.SMALL_ICON));
        mi.setMnemonic(((String)act.getValue(Action.NAME)).charAt(0));
//        mi.setHorizontalTextPosition(JButton.RIGHT);
        mi.setVerticalTextPosition(JButton.CENTER);
        mi.setEnabled(act.isEnabled());
        mi.addActionListener(act);
        mi.setToolTipText((String)act.getValue(Action.LONG_DESCRIPTION));
        buttonPanel.add(mi);
        PropertyChangeListener actionPropertyChangeListener = createActionChangeListener(mi);
        act.addPropertyChangeListener(actionPropertyChangeListener);
        actions.addElement(new Pair(act, mi));
        return mi;
    }
    /**
     */
    public void addSeparator()
    {
//        JButton separator = new JButton("   ");
//        separator.setBorderPainted(false);
//        buttonPanel.add(separator);
        JPanel separator = new JPanel();
        separator.setMinimumSize(new Dimension(10,10));
        buttonPanel.add(separator);
    }
    /**
     */
    protected PropertyChangeListener createActionChangeListener(JButton b) 
    {
        return new ActionChangedListener(b);
    }
    /**
     */
    public void propertyChange(PropertyChangeEvent evt)
    {
        if (evt.getPropertyName().equals("ancestor"))
        {
            Enumeration e = actions.elements();
            while(e.hasMoreElements())
            {
                Pair obj = (Pair)e.nextElement();
                Boolean b = (Boolean)((Action)obj.getFirst()).getValue("default");
                if(b != null && b.booleanValue())
                {
                    JRootPane root = SwingUtilities.getRootPane(this);
                    if (root != null)
                    {
                        root.setDefaultButton((JButton)obj.getSecond());
                    }
                }
            } 
        }
    }
    /**
     * Expanded from the default of JPopupMenu to include updates the icon.
     */
    protected class ActionChangedListener implements PropertyChangeListener
    {
        JButton button;
        ActionChangedListener(JButton mi)
        {
            super();
            this.button = mi;
        }
        public void propertyChange(PropertyChangeEvent e)
        {
            String propertyName = e.getPropertyName();
            if (propertyName.equals(Action.NAME))
            {
                String text = (String) e.getNewValue();
                button.setText(text);
            }
            else
            if (propertyName.equals("enabled"))
            {
                Boolean enabledState = (Boolean) e.getNewValue();
                button.setEnabled(enabledState.booleanValue());
            }
            else
            if (propertyName.equals(Action.SMALL_ICON))
            {
                button.setIcon((Icon)e.getNewValue());
            }
            else
            if (propertyName.equals("default"))
            {
                Pair obj = null;
                Enumeration en = actions.elements();
                while(en.hasMoreElements())
                {
                    obj = (Pair)en.nextElement();
                    if(obj.getSecond() == button) break;
                    obj = null;
                } 
                if(obj == null) return;
                Boolean b = (Boolean)((Action)obj.getFirst()).getValue("default");
                if(b != null && b.booleanValue())
                {
                    JRootPane root = SwingUtilities.getRootPane(ButtonPanel.this);
                    if (root != null)
                    {
                        root.setDefaultButton((JButton)obj.getSecond());
                    }
                }
            }
        }
    }
/**
*/
public static void main(String [] args)
{
    JFrame jf =new JFrame();
    final ButtonPanel buttonPanel = new ButtonPanel();
    Action act = new AbstractAction("Left"){ public void actionPerformed(ActionEvent evt) { buttonPanel.setHorizontalPosition(LEFT); } };
    buttonPanel.add(act);
    act = new AbstractAction("Center"){ public void actionPerformed(ActionEvent evt) { buttonPanel.setHorizontalPosition(CENTER); } };
    buttonPanel.add(act);
    buttonPanel.addSeparator();
    act = new AbstractAction("Right"){ public void actionPerformed(ActionEvent evt) { buttonPanel.setHorizontalPosition(RIGHT); } };
    buttonPanel.add(act);
    jf.getContentPane().add(buttonPanel);
    jf.setVisible(true);
} 
}