package com.objectwave.uiWidget;

import java.io.*;
import java.awt.event.*;
import java.awt.*;
import javax.swing.*;

/**
* A generic screen that allows one to have two lists and shift values from
* one list to the other. This is old and should be rewritten.
*/
public class ChoiceGui extends javax.swing.JFrame implements WindowListener
{
	public Object [] possibleChoices = new Object [0];
	public Object [] selectedChoices = new Object[0];
	DoubleList dlist;
	JButton pbSave, pbClose;
	Object [] result = null;

	public ChoiceGui()
	{
		super("Select ");
	}
	public ChoiceGui(Object [] pos, Object [] sel)
	{
		this(pos, sel, true);
	}
	/**
	* a filter of 'true' will remove values from pos that are found in sel
	*/
	public ChoiceGui(Object [] pos, Object [] sel, boolean filter)
	{
		this();
		if(filter)
		{
			possibleChoices = noDups(pos, sel);
			selectedChoices = sel;
		}
		else
		{
			possibleChoices = pos;
			selectedChoices = sel;
		}

		initScreen();
		show();
	}
	public void activated(){ }
	private JPanel bottomPortion()
	{
		JPanel p = new JPanel();
		p.setLayout(new FlowLayout());

		pbSave = new JButton("Apply");
		pbSave.setOpaque(true);
		pbSave.setMnemonic('A');
		p.add(pbSave);

		pbClose = new JButton("Close");
		pbClose.setOpaque(true);
		pbClose.setMnemonic('C');
		p.add(pbClose);

		return p;
	}
	public void closing(WindowEvent e)
	{
		Window f = e.getWindow();
		f.setVisible(false);
		f.dispose();
	}
	public void displayBusinessObject()
	{
	}
	public Object [] getSelection()
	{
		return result;
	}
// End create the look of the screen.

	public void hookEvents()
	{
		this.addWindowListener(this);
		pbSave.addActionListener( new ActionListener() {    public void actionPerformed(ActionEvent e){ pbSaveClicked(); } } );
		pbClose.addActionListener( new ActionListener() {    public void actionPerformed(ActionEvent e){ pbCloseClicked(); } } );
	}
	public void initScreen()
	{
		getContentPane().setLayout(new BorderLayout());
		getContentPane().add(initScreenLayout(), BorderLayout.CENTER);
		hookEvents();
		initSizeAndConstraints();
	}
	public Component initScreenLayout()
	{
		JPanel p = new JPanel();
		p.setLayout(new BorderLayout());
		p.add( bottomPortion(), BorderLayout.SOUTH);

		dlist = new DoubleList(possibleChoices, selectedChoices);
		p.add(dlist, BorderLayout.CENTER);
		return p;
	}
	public void initSizeAndConstraints()
	{
		setSize(300,200);
	}
	public static void main(String [] argv)
	{
		String [] vals = { "one", "two" };
		ChoiceGui scrn = new ChoiceGui(argv, vals);
	}
	protected static Object [] noDups(Object [] pos, Object [] sel)
	{
		java.util.Vector newPos = new java.util.Vector();
		for(int i = 0; i < pos.length; i++)
			newPos.addElement(pos[i]);
		outer:
		for(int i = 0; i < sel.length; i++)
		{
			if(sel[i] == null) System.out.println("ChoiceGui Warning:A provided selected value is null. ");
			else
			if(newPos.contains(sel[i]))
			{
				newPos.removeElement(sel[i]);
				continue outer;
			}
		}
		Object [] result = new Object [ newPos.size() ];
		newPos.copyInto(result);
		return result;
	}
	/**
	*/
	public void openInit()
	{
		displayBusinessObject();
	}
	public void pbCloseClicked()
	{
		result = null;
		processWindowEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING));
	}
	public void pbSaveClicked()
	{
		result = dlist.getRightSideItems();
		processWindowEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING));
	}
	public void show()
	{
		if(this.isShowing()){
			super.show();
			return;
		}
		super.show();
// FIXME: DAH - The following line gets around the fact that the open event doesn't appear to
// working at the time I created this code.
//        processEvent(new WindowEvent(this, WindowEvent.WINDOW_OPENED));
	}
	public void windowActivated(WindowEvent e){ activated(); }
	public void windowClosed(WindowEvent e){ }
	public void windowClosing(WindowEvent e){ closing(e); }
	public void windowDeactivated(WindowEvent e){}
	public void windowDeiconified(WindowEvent e){}
	public void windowIconified(WindowEvent e){}
// Window Listener code.
	public void windowOpened(WindowEvent e){ openInit(); }
}