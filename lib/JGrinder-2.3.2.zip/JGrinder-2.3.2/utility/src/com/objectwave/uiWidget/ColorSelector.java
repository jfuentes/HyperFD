package com.objectwave.uiWidget;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.border.*;
import javax.swing.JLabel;
import javax.swing.JComponent;

/**
*/
public class ColorSelector extends JComponent
{
	public int top;
	public int bottom;
	public int left;
	public int right;
	Color colors[] = null;
	Color selectedColor = Color.black;
	int hueMin = 0;
	int brightMin = 0;
	int saturation = 0;

	/**
	*/
	public ColorSelector()
	{
		setLayout(null);
		addMouseListener(getMouseListener());
	}
	private MouseListener getMouseListener()
	{
		return
		new MouseAdapter()
		{
			public void mouseClicked(MouseEvent e)
			{
				if (e.getClickCount() > 1)
				{
				}
			}
		};
	}
	/**
	*/
	public Dimension getPreferredSize()
	{
		return(new Dimension(300, 200));
	}
	/**
	* As in the Graph class, we collect the font metrics for measuring and the current color for resetting. The graph title is drawn centered at the
	* top. To draw the pie chart, we use the fillArc method of the Graphicsclass. This method draws an arc based on a circle contained within
	* a rectangle. We use the size variable for the width and height of this rectangle. The arcX and arcY variables represent the x and y values of
	the top-left corner of the rectangle. When we draw the arcs representing the item values, we need only to know a start angle and an arc angle
	because the size, arcX, and arcY values remain constant.

	* The for loop sifts through all the items in the vector, setting the color, drawing the arc, resetting the color to the original, and drawing the item
	* label. The values of the items are adjusted for the percentage of the whole pie (360 degrees) they represent. This process takes place in the
	* assignment of adjustedValue. The sumTot variable is added in this assignment to give the correct start angle.

	* After filling the arc, we draw the item label. This process requires a little more thought and measurement. We know the center point of the arc
	* circle because we know the size of the rectangle. We also know the formula for finding a point on a circle given an angle, and this gives us
	* enough data to find the point on the circle in the middle of each filled arc.
	*/
	public void paint(Graphics g)
	{
//      Color temp = g.getColor();
//      g.setColor(Color.black);
//      g.drawString(title, (right-left - fm.stringWidth(title))/2+left,
//                   titleHeight + padding);
//      g.setColor(temp);
		super.paint(g);
	}
	/**
	*/
	public void setBounds(int x, int y, int width, int height)
	{
		super.setBounds(x, y, width, height);
		setCenter(new Rectangle(x,y,width, height));
	}
	public void setBounds(Rectangle r)
	{
		super.setBounds(r);
		setCenter(r);
	}
	/**
	*/
	public void setCenter(Rectangle r)
	{
		int x = r.x;
		int y = r.y;
		int width = r.width;
		int height = r.height;

		top = 0;

		bottom = getSize().height;
		left = 0;
		right = getSize().width;
	}
}
