package com.objectwave.uiWidget;

import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import com.objectwave.viewUtility.*;

/**
* A list box of components.
*/
public class ComponentList extends JRootPane implements MouseDispatchListener
{
	GridBagLayout layout;
	GridBagConstraints gbc;
	JPanel dataPanel;
	Component [] listData;
	protected boolean highlight = true;
	protected ListSelectionModel selectionModel;
	protected ListSelectionListener selectionListener;

	/**
	*/
	private int pressed;
	/**
	*/
	public ComponentList()
	{
		gbc = new GridBagConstraints();
		gbc.gridwidth = GridBagConstraints.REMAINDER;
		gbc.weightx = 1.0;
		gbc.fill = GridBagConstraints.HORIZONTAL;
		
		getContentPane().setLayout(new BorderLayout());
		selectionModel = createSelectionModel();
//        selectionModel.setSelectionMode(selectionModel.SINGLE_SELECTION);

		setAutoscrolls(true);
		getGlassPane().addMouseListener(createMouseListener());
		getGlassPane().setVisible(true);
		initDataPanel();
	}
	/**
	 * Add a listener to the list that's notified each time a change
	 * to the selection occurs.  Listeners added directly to the JList
	 * will have their ListSelectionEvent.getSource() == this JList
	 * (instead of the ListSelectionModel).
	 *
	 * @param listener The ListSelectionListener to add.
	 * @see #getSelectionModel
	 */
	public void addListSelectionListener(ListSelectionListener listener) {
		/* Lazily create a ListSelectionListener that forwards
		 * ListSelectionEvents from the selectionModel to the JList
		 * ListSelectionListeners.  The forwarded events only differ
		 * from the originals in that their source is the JList
		 * instead of the selectionModel itself.
		 */
		if (selectionListener == null) {
			selectionListener = new ListSelectionListener() {
				public void valueChanged(ListSelectionEvent e) {
					fireSelectionValueChanged(e.getFirstIndex(),
											  e.getLastIndex(),
											  e.getValueIsAdjusting());
				}
			};
			getSelectionModel().addListSelectionListener(selectionListener);
		}

		listenerList.add(ListSelectionListener.class, listener);
	}
	/**
	* This is a dispatcher.
	*/
	protected MouseListener createMouseListener()
	{
		return new MouseDispatcher(getContentPane(), this);
	}
	/**
	 * Returns an instance of DefaultListSelectionModel.  This
	 * method is used by the constructor to initialize the
	 * selectionModel property.
	 *
	 * @return The ListSelectionModel used by this JList.
	 * @see #setSelectionModel
	 * @see DefaultListSelectionModel
	 */
	protected ListSelectionModel createSelectionModel()
	{
		return new DefaultListSelectionModel();
	}
	/**
	*/
	public int dataContains(Component c)
	{
		for(int i= 0; i < listData.length; i++)
			if(listData[i] == c) 
			{
				return i;
			}
		return -1;
	}
	/**
	 * This method notifies JList ListSelectionListeners that
	 * the selection model has changed.  It's used to forward
	 * ListSelectionEvents from the selectionModel to the
	 * ListSelectionListeners added directly to the JList.
	 *
	 * @see #addListSelectionListener
	 * @see #removeListSelectionListener
	 * @see EventListenerList
	 */
	protected void fireSelectionValueChanged(int firstIndex, int lastIndex,
											 boolean isAdjusting)
	{
		Object[] listeners = listenerList.getListenerList();
		ListSelectionEvent e = null;

		for (int i = listeners.length - 2; i >= 0; i -= 2) {
			if (listeners[i] == ListSelectionListener.class) {
				if (e == null) {
					e = new ListSelectionEvent(this, firstIndex, lastIndex,
											   isAdjusting);
				}
				((ListSelectionListener)listeners[i+1]).valueChanged(e);
			}
		}
	}
	/**
	 * Returns the value of the current selection model. The selection
	 * model handles the task of making single selections, selections
	 * of contiguous ranges, and non-contiguous selections.
	 *
	 * @return the ListSelectionModel that implements list selections
	 * @see #setSelectionModel
	 * @see ListSelectionModel
	 */
	public ListSelectionModel getSelectionModel()
	{
		return selectionModel;
	}
	/**
	*/
	protected void initDataPanel()
	{
		layout = new GridBagLayout();
		if(dataPanel != null)
			getContentPane().remove(dataPanel);
//            remove(dataPanel);
		dataPanel = new JPanel();
		dataPanel.setLayout(layout);
		
		getContentPane().setLayout(new BorderLayout());
//        setLayout(new BorderLayout());
		getContentPane().add(dataPanel, BorderLayout.NORTH);
//        add(dataPanel, BorderLayout.NORTH);
	}
	/**
	*/
	public boolean isAllowedToDispatch(MouseEvent e)
	{
		if(e.getID() == e.MOUSE_RELEASED)
			releasedSelection(e);

		if(e.getID() != e.MOUSE_PRESSED) return true;
		java.awt.Component c = (java.awt.Component)e.getSource();
		int i = -1;
		while(i == -1 && (c != null))
		{
			i = dataContains(c);
			if(i == -1)
				c = c.getParent();
		}

		if(i > -1 && c != null)
		{
			pressedSelection(i, e);
//            System.out.println("setting background to blue");
//            ItemEvent evt = new ItemEvent(null, ItemEvent.SELECTED, 
//            c.setBackground(Color.blue);
		}
		return true;
	}
	/**
	*/
	public void pressedSelection(int row, MouseEvent e)
	{
		pressed = row;
		ListSelectionModel list = getSelectionModel();
		if (row != -1) {
			list.setValueIsAdjusting(true);
			int anchorIndex = list.getAnchorSelectionIndex();
			if (e.isControlDown()) {
				if (list.isSelectedIndex(row)) {
					list.removeSelectionInterval(row, row);
				}
				else {
					list.addSelectionInterval(row, row);
				}
			}
			else if (e.isShiftDown() && (anchorIndex != -1)) {
				list.setSelectionInterval(anchorIndex, row);
			}
			else {
				list.setSelectionInterval(row, row);
			}
		}
//        if (!hasFocus()) {
//            requestFocus();
//        }
	}
	/**
	*/
	public void releasedSelection(MouseEvent e)
	{
		ListSelectionModel list = getSelectionModel();
		int row = pressed;
		pressed = -1;
		if (e.isShiftDown() || e.isControlDown()) {
			return;
		}
		if (row != -1) {
			list.setSelectionInterval(row, row);
		}
		list.setValueIsAdjusting(false);
		updateSelected();
	}
	/**
	 * Remove a listener from the list that's notified each time a
	 * change to the selection occurs.
	 *
	 * @param listener The ListSelectionListener to remove.
	 * @see #addListSelectionListener
	 * @see #getSelectionModel
	 */
	public void removeListSelectionListener(ListSelectionListener listener) 
	{
		listenerList.remove(ListSelectionListener.class, listener);
	}
	/**
	* Do we hightlight selected entries?
	* The default value is true.
	*/
	public void setHightlight(boolean value)
	{
		highlight = value;
	}
	/**
	*/
	public void setListData(Component [] comps)
	{
//        dataPanel.removeAll();
		initDataPanel();
		revalidate(); repaint();
		for(int i = 0; i < comps.length; i++)
			dataPanel.add(comps[i], gbc);
		listData = comps;
		dataPanel.revalidate();
		dataPanel.repaint();
	}
	/**
	 * Set the selectionModel for the list to a non-null ListSelectionModel
	 * implementation. The selection model handles the task of making single
	 * selections, selections of contiguous ranges, and non-contiguous
	 * selections.
	 * <p>
	 * This is a JavaBeans bound property.
	 *
	 * @return selectionModel  the ListSelectionModel that implements
	 *                         list selections
	 * @see #getSelectionModel
	 * @beaninfo
	 *       bound: true
	 * description: The selection model, recording which cells are selected.
	 */
	public void setSelectionModel(ListSelectionModel selectionModel)
	{
		if (selectionModel == null) {
			throw new IllegalArgumentException("selectionModel must be non null");
		}

		/* Remove the forwarding ListSelectionListener from the old
		 * selectionModel, and add it to the new one, if neccessary.
		 */
		if (selectionListener != null) {
			this.selectionModel.removeListSelectionListener(selectionListener);
			selectionModel.addListSelectionListener(selectionListener);
		}

		ListSelectionModel oldValue = this.selectionModel;
		this.selectionModel = selectionModel;
		firePropertyChange("selectionModel", oldValue, selectionModel);
	}
	public void updateSelected()
	{
		if(! highlight) return;
		ListSelectionModel selectionModel = getSelectionModel();
		for(int i= 0; i < listData.length; i++)
		{
			boolean isSelected = selectionModel.isSelectedIndex(i);
			if(listData[i] instanceof JComponent)
				((JComponent)listData[i]).setOpaque(isSelected);
			listData[i].setForeground(isSelected ? java.awt.SystemColor.textHighlightText : java.awt.SystemColor.textText);
			listData[i].setBackground(java.awt.SystemColor.textHighlight);
		}
		repaint();
	}
}
