package com.objectwave.uiWidget;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.Vector;
/**
 */
class DefaultDoubleListPanel extends DoubleListPanel
{
	private DoubleList  doubleList;
	private java.awt.Button leftToRight     = new java.awt.Button(">");
	private java.awt.Button allLeftToRight  = new java.awt.Button(">>");
	private java.awt.Button rightToLeft     = new java.awt.Button("<");
	private java.awt.Button allRightToLeft  = new java.awt.Button("<<");
	private Font   buttonFont      = new Font("TimesRoman",
		                                       Font.BOLD, 14);
	public DefaultDoubleListPanel()
	{
		GridBagLayout      gbl = new GridBagLayout();
		GridBagConstraints gbc = new GridBagConstraints();

		setLayout(gbl);

		gbc.gridwidth = GridBagConstraints.REMAINDER;
		gbc.fill      = GridBagConstraints.HORIZONTAL;
		gbl.setConstraints(leftToRight,    gbc);
		gbl.setConstraints(allLeftToRight, gbc);
		gbl.setConstraints(rightToLeft,     gbc);
		gbl.setConstraints(allRightToLeft,  gbc);

		add(leftToRight);
		add(allLeftToRight);
		add(rightToLeft);
		add(allRightToLeft);

		leftToRight.setFont   (buttonFont);
		allLeftToRight.setFont(buttonFont);
		rightToLeft.setFont   (buttonFont);
		allRightToLeft.setFont(buttonFont);

		leftToRight.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				doubleList.moveLeftToRight();
			}
		});
		allLeftToRight.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				doubleList.moveAllLeftToRight();
			}
		});
		rightToLeft.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				doubleList.moveRightToLeft();
			}
		});
		allRightToLeft.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				doubleList.moveAllRightToLeft();
			}
		});
	}
	public Insets getInsets() {
		return new Insets(4,4,4,4);
	}
	public void paint(Graphics g) {
		Dimension size = getSize();
		g.setColor(Color.black);
		g.drawRect(0,0,size.width-1,size.height-1);
		g.setColor(Color.lightGray);
		g.fill3DRect(1,1,size.width-2,size.height-2,true);
	}
	public void setDoubleList(DoubleList doubleList) {
		this.doubleList = doubleList;
	}
}