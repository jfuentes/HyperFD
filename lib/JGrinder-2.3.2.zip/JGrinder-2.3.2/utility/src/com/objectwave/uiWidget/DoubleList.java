package com.objectwave.uiWidget;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.Vector;
/**
 * Provides a pick list of elements 
 */
public class DoubleList extends JPanel
{
	protected JList left = new JList(), right = new JList();
	protected DoubleListPanel controlPanel;
	Object [] leftValues;
	Object [] rightValues;

	public DoubleList(Object[] leftStrs, Object[] rightStrs)
	{
 		this(new DefaultDoubleListPanel(), leftStrs, rightStrs);
	
	}
	public DoubleList(DoubleListPanel controlPanel,
	                  Object[] leftStrs, Object[] rightStrs)
	{
		setPanel(controlPanel);

		GridBagLayout      gbl = new GridBagLayout();
		GridBagConstraints gbc = new GridBagConstraints();

		left.setPrototypeCellValue("Index 1234567890 WWWW");
		right.setPrototypeCellValue("Index 1234567890 WWWW");

		left.setSelectionMode(left.getSelectionModel().MULTIPLE_INTERVAL_SELECTION );
		right.setSelectionMode(right.getSelectionModel().MULTIPLE_INTERVAL_SELECTION );

		setLayout(gbl);

		gbc.fill    = GridBagConstraints.BOTH;
		gbc.weightx = 1.0;
		gbc.weighty = 1.0;
		JScrollPane leftScroll = new JScrollPane(left);
		gbl.setConstraints(leftScroll, gbc);

		gbc.fill    = GridBagConstraints.VERTICAL;
		gbc.weightx = 0;
		gbc.weighty = 1.0;
		gbl.setConstraints(controlPanel, gbc);

		gbc.fill    = GridBagConstraints.BOTH;
		gbc.weightx = 1.0;
		gbc.weighty = 1.0;
		JScrollPane scroll = new JScrollPane(right);
		gbl.setConstraints(scroll, gbc);

		add(leftScroll);
		add(controlPanel);
		add(scroll);

		leftValues = leftStrs;
		left.setListData(leftStrs);
		rightValues = rightStrs;
		right.setListData(rightStrs);
		left.revalidate(); left.repaint();
		right.revalidate(); right.repaint();
	}
	public Object[] getLeftSideItems()
	{
		return leftValues;
	}
	public Object[] getLeftSideSelectedItems()
	{
		return left.getSelectedValues();
	}
	public Object[] getRightSideItems()
	{
		return rightValues;
	}
	public Object[] getRightSideSelectedItems()
	{
		return right.getSelectedValues();
	}
	/**
	* Since we are moving a random set of data, vectors make life
	* easier.
	*/
	protected void initVectors(Vector left, Vector right)
	{
		for(int i = 0; i < leftValues.length; i++)
			left.addElement(leftValues[i]);
		for(int i = 0; i < rightValues.length; i++)
			right.addElement(rightValues[i]);
	}
	public void moveAllLeftToRight()
	{
		Object [] emptyData = new Object [0];
		Object [] newRight = new Object[ rightValues.length + leftValues.length ];
		System.arraycopy(rightValues, 0, newRight, 0 , rightValues.length);
		System.arraycopy(leftValues, 0, newRight, rightValues.length , leftValues.length);

		left.setListData(emptyData);
		left.revalidate();
		left.repaint();
		rightValues = newRight;
		leftValues = emptyData;
		right.setListData(newRight);
		right.revalidate();
		right.repaint();
	}
	/**
	*/
	public void moveAllRightToLeft()
	{
		Object [] emptyData = new Object [0];
		Object [] newData = new Object[ rightValues.length + leftValues.length ];
		System.arraycopy(rightValues, 0, newData, 0 , rightValues.length);
		System.arraycopy(leftValues, 0, newData, rightValues.length , leftValues.length);

		left.setListData(newData);
		left.revalidate();
		left.repaint();
		rightValues = emptyData;
		leftValues = newData;
		right.setListData(emptyData);
		right.revalidate();
		right.repaint();
	}
	public void moveLeftToRight()
	{
		Object[] leftSelected = getLeftSideSelectedItems();
		int[]    leftSelectedIndexes = left.getSelectedIndices();
		int[] rightIndexes = right.getSelectedIndices();
		int idx = left.getMinSelectionIndex();

		Vector leftV = new Vector(), rightV = new Vector();
		initVectors(leftV, rightV);
		
		for(int i=0; i < leftSelectedIndexes.length; ++i)
		{
			leftV.removeElementAt(leftSelectedIndexes[(leftSelectedIndexes.length - 1) - i]);
		}
		for(int i=0; i < leftSelected.length; ++i)
		{
		    int insert = i;
		    if(rightIndexes.length > 0)
		        insert = rightIndexes[ rightIndexes.length - 1];
			rightV.insertElementAt(leftSelected[i], insert);
		}
		restoreValues(leftV, rightV);
		if(idx < leftValues.length)
			left.setSelectedIndex(idx);
		else
		if(leftValues.length > 0)
			left.setSelectedIndex(leftValues.length - 1);
	}
	/**
	* Move the selected values in the right list box to the left.
	*/
	public void moveRightToLeft()
	{
		Object[] rightSelected = getRightSideSelectedItems();
		int[]    rightSelectedIndexes = right.getSelectedIndices();
		int idx = right.getMinSelectionIndex();

		Vector leftV = new Vector(), rightV = new Vector();
		initVectors(leftV, rightV);

		for(int i=0; i < rightSelectedIndexes.length; ++i)
		{
			rightV.removeElementAt(rightSelectedIndexes[(rightSelectedIndexes.length - 1) - i]);
		}
		for(int i=0; i < rightSelected.length; ++i)
		{
			leftV.addElement(rightSelected[i]);
		}
		restoreValues(leftV, rightV);
		if(idx < rightValues.length)
			right.setSelectedIndex(idx);
		else
		if(rightValues.length > 0)
			right.setSelectedIndex(rightValues.length - 1);
	}
	/**
	*/
	protected void restoreValues(Vector leftV, Vector rightV)
	{
		leftValues = new Object [leftV.size()];
		rightValues = new Object [ rightV.size() ];
		leftV.copyInto(leftValues);
		rightV.copyInto(rightValues);
		left.setListData(leftValues);
		right.setListData(rightValues);
		left.revalidate(); left.repaint();
		right.revalidate(); right.repaint();
	}
	public void setPanel(DoubleListPanel controlPanel)
	{
		this.controlPanel = controlPanel;
		controlPanel.setDoubleList(this);
	}
}