package com.objectwave.uiWidget;

abstract public class DoubleListPanel extends javax.swing.JPanel
{
	abstract public void setDoubleList(DoubleList dblList);
}