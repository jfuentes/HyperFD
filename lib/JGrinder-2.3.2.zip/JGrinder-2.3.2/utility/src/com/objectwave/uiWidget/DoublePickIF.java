package com.objectwave.uiWidget;

import com.objectwave.uiWidget.*;

public interface DoublePickIF 
{
	void accept();
	void cancel();
	Object [] getDetail(Object selection);
	Object [] getMasterList();
	void selected(Object value);
	boolean selectedMaster(Object value);
}