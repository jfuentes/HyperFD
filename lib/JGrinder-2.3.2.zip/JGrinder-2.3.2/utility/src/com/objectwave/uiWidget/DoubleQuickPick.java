package com.objectwave.uiWidget;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.BevelBorder;
import javax.swing.event.*;
import java.util.Hashtable;
/**
* A widget for displaying a quick dialog containing two lists of items. 
* In particular, used when you have a Slave-Master relationship.  It is
* incumbent upon the user of this class to create a DoublePickIF model.
* The selected value will either be null (if none) or the item that
* was selected.
*/
public class DoubleQuickPick extends com.objectwave.uiWidget.QuickPick
{
	JList lbMasterList;
	Object [] masterList;
	Object masterSelection;

	static Hashtable oneInstance = new Hashtable(5);
	DoublePickIF model;

	/**
	*/
	public DoubleQuickPick(Object [] list, Frame f, boolean modal)
	{
		super(new String [0], f, modal);
		setMasterList(list);
	}
	/**
	*/
	public DoubleQuickPick( Frame f, boolean modal, DoublePickIF model)
	{
		super(new String [0], f, modal);
		setModel(model);
	}
	protected void cleanUp()
	{
		items = null;
		masterList = null;
		lbMasterList.setListData(new String [0]);
		super.cleanUp();
	}
	/**
	*/
	public static QuickPick getInstance(String [] list, Frame f, boolean modal)
	{
		DoubleQuickPick it = (DoubleQuickPick)oneInstance.get(f);
		if(it == null){
			it = new DoubleQuickPick(list, f, modal);
			oneInstance.put(f, it );
			return it;
		}
		it.setMasterList(list);
		it.selection = null;

		return it;
	}
	/**
	*/
	public Component getMainPanel()
	{
		JPanel p = new JPanel();
		com.objectwave.viewUtility.ResizableGridBagLayout layout = new com.objectwave.viewUtility.ResizableGridBagLayout();
		p.setLayout(layout);
		java.awt.GridBagConstraints gbc = new java.awt.GridBagConstraints();
		gbc.gridheight = gbc.gridwidth = 1;
		gbc.weightx = gbc.weighty = 100.0;
		gbc.fill = java.awt.GridBagConstraints.BOTH;
		gbc.gridx = GridBagConstraints.RELATIVE;
		JComponent c = getMasterList();
		layout.setConstraints(c, gbc);
		p.add(c);
		Component l2 = super.getMainPanel();
		layout.setConstraints(l2, gbc);
		p.add(l2);

		return p;
	}
	/**
	*/
	protected JScrollPane getMasterList()
	{
		lbMasterList = new JList();
		lbMasterList.addListSelectionListener(this);
		lbMasterList.setFont(new java.awt.Font("Serif", Font.BOLD, 15));
		ListCellRenderer render = lbMasterList.getCellRenderer();
		if(render instanceof JComponent){
			JComponent c = (JComponent)render;
			c.setFont(lbMasterList.getFont());
		}
		lbMasterList.setBackground(Color.white);
		
		JScrollPane pane = new JScrollPane(lbMasterList);
		pane.setBorder(new BevelBorder(BevelBorder.LOWERED));
		return pane;
	}
	/**
	*/
	public static void main(String [] args)
	{
		java.awt.Frame frame = new java.awt.Frame("Test Frame");
		frame.setSize(100, 100);
		getInstance(args, frame , true).setVisible(true);
		System.exit(0);

	}
	/**
	*/
	protected void pbCloseClicked()
	{
		model.cancel();
		super.pbCloseClicked();
	}
	/**
	*/
	protected void pbOkClicked(){
		model.accept();
		super.pbOkClicked();
	}
	/**
	*/
	public void setMasterList(Object [] vals)
	{
		masterList = vals;
		lbMasterList.setListData(masterList);
	}
	public void setModel(DoublePickIF model)
	{
		this.model = model;
		setMasterList(model.getMasterList());
	}
	public void updateDetail()
	{
		items = model.getDetail(masterSelection);
		showItems();
		l.revalidate();
		l.repaint();
	}
	/**
	*/
	public void valueChanged(ListSelectionEvent e){
		if(e.getValueIsAdjusting()) return;
		if(e.getSource() != lbMasterList){
			super.valueChanged(e);
			model.selected(selection);
			return;
		}

		if(model == null) return;
		int idx = e.getFirstIndex();
		if(idx < 0) {
			selection = null;
			return;
		}
		masterSelection = masterList[idx];
		if(masterSelection != null) 
			if(model.selectedMaster(masterSelection))
				updateDetail();
	}
}
