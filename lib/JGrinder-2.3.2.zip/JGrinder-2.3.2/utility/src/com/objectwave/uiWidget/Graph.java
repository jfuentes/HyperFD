package com.objectwave.uiWidget;

import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class Graph extends Canvas
{
   // variables needed
	public int top;
	public int bottom;
	public int left;
	public int right;
	int titleHeight;
	int labelWidth;
	FontMetrics fm;
	int padding = 4;
	String title;
	int min;
	int max;
	Vector items;

	/*The constructor takes the graph title and the range of values, and
	we create empty vector for the individual graph items.
	*/
	public Graph(String title, int min, int max) {
	  this.title = title;
	  this.min = min;
	  this.max = max;
	  items = new Vector();
	} // end constructor
	public void addItem(String name, int value) {
		items.addElement(new GraphItem(name, value, Color.black));
	} // end addItem
	public void addItem(String name, int value, Color col) {
		items.addElement(new GraphItem(name, value, col));
	} // end addItem
	/* Set the preferred size for the component by overriding the preferredSize method. The preferredSize method is
	also inherited from the Component class. Components can specify a preferred size and a minimum size. I have chosen a preferred width of
	300 and a preferred height of 200. The layout manager will call this method when it lays out the component.
	*/

	public Dimension getPreferredSize() {
		return(new Dimension(300, 200));
	}
	/*The framework is drawn in the paint method. We draw the title and labels in
	their appropriate places. We draw a vertical line at the left
	border of the graph drawing region, and a horizontal line at the bottom border.
	*/
	public void paint(Graphics g) {
		// draw the title
		fm = getFontMetrics(getFont());
		g.drawString(title, (getSize().width - fm.stringWidth(title))/2, top);
		// draw the max and min values
		g.drawString(new Integer(min).toString(), padding, bottom);
		g.drawString(new Integer(max).toString(), padding, top + titleHeight);
		// draw the vertical and horizontal lines
		g.drawLine(left, top, left, bottom);
		g.drawLine(left, bottom, right, bottom);
	} // end paint
	public void removeItem(String name) {
		for (int i = 0; i < items.size(); i++) {
			if (((GraphItem)items.elementAt(i)).title.equals(name))
				items.removeElementAt(i);
		}
	} // end removeItem
	/*    We override the setBounds method, which is inherited down the chain from the Component class. The reshape method is called when the
	component is resized and when it is laid out the first time. We use this method to collect measurements, so that they will always be updated if
	the component is resized. We get the font metrics for the current font and assign the titleHeight variable the maximum height of that font.
	We get the maximum width of the labels, testing to see which one is bigger and then using that one. The top, bottom, left, and right
	variables are calculated from the other variables and represent the borders of the center graph drawing region. We'll use these variables in the
	subclasses of Graph. Note that all of the measurements take into account a current size of the component so that redrawing will be correct
	at any size or aspect. If we used hard-coded values, the component could not be resized.
	*/
	public void setBounds(Rectangle r){
		int x = r.x;
		int y = r.y;
		int width = r.width;
		int height = r.height;

		super.setBounds(r);
		fm = getFontMetrics(getFont());
		titleHeight = fm.getHeight();
		labelWidth = Math.max(fm.stringWidth(new Integer(min).toString()),
				   fm.stringWidth(new Integer(max).toString())) + 2;
		top = padding + titleHeight;
		bottom = getSize().height - padding;
		left = padding + labelWidth;
		right = getSize().width - padding;
	}
}
