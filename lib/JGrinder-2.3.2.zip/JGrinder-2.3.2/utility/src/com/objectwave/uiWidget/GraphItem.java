package com.objectwave.uiWidget;

import java.awt.Color;
import java.awt.Rectangle;

/**
*
*/
public class GraphItem
{
	String title;
	Object object;
	Rectangle bounds;
	int value;
	int index=-1; // Indicate a position in an ordering of GraphItems,
				  // for instance which slice in a pie chart.
	Color color;

	public GraphItem(Object object, int value, Color color) 
	{
		this.title = object.toString();
		this.object = object;
		this.value = value;
		this.color = color;
	} // end constructor
	public GraphItem(String title, int value, Color color) 
	{
		this.title = title;
		this.value = value;
		this.color = color;
	} // end constructor
	public Rectangle getBounds() { return bounds; }
	public Color     getColor()  { return color; }
	public int       getIndex()  { return index; }
	public Object    getObject() { return object; }
	public String    getTitle()  { return title; }
	public int       getValue()  { return value; }
	public void setBounds(Rectangle b) { bounds = b; }
} 
