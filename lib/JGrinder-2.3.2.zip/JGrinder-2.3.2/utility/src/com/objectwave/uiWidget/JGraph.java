package com.objectwave.uiWidget;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.border.*;
import javax.swing.JLabel;
import javax.swing.JComponent;

/**
*/
public abstract class JGraph extends JComponent implements ItemSelectable
{
	protected static byte[] red   = { 2, 0, 0,  2, 2, 0,  0, 0, 2,  1, 1, 2,  2, 1, 1,  1, 2, 2,  1, 0, 0,  1, 1, 0 };
	protected static byte[] green = { 0, 2, 0,  2, 0, 2,  1, 2, 1,  0, 2, 0,  1, 2, 1,  2, 1, 2,  0, 1, 0,  1, 0, 1 };
	protected static byte[] blue  = { 0, 0, 2,  0, 2, 2,  2, 1, 0,  2, 0, 1,  1, 1, 2,  2, 2, 1,  0, 0, 1,  0, 1, 1 };

	public int currColor = 0;
	public int top;
	public int bottom;
	public int left;
	public int right;
	public int padding = 10;
	
	protected boolean recalc;
	protected Vector graphItems = new Vector();
	protected JLabel focusedItemValue;
	protected GraphItem selectedItem;
	protected boolean shadeSelection  = true;
	protected Vector itemListeners    = new Vector();

	/**
	*/
	public JGraph()
	{
	}
	/** Pass an object instead of a name so that it can be accessed later.
	* the object's name will be object.toString().
	*/
	public void addItem(Object object, int value, Color col)
	{
		graphItems.addElement(new GraphItem(object, value, col==null ? pickColor() : col));
		recalc = true;
		revalidate();
	}
	/**
	*/
	public void addItem(String name, int value)
	{
		addItem(name, value, pickColor());
		recalc = true;
		revalidate();
	}
	/**
	*/
	public void addItem(String name, int value, Color col)
	{
		graphItems.addElement(new GraphItem(name, value, col==null ? pickColor() : col));
		recalc = true;
		revalidate();
	}
	/**
	 */
	public synchronized void addItemListener(ItemListener l)
	{
		if (l != null)
			itemListeners.addElement(l);
	}
	/**
	*/
	public void clear()
	{
		graphItems = new Vector();
		selectedItem = null;
		invalidate();
		repaint();
	}
	/**
	 */
	public synchronized void fireSelectionEvent()
	{
		ItemEvent evt = new ItemEvent(this, 0, selectedItem,
									  ItemEvent.SELECTED);
		for (Enumeration enum = itemListeners.elements();
			 enum.hasMoreElements(); )
		{
			((ItemListener)enum.nextElement()).itemStateChanged(evt);
		}
	}
	protected MouseListener getMouseListener()
	{
		return
		new MouseAdapter()
		{
			public void mouseClicked(MouseEvent e)
			{
				if (e.getClickCount() > 1)
					setSelectedItem(itemAtPoint(new Point(e.getX(), e.getY())));
			}
			public void mouseExited(MouseEvent e)
			{ focusedItemValue.setVisible(false); }
		};
	}
	/**
	*/
	protected MouseMotionListener getMouseMotionListener()
	{
		return new MouseMotionAdapter()
		{
			 public void mouseMoved(MouseEvent e)
			 { updateFocusedItemLabel(new Point(e.getX(), e.getY())); }
		};
	}
	/**
	*/
	public Dimension getPreferredSize()
	{
		return(new Dimension(300, 200));
	}
	/**
	*/
	public GraphItem getSelectedItem()
	{
		return selectedItem;
	}
	/**
	*/
	public GraphItem getSelectedItem(Point p)
	{
		return itemAtPoint(p);
	}
	/**
	 */
	public String getSelectedItemLabel()
	{
		return selectedItem==null ? null : selectedItem.title;
	}
	/** (to satisfy the ItemSelectable interface)
	*/
	public Object[] getSelectedObjects()
	{
		Object[] array = { selectedItem };
		return array;
	}
	public abstract GraphItem itemAtPoint(Point p);
	/**
	*/
	public void paint(Graphics g)
	{
		super.paint(g);
	}
	/**
	* Select a color for you.
	*/
	public Color pickColor()
	{
	    return new Color(red[currColor%24]*127,
	                     green[currColor%24]*127,
	                     blue[(currColor++)%24]*127); // note the ++
	}
	/**
	*/
	public void removeItem(String name)
	{
		for (int i = 0; i < graphItems.size(); i++) {
		if (((GraphItem)graphItems.elementAt(i)).title.equals(name))
			if (selectedItem == graphItems.elementAt(i))
				selectedItem = null;
			graphItems.removeElementAt(i);
			recalc = true;
		}
	}
	/**
	 */
	public synchronized void removeItemListener(ItemListener l)
	{
		itemListeners.removeElement(l);
	}
	/**
	*/
	public void setBounds(int x, int y, int width, int height)
	{
		super.setBounds(x, y, width, height);
		setDimensions(new Rectangle(x,y,width, height));
		recalc = true;
		revalidate();
		repaint();
	}
	public void setBounds(Rectangle r)
	{
		super.setBounds(r);
		recalc = true;
		setDimensions(r);
	}
	/**
	*/
	public void setDimensions(Rectangle r)
	{
		int x = r.x;
		int y = r.y;
		int width = r.width;
		int height = r.height;

		top = padding;
		bottom = getSize().height - padding;
		Rectangle rect = focusedItemValue.getBounds();
		rect.x = padding;
		rect.y = top;
		focusedItemValue.setBounds(rect);
		left = 2*padding;
		right = getSize().width - padding;
	}
	/**
	 */
	public void setSelectedItem(GraphItem item)
	{
		selectedItem = item;
		invalidate();
		repaint();
		fireSelectionEvent();
	}
	/**
	 */
	public boolean setSelectedItem(String title)
	{
		for (Enumeration e = graphItems.elements(); e.hasMoreElements(); )
		{
			GraphItem item = (GraphItem)e.nextElement();
			if (item.title.equals(title))
			{
				setSelectedItem(item);
				return true;
			}
		}
		return false;
	}
	/**
	 */
	public void setShadeSelection(boolean shadeIt)
	{
		shadeSelection = shadeIt;
	}
	/**
	*/
	protected void updateFocusedItemLabel(Point p)
	{
		GraphItem item = itemAtPoint(p);
		double value = 0.0;
		if (item == null)
		{
				focusedItemValue.setVisible(false);
				return;
		}
		updateItemLabel(p, item.color, "" + item.title + " - " + item.value);
	}
	protected void updateItemLabel(Point p, Color bg, String txt)
	{
		Color fg = new Color(0xff-bg.getRed(), 0xff-bg.getGreen(), 0xff-bg.getBlue());
		StringBuffer text = new StringBuffer(txt);
		char chars[] = new char[text.length()];
		text.getChars(0, text.length(), chars, 0);
		FontMetrics metrics = focusedItemValue.getFontMetrics(focusedItemValue.getFont());
		int width = metrics.charsWidth(chars, 0, chars.length);
		focusedItemValue.setForeground(fg);
		focusedItemValue.setBackground(bg);
		focusedItemValue.setText(text.toString());
		focusedItemValue.setVisible(true);
		Rectangle bounds = focusedItemValue.getBounds();
		bounds.width = width + 8;
		bounds.x = right-p.x < width+20 ? right-width : p.x+20;
		bounds.y = bottom-p.y < 40 ? bottom-20 : p.y+20;
		focusedItemValue.setBounds(bounds);
		invalidate();
		repaint();
	}
}
