package com.objectwave.uiWidget;
import com.objectwave.viewUtility.BrowserControl;
import java.awt.Cursor;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JLabel;

/**
 * @author  dlossev
 * @version  $Id: JLinkLabel.java,v 1.1 2001/12/21 20:28:43 dave_hoag Exp $
 */
public class JLinkLabel extends JLabel
{

	String url = "www.javaworld.com";

	/**
	 *Constructor for the JLinkLabel object
	 */
	public JLinkLabel()
	{
		addMouseListener();
	}

	/**
	 *The main program for the JLinkLabel class
	 *
	 * @param  args The command line arguments
	 */
	public static void main(String[] args)
	{
		javax.swing.JDialog dialog = new javax.swing.JDialog(new javax.swing.JFrame(), "Test");
		java.awt.Container container = dialog.getContentPane();
		container.setLayout(new java.awt.FlowLayout());
		JLinkLabel linkLabel = new JLinkLabel();
		linkLabel.setUrl("www.javable.com");
		container.add(linkLabel);
		container.add(new JLabel("test"));
		dialog.setVisible(true);
	}

	/**
	 *Sets the Url attribute of the JLinkLabel object
	 *
	 * @param  url The new Url value
	 */
	public void setUrl(String url)
	{
		this.url = url;
		setText("<html><a href=" + url + ">" + url + "</a>");
	}

	/**
	 *Adds a feature to the MouseListener attribute of the JLinkLabel object
	 */
	public void addMouseListener()
	{
		// Add listener for the label clicks
		addMouseListener(
			new MouseListener()
			{
				/**
				 * @param  ae
				 */
				public void mouseClicked(MouseEvent ae)
				{
					BrowserControl.displayURL(url);
				}
				/**
				 * @param  p0
				 */
				public void mousePressed(MouseEvent p0)
				{
				}
				/**
				 * @param  p0
				 */
				public void mouseReleased(MouseEvent p0)
				{
				}
				/**
				 * @param  p0
				 */
				public void mouseEntered(MouseEvent p0)
				{
					Cursor cur = getCursor();
					setCursor(cur.getPredefinedCursor(Cursor.HAND_CURSOR));
				}
				/**
				 * @param  p0
				 */
				public void mouseExited(MouseEvent p0)
				{
					Cursor cur = getCursor();
					setCursor(cur.getDefaultCursor());
				}
			});
	}
}
