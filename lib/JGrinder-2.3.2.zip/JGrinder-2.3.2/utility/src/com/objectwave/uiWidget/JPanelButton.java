package com.objectwave.uiWidget;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

/**
 *    In a complex panel, sometimes it is desirable to replace a subpanel
 *  with a button which, when clicked, will present the given panel in
 *  it's own frame.  This class accomplished this, requiring minimal
 *  change to the original code.  The frame will contain the given panel,
 *  as well as a "close" button in the center-south.
 *
 *    This is a substitute for the DetailModel classes which have been used.
 *  although these are more powerful, and include their own transactions,
 *  the user code must be modified to use the different technique for
 *  accessing and changing the data.  Also, it is difficult (impossible?)
 *  to directly access the panel that is being displayed by the DetailModel
 *  class.
 *
 *    Note that an AncestorListener is used to make the frame invisible if
 *  the container of the JPanelButton becomes invisible.  This is comes in
 *  pretty handy.  If this behavior is not desired, then a subclass of
 *  JPanelButton can be created similar to the following:
 *  Ex: JPanelButton b = new JPanelButton(panel, "A Panel")
 *           { protected void setVisibilityListener() {} } );
 */
public class JPanelButton extends JButton
{
	private JPanel panel;
	private JFrame frame;
	private boolean autoOpen; // make visible open whenever button becomes visible.

	/**
	 * Create a JPanelButton.  Bases frame size panel's preferred size.
	 * Note that buttonText will also be the frame's title.
	 */
	public JPanelButton(JPanel panel, String buttonText)
	{
		this(panel, buttonText, new Rectangle(100, 100, panel.getPreferredSize().width, panel.getPreferredSize().height+60));
	}
	/**
	 * Create a JPanelButton.  Bases frame size on width,height.
	 * Note that buttonText will also be the frame's title.
	 */
	public JPanelButton(JPanel panel, String buttonText, int width, int height)
	{
		this(panel, buttonText, new Rectangle(100, 100, width, height));
	}
	/**
	 * Create a JPanelButton.  Frame size will be "bounds".
	 * Note that buttonText will also be the frame's title.
	 */
	public JPanelButton(JPanel panel, String buttonText, Rectangle bounds)
	{
		super(buttonText);
		this.panel = panel;
		initFrame(buttonText, bounds);
		addActionListener(
			new ActionListener()
			{
				public void actionPerformed(ActionEvent e)
				{
					frame.setVisible(true);
					autoOpen = true;
				}
			} );
	}
	/**
	 *  Access the JFrame managed by the JPanelButton.
	 */
	public JFrame getFrame()
	{
		return frame;
	}
	/**
	 *  Access the panel contained by the JPanelButton.
	 */
	public JPanel getPanel()
	{
		return panel;
	}
	/**
	 *  Initialize the frame (called by the contructor).
	 */
	protected void initFrame(String title, Rectangle bounds)
	{
		JButton closeButton = new JButton("Close");
		closeButton.addActionListener(
			new ActionListener()
			{   public void actionPerformed(ActionEvent evt)
				{
					frame.setVisible(false);
					autoOpen = false;
				}
			} );

		frame = new JFrame();
		frame.setTitle(title);
		frame.setBounds(bounds);
		Container pane = frame.getContentPane();

		GridBagLayout layout = new GridBagLayout();
		pane.setLayout(layout);
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.gridwidth = GridBagConstraints.REMAINDER;
		gbc.weightx = gbc.weighty = 1.0;
		gbc.fill = GridBagConstraints.BOTH;
		layout.setConstraints(panel, gbc);
		gbc = new GridBagConstraints();
		gbc.anchor = GridBagConstraints.WEST;
		gbc.insets = new Insets(5, 5, 5, 5);
		layout.setConstraints(closeButton, gbc);
		pane.add(panel);
		pane.add(closeButton);

		setVisibilityListener();
		setWindowListener();
	}
	/**
	 *  A rudimentary (spl?) test of the JPanelButton class.
	 */
	public static void main(String args[])
	{
		JPanel panel = new JPanel();
		panel.add(new JButton("West"), "West");
		panel.add(new JTextField("Center"), "Center");
		panel.setPreferredSize(new Dimension(150, 70));

		JFrame frame = new JFrame("test JPanelButton");
		frame.getContentPane().setLayout(new BorderLayout(8,8));
		frame.setSize(new Dimension(200,100));
		JPanelButton panelButton = new JPanelButton(panel, "The Panel");
		frame.getContentPane().add(panelButton);
		frame.setVisible(true);
	}
	/**
	 *  Listen to the button for when the button's container becomes
	 *  invisible: when this happens, the frame is becomes invisible also.
	 */
	protected void setVisibilityListener()
	{
		this.addAncestorListener(
			new AncestorListener()
			{
				public void ancestorRemoved(AncestorEvent evt)
				{
					frame.setVisible(false);
				}
				public void ancestorAdded(AncestorEvent evt)
				{
					if (autoOpen)
						frame.setVisible(true);
				}
				public void ancestorMoved(AncestorEvent evt) {}
			} );
	}
	/**
	 *  Listen for the window closing (someone clicked the north-east 'X')
	 */
	protected void setWindowListener()
	{
		frame.addWindowListener(
			new WindowAdapter()
			{
				public void windowClosing(WindowEvent e)
				{
					autoOpen = false;
				}
			} );
	}
}