package com.objectwave.uiWidget;

import javax.swing.*;
import javax.swing.event.*;
import java.awt.event.*;
import javax.swing.table.*;

/**
* This class is intended to provide for better tab support within * a JTable.
*/
public class JTableTabbing extends JTable
{
	/**
	*/
	class MyKeyListener implements KeyListener
	{
		/**
		*/
		public void keyReleased(KeyEvent e){}
		public void keyTyped(KeyEvent e){
			//           System.out.println(e);
			editSelection();
		}
		/**
		*/
		public void keyPressed(KeyEvent event)
		{
			JTableTabbing.this.keyPressed(event);
		}
	}
	/**
	*/
	public JTableTabbing()
	{
		super();
		addKeyListener(new MyKeyListener());
	}
	/**
	*/
	public JTableTabbing(TableModel mod)
	{
		super(mod);
		addKeyListener(new MyKeyListener());
	}
	/**
	*/
	public void doTabEvent(KeyEvent event)
	{
		int row = getEditingRow();
		int col = getEditingColumn();

		//        System.out.println("--------- Entered Do Tab Row : " + getSelectedRow() + " Col: " + getSelectedColumn());
		//This works because I select the row and column being edited. row = getSelectedRow(); col = getSelectedColumn();

		editingStopped(new ChangeEvent(this));
		if(event.isShiftDown())
			col--;
		else
			col++;
		if(col == getColumnModel().getColumnCount())
		{
			col = 0;
			if(++row == getModel().getRowCount())
			{
				FocusManager focusManager =
				FocusManager.getCurrentManager();
				focusManager.focusNextComponent(this); event.consume();
				return;
			}
		}
		else
		if(col < 0)
		{
			col = getColumnModel().getColumnCount() - 1;
			if(--row < 0)
			{
				FocusManager focusManager = FocusManager.getCurrentManager();
				focusManager.focusPreviousComponent(this);
				event.consume();
				return;
			}
		}
		editCellAt(row, col);
		event.consume();
	}
	/**
	*/
	public boolean editCellAt(int row, int column, java.util.EventObject e)
	{
	//        System.out.println("Calling editCellAt(E) " + row + " " + column);

		requestFocus();
		if(isEditing())
			editingStopped(new ChangeEvent(this));
		if(! isRowSelected(row))
		{
			setRowSelectionInterval(row, row);
		}
		if(! isColumnSelected(column))
			setColumnSelectionInterval(column, column);
		boolean res = super.editCellAt(row, column, e);
		return res;
	}
	/**
	FocusListener theOne = new MyFocusListener(); java.util.Vector theList = new java.util.Vector(4); /**
	public java.awt.Component prepareEditor(TableCellEditor editor,
	int row,
	int column)
	{
	java.awt.Component comp = super.prepareEditor(editor, row,
	column);
	if(! theList.contains(comp))
	{
	comp.addFocusListener(theOne);
	theList.addElement(comp);
	}
	return comp;
	}
	/**
	class MyFocusListener implements FocusListener {
	/**
	public void focusLost(FocusEvent evt) {
	System.out.println("Editor losing focus"); if(JTableTabbing.this.isEditing())
	editingStopped(new
	com.sun.java.swing.event.ChangeEvent(this));
	}
	/**
	public void focusGained(FocusEvent evt) {
	System.out.println("Editor gaining focus");
	}
	}
	/**
	*/
	void editSelection()
	{
		int row = getSelectedRow();
		int col = getSelectedColumn();
		editCellAt(row, col);
	}
	/**
	*/
	public boolean isManagingFocus() { return true; }
	/**
	* This can delegate tab and arrow events.
	*/
	public void keyPressed(KeyEvent event)
	{
		if(event.getKeyCode() == KeyEvent.VK_TAB
			|| event.getKeyChar() == '\t')
		{
			doTabEvent(event);
		}
		else
			moveCellFocus(event.getKeyCode());
	}
	/**
	*/
	protected void moveCellFocus(int keyCode)
	{
	    int col = getEditingColumn();
		int row = getEditingRow();
		if (col < 0 || row < 0)
			return;
	    if (keyCode == KeyEvent.VK_UP)
	    {
			if (row > 0)
			{
				editingStopped(new ChangeEvent(this));
				editCellAt(row-1, col);
			}
	    }
	    else if (keyCode == KeyEvent.VK_DOWN)
	    {
			if (row < getRowCount()-1)
			{
				editingStopped(new ChangeEvent(this));
				editCellAt(row+1, col);
			}
	    }
	}
}