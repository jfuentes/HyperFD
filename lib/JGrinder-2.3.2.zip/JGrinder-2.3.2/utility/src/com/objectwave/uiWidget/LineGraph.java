package com.objectwave.uiWidget;

import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class LineGraph extends Graph 
{
	int increment;
	int position;

	public LineGraph(String title, int min, int max) {
		super(title, min, max);
	}
	static public void main(String args[])
	{
		//LineGraph graph = new LineGraph("Test Line Graph", 10, 100);
		PieChart graph = new PieChart("Test Line Graph");
		graph.addItem("debt", 90, Color.red);
		graph.addItem("assets", 20, Color.black);
		graph.addItem("etcetera", 50, Color.green);
		java.awt.Frame frame;
		try {
			Class aFrameClass = Class.forName("uvm.abt.edit.TestFrame");
			frame = (java.awt.Frame)aFrameClass.newInstance();
		} catch (java.lang.Throwable ivjExc) {
			frame = new java.awt.Frame();
		}
		frame.add("Center", graph);
		frame.setSize(graph.getPreferredSize());
		frame.setVisible(true);
		graph.invalidate();
		graph.repaint();
	}
	public void paint(Graphics g) {
		super.paint(g);

		increment = (right - left)/(items.size() - 1);
		position = left;
		Color temp = g.getColor();
		GraphItem firstItem = (GraphItem)items.firstElement();
		int firstAdjustedValue = bottom - (((firstItem.value - min)*(bottom - top)
										 )/(max - min));
		g.setColor(firstItem.color);
		g.drawString(firstItem.title, position - fm.stringWidth(firstItem.title),
				   firstAdjustedValue - 2);
		g.fillOval(position - 2, firstAdjustedValue - 2, 4, 4);
		g.setColor(temp);
		for (int i = 0; i < items.size() - 1; i++) {

			GraphItem thisItem = (GraphItem)items.elementAt(i);
			int thisAdjustedValue = bottom - (((thisItem.value - min)*
								 (bottom - top))/(max - min));
			GraphItem nextItem = (GraphItem)items.elementAt(i+1);
			int nextAdjustedValue = bottom - (((nextItem.value - min)*
								 (bottom - top))/(max - min));

			g.drawLine(position, thisAdjustedValue,
					position+=increment, nextAdjustedValue);
			g.setColor(nextItem.color);
			if (nextAdjustedValue < thisAdjustedValue)
			g.drawString(nextItem.title, position - fm.stringWidth(nextItem.title),
						 nextAdjustedValue + titleHeight + 4);
		else
			g.drawString(nextItem.title, position - fm.stringWidth(nextItem.title),
						 nextAdjustedValue - 4);
		g.fillOval(position - 2, nextAdjustedValue - 2, 4, 4);
		g.setColor(temp);
		}
	} // end paint
}