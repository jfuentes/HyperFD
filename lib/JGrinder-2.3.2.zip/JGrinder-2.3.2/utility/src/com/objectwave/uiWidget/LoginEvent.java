package com.objectwave.uiWidget;

import java.util.EventObject;

/** LoginEvent
*/
public class LoginEvent extends EventObject
{
	public String userName;
	public String password;

	public LoginEvent(Object source)
	{
		super(source);
	}
	public String getPassword(){ return password; }
	public String getUserName(){ return userName; }
	public void setPassword(String val){ password = val; }
	public void setUserName(String val) { userName = val; }
}