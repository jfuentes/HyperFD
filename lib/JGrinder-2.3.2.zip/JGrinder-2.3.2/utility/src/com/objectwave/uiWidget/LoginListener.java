package com.objectwave.uiWidget;

import java.util.EventListener;

/** LoginEvent
*/
public interface LoginListener extends EventListener
{
	public boolean loginRequest(LoginEvent e) throws Exception;
}