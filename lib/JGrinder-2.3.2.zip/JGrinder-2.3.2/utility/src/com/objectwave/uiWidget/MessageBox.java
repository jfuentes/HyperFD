package com.objectwave.uiWidget;

import java.awt.*;
import java.awt.event.*;
import java.util.Hashtable;

import javax.swing.*;
import com.objectwave.viewUtility.WindowControl;

/**
* Used for displaying a quick message.
*/
public class MessageBox extends JDialog implements ActionListener, Runnable
{
	static Hashtable oneInstance = new Hashtable();
	public boolean result = false;
	String message;
	String title = "Information - ";
	JPanel messagePanel;
	JButton pbOk, pbClose;
	Frame titleFrame;

	JTextPane taMessage;

	public MessageBox(String e, Frame f, boolean modal)
	{
		super(f,modal);
		message = e;
		initialize();
		setTitle(title);
		pack();
		WindowControl.enforceMinimumSize(this, 200, 100);
		WindowControl.centerWindow(this);
		displayBusinessObject();
	}
	public void actionPerformed(ActionEvent e)
	{
		if(e.getSource() == pbOk) pbOkClicked();
		else
		if(e.getSource() == pbClose) pbCloseClicked();
	}
	public JPanel buttonPanel()
	{
		JPanel p = new JPanel();
		pbOk = new JButton("Ok");
		p.add(pbOk);
		pbOk.addActionListener(this);
		pbClose = new JButton("Cancel");
		pbClose.addActionListener(this);
		p.add(pbClose);
		return p;
	}
	void close()
	{
	    if(titleFrame != null) {
		    titleFrame.setVisible(false);
		    titleFrame.dispose();
		}
		setVisible(false);
		dispose();
	}
	public void displayBusinessObject()
	{
/*	    java.util.Vector v = com.objectwave.utility.StringManipulator.extractStringsDelimiter(message, ' ');
	    java.util.Enumeration e = v.elements();
	    messagePanel.removeAll();
	    while(e.hasMoreElements()){
	        messagePanel.add(new JLabel((String)e.nextElement()));
	    }
*/
		taMessage.setText(message);
	}
	/**
	* If you wish to retain the 'bounds' of the previous message box, use this message
	* to create your message boxes.
	*/
	public static MessageBox getInstance(String e,  Component f, boolean modal)
	{
		Component foundF = f;
/*		Component oldFound = null;
		while( (! (foundF instanceof Frame)) && (foundF != null) && (oldFound != foundF) ){
		    oldFound = foundF;
			foundF = foundF.getParent();
		}
		if(oldFound == foundF || foundF == null){
*/
			foundF = new Frame("Message");
			foundF.setBounds(-100,-100,10,10);
			foundF.setVisible(true);
			MessageBox box = new MessageBox(e, (Frame)foundF, modal);
			box.titleFrame = (Frame)foundF;
if(true)            return box;
//        }

		MessageBox it = (MessageBox)oneInstance.get(foundF);
		if(it == null){
			it = new MessageBox(e, (Frame)foundF, modal);
		}
		else {
			MessageBox tmp = new MessageBox(e, (Frame)foundF, modal);
			tmp.setBounds(it.getBounds());
			it = tmp;
		}

		oneInstance.put(foundF, it );
		return it;
	}
	/**
	 * Method to handle old AWT events
	 * @return boolean
	 * @param evt java.awt.Event
	 */
	public boolean handleEvent(java.awt.Event evt)
	{
		/* Note: Changes to this method will not be overwritten when code is re-generated */
		if (evt.id == java.awt.Event.WINDOW_DESTROY) {
			close();
			return true;
		}
		return super.handleEvent(evt);
	}
	void initialize()
	{
		Container c = getContentPane();
		c.setLayout(new BorderLayout());
		taMessage = new JTextPane();
		taMessage.setEditable(false);
		c.add("Center", taMessage);
//        messagePanel = new JPanel();
//        c.add("Center", messagePanel);
		c.add("South", buttonPanel());
	}
	void pbCloseClicked()
	{
		result = false;
		close();
	}
	void pbOkClicked()
	{
		result = true;
		close();
	}
	/**
	 * This prevents the caller from blocking on ask(), which
	 * if this class is used on an awt event thread would
	 * cause a deadlock.
	 */
	public void run()
	{
		Toolkit.getDefaultToolkit().beep();
		setVisible(true);
	}
	/**
	 * This prevents the caller from blocking on setVisible(true).
	 */
	public void showNoBlock()
	{
		// Start a new thread to show the dialog
		Thread thread = new Thread(this);
		thread.start();
	}
}