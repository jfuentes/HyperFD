package com.objectwave.uiWidget;

import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.io.IOException;
import java.util.Vector;
import com.objectwave.utility.FileFinder;

import javax.swing.*;
import javax.swing.tree.*;

public class MultipleFileSelector extends JDialog implements WindowListener
{
	static File currentDirectory;
	String [] initList;
	TextField tfFileName;
	TextField tfCurrentDirectory;
	Choice chFileTypes;
	Choice chDrives;
	List lbProjectFiles, lbAllFiles;

	JList lbDirectories;

	Button pbAdd, pbRemove, pbSelectAll, pbUnselectAll, pbOk, pbCancel;
	String [] fileTypes;
	String [] selection;
	JTree tree = null;

	public boolean terminateThreadOnClose = false;

	public boolean paintOff = false;

	public MultipleFileSelector(Frame f)
	{
		super(f, "Select Files" ,true);
		if(currentDirectory == null)
			currentDirectory = new File(System.getProperty("user.dir"));
		fileTypes = defaultFileTypes();
	}
	public MultipleFileSelector(Frame f, String [] initialFileList)
	{
		this(f);
		setInitialList(initialFileList);
	}
	/**
	* Very costly recursive algorithm
	*/
	void assembleDirectories(DefaultMutableTreeNode root, String currentDir) throws IOException
	{
		if(true) return;
		File f = new File(currentDir);
		FileFinder ff = new FileFinder(f);
		ff.setUserFilter(FileFinder.dirFilter);
		String [] list = ff.list();
		for( int i = 0; i < list.length; i++){
			DefaultMutableTreeNode tmp = new DefaultMutableTreeNode(list[i]);
			root.add(tmp);
			assembleDirectories(tmp, f.getCanonicalPath() + File.separatorChar + list[i]);
		}
	}
	public JPanel buttonPanel()
	{
  		JPanel panel1 = new JPanel();
		GridBagLayout gridBagLayout;
		gridBagLayout = new GridBagLayout();
		panel1.setLayout(gridBagLayout);
		GridBagConstraints gbc;
		gbc = new GridBagConstraints();
		gbc.weightx = 1.0;
		gbc.weighty = 1.0;
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.gridwidth = GridBagConstraints.REMAINDER;
		gbc.anchor = GridBagConstraints.SOUTH;
		gbc.insets = new Insets(5,5,0,5);
		pbAdd = new Button("Add");
		gridBagLayout.setConstraints(pbAdd, gbc);
		panel1.add(pbAdd);
		pbRemove = new Button("Remove");
		gbc.anchor = GridBagConstraints.NORTH;
		gbc.insets = new Insets(3,5,5,5);
		gridBagLayout.setConstraints(pbRemove, gbc);
		panel1.add(pbRemove);
		pbSelectAll = new Button("Select All");
		gbc.anchor = GridBagConstraints.SOUTH;
		gbc.insets = new Insets(5,5,0,5);
		gridBagLayout.setConstraints(pbSelectAll, gbc);
		panel1.add(pbSelectAll);
		pbUnselectAll = new Button("Unselect All");
		gbc.anchor = GridBagConstraints.NORTH;
		gbc.insets = new Insets(3,5,5,5);
		gridBagLayout.setConstraints(pbUnselectAll, gbc);
		panel1.add(pbUnselectAll);
		pbOk = new Button("Ok");
		gbc.insets = new Insets(5,5,0,5);
		gbc.anchor = GridBagConstraints.SOUTH;
		gridBagLayout.setConstraints(pbOk, gbc);
		panel1.add(pbOk);
		pbCancel = new Button("Cancel");
		gbc.anchor = GridBagConstraints.NORTH;
		gbc.insets = new Insets(3,5,5,5);
		gridBagLayout.setConstraints(pbCancel, gbc);
		panel1.add(pbCancel);
		return panel1;
	}
	public void cbFileTypesStateChanged()
	{
		showCurrentFiles();
	}
	public void closing(WindowEvent e)
	{
		Window f = e.getWindow();
		f.setVisible(false);
		f.dispose();
		if(terminateThreadOnClose)
			System.exit(0);
	}
	public static String [] defaultFileTypes()
	{
		String [] result = new String [2];
		result[0] = "Java Src Files (*.java)";
		result[1] = "All Files(*)";
		return result;
	}
	public void displayBusinessObject()
	{
		showCurrentDirectory();
		showProjectFiles();
		showCurrentFiles();
		showCurrentDirectories();
	}
	void doubleClickDirectory(Object directoryName)
	{
		String name = (String)directoryName;
		try {
		name = currentDirectory.getCanonicalPath() + File.separatorChar + name;
		setCurrentDirectory(new File(name));
		showCurrentFiles();
		showCurrentDirectories();
		} catch (java.io.IOException e) { System.err.println(e); }
	}
	void fillDriveList()
	{
		Vector driveList = new Vector();
		File f;
		chDrives.addItem("A:");
		f = new File("c:\\");
		if(f.isDirectory()) chDrives.addItem("C:");
		f = new File("d:\\");
		if(f.isDirectory()) chDrives.addItem("D:");
		f = new File("e:\\");
		if(f.isDirectory()) chDrives.addItem("E:");
	}
	void fillTypeList()
	{
		for(int i = 0; i < fileTypes.length; i++)
			chFileTypes.addItem(fileTypes[i]);
	}
	public JScrollPane getDirectoryPanel()
	{
		lbDirectories = new JList();
		MouseListener mouseListener = new MouseAdapter() {
			public void mouseClicked(MouseEvent e)
				{
					if (e.getClickCount() == 2) {
						int index = lbDirectories.locationToIndex(e.getPoint());
						doubleClickDirectory(lbDirectories.getModel().getElementAt(index));
					}
				}
		};
		lbDirectories.addMouseListener(mouseListener);
		return new JScrollPane(lbDirectories);
	}
	protected void getMiddlePart(JPanel panel2, GridBagLayout gridBagLayout, GridBagConstraints gbc)
	{
		Label label1;

		lbAllFiles = new java.awt.List();
		lbAllFiles.setMultipleMode(true);
		gbc.gridx = 0;
		gbc.gridy++;
		gbc.weightx = 1.0;
		gbc.weighty = 41.0;
		gbc.fill = GridBagConstraints.BOTH;
		gbc.insets = new Insets(0,5,0,0);
		gridBagLayout.setConstraints(lbAllFiles, gbc);
		panel2.add(lbAllFiles);
		gbc.gridx = 1;
		JScrollPane directories = getDirectoryPanel();
		directories.setPreferredSize(new java.awt.Dimension(10, 20));
		gbc.insets = new Insets(0,10,0,0);
		gridBagLayout.setConstraints(directories, gbc);
		panel2.add(directories);

		gbc.gridx = 0;
		gbc.gridy++;
		JLabel label = new JLabel("List files of Type:");
		gbc.weighty = 1.0;
//		gbc.anchor = GridBagConstraints.NORTHWEST;
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.insets = new Insets(0,0,0,0);
		gridBagLayout.setConstraints(label, gbc);
		panel2.add(label);
		gbc.gridx = 1;
		gbc.insets = new Insets(0,10,0,0);
		label = new JLabel("Drives:");
		label.setPreferredSize(new java.awt.Dimension(20,gbc.ipady));
		gridBagLayout.setConstraints(label, gbc);
		panel2.add(label);

		chFileTypes = new java.awt.Choice();
		gbc.gridx = 0;
		gbc.gridy++;
		gbc.gridwidth = 1;
		gbc.insets = new Insets(0,5,0,0);
		gridBagLayout.setConstraints(chFileTypes, gbc);
		panel2.add(chFileTypes);
		chDrives = new java.awt.Choice();
		chDrives.setEnabled(false);
		gbc.insets = new Insets(0,10,0,0);
		gbc.gridx = 1;
		gridBagLayout.setConstraints(chDrives, gbc);
		panel2.add(chDrives);
		label = new JLabel("Project Files:");
		gbc.insets = new Insets(0,0,0,0);
		gbc.gridx = 0;
		gbc.gridy++;
		gridBagLayout.setConstraints(label, gbc);
		panel2.add(label);
		gbc.gridx = 0;
		gbc.gridy++;
		lbProjectFiles = new java.awt.List();
		lbProjectFiles.setMultipleMode(true);
		gbc.fill = GridBagConstraints.BOTH;
		gbc.gridwidth = GridBagConstraints.REMAINDER;
		gbc.insets = new Insets(0,5,0,0);
		gbc.weighty = 1.0;
		gbc.ipady = 40;
		gridBagLayout.setConstraints(lbProjectFiles, gbc);
		panel2.add(lbProjectFiles);
	}
	public String getPatternString()
	{
		String str = chFileTypes.getSelectedItem();
		if(str == null) return "*";
		String result = str;
		int idx = str.lastIndexOf('(');
		if(idx > 0)
			result = str.substring(idx + 1, str.lastIndexOf(')'));
		return result;
	}
	public String [] getSelection()
	{
		return selection;
	}
	public void hookEvents()
	{
		this.addWindowListener(this);
		pbCancel.addActionListener(new ActionListener() {    public void actionPerformed(ActionEvent e){ pbCancelClicked(); } } );
		pbAdd.addActionListener(new ActionListener() {    public void actionPerformed(ActionEvent e){ pbAddClicked(); } } );
		pbRemove.addActionListener(new ActionListener() {    public void actionPerformed(ActionEvent e){ pbRemoveClicked(); } } );
		pbSelectAll.addActionListener(new ActionListener() {    public void actionPerformed(ActionEvent e){ pbSelectAllClicked(); } } );
		pbUnselectAll.addActionListener(new ActionListener() {    public void actionPerformed(ActionEvent e){ pbUnselectAllClicked(); } } );
		pbOk.addActionListener(new ActionListener() {    public void actionPerformed(ActionEvent e){ pbOkClicked(); } } );
		lbProjectFiles.addActionListener(new ActionListener() {    public void actionPerformed(ActionEvent e){ lbProjectFilesDoubleClicked(); } } );
		lbAllFiles.addActionListener(new ActionListener() {    public void actionPerformed(ActionEvent e){ lbAllFilesDoubleClicked(); } } );
		chFileTypes.addItemListener(new ItemListener() {    public void itemStateChanged(ItemEvent e){ cbFileTypesStateChanged();  } } );
		tfFileName.addActionListener(new ActionListener() {    public void actionPerformed(ActionEvent e){ tfFileNameEntered(); } } );
	}
	public void initScreen()
	{
		getContentPane().setLayout(new BorderLayout());
		getContentPane().add("Center",initScreenLayout());
		hookEvents();
		initSizeAndConstraints();
	}
	public Component initScreenLayout()
	{
		JPanel p = new JPanel();

		p.setLayout(new BorderLayout(0,0));
		p.add("East", buttonPanel());
		p.add("Center", mainPanel());
		return p;
	}
// Create the look of the screen.
	public void initSizeAndConstraints()
	{
		setSize(426,300);
	}
	public void lbAllFilesDoubleClicked()
	{
		pbAddClicked();
	}
	public void lbProjectFilesDoubleClicked()
	{
		pbRemoveClicked();
	}
	public static void main(String [] argv)
	{
		Frame f = new Frame("Test");
		FileFinder ff = new FileFinder();
		String [] inits =  ff.getAllFilenames(System.getProperty("user.dir"));
		MultipleFileSelector scrn = new MultipleFileSelector(f, inits);

		scrn.initScreen();
		scrn.terminateThreadOnClose = true;
		scrn.show();
		String [] result = scrn.getSelection();
		if(result != null){
			for(int i = 0; i < result.length; i++)
				System.out.println(result[i]);
		}
	}
	public JPanel mainPanel()
	{
		JPanel main = new JPanel();
		GridBagLayout gridBagLayout;
		gridBagLayout = new GridBagLayout();
		main.setLayout(gridBagLayout);
		JLabel label1 = new JLabel("File Name:");
		GridBagConstraints gbc;
		gbc = new GridBagConstraints();
		gbc.weightx = 1.0;
		gbc.weighty = 1.0;
		gbc.gridx = gbc.gridy = 0;
		gbc.anchor = GridBagConstraints.NORTHWEST;
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.insets = new Insets(0,0,0,0);
		gridBagLayout.setConstraints(label1, gbc);
		main.add(label1);
		label1 = new JLabel("Directories:");
		gbc.insets = new Insets(0,10,0,0);
		gbc.gridx = 1;
		gridBagLayout.setConstraints(label1, gbc);
		main.add(label1);
		tfFileName = new java.awt.TextField();

		gbc.gridx = 0;
		gbc.gridy++;
		gbc.gridwidth = 2;
		gbc.weighty = 1.0;
		gbc.insets = new Insets(0,5,0,0);
		gridBagLayout.setConstraints(tfFileName, gbc);
		main.add(tfFileName);
		tfCurrentDirectory = new java.awt.TextField();
//		tfCurrentDirectory.setEditable(false);
//		gbc.insets = new Insets(0,10,0,0);
//		gbc.gridx = 1;
//		gridBagLayout.setConstraints(tfCurrentDirectory, gbc);
//		main.add(tfCurrentDirectory);
		gbc.gridwidth = 1;
		gbc.ipady = 8;

		getMiddlePart(main, gridBagLayout, gbc);
		return main;
	}
	public void openInit()
	{
		fillDriveList();
		fillTypeList();
		displayBusinessObject();
		validate();
	}
	public void paint(Graphics g)
	{
		if(paintOff) return;
		super.paint(g);
	}
	public void pbAddClicked()
	{
		String [] sel = lbAllFiles.getSelectedItems();
		for(int i = 0; i < sel.length; i++){
			lbAllFiles.remove(sel[i]);
			lbProjectFiles.add( currentDirectory.getPath() + File.separatorChar + sel[i]);
		}
	}
	public void pbCancelClicked()
	{
		selection = null;
		processWindowEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING));
	}
	public void pbOkClicked()
	{
		selection = lbProjectFiles.getItems();
		processWindowEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING));
	}
	public void pbRemoveClicked()
	{
		String [] sel = lbProjectFiles.getSelectedItems();
		for(int i = 0; i < sel.length; i++)
			lbProjectFiles.remove(sel[i]);
		showCurrentFiles();
	}
	public void pbSelectAllClicked()
	{
		int size = lbAllFiles.getItemCount();
		for(int i = 0; i < size; i++)
			lbAllFiles.select(i);
	}
	public void pbUnselectAllClicked()
	{
		int size = lbAllFiles.getItemCount();
		for(int i = 0; i < size; i++)
			lbAllFiles.deselect(i);
	}
	boolean projectContains(String str)
	{
		String [] proj = lbProjectFiles.getItems();
		for(int i = 0; i < proj.length; i++)
			if(proj[i].equals(str)) return true;
		return false;
	}
	void setCurrentDirectory(File f)
	{
		currentDirectory = f;
		showCurrentDirectory();
	}
	public void setFileTypes(String [] values )
	{
		if(values == null) return;
		fileTypes = values;
		if(this.isShowing())
			fillTypeList();
	}
	void setInitialList(String [] values)
	{
		initList = values;
		if(this.isShowing())
			showProjectFiles();
	}
	void showCurrentDirectories()
	{

		FileFinder ff = new FileFinder(currentDirectory);
		ff.setUserFilter(FileFinder.dirFilter);
		String [] list = ff.list();
		String [] realList = new String [list.length + 1 ];
		System.arraycopy(list, 0, realList, 1, list.length);
		realList [0] = "..";
		lbDirectories.setListData(realList);
		lbDirectories.revalidate();
/*Attempt to display trees.
		try{
			String path = currentDirectory.getCanonicalPath();
			int idx = path.indexOf(File.separatorChar);
			DefaultMutableTreeNode top = null;
			DefaultMutableTreeNode prev = null;
			if(idx > -1){
				top = new DefaultMutableTreeNode(path.substring(0, idx));
				assembleDirectories(top, path.substring(0, idx + 1));
			}
			if(top == null) return;
			if(tree != null)
				lbDirectories.getViewport().remove(tree);
			tree = new JTree(top);
			lbDirectories.getViewport().add(tree);
		} catch (IOException e) {}
*/
	}
	void showCurrentDirectory()
	{
		try{
			String path = currentDirectory.getCanonicalPath();
			chDrives.select(path.substring(0,2));
//            tfCurrentDirectory.setText(path);
				tfFileName.setText(path);
		} catch (IOException e) {}
	}
	/**
	* Find all of the files that match the pattern string '*.java' in the current directory.
	*/
	void showCurrentFiles()
	{
		FileFinder ff = new FileFinder(currentDirectory);
		ff.setPatternString(getPatternString());
		String [] list = ff.list();
		paintOff = true;
		lbAllFiles.removeAll();
		for(int i = 0; i < list.length; i++){
			if(i > 50) lbAllFiles.setVisible(true);
			if(! projectContains(currentDirectory.getPath() + File.separatorChar + list[i])){
				File f = new File(currentDirectory.getPath() + File.separatorChar + list[i]);
				if(! f.isDirectory())
					lbAllFiles.addItem(list[i]);
			}
		}
		paintOff = false;
		lbAllFiles.setVisible(true);
	}
	void showProjectFiles()
	{
		lbProjectFiles.removeAll();
		if(initList == null) return;
		for(int i = 0; i < initList.length; i++)
			lbProjectFiles.addItem(initList[i]);
	}
	public void tfFileNameEntered()
	{
		String fName = tfFileName.getText();
		try{
			File f = new File(fName);
			if(! f.isDirectory())
				if(f.isFile()){
					lbProjectFiles.add( f.getCanonicalPath());
					f = new File(f.getParent());
				}
			if(!currentDirectory.equals(f))
				setCurrentDirectory(f);
			showCurrentFiles();
			showCurrentDirectories();
		} catch (IOException e) {}
	}
	public void windowActivated(WindowEvent e){ }
	public void windowClosed(WindowEvent e){ }
	public void windowClosing(WindowEvent e){ closing(e); }
	public void windowDeactivated(WindowEvent e){}
	public void windowDeiconified(WindowEvent e){}
	public void windowIconified(WindowEvent e){}
// Window Listener code.
	public void windowOpened(WindowEvent e){ openInit(); }
}