package com.objectwave.uiWidget;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.border.*;
import javax.swing.JLabel;
import javax.swing.JComponent;

/**
*/
public class PieChart extends JGraph
{
   public int arcX;
	public int arcY;
	public int size;
	public Point center;
	int titleHeight;
	FontMetrics fm;
	int wedgeLimit = -1;
	double wedgeLimitPercent = -1;
	String title;
	boolean staleDegrees = true;
	Vector itemDegrees; // pie slices relating to elements of "graphItems"
	Vector labels;
	int totalValue;
	boolean displayLabels = false;

	/**
	*/
	public PieChart()
	{
		this("");
	}
	/**
	*/
	public PieChart(String title)
	{
		this.title = title;
		clear();
		setLayout(null);
		addMouseListener(getMouseListener());
		addMouseMotionListener(getMouseMotionListener());
		focusedItemValue = new JLabel();
		focusedItemValue.setBounds(new Rectangle(0, 0, 50, 18));
		focusedItemValue.setOpaque(true);
		focusedItemValue.setForeground(Color.black);
		focusedItemValue.setBackground(Color.white);
		focusedItemValue.setToolTipText("Value & label of slice under the pointer");
		focusedItemValue.setText("value");
		focusedItemValue.setHorizontalAlignment(JLabel.CENTER);
		focusedItemValue.setVisible(false);
		focusedItemValue.setBorder(new LineBorder(Color.black));
		this.add(focusedItemValue);
	}
	/** Pass an object instead of a name so that it can be accessed later.
	* the object's name will be object.toString().
	*/
	public void addItem(Object object, int value, Color col)
	{
		graphItems.addElement(new GraphItem(object, value, col==null ? pickColor() : col));
		JLabel l = new JLabel(object.toString());
		l.setToolTipText("Value: " + value);
		labels.addElement(l);
		add(l);
		revalidate();
		totalValue += value;
		staleDegrees = true;
	}
	/**
	*/
	public void addItem(String name, int value)
	{
		addItem(name, value, pickColor());
		staleDegrees = true;
	}
	/**
	*/
	public void addItem(String name, int value, Color col)
	{
		graphItems.addElement(new GraphItem(name, value, col==null ? pickColor() : col));
		JLabel l = new JLabel(name);
		l.setToolTipText("Value: " + value);
		labels.addElement(l);
		add(l);
		revalidate();
		totalValue += value;
		staleDegrees = true;
	}
	public void clear()
	{
		graphItems = new Vector();
		if(labels != null)
		{
			Enumeration e = labels.elements();
			while(e.hasMoreElements())
			{
				remove((Component)e.nextElement());
			}
		}
		labels = new Vector();
		itemDegrees = new Vector();
		totalValue = 0;
		staleDegrees = true;
		super.clear();
	}
	/**
	*/
	protected void displayLabel(JLabel label, int degrees, int adjustedValue, int size)
	{
		Dimension d = label.getPreferredSize();

		Point titlePosition = new Point(0, 0);
		titlePosition.x = (int)(Math.cos(degrees*Math.PI/180 +
					   adjustedValue*Math.PI/360) * size/2) + center.x + left;
		titlePosition.y = center.y - (int)(Math.sin(degrees*Math.PI/180 +
					   adjustedValue*Math.PI/360) * size/2) + top;

		Point wedgeCenter = new Point((arcX + (size /2)), (arcY + (size /2)));
		if (titlePosition.x <= wedgeCenter.x)
			titlePosition.x = titlePosition.x - d.width ;
		else
			titlePosition.x += 5;
		if (titlePosition.y > wedgeCenter.y - 3)
			titlePosition.y = titlePosition.y + /* d.height + */ 1;
		else
			titlePosition.y -= (1 + d.height);

		int maxWidth = getSize().width;
		if((d.width + titlePosition.x) > maxWidth)
		{
			d.width = maxWidth - titlePosition.x;
		}
		label.setBounds(titlePosition.x, titlePosition.y, d.width, d.height);
	}
	/**
	*/
	protected void displayLabelOld(GraphItem item, int degrees, int adjustedValue, int size, Graphics g)
	{
		Point titlePosition = new Point(0, 0);
		titlePosition.x = (int)(Math.cos(degrees*Math.PI/180 +
					   adjustedValue*Math.PI/360) * size/2) + center.x + left;
		titlePosition.y = center.y - (int)(Math.sin(degrees*Math.PI/180 +
					   adjustedValue*Math.PI/360) * size/2) + top;

		Point wedgeCenter = new Point((arcX + (size /2)), (arcY + (size /2)));
		if (titlePosition.x <= wedgeCenter.x)
			titlePosition.x = titlePosition.x - fm.stringWidth(item.title) - 5;
		else
			titlePosition.x += 5;
		if (titlePosition.y > wedgeCenter.y - 3)
			titlePosition.y = titlePosition.y + fm.getHeight() + 1 - 10;
		else
			titlePosition.y -= 1;

		g.drawString(item.title, titlePosition.x, titlePosition.y);
	}
	/**
	* The number of visible pie wedges.
	*/
	protected int getPieWedgeCount()
	{
		if(totalValue == 0) return 0;
		if(wedgeLimit < 0 && wedgeLimitPercent < 0)
			return graphItems.size();
		if(wedgeLimit > 0)
			return graphItems.size() < wedgeLimit ? graphItems.size() : wedgeLimit;
		int sumTot = 0;
		for (int i = 0; i < graphItems.size(); i++)
		{
			GraphItem item = (GraphItem)graphItems.elementAt(i);
			if(item.value == 0) continue;
			sumTot += item.value;
			double adjustedValue = ((double)item.value / totalValue /*sumTot*/ ) * 100;
			if(adjustedValue < wedgeLimitPercent) return i + 1;
		}
		return graphItems.size();
	}
	/**
	*/
	public GraphItem getSelectedItem(Point p)
	{
		return pieSliceAtPoint(p);
	}
	/**
	* @return The sum of the first <count> graphItems.
	*/
	protected int getTotalValue(int count)
	{
		if(totalValue == 0) return 0;
		if(count == graphItems.size()) return totalValue;
		int sumTot = 0;
		for (int i = 0; i < count; i++)
		{
			GraphItem item = (GraphItem)graphItems.elementAt(i);
			if(item.value == 0) continue;
			sumTot += item.value;
		}
		return sumTot;
	}
	/**
	*/
	public boolean isDisplayLabels(){ return displayLabels; }
	/**
	*/
	public GraphItem itemAtPoint(Point p) { return pieSliceAtPoint(p); }
	/**
	* As in the Graph class, we collect the font metrics for measuring and the current color for resetting. The graph title is drawn centered at the
	* top. To draw the pie chart, we use the fillArc method of the Graphicsclass. This method draws an arc based on a circle contained within
	* a rectangle. We use the size variable for the width and height of this rectangle. The arcX and arcY variables represent the x and y values of
	the top-left corner of the rectangle. When we draw the arcs representing the item values, we need only to know a start angle and an arc angle
	because the size, arcX, and arcY values remain constant.

	* The for loop sifts through all the graphItems in the vector, setting the color, drawing the arc, resetting the color to the original, and drawing the item
	* label. The values of the graphItems are adjusted for the percentage of the whole pie (360 degrees) they represent. This process takes place in the
	* assignment of adjustedValue. The sumTot variable is added in this assignment to give the correct start angle.

	* After filling the arc, we draw the item label. This process requires a little more thought and measurement. We know the center point of the arc
	* circle because we know the size of the rectangle. We also know the formula for finding a point on a circle given an angle, and this gives us
	* enough data to find the point on the circle in the middle of each filled arc.
	*/
	public void paint(Graphics g)
	{
//        setCenter(getBounds());
		// draw the title
		fm = getFontMetrics(getFont());
		Color temp = g.getColor();

		size = Math.min(bottom - top, right - left) - padding;
		if(title != null && (! title.equals("")))
		{
			g.setColor(Color.black);

			g.drawString(title, (right-left - fm.stringWidth(title))/2+left,
							   titleHeight + padding);
		}
		arcX = left + (right  - left - size)/2;
		arcY = top  + (bottom - top  - size)/2;

		int count = getPieWedgeCount();
		int visValue = getTotalValue(count);
		int sumTot = 0;
		if (staleDegrees)
			itemDegrees.removeAllElements();
		if(totalValue == 0) return;
		for (int i = 0; i <= count; i++)
		{
			if(i == graphItems.size()) break;
			int itemValue = 0;
			GraphItem item;
			if(i == count)
			{
				item = (GraphItem)graphItems.elementAt(i);
				itemValue = totalValue - visValue;
			}
			else {
				item = (GraphItem)graphItems.elementAt(i);
				itemValue =  item.value;
			}
			int degrees = (int)(((long)sumTot * 360) / totalValue);
			int adjustedValue = (int)(((long)(sumTot + itemValue)*360) / totalValue) - degrees;
			if (shadeSelection && selectedItem != null && item == selectedItem)
			{
				int R = Math.min(0xff, 128 + item.color.getRed());
				int G = Math.min(0xff, 128 + item.color.getGreen());
				int B = Math.min(0xff, 128 + item.color.getBlue());
				g.setColor(new Color(R,G,B));
			}
			else
			{
				g.setColor(item.color);
			}
			g.fillArc(arcX, arcY, size, size, degrees, adjustedValue);
			if (staleDegrees)
				itemDegrees.addElement(new Double(degrees));

//            if(isDisplayLabels())
//                displayLabel(item, degrees, adjustedValue, size, g);

			sumTot += itemValue;
		}
		staleDegrees = false;
		g.setColor(temp);
		super.paint(g);
	}
	/**
	 */
	public GraphItem pieSliceAtPoint(Point p)
	{
		if (!pointInPie(p))
			return null;
		double degrees = pointToDegrees(p);
		int i;
		for (i=0; i < itemDegrees.size(); ++i)
		{
			double deg = ((Double)itemDegrees.elementAt(i)).doubleValue();
			if (degrees <= deg)
				break;
		}
		return (i==0) ? null : (GraphItem)graphItems.elementAt(i-1);
	}
	/**
	 */
	public String pieSliceLabelAtPoint(Point p)
	{
		GraphItem item = pieSliceAtPoint(p);
		return (item==null ? null : item.title);
	}
	/**
	 */
	public boolean pointInPie(Point p)
	{
		Point c = new Point(arcX + size/2, arcY + size/2);
		int base = p.x - c.x;
		int height = c.y - p.y;
		double radius = java.lang.Math.sqrt(base*base + height*height);
		return (radius*2 <= size);
	}
	/**       90          Translate a point to be relative to the pie's
	 *        |         center, then figure it's degrees using the reverse,
	 *  180 --+-- 0/360 rotated coordinate system used by Java, as described
	 *        |         on the left.
	 *        270
	 */
	public double pointToDegrees(Point p)
	{
		Point c = new Point(arcX + size/2, arcY + size/2);
		int base = p.x - c.x;
		int height = c.y - p.y;
		double radians = (base==0 ? 0 : java.lang.Math.atan2(base, height));
		double degrees = (radians * (180 / java.lang.Math.PI)) - 90;
		degrees += (degrees<0 ?1:0)*360;
		return 360 - degrees;
	}
	/**
	*/
	public void removeItem(String name)
	{
		for (int i = 0; i < graphItems.size(); i++) {
		if (((GraphItem)graphItems.elementAt(i)).title.equals(name))
			if(labels != null && labels.size() == graphItems.size())
			{
				JLabel l = (JLabel)labels.elementAt(i);
				remove(l);
			}
			graphItems.removeElementAt(i);
			labels.removeElementAt(i);

		}
		staleDegrees = true;
	}
	/**
	*/
	public void setBounds(int x, int y, int width, int height)
	{
		super.setBounds(x, y, width, height);
		setCenter(new Rectangle(x,y,width, height));
		if (displayLabels)
		{
			setLabelPositions();
			revalidate();
			repaint();
		}
	}
	public void setBounds(Rectangle r)
	{
		super.setBounds(r);
		setCenter(r);
		if (displayLabels)
			setLabelPositions();
	}
	/**
	*/
	public void setCenter(Rectangle r)
	{
		int x = r.x;
		int y = r.y;
		int width = r.width;
		int height = r.height;

		fm = getFontMetrics(getFont());
		titleHeight = fm.getHeight();
		if(title != null && (! title.equals("")))
		{
			top = padding*2 + titleHeight;
		}
		else
			top = padding;

		bottom = getSize().height - padding;
		Rectangle rect = focusedItemValue.getBounds();
		rect.x = padding;
		rect.y = top;
		focusedItemValue.setBounds(rect);
		left = 2*padding;
		right = getSize().width - padding;
		center = new Point((right - left)/2, (bottom - top)/2);
	}
	/**
	*/
	public void setDisplayLabels(boolean value)
	{
		displayLabels = value;
	}
	/**
	*/
	public void setLabelPositions()
	{
		int size = Math.min(bottom - top, right - left) - padding;

		int sumTot = 0;
		if(totalValue == 0) return;
		Vector graphItems = (Vector)this.graphItems.clone();
		Vector labels = (Vector)this.labels.clone();
		if(labels.size() != graphItems.size()) return;
		int count = getPieWedgeCount();
		for (int i = 0; i < graphItems.size(); i++)
		{
			GraphItem item = (GraphItem)graphItems.elementAt(i);
			int degrees = (int)(((long)sumTot * 360) / totalValue);
			int adjustedValue = (int)(((long)(sumTot + item.value)*360) / totalValue) - degrees;

			JLabel l = (JLabel)labels.elementAt(i);
			if( i < count)
			{
				displayLabel(l, degrees, adjustedValue, size);
				sumTot += item.value;
			}
			else
			if(i == count)
			{
				JLabel other = new JLabel("Other");
				displayLabel(other, degrees, adjustedValue, size);
			}
			else
			if (displayLabels)
				l.setVisible(false);
		}
	}
	public void setTitle(String t)
	{
	    this.title = t;
	}
	/**
	* Limit the number wedges the specified value.
	*/
	public void setWedgeLimit(int value)
	{
		wedgeLimitPercent= -1;
		wedgeLimit = value;
	}
	/**
	*/
	public void setWedgeLimitPercentage(double d)
	{
		wedgeLimit = -1;
		wedgeLimitPercent= d;
	}
}