package com.objectwave.uiWidget;

import java.awt.*;
import java.awt.event.*;
import java.util.Hashtable;
import com.objectwave.utility.Sorter;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.BevelBorder;

/**
* A widget for displaying a quick dialog containing a list of items. Of which one
* will be selected.  The selected value will either be null (if none) or the item that
* was selected.
*/
public class QuickPick extends JDialog implements ListSelectionListener, ActionListener
{
	static Hashtable oneInstance = new Hashtable(5);
	Object [] items;
	Object selection = null;
	final JList l = new JList();
	JButton pbOk;
	JButton pbClose;

	/**
	*/
	class WindowCloser extends java.awt.event.WindowAdapter
	{
		public void windowClosing(java.awt.event.WindowEvent e){
			Window source = (Window)e.getSource();
			source.setVisible(false);
			cleanUp();
			source.dispose();
		}
		public void windowOpened(java.awt.event.WindowEvent e){
				selection = null;
		}

	}
	/**
	*/
	MouseListener mouseListener = new MouseDoubleClick();
	/**
	*/
	class MouseDoubleClick extends MouseAdapter{
		public void mouseClicked(MouseEvent e) {
			if (e.getClickCount() == 2) {
				int index = l.locationToIndex(e.getPoint());
				pbOkClicked();
			}
		}
	}
	/**
	*/
	public QuickPick(String [] list, Frame f, boolean modal)
	{
		super(f,modal);
		items = list;
		Container c = getContentPane();
		c.setLayout(new BorderLayout());
		l.addListSelectionListener(this);
		l.addMouseListener(mouseListener);
		l.setPrototypeCellValue("Index 1234567890 WWWW");
		l.setBackground(Color.white);

		c.add("Center", getMainPanel());
		c.add("South", buttonPanel());
		setTitle("Select Item");
		setSize(150, 150);
		addWindowListener(new WindowCloser());
		showItems();
	}
	/**
	*/
	public void actionPerformed(ActionEvent e)
	{
		if(e.getSource() == pbOk) pbOkClicked();
		else
		if(e.getSource() == pbClose) pbCloseClicked();
		else
		if(e.getSource() == l) pbOkClicked();
	}
	/**
	*/
	public void addNotify()
	{
	    super.addNotify();
		getRootPane().setDefaultButton(pbOk);
		l.requestFocus();
	}
	/**
	*/
	protected JPanel buttonPanel()
	{
		JPanel p = new JPanel();
		pbOk = new JButton("Ok");
		pbOk.setMnemonic('O');
		p.add(pbOk);
		pbOk.addActionListener(this);
		pbClose = new JButton("Cancel");
		pbClose.setMnemonic('C');
		pbClose.addActionListener(this);
		p.add(pbClose);
		return p;
	}
	protected void cleanUp()
	{
	    Object sel = selection;
		l.setListData(new String [0]);
		selection = sel;
	}
	/**
	*/
	void close()
	{
		dispatchEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING));
	}
	/**
	*/
	public static QuickPick getInstance(String [] list, Component comp, boolean modal)
	{
	    while((!(comp instanceof Frame)) && (comp != null))
	    {
	        comp = comp.getParent();
	    }
	    Frame f = (Frame)comp;
	    if(comp == null) f = new Frame();

		QuickPick it = (QuickPick)oneInstance.get(f);
		if(it == null){
			it = new QuickPick(list, f, modal);
			oneInstance.put(f, it );
			return it;
		}
		it.items = list;
		it.selection = null;
		it.showItems();

		return it;
	}
	/**
	*/
	protected Component getMainPanel()
	{
		JScrollPane pane = new JScrollPane(l);
		pane.setBorder(new BevelBorder(BevelBorder.LOWERED));
		return pane;
	}
	/**
	*/
	public Object getSelection(){ return selection; }
	/**
	*/
	protected void pbCloseClicked()
	{
	    selection = null;
		close();
	}
	/**
	*/
	protected void pbOkClicked()
	{
		selection = l.getSelectedValue();
		close();
	}
	/**
	*/
	public void showItems()
	{
		setCursor(new Cursor(Cursor.WAIT_CURSOR));
//		l.removeAll();
//		for(int i = 0; i < items.length; i++)
//			l.add(items[i]);
		l.setListData(items);
		l.revalidate();
		setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
		if(items.length > 0)
			l.setSelectedIndex(0);
	}
	/**
	*/
	public void valueChanged(ListSelectionEvent e)
	{
		if(e.getValueIsAdjusting()) return;
		int idx = e.getFirstIndex();
		if(idx < 0) {
			selection = null;
			return;
		}
		selection = items[idx];
	}
}
