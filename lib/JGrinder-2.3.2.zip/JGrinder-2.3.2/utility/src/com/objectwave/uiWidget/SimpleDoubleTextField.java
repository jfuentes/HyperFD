package com.objectwave.uiWidget;

import com.objectwave.viewUtility.WidgetFunctions;
import javax.swing.*;
import java.util.*;
import java.awt.event.*;
import java.text.DecimalFormat;

/**
 *  A replacement for the jclass.fields.JCDoubleTextField.  This little guy
 *  requires less setup, but is less configurable than the former.  If all
 *  that is required is a int-parsing text field, this is the guy to use.
 *  Also, this JTextField allows null values to be legal: the user can
 *  supply a string to be used in such cases, the default being "".
 *  Additionally, the user can define a string to be used whenever an invalid
 *  date has been entered.
 */
public class SimpleDoubleTextField extends JTextField
{
	private String invalidText = "invalid";
	private static DecimalFormat format = new DecimalFormat("$#,###.00");

	private static SimpleDoubleTextField main_tf; // for testing.
	private static JTextField main_tf2; // for testing.
	public SimpleDoubleTextField() { super(); init(); }
	public SimpleDoubleTextField(String invalidText)
	{
		this.invalidText = invalidText;
		init();
	}
	public SimpleDoubleTextField(String invalidText, String formatPattern)
	{
		this.invalidText = invalidText;
		setPattern(formatPattern);
		init();
	}
	public String getInvalidText() { return invalidText; }
	public String getPattern() { return format==null ? null : format.toPattern(); }
	public Double getValue()
	{
		return parseText();
	}
	protected void init()
	{
		java.awt.Dimension dim = getSize();
		if (dim.width == 0)
		{
			dim.width = 50;
			setSize(dim);
		}

		this.addFocusListener(
		    new java.awt.event.FocusAdapter()
		    {
		        public void focusLost(java.awt.event.FocusEvent e)
		        {
		            setValue(parseText());
		        }
		    } );
		this.addKeyListener(
		    new java.awt.event.KeyAdapter()
		    {
		        public void keyTyped(java.awt.event.KeyEvent e)
		        {
		            if (e.getKeyChar() == '\r')
			        {
			            setValue(parseText());
			        }
		        }
		    } );
	}
	public static void main(String args[])
	{
		if (args.length == 1)
			main_tf = new SimpleDoubleTextField("invalid", args[0]);
		else
			main_tf = new SimpleDoubleTextField("invalid");

		JPanel panel = new JPanel();
		panel.setLayout(new java.awt.GridLayout(1, 3));
		panel.add(main_tf);
		java.awt.Dimension dim = main_tf.getSize();
		if (dim.width == 0)
		{
			dim.width = 50;
			main_tf.setSize(dim);
		}

		JButton button;
		button = new JButton(">> get value >>");
		panel.add(button);
		main_tf2 = new JTextField();
		button.addActionListener(new ActionListener()
			{ public void actionPerformed(ActionEvent e)
				{
					main_tf2.setText("" + main_tf.getValue());
				}
			} );
		panel.add(main_tf2);
		com.objectwave.uiWidget.SimpleOkCancelDialog dialog;
		dialog = new com.objectwave.uiWidget.SimpleOkCancelDialog(null, "Test date field", panel);
		dialog.setBounds(100, 100, 300, 100);
		dialog.setVisible(true);
		System.exit(0);
	}
	protected Double parseText()
	{
		String str = getText().trim();
		Double d = null;
		try { d = new Double(getText().trim()); }
		catch (NumberFormatException e) { }
		if (d == null && format != null)
		{
			try
			{
				Number n = format.parse(str);
				if (n != null)
					d = new Double(n.doubleValue());
			}
			catch (java.text.ParseException e) { }
		}
		return d;
	}
	public void setInvalidText(String s) { invalidText = s ; }
	public void setPattern(String p) { format = p==null ? null : new DecimalFormat(p); }
	public void setValue(double d)
	{
		setValue(new Double(d));
	}
	public void setValue(Double d)
	{
		if (d == null)
			setText(getText().trim().length()==0  ? "" : getInvalidText());
		else
			try { setText(format==null ? (""+d) : format.format(d)); }
			catch (IllegalArgumentException e) { setText(""+d); }
	}
}