package com.objectwave.uiWidget;

import com.objectwave.viewUtility.WidgetFunctions;
import javax.swing.*;
import java.util.*;
import java.awt.event.*;

/**
 *  A replacement for the jclass.fields.JCIntTextField.  This little guy
 *  requires less setup, but is less configurable than the former.  If all
 *  that is required is a int-parsing text field, this is the guy to use.
 *  Also, this JTextField allows null values to be legal: the user can
 *  supply a string to be used in such cases, the default being "".
 *  Additionally, the user can define a string to be used whenever an invalid
 *  date has been entered.
 */
public class SimpleIntTextField extends JTextField
{
	private String invalidText = "invalid";

	private static SimpleIntTextField main_tf; // for testing.
	private static JTextField main_tf2; // for testing.
	public SimpleIntTextField() { super(); init(); }
	public SimpleIntTextField(String invalidText)
	{
		super();
		this.invalidText = invalidText;
		init();
	}
	public String getInvalidtext() { return invalidText; }
	public Integer getValue()
	{
		return parseText();
	}
	protected void init()
	{
		java.awt.Dimension dim = getSize();
		if (dim.width == 0)
		{
			dim.width = 50;
			setSize(dim);
		}

		this.addFocusListener(
		    new java.awt.event.FocusAdapter()
		    {
		        public void focusLost(java.awt.event.FocusEvent e)
		        {
		            setValue(parseText());
		        }
		    } );
		this.addKeyListener(
		    new java.awt.event.KeyAdapter()
		    {
		        public void keyTyped(java.awt.event.KeyEvent e)
		        {
		            if (e.getKeyChar() == '\r')
			        {
			            setValue(parseText());
			        }
		        }
		    } );
	}
	public static void main(String args[])
	{
		main_tf = new SimpleIntTextField("invalid");
		JPanel panel = new JPanel();
		panel.setLayout(new java.awt.GridLayout(1, 3));
		panel.add(main_tf);
		java.awt.Dimension dim = main_tf.getSize();
		if (dim.width == 0)
		{
			dim.width = 50;
			main_tf.setSize(dim);
		}

		JButton button;
		button = new JButton(">> get value >>");
		panel.add(button);
		main_tf2 = new JTextField();
		button.addActionListener(new ActionListener()
			{ public void actionPerformed(ActionEvent e)
				{
					main_tf2.setText("" + main_tf.getValue());
				}
			} );
		panel.add(main_tf2);
		com.objectwave.uiWidget.SimpleOkCancelDialog dialog;
		dialog = new com.objectwave.uiWidget.SimpleOkCancelDialog(null, "Test date field", panel);
		dialog.setBounds(100, 100, 300, 100);
		dialog.setVisible(true);
		System.exit(0);
	}
	protected Integer parseText()
	{
		String str = getText().trim();
		Integer i = null;
		try { i = new Integer(getText().trim()); }
		catch (NumberFormatException e) { }
		return i;
	}
	public void setInvalidText(String s) { invalidText = s ; }
	public void setValue(int i)
	{
		setValue(new Integer(i));
	}
	public void setValue(Integer i)
	{
		if (i == null)
		{
			this.setText(getText().trim().length()==0 ? "" : invalidText);
			return;
		}
		this.setText("" + i);
	}
}