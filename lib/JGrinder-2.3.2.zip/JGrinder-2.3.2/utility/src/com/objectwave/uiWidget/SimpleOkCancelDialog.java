package com.objectwave.uiWidget;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 *  A generic ok/cancel dialog without all of the persistence model stuff hanging off of it.
 */
public class SimpleOkCancelDialog extends JDialog
{
	protected JPanel  buttonPanel;
	protected JButton okButton;
	protected JButton cancelButton;
	protected Component component;
	protected boolean cancelled = true;

	public SimpleOkCancelDialog(Frame owner, String title, JComponent component)
	{
		super(owner, title, true);
		setBounds(100, 100, 200, 100);
		Container pane = getContentPane();
		pane.setLayout(new BorderLayout());
		buttonPanel = new JPanel();
		buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		okButton = new JButton("Ok");
//            okButton.setFont(UIManager.getFont("JCIFont"));
		okButton.setMnemonic('O');
		okButton.setOpaque(true);
		cancelButton = new JButton("Cancel");
//            cancelButton.setFont(UIManager.getFont("JCIFont"));
		cancelButton.setMnemonic('C');
		cancelButton.setOpaque(true);
		okButton.addActionListener(new ActionListener()
			{ public void actionPerformed(ActionEvent evt)
				{ cancelled = false; setVisible(false); } } );
		cancelButton.addActionListener(new ActionListener()
			{ public void actionPerformed(ActionEvent evt)
				{ setVisible(false); } } );
		buttonPanel.add(okButton);
		buttonPanel.add(cancelButton);
		pane.add("South", buttonPanel);
		setComponent(component);
	}
	public boolean isCancelled() { return cancelled; }
	public void removeCancel() { buttonPanel.remove(cancelButton); }
	public void removeOk() { buttonPanel.remove(okButton); }
	public void setCancelled(boolean c) { cancelled = c; }
	public void setComponent(JComponent c)
	{
		if (c == null) return;
		component = c;
		getContentPane().add("Center", c);
		updatePreferredSize();
	}
	public void updatePreferredSize()
	{
		Dimension cDim = component.getPreferredSize();
		Dimension bDim = buttonPanel.getPreferredSize();
		Rectangle b = getBounds();
		setBounds(b.x, b.y, Math.max(cDim.width, bDim.width) + 6,
							cDim.height + bDim.height + 25);
		if (JComponent.class.isInstance(component))
			((JComponent)component).revalidate();
		if (JComponent.class.isInstance(getContentPane()))
			((JComponent)getContentPane()).revalidate();
	}
}