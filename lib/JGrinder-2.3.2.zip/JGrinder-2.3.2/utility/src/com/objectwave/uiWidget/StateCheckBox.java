package com.objectwave.uiWidget;

import javax.swing.*;
import java.beans.*;
import java.awt.*;
import java.awt.event.*;

/**
*/
public class StateCheckBox extends javax.swing.JPanel
{
	String actionCommand = "StateCheckBoxChanged";
	Color original;
	//{{DECLARE_CONTROLS
	StateTextField tf;
	JLabel label;
	//}}

	public StateCheckBox()
	{
		super();
		setLayout(new BorderLayout());
		tf = new StateTextField();
		tf.setEditable(false);
		add(tf, BorderLayout.WEST);
		label = new JLabel("CheckBox");
		add(label, BorderLayout.CENTER);
		setFont(getFont());

/*		setSize(insets().left + insets().right + 200,insets().top + insets().bottom + 100);
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.weighty =1.0;
		gbc.anchor = gbc.WEST;
		tf = new StateTextField();
		tf.setEditable(false);
		add(tf, gbc);
		gbc.insets = new Insets(0,3,0,0);
		label = new JLabel("CheckBox");
		add(label, gbc);
		setFont(getFont());
*/

		//{{REGISTER_LISTENERS
		//}}

		MouseAdapter ma = getMouseListener();
		tf.addMouseListener(ma);
		label.addMouseListener(ma);
	}
	public StateCheckBox(String label)
	{
		this();
		setText(label);
	}
	/**
	 * adds an ActionListener to the button
	 */
	public void addActionListener(ActionListener l) {
		listenerList.add(ActionListener.class, l);
	}
	/*
	 * Notify all listeners that have registered interest for
	 * notification on this event type.  The event instance
	 * is lazily created using the parameters passed into
	 * the fire method.
	 * @see EventListenerList
	 */
	protected void fireActionPerformed(ActionEvent event) {
		// Guaranteed to return a non-null array
		Object[] listeners = listenerList.getListenerList();
		ActionEvent e = null;
		// Process the listeners last to first, notifying
		// those that are interested in this event
		for (int i = listeners.length-2; i>=0; i-=2) {
			if (listeners[i]==ActionListener.class) {
				// Lazily create the event:
				if (e == null) {
					e = new ActionEvent(this,
										ActionEvent.ACTION_PERFORMED,
										getActionCommand(),
					event.getModifiers());
				}
				((ActionListener)listeners[i+1]).actionPerformed(e);
			}
		}
	}
	public String getActionCommand(){ return actionCommand; }
	public MouseAdapter getMouseListener()
	{
		return new MouseAdapter(){
			 public void mouseClicked(MouseEvent e)
			 {
			    StateCheckBox.this.mouseClick();
			 }
			 public void mousePressed(MouseEvent e)
			 {
			    StateCheckBox.this.mousePress();
			 }
			 public void mouseReleased(MouseEvent e)
			 {
			    StateCheckBox.this.mouseRelease();
			 }
		};
	}
	public int getState()
	{
		return tf.getState();
	}
	public String getValue()
	{
		return tf.getText();
	}
	public void mouseClick()
	{
		tf.nextState();
		fireActionPerformed(new ActionEvent(this, ActionEvent.ACTION_PERFORMED, getActionCommand()));
	}
	public void mousePress()
	{
		original = tf.getBackground();
		tf.setBackground(Color.lightGray);
		tf.repaint();
	}
	public void mouseRelease()
	{
		tf.setBackground(original);
		tf.repaint();
	}
	/**
	 * removes an ActionListener from the button
	 */
	public void removeActionListener(ActionListener l) {
		listenerList.remove(ActionListener.class, l);
	}
	public void setActionCommand(String val) { actionCommand = val; }
	public void setFont(java.awt.Font f)
	{
		if(f == null) return;
		if(label != null)
			label.setFont(f);
		if(tf != null) {
			tf.setFont(f);
			FontMetrics fm = getFontMetrics(f);
			int height = fm.getMaxDescent() + fm.getMaxAscent() + 2;
			int width = fm.getMaxAdvance();
			tf.setPreferredSize(new java.awt.Dimension(width, height));
			revalidate();
		}
		super.setFont(f);
	}
	public void setForeground(Color c)
	{
		if(label != null)
			label.setForeground(c);
		if(tf != null)
			tf.setForeground(c);
	}
	public void setState(int val)
	{
		tf.setState(val);
	}
	public void setStates(String [] states)
	{
		tf.setStates(states);
	}
	public void setText(String value)
	{
		label.setText(value);
		revalidate();
		repaint();
	}
	public void setValue(String value)
	{
		tf.setText(value);
	}
}