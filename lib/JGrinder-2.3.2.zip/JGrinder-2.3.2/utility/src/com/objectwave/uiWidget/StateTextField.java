package com.objectwave.uiWidget;

import javax.swing.*;

/**
* Forces that values of a text field to either be blank
* or one of several values specified by the 'states' string array.
*/
public class StateTextField extends JTextField
{
	String [] states;
	int state;

	public int getState()
	{
		return state;
	}
	public void nextState()
	{
		if(++state == states.length)
			state = 0;
		setState(state);
	}
	public void setState(int value)
	{
		if(value < 0 || value >= states.length) return;
		state = value;
		super.setText(states[value]);
	}
	public void setStates(String [] vals)
	{
		states = vals;
	}
	public void setText(String text)
	{
		if(text == null) {
			super.setText("");
			return;
		}
		for(int i = 0; i < states.length; i++)
			if(text.equals(states[i])){
					setState(i);
					return;
				}
	}
}
