package com.objectwave.uiWidget;
import com.objectwave.event.*;
import java.awt.Color;
import java.awt.Dimension;
import javax.swing.JFrame;

import javax.swing.JTextField;
/**
 * For use with the StatusEvent support found in the package com.objectwave.event.*;
 * When a status event occurs, this will display the message.  After the time out
 * period the status bar will be cleared. Upon creation of this status bar
 * it will register itself with the DefaultStatusManager as a listener.
 *
 * @author  trever
 * @version  $Id: StatusBar.java,v 2.1 2001/10/19 14:15:13 dave_hoag Exp $
 */
public class StatusBar extends JTextField implements StatusEventListener, Runnable, java.io.Serializable
{
	static boolean clear = true;
	Thread timer;
	int messageDisplayTime = 3000;
	private java.awt.Color informationalColor = Color.blue;
	private java.awt.Color errorColor = Color.red;
	private java.awt.Color warningColor = Color.yellow;
	/**
	 * Register for events on the StatusManager.
	 *
	 * @see  com.objectwave.event.StatusManager
	 */
	public StatusBar()
	{
		setBackground(Color.lightGray);
		StatusManager.getDefaultManager().addStatusEventListener(this);
		timer = new Thread(this, "StatusBarTimer");
		timer.start();
		setEditable(false);
		try
		{
			jbInit();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	/**
	 * Test routine.
	 *
	 * @param  args The command line arguments
	 */
	public static void main(String[] args)
	{
		final JFrame f = new JFrame("Status Bar Test");
		new StatusBarBeanInfo().getPropertyDescriptors();
		f.getContentPane().add("South", new StatusBar());
		f.setBounds(100, 100, 100, 100);
		f.setVisible(true);
		f.addMouseListener(
			new java.awt.event.MouseAdapter()
			{
				/**
				 * @param  e
				 */
				public void mousePressed(java.awt.event.MouseEvent e)
				{
					StatusManager.getDefaultManager().fireStatusEvent(f, "Mouse Pressed: ");
				}
				/**
				 * @param  e
				 */
				public void mouseReleased(java.awt.event.MouseEvent e)
				{
					StatusManager.getDefaultManager().fireStatusEvent(f, "Mouse Released: ");
				}
			});
		StatusManager.getDefaultManager().fireStatusEvent(f, "Test Message");
	}
	/**
	 *Sets the MessageDisplayTime attribute of the StatusBar object
	 *
	 * @param  seconds The new MessageDisplayTime value
	 */
	public void setMessageDisplayTime(int seconds)
	{
		messageDisplayTime = 1000 * seconds;
	}
	/**
	 *Sets the InformationalColor attribute of the StatusBar object
	 *
	 * @param  newInformationalColor The new InformationalColor value
	 */
	public void setInformationalColor(java.awt.Color newInformationalColor)
	{
		informationalColor = newInformationalColor;
	}
	/**
	 *Sets the ErrorColor attribute of the StatusBar object
	 *
	 * @param  newErrorColor The new ErrorColor value
	 */
	public void setErrorColor(java.awt.Color newErrorColor)
	{
		errorColor = newErrorColor;
	}
	/**
	 *Sets the WarningColor attribute of the StatusBar object
	 *
	 * @param  newWarningColor The new WarningColor value
	 */
	public void setWarningColor(java.awt.Color newWarningColor)
	{
		warningColor = newWarningColor;
	}
	/**
	 *Gets the MessageDisplayTime attribute of the StatusBar object
	 *
	 * @return  The MessageDisplayTime value
	 */
	public int getMessageDisplayTime()
	{
		return messageDisplayTime;
	}
	/**
	 *Gets the InformationalColor attribute of the StatusBar object
	 *
	 * @return  The InformationalColor value
	 */
	public java.awt.Color getInformationalColor()
	{
		return informationalColor;
	}
	/**
	 *Gets the ErrorColor attribute of the StatusBar object
	 *
	 * @return  The ErrorColor value
	 */
	public java.awt.Color getErrorColor()
	{
		return errorColor;
	}
	/**
	 *Gets the WarningColor attribute of the StatusBar object
	 *
	 * @return  The WarningColor value
	 */
	public java.awt.Color getWarningColor()
	{
		return warningColor;
	}
	/**
	 *Main processing method for the StatusBar object
	 */
	public void run()
	{
		while(true)
		{
			try
			{
				synchronized(this)
				{
					while(clear)
					{
						//If we are clear, go into wait state.
						wait();
					}
				}
			}
			catch(InterruptedException e)
			{
			}
			try
			{
				timer.sleep(messageDisplayTime);
				setText("");
				clear = true;
			}
			catch(InterruptedException e)
			{
			}
			catch(Throwable e)
			{
				System.out.println("StatusBar>>" + e);
			}
		}
	}
	/**
	 * Based off the event type, change the color of the status message.
	 *
	 * @param  evt
	 */
	public void updateStatus(StatusEvent evt)
	{
		if(evt.getType() == StatusType.INFORMATIONAL)
		{
			setForeground(this.informationalColor);
		}
		else if(evt.getType() == StatusType.WARNING)
		{
			setForeground(this.warningColor);
		}
		else if(evt.getType() == StatusType.CRITICAL)
		{
			setForeground(this.errorColor);
		}
		clear = false;
		timer.interrupt();
		setText(evt.getText());
		this.paintImmediately(0, 0, this.getWidth(), this.getHeight());
	}
	/**
	 * @exception  Exception
	 */
	private void jbInit() throws Exception
	{
		this.setBorder(null);
		this.setPreferredSize(new Dimension(100, 17));
	}
}
