package com.objectwave.uiWidget;

import java.beans.*;
/**
 * Let super class do all of the work!
 *
 * @author  trever
 * @version  $Id: StatusBarBeanInfo.java,v 2.1 2001/10/19 14:15:13 dave_hoag Exp $
 */

public class StatusBarBeanInfo extends SimpleBeanInfo
{
	Class beanClass = StatusBar.class;
	String iconColor16x16Filename;
	String iconColor32x32Filename;
	String iconMono16x16Filename;
	String iconMono32x32Filename;

	/**
	 *Constructor for the StatusBarBeanInfo object
	 */
	public StatusBarBeanInfo()
	{
	}
	/**
	 *Gets the PropertyDescriptors attribute of the StatusBarBeanInfo object
	 *
	 * @return  The PropertyDescriptors value
	 */
	public PropertyDescriptor[] getPropertyDescriptors()
	{
		try
		{
			PropertyDescriptor _errorColor = new PropertyDescriptor("errorColor", beanClass, "getErrorColor", "setErrorColor");
			_errorColor.setDisplayName("errorColor");
			_errorColor.setShortDescription("errorColor");
			PropertyDescriptor _informationalColor = new PropertyDescriptor("informationalColor", beanClass, "getInformationalColor", "setInformationalColor");
			_informationalColor.setDisplayName("informationalColor");
			_informationalColor.setShortDescription("informationalColor");
			PropertyDescriptor _messageDisplayTime = new PropertyDescriptor("messageDisplayTime", beanClass, "getMessageDisplayTime", "setMessageDisplayTime");
			PropertyDescriptor _warningColor = new PropertyDescriptor("warningColor", beanClass, "getWarningColor", "setWarningColor");
			_warningColor.setDisplayName("warningColor");
			_warningColor.setShortDescription("warningColor");
			PropertyDescriptor[] pds = new PropertyDescriptor[]{
					_errorColor,
					_informationalColor,
					_messageDisplayTime,
					_warningColor};
			return pds;


		}
		catch(IntrospectionException ex)
		{
			ex.printStackTrace();
			return null;
		}
	}
	/**
	 *Gets the Icon attribute of the StatusBarBeanInfo object
	 *
	 * @param  iconKind
	 * @return  The Icon value
	 */
	public java.awt.Image getIcon(int iconKind)
	{
		switch (iconKind)
		{
			case BeanInfo.ICON_COLOR_16x16:
				return iconColor16x16Filename != null ? loadImage(iconColor16x16Filename) : null;
			case BeanInfo.ICON_COLOR_32x32:
				return iconColor32x32Filename != null ? loadImage(iconColor32x32Filename) : null;
			case BeanInfo.ICON_MONO_16x16:
				return iconMono16x16Filename != null ? loadImage(iconMono16x16Filename) : null;
			case BeanInfo.ICON_MONO_32x32:
				return iconMono32x32Filename != null ? loadImage(iconMono32x32Filename) : null;
		}
		return null;
	}
	/**
	 *Gets the AdditionalBeanInfo attribute of the StatusBarBeanInfo object
	 *
	 * @return  The AdditionalBeanInfo value
	 */
	public BeanInfo[] getAdditionalBeanInfo()
	{
		Class superclass = beanClass.getSuperclass();
		try
		{
			BeanInfo superBeanInfo = Introspector.getBeanInfo(superclass);
			return new BeanInfo[]{superBeanInfo};
		}
		catch(IntrospectionException ex)
		{
			ex.printStackTrace();
			return null;
		}
	}
}
