package com.objectwave.uiWidget;

import java.awt.event.*;
import java.awt.*;
import java.util.Vector;
import javax.swing.*;
import javax.swing.border.*;

public class VariablePanel extends JPanel implements ActionListener, KeyListener
{
	String result = null;
	TitledBorder border;
	JTextField tfEntry;
	JList lbContents;
	Vector entries = new Vector();
	String [] listData = new String [0];
	boolean duplicatesAllowed = false;

	/**
	*/
	public VariablePanel()
	{
		this("Instance Variables");
	}
	/**
	*/
	public VariablePanel(String title)
	{
		setLayout(new BorderLayout());
		border = new TitledBorder(title);
		setBorder(border);
		tfEntry = new JTextField();
		tfEntry.setPreferredSize(new Dimension(20, 20));
		tfEntry.addActionListener(this);
		add("North", tfEntry);

		lbContents = new JList();
		lbContents.setPrototypeCellValue("Index 1234567890 WWWWWWWWWWWWWWWWWWWWWWW");
		lbContents.addKeyListener(this);
//        lbContents.setPreferredSize(new java.awt.Dimension(30, 50));
		add(new JScrollPane(lbContents), BorderLayout.CENTER);
	}
	/**
	*/
	public void actionPerformed(ActionEvent e)
	{
		String entry = tfEntry.getText();
		tfEntry.setText("");
		if(duplicatesAllowed){
			entries.addElement(entry);
/*(            String [ ] newData = new String [listData.length + 1];
			System.arraycopy(listData, 0, newData, 0 , listData.length );
			newData[ listData.length ] = entry;
			listData = newData;
			lbContents.setListData(listData);
*/
			lbContents.setListData(entries);
			lbContents.revalidate(); lbContents.repaint(); 
			return;
		}
		if(entries.contains(entry)) return;
		entries.addElement(entry);
		lbContents.setListData(entries);
/*
		for(int i = 0; i < listData.length; i++)
			if(listData[i].equals(entry)) return;
		entries.addElement(entry);
		String [ ] newData = new String [listData.length + 1];
		System.arraycopy(listData, 0, newData, 0 , listData.length );
		newData[ listData.length ] = entry;
		listData = newData;
		lbContents.setListData(listData);
*/
		lbContents.revalidate(); lbContents.repaint(); 
	}
	/**
	*/
	public String [] getItems()
	{
		listData = new String [entries.size() ];
		entries.copyInto(listData);
		return listData;
	}
	/**
	*/
	public void keyPressed(KeyEvent e) { }
	/**
	*/
	public void keyReleased(KeyEvent e)
	{
		if(e.getKeyCode() == KeyEvent.VK_DELETE){
			int idx = lbContents.getSelectedIndex();
			if(idx < 0) return;
			entries.removeElementAt(idx);
			lbContents.setListData(entries);
			lbContents.revalidate(); lbContents.repaint(); 
		}
	}
	/**
	*/
	public void keyTyped(KeyEvent e)
	{
	}
	/**
	*/
	public void setDuplicatesAllowed(boolean aValue)
	{
		duplicatesAllowed = aValue;
	}
	/**
	*/
	public void setListData(String [] data)
	{
		if(data == null)
		{
			entries = new Vector();
			String [] listData = new String [0];
			lbContents.setListData(listData);
			lbContents.revalidate(); lbContents.repaint();
			return;
		}
		entries = new Vector();
		for(int i = 0; i < data.length; i++) entries.addElement(data[i]);
		listData = data;
		lbContents.setListData(listData);
		lbContents.revalidate(); lbContents.repaint();
	}
	/**
	*/
	public void setListData(Vector vals)
	{
		entries = vals;
		listData = new String [ vals.size() ];
		vals.copyInto(listData);
		lbContents.setListData(listData);
		lbContents.revalidate(); lbContents.repaint();
	}
	/**
	*/
	public void setText(String text)
	{
		border.setTitle(text);
	}
}