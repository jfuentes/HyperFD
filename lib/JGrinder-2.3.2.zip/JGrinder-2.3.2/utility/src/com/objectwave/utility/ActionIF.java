package com.objectwave.utility;

/**
 *  Used in conjunction with at least viewUtility.VectorToButtons, this
 *  interface allows the user to specify a certain action to perform when
 *  some state is entered.  In the case of VectorToButtons, an ActionIF can
 *  be attached to each generated button, allowing for generic behavior to
 *  be specified for all buttons involved.
 */
public interface ActionIF
{
	public void performAction(Object datum);
}