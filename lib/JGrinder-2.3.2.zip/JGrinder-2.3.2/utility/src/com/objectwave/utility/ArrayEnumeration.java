package com.objectwave.utility;

/**
 * This is a handy class to perform an enumeration over any object array. Note
 * that this enumeration class will not work with any arrays of primitive type
 * (int, double, byte, etc) since they do not extend java.lang.Object.
 */
public class ArrayEnumeration implements java.util.Enumeration
{
    StringifyIF formater;
	public ArrayEnumeration(Object array[])
	{
		this.array = array;
		pos = 0;
	}
    /**
     */
    public void setDisplayFormatter(StringifyIF formater)
    {
        this.formater = formater;
    }
	public boolean hasMoreElements()
	{
		return pos < array.length;
	}
	public Object nextElement()     
	{
	    if(formater == null)
		    return hasMoreElements() ? array[pos++] : null;
		return hasMoreElements() ? formater.toString(array[pos++]) : null;
	}

	private Object array[];
	private int pos = 0;
}


