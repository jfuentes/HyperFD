package com.objectwave.utility;


import java.util.*;

/**
 * A simple implementation of a binary tree.
 */
public class BinaryTree
{
	private TreeNode rootHolder = new TreeNode(null);
	private SorterComparisonIF comp = null;
	private int size=0;
	private TreeNode reserveNodes=null;
	private int reserveNodeCount=0;

	private class TreeNode
	{
		TreeNode(Object d) { data = d; }
		Object data;
		TreeNode lhs;
		TreeNode rhs;
	}

	/**
	 * Provide an in-order traveral of the tree using manual recursion
	 * (ie, we manage our own ``call stack''.
	 */
	private class BinaryTreeEnum implements Enumeration
	{
		private Stack sk = new Stack();
		private boolean goLeft = true;

		BinaryTreeEnum(BinaryTree tree)
		{
			TreeNode root = tree.rootHolder.rhs;
			if (root != null)
				sk.push(root);
		}

		public Object nextElement()
		{
			if (sk.empty())
				return null;
			if (goLeft)
			{
				TreeNode curr = ((TreeNode)sk.peek()).lhs;
				while (curr != null)
				{
					sk.push(curr);
					curr = curr.lhs;
				}
				goLeft = false;
			}
			TreeNode ret = (TreeNode)sk.pop();
			if (ret.rhs != null)
			{
				sk.push(ret.rhs);
				goLeft = true;
			}
			return ret.data;
		}

		public boolean hasMoreElements()
		{
			return !sk.empty();
		}
	}
/**
 * 
 * @author Steven Sinclair
 */
public BinaryTree()
{
}
/**
 * 
 * @author Steven Sinclair
 * @param comp com.objectwave.utility.SorterComparisonIF
 */
public BinaryTree(SorterComparisonIF comp)
{
	setComparison(comp);
}
/**
 * toss out the tree and start anew.
 * 
 * @author Steven Sinclair
 */
public void clear()
{
	rootHolder.rhs = null;
	size = 0;
}
/**
 * 
 * @author Steven Sinclair
 * @return boolean
 * @param data java.lang.Object
 */
public boolean contains(Object data)
{
	return recursiveFindParent(data, rootHolder) != null;
}
/**
 * 
 * @author Steven Sinclair
 * @param os OutputStream
 */
public void dumpTree(java.io.OutputStream os)
{
	java.io.Writer writer = new java.io.OutputStreamWriter(os);

	try
	{
		if (rootHolder.rhs == null)
			writer.write("<null tree>");
		else
			dumpTree(writer, rootHolder.rhs, 1);
		writer.flush();
	}
	catch (java.io.IOException ex) { System.err.println("tree dump: " + ex); }
}
/**
 * 
 * @author Steven Sinclair
 * @param writer java.io.Writer
 * @param parent TreeNode
 * @param depth int
 */
private void dumpTree(java.io.Writer writer, TreeNode curr, int depth)
	throws java.io.IOException
{
	if (curr == null)
		return;
	StringBuffer buf = new StringBuffer(depth);
	for (int i=0; i < depth; ++i)
		buf.append("  ");
	dumpTree(writer, curr.rhs, depth+1);
	writer.write(buf.toString() + curr.data + '\n');
	dumpTree(writer, curr.lhs, depth+1);
}
/**
 * 
 * @author Steven Sinclair
 * @return java.util.Enumeration
 */
public Enumeration elements()
{
	return new BinaryTreeEnum(this);
}
/**
 * Sum of all available nodes and all used nodes.
 *
 * @author Steven Sinclair
 * @return int
 */
public int getCapacity()
{
	return size() + reserveNodeCount;
}
/**
 * 
 * @author Steven Sinclair
 * @return com.objectwave.utility.SorterComparisonIF
 */
public SorterComparisonIF getComparison()
{
	return comp;
}
/**
 * 
 * @author Steven Sinclair
 * @param data java.lang.Object
 */
public void insert(Object data)
{
	TreeNode node = newNode(data);
	if (rootHolder.rhs == null)
		rootHolder.rhs = node;
	else
		insertRecursive(node, rootHolder.rhs);
	++size;
}
/**
 * 
 * @author Steven Sinclair
 * @param node TreeNode
 */
private void insertRecursive(TreeNode node, TreeNode curr)
{
	int v=0;
	if (comp == null || (v=comp.compare(node.data, curr.data)) < 0)
	{
		if (curr.lhs == null)
			curr.lhs = node;
		else
			insertRecursive(node, curr.lhs);
	}
	else
	{
		if (curr.rhs == null)
			curr.rhs = node;
		else
			insertRecursive(node, curr.rhs);
	}
}
/**
 * 
 * @author Steven Sinclair
 * @return boolean
 */
private boolean isRoot(TreeNode node)
{
	return node == rootHolder.rhs;
}
/**
 * 
 * @author Steven Sinclair
 * @param args java.lang.String[]
 */
public static void main(String args[])
{
	if (args.length == 0 || args[0].equals("-?") || args[0].equals("/?"))
	{
		System.out.println("Expected args: #nodesToCreate");
		return;
	}

	int numNodes = 10;
	try { numNodes = Integer.parseInt(args[0]); }
	catch (Throwable ex) { }

	System.out.println("Build a tree having " + numNodes + " nodes.");

	java.security.SecureRandom rnd = new java.security.SecureRandom();
	SorterComparisonIF comp = new SorterComparisonIF()
		{ public int compare(Object a, Object b)
				{ return ((Integer)a).intValue() - ((Integer)b).intValue(); } };
	BinaryTree tree = new BinaryTree(comp);

	java.util.Vector data = new java.util.Vector(numNodes);
	for (int i=0; i < numNodes; ++i)
	{
		Integer integer = new Integer(Math.abs(rnd.nextInt()%100000));
		tree.insert(integer);
		data.addElement(integer);
		System.out.println("\tInserted " + integer);
	}

	System.out.println("Tree built of size " + tree.size());
	System.out.println("Tree dump:");
	tree.dumpTree(System.out);

	System.out.println("---------------");
	System.out.println("Find each element:");
	for (int i=0; i < numNodes; ++i)
	{
		Object datum = data.elementAt(i);
		System.out.println("\ttree.contains(" + datum + ")? " + tree.contains(datum));
	}
	System.out.println("Find elements which aren't in the tree:");
	System.out.println("\ttree.contains(-100)? " + tree.contains(new Integer(-100)));
	System.out.println("\ttree.contains(-500)? " + tree.contains(new Integer(-500)));
	
	System.out.println("----------------");
	System.out.println("Remove half of the elements (" + (numNodes/2) + "):");
	for (int i=0; i < numNodes/2; ++i)
	{
		Object datum = data.elementAt(i);
		System.out.println("Removing " + datum + (tree.remove(datum) ? "" : "[failed]"));
		//tree.dumpTree(System.out);
		//System.out.println("");
	}
	System.out.println("Dump tree:");
	tree.dumpTree(System.out);

	System.out.println("----------------");
	System.out.println("Enumerate elements:");
	Enumeration e = tree.elements();
	while (e.hasMoreElements())
		System.out.println(e.nextElement());
}
/**
 * 
 * @author Steven Sinclair
 * @return TreeNode
 */
private TreeNode newNode(Object data)
{
	if (reserveNodes != null)
	{
		TreeNode newNode = reserveNodes;
		reserveNodes = newNode.rhs;
		newNode.lhs = newNode.rhs = null;
		newNode.data = data;
		--reserveNodeCount;
		return newNode;
	}
	else
		return new TreeNode(data);
}
/**
 * Remove any "reserve" nodes.
 * 
 * @author Steven Sinclair
 */
public void pack()
{
	reserveNodes = null;
}
/**
 *
 * This method assumes that curr.data has already been checked.
 *
 * @author Steven Sinclair
 * @return TreeNode
 * @param data java.lang.Object
 */
public TreeNode recursiveFindParent(Object data, TreeNode curr)
{
	if (!(curr==rootHolder) && (data == null || comp.compare(data, curr.data) < 0))
	{
		if (curr.lhs == null)
			return null;
		else
		{
			if (curr.lhs.data == data)
				return curr;
			else
				return recursiveFindParent(data, curr.lhs);
		}
	}
	else
	{
		if (curr.rhs == null)
			return null;
		else
		{
			if (curr.rhs.data == data)
				return curr;
			else
				return recursiveFindParent(data, curr.rhs);
		}
	}
}
/**
 * 
 * @author Steven Sinclair
 * @return boolean
 * @param data java.lang.Object
 */
public boolean remove(Object data)
{
	// SPS - this one's a little trickier.
	//
	
	if (rootHolder.rhs == null)
		return false;
		
	TreeNode parent = recursiveFindParent(data, rootHolder);
	if (parent == null)
		return false;
	boolean isLhs = parent==rootHolder ? false : comp.compare(data, parent.data) <= 0;
	TreeNode reserve = isLhs ? parent.lhs : parent.rhs;
	removeNode(parent, isLhs);
	
	reserve.rhs = reserveNodes;
	reserveNodes = reserve;
	++reserveNodeCount;
	return true;
}
/**
 * 
 * @author Steven Sinclair
 * @param parent TreeNode
 * @param isLhs boolean
 */
private void removeNode(TreeNode parent, boolean isLhs)
{
	TreeNode deathNode = isLhs ? parent.lhs : parent.rhs;

	System.out.println("[deathNode.data = " + deathNode.data + "]");
		
	TreeNode curr = deathNode.rhs;
	if (curr == null)
	{
		// There is no RHS, therefore make the root of the left subtree
		// the new element.
		//
		if (isLhs)
			parent.lhs = deathNode.lhs;
		else
			parent.rhs = deathNode.lhs;
	}
	else
	{
		if (curr.lhs == null)
		{
			// The right subtree has no left:
			// transfer deathNode's lhs to rst's root
			// and promote that node.
			//
			curr.lhs = deathNode.lhs;
			if (isLhs)
				parent.lhs = curr;
			else
				parent.rhs = curr;
		}
		else
		{
			// find the parent of the leftmost node of the rhs subtree:
			//
			while (curr.lhs.lhs != null)
				curr = curr.lhs;
			TreeNode rightLeftmostRight = curr.lhs.rhs;
			curr.lhs.rhs = deathNode.rhs;
			curr.lhs.lhs = deathNode.lhs;
			if (isLhs)
				parent.lhs = curr.lhs;
			else
				parent.rhs = curr.lhs;
			curr.lhs = rightLeftmostRight;
		}
	}
}
/**
 * 
 * @author Steven Sinclair
 * @param size int
 */
public void reserveCapacity(int size)
{
	int newSize = size() - size;
	for (int i=0; i < newSize; ++i)
	{
		TreeNode node = new TreeNode(null);
		node.rhs = reserveNodes;
		reserveNodes = node;
		++reserveNodeCount;
	}
}
/**
 * 
 * @author Steven Sinclair
 * @param newValue com.objectwave.utility.SorterComparisonIF
 */
public void setComparison(SorterComparisonIF newValue)
{
	this.comp = newValue;
}
/**
 * 
 * @author Steven Sinclair
 * @return int
 */
public int size()
{
	return size;
}
}