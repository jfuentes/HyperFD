package com.objectwave.utility;

import java.util.Vector;
/**
 * A utility class that is similar to hashtable in that an object (or objects) are associated
 * with a class.
 * 
 * @author Dave Hoag
 * @version 1.4
 */
public class ClassTree
{
	ListenerTree tree;
	/**
	 * Start with the most general and progress to the most specialized.
	 */
	boolean sortDescending = true;
	boolean allowMultipleValues = true;
	/**
     * 
	 */
	private class ListenerTree
	{
	    ListenerTree next = null;
	    Class type = null;
	    ListenerTree children = null;
	    AccessList list = new AccessList();
		/**
		 */
		protected boolean needsExecution()
		{
			if(list.needsExecution()) return true;
			if(next != null && next.needsExecution()) return true;
			if(children != null && children.needsExecution()) return true;
			return false;
		}
		/**
		 */
		protected void getObjects(final Object source, Vector v)
		{
		    if(type == null) return;
		    boolean doIt = false;

		    if(sortDescending)
		    {
			    if(source instanceof Class)
			    	doIt = type.isAssignableFrom((Class)source);
			    else
			    	doIt = type.isInstance(source);
		    }
		    else
		    {
			    if(source instanceof Class)
			    	doIt = ((Class)source).isAssignableFrom(type);
			    else
			    	doIt = source.getClass().isInstance(type);
		    }
		    if(next != null)
		        next.getObjects( source, v);

		    if(doIt)
		    {
		        list.fireObjectAccessEvent(v);
		        if(children != null)
				    children.getObjects(source, v);
		    }
		}
	    /**
	     * Build a link list structure that takes into account class heirarchy.
	     */
		protected ListenerTree addObject(final Class objectClass, final Object listener, ListenerTree root)
		{
		    if(type == null)
		    {
		        type = objectClass;
		        list = list.addObject(listener);
		    }
		    else
		    if(objectClass == type)
		    {
		        if(allowMultipleValues)
			        list = list.addObject(listener);
			    else
				    list.listener = listener;
		    }
		    else //is type a superClass of objectClass
		    if((sortDescending && type.isAssignableFrom(objectClass)) || (! sortDescending && objectClass.isAssignableFrom(type)))
		    {
		        if(children == null) children = new ListenerTree();
		        children = children.addObject(objectClass, listener, children);
		    }
		    else //is objectClass is a superclass of type?
		    if((sortDescending && objectClass.isAssignableFrom(type)) || (! sortDescending && type.isAssignableFrom(objectClass)))
		    {
		        root = updateNext(objectClass);
		        root.list = root.list.addObject(listener);
		    }
		    else
		    if(next == null)
		    {
		        next = new ListenerTree();
		        next.type = objectClass;
		        next.list = next.list.addObject(listener);
		    }
		    else
		    {
		        next = next.addObject(objectClass, listener, next);
		    }
		    
		    return root;
		}
		/**
		 */
		ListenerTree updateNext(Class objectClass)
		{
	        ListenerTree root = new ListenerTree();
	        root.children = this;
	        root.type = objectClass;
//	        com.ibm.uvm.tools.DebugSupport.halt();
	        updateNext(root, this, root, null);
//.	        root.next = this.next;
//	        this.next = null;
			return root;
		}
		/**
		 */
		ListenerTree updateNext(ListenerTree parent, ListenerTree child, ListenerTree nextList, ListenerTree childRef)
		{
			if(child == null) return parent;
			//is current type a superClass of objectClass
		    if((sortDescending && parent.type.isAssignableFrom(child.type)) || (! sortDescending && child.type.isAssignableFrom(parent.type)))
		    {
			    //Leave as child.
			    return updateNext(parent, child.next, nextList, child);
		    }
			//Promote the child to be equal
		    nextList.next = child;
		    if(childRef != null)
		    {
			    childRef.next = child.next;
		        child.next = null;
		    }
		    return updateNext(parent, childRef.next, nextList.next, childRef);
		}
	}
	/**
	 * An inner class that is used to provide a link list of access listeners.
	 */
	private class AccessList
	{
		AccessList next = null;
		Object listener = null;
		/**
		*/
		protected boolean needsExecution(){ return next != null; }
		/**
		*/
		protected void fireObjectAccessEvent(Vector v)
		{
			//The last entry will never have a listener.
			if(needsExecution())
            {
				v.addElement(listener);
//				System.out.println("Identified " + listener);
				next.fireObjectAccessEvent(v);
			}
		}
		/**
		*/
		protected AccessList addObject(final Object list)
		{
			AccessList result = new AccessList();
			result.next = this;
			result.listener = list;
			return result;
		}
		/**
		*/
		protected AccessList removeObject(final Object list)
		{
			AccessList head = this;
			if(listener == list){ return next; }
			if(next != null)
				next = next.removeObject(list);
			return head;
		}
	}
	/**
	 * 
	 */
	public ClassTree()
	{
		this(true);
	}
	/**
	 */
	public ClassTree(boolean sortDescending)
	{
		this(sortDescending, true);
	}
	/**
	 */
	public ClassTree(boolean sortDescending, boolean allowMultiple)
	{
		this.sortDescending = sortDescending;
		this.allowMultipleValues = allowMultiple;
		tree = new ListenerTree();
	}
	/**
	 */
	public void addObject(final Class objectClass, final Object listener)
	{
		tree = tree.addObject(objectClass, listener, tree);
	}
	/**
	 */
	public Vector getObjects(final Object source)
	{
		Vector result = new Vector();
		tree.getObjects(source, result);
		return result;
	}
/**
 * @author Dave Hoag
 * 
 * @param args java.lang.String[]
public static void main(String args[])
{
	ClassTree t = new ClassTree(args.length == 0);
	System.out.println("new " + new java.util.Date());

	t.addObject(com.objectwave.persist.OracleBroker.class, "OracleBroker");
	t.addObject(com.objectwave.persist.BrokerFactory.class, "BrokerFact");
	t.addObject(java.lang.String.class, "String");
	t.addObject(com.objectwave.persist.Broker.class, "Broker");
	t.addObject(java.lang.Object.class, "Object");
	t.addObject(com.objectwave.persist.RDBBroker.class, "RDBBroker");

	System.out.println("looking for " + com.objectwave.persist.OracleBroker.class);
	t.getObjects(com.objectwave.persist.OracleBroker.class);

	System.out.println("--- : " + com.objectwave.persist.Broker.class);
	t.getObjects(com.objectwave.persist.Broker.class);
	System.out.println("---" + java.lang.String.class);
	t.getObjects(java.lang.String.class);
}
	/**
	 * The default is to allow a list of elements for every key. We may wish to force only one element per key.
	 */
	public void setAllowMultipleValues(boolean value)
	{
		allowMultipleValues = value;
	}
}
