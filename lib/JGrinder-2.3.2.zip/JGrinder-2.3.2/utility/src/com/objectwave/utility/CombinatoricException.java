package com.objectwave.utility;

/**
 */
public class CombinatoricException extends Exception
{
    public CombinatoricException (String str)
    {
        super(str);
    }
}
