package com.objectwave.utility;

/**
 * Just like pair, this is an association between two objects.
 * Unlike pair, this class's toString() method will return the first object.toString() results.
 * This is usefull for displaying objects in a list or tree or something where you want a display
 * to be different than the actual object, but you want to obtain a reference to the actual object
 * when a selection is made.
 * An additional benefit is sorting. The Sorter class can sort objects and it will do so on the toString()
 * results.
 *
 * @version 1.3
 * @author Dave Hoag
 */
public class DisplayPair extends Pair
{
/**
 * DisplayPair constructor comment.
 */
public DisplayPair() {
	super();
}
/**
 * DisplayPair constructor comment.
 * @param first java.lang.Object
 * @param second java.lang.Object
 */
public DisplayPair(Object first, Object second)
{
	super(first, second);
}
/**
 * @author Dave Hoag
 */
public String toString()
{
	return getFirst().toString();
}
}