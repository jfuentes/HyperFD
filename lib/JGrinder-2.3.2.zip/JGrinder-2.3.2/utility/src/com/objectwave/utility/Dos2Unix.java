package com.objectwave.utility;
import java.io.*;
/**
 * @version $Id: Dos2Unix.java,v 2.0 2001/06/11 15:46:53 dave_hoag Exp $
 */
public class Dos2Unix
{
	public static void main(String [] args)
	{
		try
		{
			FileWriter fileWriter = new FileWriter(args[1]);
			BufferedWriter fwr = new BufferedWriter( fileWriter );
			FileReader frdr = new FileReader(args[0]);
			BufferedReader buff = new BufferedReader( frdr );
			int bt = buff.read();
			char c = (char)bt;
			while(bt > -1)
			{
				//System.out.print("Char " + c + " = ");
				//System.out.println((int)c);
				if (bt != 13 )
					fwr.write(c);
				bt = buff.read();
				c = (char)bt;
			}
			fwr.write(c);
			if( c != '\n' ) fwr.write('\n');
			fwr.close();
			frdr.close();
		}
		catch(Throwable t)
		{
			t.printStackTrace();
		}
	}
}
