package com.objectwave.utility;

import java.lang.*;
import com.objectwave.event.*;
import java.io.*;

/**
* Any time an exception is the source of a StatusEvent, we'll log the
* time and the stack trace to the log file.
*/
public class ExceptionLogger implements StatusEventListener
{
	File logFile;
	/**
	*/
	protected void logException(Exception e) throws IOException
	{
		FileWriter wri = new FileWriter(logFile);
		PrintWriter buff = new PrintWriter(wri);
		buff.println(e.toString() + " " + new java.util.Date());
		e.printStackTrace(buff);
		if( buff.checkError())
			throw new IOException("Failed to log error to file " + logFile);
	}
	/**
	*/
	public void setLogFile(String fileName)
	{
		logFile = new File(fileName);
	}
	/**
	*/
	public void updateStatus(StatusEvent evt)
	{
		if(! (evt.getSource() instanceof Exception)) return;
		Exception e = (Exception) evt.getSource();
		System.out.println("++++++++++ Exception Logger Generated +++++++++");
		e.printStackTrace();
		System.out.println("---------- Exception Logger Generated ---------");
		try {
		if(logFile != null)
			logException(e);
		} catch (Exception ex)
			{
				System.out.println("ERROR WHILE TRYING TO LOG EXCEPTIONS");
				ex.printStackTrace();
			}
	}
}