/*
 *  Copyright (C) 2001 David Hoag
 *  ObjectWave Corporation
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *  For a full copy of the license see:
 *  http://www.opensource.org/licenses/lgpl-license.html
 */
package com.objectwave.utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FilenameFilter;
import java.io.IOException;
import java.net.URL;
import java.util.StringTokenizer;
import java.util.Vector;
/**
 *  Useful for doing directory listings or locating a specific file. When doing
 *  directory listings via the getAllFilenames command, the default filter is
 *  for a file that ends with ".java". <br />
 *  One of the most beneficial commands is the getUrl command. Often times we
 *  need to find files for our applications, and Java supports 3 ways to look
 *  for these files. Rather than write this same code over and over this
 *  provides all 3 in single method.
 *
 * @author  dhoag
 * @version  $Id: FileFinder.java,v 2.3 2002/02/28 04:19:56 dave_hoag Exp $
 * @see  #getUrl
 * @see  #getAllFilenames
 */
public class FileFinder
{
	/**
	 */
	public final static FilenameFilter JAVA_FILTER;
	/**
	 */
	public final static FilenameFilter dirFilter;
	/**
	 *  Set a pattern string to limit the results to files matching that pattern.
	 */
	public String patternString = null;
	FilenameFilter userFilter = null;
	File initialFile;
	FilenameFilter patternFilter;
	/**
	 *  Constructor for the FileFinder object
	 */
	public FileFinder()
	{
		initialize();
		setUserFilter(JAVA_FILTER);
	}
	/**
	 *  Constructor for the FileFinder object
	 *
	 * @param  f
	 */
	public FileFinder(File f)
	{
		this();
		initialize();
		setInitialFile(f);
	}
	/**
	 *  The main program for the FileFinder class
	 *
	 * @param  argv The command line arguments
	 */
	public static void main(String[] argv)
	{
		FileFinder fFinder = new FileFinder();
		if(argv.length > 0)
		{
			fFinder.setPatternString(argv[0]);
		}
		else
		{
			fFinder.setPatternString("*");
		}
//        fFinder.setUserFilter(JAVA_FILTER);
		String[] result = fFinder.getAllFilenames(System.getProperty("user.dir"));
		for(int i = 0; i < result.length; i++)
		{
			System.out.println(result[i]);
		}
	}
	/**
	 *  Sets the InitialFile attribute of the FileFinder object
	 *
	 * @param  f The new InitialFile value
	 */
	public void setInitialFile(File f)
	{
		initialFile = f;
	}
	/**
	 *  Sets the pattern that is to limit the result set. <br />
	 *  ex. "*", or "*.class", or "T*.java".
	 *
	 * @param  str The pattern or null - If null, change filter to be "*.java"
	 */
	public void setPatternString(String str)
	{
		if(str != null)
		{
			setUserFilter(patternFilter);
			patternString = str;
		}
		else
		{
			setUserFilter(null);
		}
	}
	/**
	 *  Use the provided FilenameFilter when getting file names. Use this to
	 *  customize your results, or use setPatternString and don't worry about
	 *  FilenameFilter instances at all!
	 *
	 * @param  filt A custom FilenameFilter
	 */
	public void setUserFilter(FilenameFilter filt)
	{
		userFilter = filt;
	}
	/**
	 *  Look for the fileName to be an abosolute reference to a file. If not, look
	 *  for the file to be located in the same directory as the sourceClass. If
	 *  not, look for the resource to be anywhere on the classpath.
	 *
	 * @param  sourceClass
	 * @param  fileName
	 * @return  The Url value
	 * @exception  java.net.MalformedURLException
	 */
	public URL getUrl(final Class sourceClass, final String fileName) throws java.net.MalformedURLException
	{
		File file = new File(fileName);
		URL url = null;
		if(file.exists())
		{
			url = new URL("file:///" + file.getAbsolutePath());
		}
		if(url == null && sourceClass != null)
		{
			url = sourceClass.getResource(fileName);
			if(url == null)
			{
				url = sourceClass.getResource('/' + fileName);
			}
		}
		if(url == null)
		{
			url = ClassLoader.getSystemResource(fileName);
		}
		return url;
	}
	/**
	 *  Find the relative path to the provided file, using the initialFile as
	 * the source location.
	 * The initialFile must be set prior to calling this method.
	 *
	 * @param  targetFile
	 * @return  The RelativePath value
	 */
	public String getRelativePath(File targetFile)
	{
		if(initialFile == null)
		{
			throw new IllegalStateException("Use getRelativePath( File, File) if initial file is not set!");
		}
		return getRelativePath(initialFile, targetFile);
	}
	/**
	 *  Find the relative path between two files.
	 *
	 * @param  sourceDir Starting at this file
	 * @param  targetFile navigate to this file
	 * @return  The RelativePath value
	 */
	public String getRelativePath(File sourceDir, File targetFile)
	{
		Vector myPaths = new Vector();
		Vector relToPaths = new Vector();
		StringTokenizer st = new StringTokenizer(targetFile.getAbsolutePath(), File.separator);
		while(st.hasMoreTokens())
		{
			myPaths.add(st.nextToken());
		}
		st = new StringTokenizer(sourceDir.getAbsolutePath(), File.separator);
		while(st.hasMoreTokens())
		{
			relToPaths.add(st.nextToken());
		}

		// find the branch point index.
		// d:/projects/movies/etc/test.xml
		// d:/projects/movies/xml/test.dtd
		// branch point index = 3 (etc/xml)
		int breakPoint = 0;
		int minCount = Math.min(myPaths.size(), relToPaths.size());
		for(int i = 0; i < minCount; i++)
		{
			String myPath = myPaths.get(i).toString();
			String relToPath = relToPaths.get(i).toString();
			breakPoint = i;
			if(!myPath.equalsIgnoreCase(relToPath))
			{
				break;
			}
		}
		StringBuffer path = new StringBuffer();
		int backDirs = relToPaths.size() - breakPoint - 1;
		for(int i = 0; i < backDirs; i++)
		{
			if(i > 0)
			{
				path.append(File.separatorChar);
			}
			path.append("..");
		}

		if(sourceDir.isDirectory())
		{
			breakPoint++;
		}
		for(int i = breakPoint; i < myPaths.size(); i++)
		{
			if(backDirs > 0 || i > breakPoint)
			{
				path.append(File.separatorChar);
			}
			path.append(myPaths.get(i));
		}
		return path.toString();
	}
	/**
	 *  Starting at the initial file location, search for all filenames matching
	 *  the pattern string.
	 *
	 * @return  The AllFilenames value
	 */
	public String[] getAllFilenames()
	{
		return getAllFilenames(initialFile);
	}
	/**
	 *  Starting at the initialDirectory location, search for all filenames
	 *  matching the pattern string.
	 *
	 * @param  initialDirectory A file representing a directory
	 * @return  All filenames that match the pattern string
	 */
	public String[] getAllFilenames(File initialDirectory)
	{
		return getAllFilenames(initialDirectory, false);
	}
	/**
	 *  Starting at the initialDirectory location, search for all filenames
	 *  matching the pattern string. If recurse is true, examine all subdirectories
	 *  for additional files matching the pattern.
	 *
	 * @param  initialDirectory The place to begin the file search
	 * @param  recurse boolean indicating to to traverse subdirectories
	 * @return  All filenames that match the pattern string
	 */
	public String[] getAllFilenames(File initialDirectory, boolean recurse)
	{
		if(!initialDirectory.isDirectory())
		{
			return new String[0];
		}
		return allFileNames(initialDirectory, new Vector(), true, recurse, true);
	}
	/**
	 *  Starting at the initialDirectory location, search for all filenames
	 *  matching the pattern string.
	 *
	 * @param  file
	 * @return  All filenames that match the pattern string
	 */
	public String[] getAllFilenames(String file)
	{
		return getAllFilenames(new File(file));
	}
	/**
	 *  Gets the PatternString attribute of the FileFinder object
	 *
	 * @return  The PatternString value
	 */
	public String getPatternString()
	{
		return patternString;
	}
	/**
	 *  Gets the UserFilter attribute of the FileFinder object
	 *
	 * @return  The UserFilter value
	 */
	public FilenameFilter getUserFilter()
	{
		return userFilter;
	}
	/**
	 *  Provide a list of files in the initialFile directory.
	 *
	 * @return
	 */
	public String[] list()
	{
		return allFileNames(initialFile, new Vector(), true, false, false);
	}
	/**
	 */
	protected void initialize()
	{
		patternFilter =
			new FilenameFilter()
			{
				/**
				 * @param  f
				 * @param  name
				 * @return
				 */
				public boolean accept(File f, String name)
				{
					return (StringManipulator.isPatternMatch(patternString, name));
				}
			};
	}
	/**
	 * @param  f the initial directory.
	 * @param  v used to build list of files.
	 * @param  comp tells me when I am done.
	 * @param  recurse recurse, do I recurse into subdirectories?
	 * @param  fullName Do we provide just the file name, or the whole path to the
	 *      file?
	 * @return
	 */
	private String[] allFileNames(final File f, final Vector v, boolean comp, final boolean recurse, final boolean fullName)
	{
		FilenameFilter filter = getUserFilter();
		String[] files;
		if(filter != null)
		{
			files = f.list(filter);
		}
		else
		{
			files = f.list();
		}

		String path = f.getPath();
		if(!path.endsWith(File.separator))
		{
			path += File.separatorChar;
		}
		for(int i = 0; i < files.length; i++)
		{
			String addElement;
			if(fullName)
			{
				addElement = path + files[i];
			}
			else
			{
				addElement = files[i];
			}

			v.addElement(addElement);
		}
		if(recurse)
		{
			String[] dirs = f.list(dirFilter);
			for(int i = 0; i < dirs.length; i++)
			{
				File newF = new File(path + dirs[i]);
				allFileNames(newF, v, false, true, fullName);
			}
		}
		else
		{
			comp = true;
		}
		if(comp)
		{
			String[] strs = new String[v.size()];
			v.copyInto(strs);
			return strs;
		}
		return null;
	}
	/**
	 * @author  dhoag
	 * @version  $Id: FileFinder.java,v 2.3 2002/02/28 04:19:56 dave_hoag Exp $
	 */
	public static class Test extends com.objectwave.test.UnitTestBaseImpl
	{
		/**
		 *  The main program for the Test class
		 *
		 * @param  args The command line arguments
		 */
		public static void main(String[] args)
		{
			com.objectwave.test.TestRunner.run(new Test(), args);
		}
		/**
		 *  A unit test for JUnit
		 *
		 * @exception  Exception
		 */
		public void testRelative() throws Exception
		{
			FileFinder ff = new FileFinder();
			URL url = ff.getUrl(FileFinder.class, "FileFinder.class");
			File one = new File(url.getFile());
			File otherFile = new File(ff.getUrl(FileFinder.class, "FileList.class").getFile());
			//Directory as first arg, file as second
			String rel = ff.getRelativePath(otherFile, one);
			testContext.assertEquals("FileFinder.class", rel);

			File two = one.getParentFile();
			rel = ff.getRelativePath(two, one);
			testContext.assertEquals("FileFinder.class", rel);

			two = one.getParentFile().getParentFile();
			rel = ff.getRelativePath(two, one);
			testContext.assertEquals("utility" + File.separatorChar + "FileFinder.class", rel);
		}
	}

	static
	{
		JAVA_FILTER =
			new FilenameFilter()
			{
				/**
				 * @param  f
				 * @param  name
				 * @return
				 */
				public boolean accept(File f, String name)
				{
					return (name.indexOf(".java") > 0);
				}
			};
		dirFilter =
			new FilenameFilter()
			{
				/**
				 * @param  f
				 * @param  name
				 * @return
				 */
				public boolean accept(File f, String name)
				{
					return (new File(f.getPath() + File.separatorChar + name).isDirectory());
				}
			};
	}
}
