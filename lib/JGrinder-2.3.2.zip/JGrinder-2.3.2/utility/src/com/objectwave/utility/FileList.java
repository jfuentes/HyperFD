package com.objectwave.utility;

import javax.swing.JCheckBox;
import java.util.Vector;
import java.util.Enumeration;
import java.beans.*;

/**
 * This type was created in VisualAge.
 * This class will convert a list of strings into a list of JComboBoxes.
 *
 * @version 2.4
 */
public class FileList
{
	Vector list = new Vector();
	Object [] data;
	JCheckBox [] uiElements;
	PropertyChangeSupport support = new PropertyChangeSupport(this);
	boolean containsNewFiles;
	boolean enforceUnique = true;
	boolean selected [];
	/** 
	 */
	public void setSelection(Object [] selectedElements)
	{
	    selected = null;
	    boolean update = uiElements != null;

	    if(! update)
	    {
            getCheckBoxList();
    	    selected = new boolean [data.length];
        }
	    if(data == null) return;
	    if(update)
	    {
	        for(int i = 0; i < uiElements.length; ++i)
	        {
	            uiElements[i].setSelected(false);
	        } 
	    }
	    for(int i = 0; i < selectedElements.length; ++i)
	    {
	        int idx = list.indexOf(selectedElements[i]);
	        if(update)
	            uiElements[idx].setSelected(true);
	        else
	            selected [idx ] = true;
	    } 
	}
    /**
     * FileList constructor comment.
     */
    public FileList()
    {
	    super();
    }
    /**
     */
    public FileList(Object [] data)
    {
        for(int i = 0; i < data.length; ++i)
        {
            addFileName(data[i]);
        } 
    }
	/**
	*/
	public synchronized void addFileName(Object fileName)
	{
		if(enforceUnique && list.contains(fileName)) return;
		list.addElement(fileName);
	}
	/**
	 */
	public void addPropertyChangeListener(PropertyChangeListener listener)
	{
		support.addPropertyChangeListener(listener);
	}
	/**
	 */
	public void firePropertyChange(String propertyName, Object oldValue, Object newValue)
	{
		support.firePropertyChange(propertyName,oldValue, newValue);
	}
	/**
	 */
	public JCheckBox [] getCheckBoxList()
	{
	    list = com.objectwave.utility.Sorter.quickSort(list);
		data = new Object [ list.size() ];
		list.copyInto(data);
		uiElements = new JCheckBox [ data.length ];
		for(int i = 0; i < data.length; i++)
		{
		    if(selected == null)
    			uiElements[i] = new JCheckBox(data[i].toString(), true);
    	    else
    	        uiElements[i] = new JCheckBox(data[i].toString(), selected [i]);
		}
		selected = null;
		return uiElements;
	}
    /**
     * @author Dave Hoag
     * @return boolean
     */
    public boolean getContainsNewFiles()
    {
	    return containsNewFiles;
    }
    /**
     * This method was created in VisualAge.
     */
    public Object [] getSelectedFiles()
    {
	    Vector result = new Vector(uiElements.length);
	    for(int i = 0; i < uiElements.length; i++)
	    {
		    if(uiElements[i].isSelected())
			    result.addElement(data[i]);
	    }
	    Object [] vals = new Object [ result.size() ];
	    result.copyInto(vals);
	    return vals;
    }
	/**
	*/
	public synchronized void removeFileName(Object fileName)
	{
		list.removeElement(fileName);
	}
	/**
	 */
	public void removePropertyChangeListener(PropertyChangeListener listener)
	{
		support.removePropertyChangeListener(listener);
	}
    /**
    * @author Dave Hoag
    * @param newValue boolean
    */
    public void setContainsNewFiles(boolean newValue)
    {
	    this.containsNewFiles = newValue;
    }
}