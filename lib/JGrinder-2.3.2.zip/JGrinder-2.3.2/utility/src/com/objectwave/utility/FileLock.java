package com.objectwave.utility;

import java.io.*;
import java.util.*;
/**
 * Write an int to the head of a RandomAccessFile to mark it as locked.
 *
 * @author Dave Hoag
 * @version 1.2
 */
public class FileLock
{
    static boolean verbose = System.getProperty("ow.fileLockVerbose","false").equalsIgnoreCase("true");
	/**
	 * Both an example and a utility to manually release the lock.
	 */
	public static void main(String [] args)
	{
		if(args.length == 0)
		{
			System.out.println("Usage java com.objectwave.utility.FileLock [ release <fileName> | <fileName> <mode> <text>]");
			return;
		}
		try
		{
			if(args[0].equals("release"))
			{
				RandomAccessFile lockedFile = new RandomAccessFile(args[1], "rw");
				releaseLock(lockedFile);
				lockedFile.close();
				System.out.println("The file lock has been removed.");
                return;
			}
			RandomAccessFile file = new RandomAccessFile(args[0], args[1]);
			getLock(file);
			file.writeUTF(args[2]);
			System.out.println("Press enter to release file");
			new DataInputStream(System.in).readLine();
			releaseLock(file);
			file.close();
		}
		catch (Exception e) { e.printStackTrace(); }
	}
	/**
	 * Mark the initial int of a RandomAccessFile as a zero.
	 * Effectively releasing the lock on the file.
	 */
	public static void releaseLock(RandomAccessFile file) throws IOException
	{
		file.seek(0);
		file.writeInt(0);
		file.getFD().sync();
	}
	/**
	 * Lock the provided file by setting the first int of the file to be a random number.
	 * Warning: The first int value will be set to a Random Number! Make sure this is ok.
	 * To prevent 'dead lock' always be sure to release a lock once it is obtained.
	 * @param file java.io.RandomAccessFile The file to be locked.
	 */
	public static void getLock(RandomAccessFile file) throws IOException
	{
		Random rnd = new Random();

		int mySeed = rnd.nextInt();
        if(verbose)
        {
		    System.out.println("Attempting to lock file with SEED " + mySeed);
        }
		while(true)
		{
			int currentSeed;
			try
			{
			while((currentSeed = file.readInt()) != 0)
			{
                if(verbose)
				    System.out.println("Failed! Found CURRENT SEED "+ currentSeed);
				try
				{
					Thread.currentThread().sleep(5000);
				}
				catch(InterruptedException ex) {}
				file.seek(0);
			}
			file.seek(0); //Go back after reading the zero
			}catch(EOFException ex) {} //File didn't exist. Proceed!
			file.writeInt(mySeed);
			file.getFD().sync();
			file.seek(0);
			int validate = file.readInt();
            if(verbose)
            {
			    System.out.println("VALIDATE CODE: " + validate + " against " + mySeed);
            }
			if(validate == mySeed) return;
			file.seek(0);
			//Error occured getting lock. Thought I had it, but lost
		}
	}
}
