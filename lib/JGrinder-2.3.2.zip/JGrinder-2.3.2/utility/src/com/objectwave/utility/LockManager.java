package com.objectwave.utility;

import java.util.*;

/**
 *  A simple implementation of a LockManager.
 *
 * @author  Dave Hoag
 * @version  $Id: LockManager.java,v 2.0 2001/06/11 15:46:53 dave_hoag Exp $
 */
public class LockManager
{
	HashMap objects;
	private final static boolean debug = System.getProperty("ow.LockManagerVerbose") != null;

	/**
	 *  LockManager default constructor
	 */
	public LockManager()
	{
		objects = new HashMap(19);
	}

	/**
	 *  Lock a single object
	 *
	 * @param  objectToLock the object to lock
	 */
	public synchronized void lock(Object objectToLock)
	{
		java.lang.Object tempObj = null;
		String myThread = Thread.currentThread().getName();
		while(true)
		{
			tempObj = objects.get(objectToLock);
			if(tempObj == null)
			{
				// no lock, take it
				objects.put(objectToLock, myThread);
				if(debug)
				{
					System.out.println("LockManager::lock: thread " + myThread + " locked " + objectToLock);
				}
				return;
			}
			else if(((String) tempObj).equals(myThread))
			{
				// my thread already owns lock
				return;
			}
			else
			{
				// somebody else has the lock
				try
				{
					wait();
				}
				catch(InterruptedException ex)
				{
				}
			}
		}
	}

	/**
	 *  Release a single object
	 *
	 * @param  objectToUnlock the object to unlock
	 */
	public synchronized void release(Object objectToUnlock)
	{
		String temp = (String) objects.get(objectToUnlock);
		if(temp != null)
		{
			if(temp.equals(Thread.currentThread().getName()))
			{
				objects.remove(objectToUnlock);
				if(debug)
				{
					System.out.println("LockManager::release: thread " + Thread.currentThread().getName() + " unlocking " + objectToUnlock);
				}
			}
			else
			{
				throw new IllegalArgumentException("Attempt to release object not owned by this thread (owned by " + temp + ")");
			}
		}
		notify();
	}

	/**
	 *  Acquire locks for all of the objects in the List, or none of them. Attempt
	 *  to acquire locks. If we cannot, get in line to try again.
	 *
	 * @param  listToLock list of objects to lock
	 */
	public synchronized void acquireLocks(List listToLock)
	{
		boolean alreadyLocked = false;
		Thread myThread = Thread.currentThread();
		Object tempObj = null;
		while(true)
		{
//			synchronized(listToLock) // prevent changes to input list
//			{
			Iterator itr = listToLock.iterator();
			while(itr.hasNext())
			{
				tempObj = objects.get(itr.next());
				if(tempObj != null && tempObj != myThread)
				{
					alreadyLocked = true;
					break;
				}
			}

			if(!alreadyLocked)
			{
				// add the whole collection to objects
				itr = listToLock.iterator();
				while(itr.hasNext())
				{
					objects.put(itr.next(), myThread);
				}

				if(debug)
				{
					System.out.println("LockManager::acquireLocks: thread " + myThread + " locking " + listToLock);
				}
				return;
			}
//			}

			try
			{
				wait();
			}
			catch(InterruptedException ex)
			{
			}
			alreadyLocked = false;
		}
	}

	/**
	 *  Release locks for all objects in a List
	 *
	 * @param  listToUnlock the objects to unlock
	 */
	public synchronized void releaseLocks(List listToUnlock)
	{
		Object temp = null;
		Thread myThread = Thread.currentThread();
//		synchronized(listToUnlock) { // prevent changes to the input list.
		Iterator listIter = listToUnlock.iterator();
		while(listIter.hasNext())
		{
			temp = objects.remove(listIter.next());
			if(temp != null && temp != myThread)
			{
				throw new IllegalArgumentException(myThread + " attempted to release object not owned by this thread (owned by " + temp + ")");
			}
		}
// 			remove only when I know I own all the locks.
//			objects.keySet().removeAll(listToUnlock);
		if(debug)
		{
			System.out.println("LockManager::releaseLocks: thread " + myThread + " unlocking " + listToUnlock);
		}
//			}
		notifyAll();
	}
}
