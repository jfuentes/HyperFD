package com.objectwave.utility;

import java.io.*;

public class LogOutput
{
	private FileOutputStream fileOut;
	private PrintStream printOut;

	public LogOutput()
		throws IOException
	{
		this(System.getProperty("ow.outputLog"));
	}
	public LogOutput(String fileName)
		throws IOException
	{
		try
		{
			if (fileName!=null)
			{
				fileOut = new FileOutputStream(fileName);
				printOut = new PrintStream(fileOut);
			}
		}
		finally
		{
			if (printOut == null)
				printOut = System.out;
		}
	}
	public PrintStream getPrintStream() { return printOut; }
	public static void hookupSystemErr()
		throws IOException
	{
		System.setErr(new LogOutput().getPrintStream());
	}
	public static void hookupSystemOut()
		throws IOException
	{
		System.setOut(new LogOutput().getPrintStream());
	}
	public static void main(String args[])
	{
		try
		{
			LogOutput.hookupSystemOut();
			System.out.println("Hello!");
			System.out.println("Hey!!!!");
		}
		catch (IOException io) { System.out.println(io); }
		try
		{
			System.out.println("ow.outputLog = \"" + System.getProperty("ow.outputLog") + "\"");
			LogOutput.hookupSystemOut();
			System.out.println("Hello!");
			System.out.println("Hey!!!!");
		}
		catch (IOException io) { System.out.println(io); }
	}
}