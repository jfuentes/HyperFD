package com.objectwave.utility;

import java.util.*;
/**
 * A helper class that works with the ThreadPoolManager to implement thread pooling.
 * 
 * @version 2.0
 * @see com.objectwave.utility.ThreadPoolManager
 */
class ManagedThread extends Thread
{
	protected ThreadPoolManager manager;
	Runnable r;
	static int count = 0;
	/**
	 * This class should not be used by anyone other than the thread pool manager.
	 */
	ManagedThread(ThreadPoolManager mgr, ThreadGroup group)
	{
		super( group, "ManagedThread[" + count++ + ']');
		manager = mgr;
		start();
	}
	/**
	 */
	public void run()
	{
		try 
		{
			while(true)
			{
				//First wait for a runnable.
				boolean shutdown = manager.threadWaiting(this);
				//We should exit since we are done.
				if(shutdown) return;
				try
				{
			  //Then run it!
					r.run();
				}
				catch (Exception e)
				{
					System.err.println("Error in execution of runnable " + r + "\n" + e);
					e.printStackTrace(System.err);
				}
			}
		}
		catch (InterruptedException e) {}
	}
	/**
	 * Set the runnable value. This is called from the thread pool manager.
	 * Once the manager returns from the threadWaiting method, the value
	 * of r will be executed.
	 */
	public void startRunnable(Runnable r)
	{
	    this.r = r;
	}
}