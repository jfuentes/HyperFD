package com.objectwave.utility;

import java.util.*;

/**
 * Extend hashtable to allowmultiple values to be associated with each key.
 * Calls to get() return a vector of values. Elements, likewise, returns an
 * enumeration of vectors.
 */
public class NonUniqueHashtable extends Hashtable
{
	public NonUniqueHashtable()
	{
	}
	public NonUniqueHashtable(int initializeCapacity)
	{
		super(initializeCapacity);
	}
	public NonUniqueHashtable(int initializeCapacity, float loadFactor)
	{
		super(initializeCapacity, loadFactor);
	}
	public synchronized boolean contains(Object value)
	{
		for (Enumeration e = elements(); e.hasMoreElements();)
		{
			Vector v = (Vector)e.nextElement();
			if (v == null)
				continue;
			for (Enumeration ee = v.elements(); ee.hasMoreElements(); )
			{
				if (ee.nextElement().equals(value))
					return true;
			}
		}
		return false;
	}
	public static void main(String args[])
	{
		if (args.length == 0)
			System.out.println("Expected pairs of args to go in the table.");
		
		NonUniqueHashtable table = new NonUniqueHashtable(8);
		
		for (int i=0; i < args.length; i++)
		{
			String key = args[i++];
			if (i == args.length) break;
			String value = args[i];
			table.put(key, value);
		}
		
		System.out.println("Table:\n" + table);
		
		if (args.length > 0)
		{
			System.out.println("\"" + args[0] + "\" is a key? " + table.containsKey(args[0]));
			System.out.println("\"" + args[args.length-1] + "\" is a value? " + table.contains(args[args.length-1]));
			System.out.println("Value for \"" + args[0] + "\" is " + table.get(args[0]));
		}
	}
	public synchronized Object put(Object key, Object value)
	{
		if (!containsKey(key))
			super.put(key, new Vector(4));
		Vector v = (Vector)super.get(key);
		v.addElement(value);
		return (v.size() < 2) ? null : v.elementAt(v.size()-2);
	}
	public synchronized Object removeValue(Object key, Object value)
	{
		Vector v = (Vector)get(key);
		if (v == null || v.size() < 1) return null;
		if (v.removeElement(value))
			return (v.size() == 1) ? remove(key) : key;
		return null;
	}
}