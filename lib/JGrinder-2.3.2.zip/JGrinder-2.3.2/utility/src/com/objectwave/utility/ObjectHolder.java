package com.objectwave.utility;

import java.awt.Window;

/**
 *  Just holds an object. Useful in fireDataRequest() et cetera, where a value
 *  is to be passed back.
 *
 * @author  dhoag
 * @version  $Id: ObjectHolder.java,v 2.0 2001/06/11 15:46:53 dave_hoag Exp $
 */
public class ObjectHolder
{
	private Object object;

	/**
	 *  Constructor for the ObjectHolder object
	 */
	public ObjectHolder()
	{
	}
	/**
	 *  Constructor for the ObjectHolder object
	 *
	 * @param  object
	 */
	public ObjectHolder(Object object)
	{
		setObject(object);
	}
	/**
	 *  Sets the Object attribute of the ObjectHolder object
	 *
	 * @param  object The new Object value
	 */
	public void setObject(Object object)
	{
		this.object = object;
	}
	/**
	 *  Gets the Object attribute of the ObjectHolder object
	 *
	 * @return  The Object value
	 */
	public Object getObject()
	{
		return object;
	}
}
