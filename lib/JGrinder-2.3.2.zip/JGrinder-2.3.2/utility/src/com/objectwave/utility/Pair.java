package com.objectwave.utility;

import java.io.Serializable;
/**
 *  This type was created in VisualAge.
 *
 * @author  zcai
 * @version  $Id: Pair.java,v 2.0 2001/06/11 15:46:53 dave_hoag Exp $
 */
public class Pair implements Serializable
{

	protected Object first = null;
	protected Object second = null;
	/**
	 *  Pair constructor comment.
	 */
	public Pair()
	{
	}
	/**
	 *  This method was created in VisualAge.
	 *
	 * @param  first java.lang.Object
	 * @param  second java.lang.Object
	 */
	public Pair(Object first, Object second)
	{
		this.first = first;
		this.second = second;
	}
	/**
	 *  This method was created in VisualAge.
	 *
	 * @param  newValue java.lang.Object
	 */
	public void setFirst(Object newValue)
	{
		this.first = newValue;
	}
	/**
	 *  This method was created in VisualAge.
	 *
	 * @param  newValue java.lang.Object
	 */
	public void setSecond(Object newValue)
	{
		this.second = newValue;
	}
	/**
	 *  This method was created in VisualAge.
	 *
	 * @return  java.lang.Object
	 */
	public Object getFirst()
	{
		return first;
	}
	/**
	 *  This method was created in VisualAge.
	 *
	 * @return  java.lang.Object
	 */
	public Object getSecond()
	{
		return second;
	}
	/**
	 *  This method was created in VisualAge.
	 *
	 * @return  java.lang.String
	 */
	public String toString()
	{
		return "{" + getFirst() + "," + getSecond() + "}";
	}
}
