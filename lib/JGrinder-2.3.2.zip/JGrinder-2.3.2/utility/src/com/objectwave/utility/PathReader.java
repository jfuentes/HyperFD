package com.objectwave.utility;

import java.util.*;
import java.io.*;

/**
* This is incomplete since the idea is not well thought out.
*/
public class PathReader extends java.lang.Object
{
	String [] dirs;
	File file;
	
	public PathReader(String fileName) throws IOException
	{
		file = new File(fileName);
		if(! file.exists())
			throw new  IOException("File doesn't exist. " + fileName);
		if(! file.isDirectory())
			throw new  IOException("File isn't a directory. " + fileName);
		initPossible();
	}
	public boolean canContain(String fileName)
	{
		return true;
	}
	void initPossible()
	{
		FileFinder ff = new FileFinder(file);
		ff.setUserFilter(FileFinder.dirFilter);
		dirs = ff.list();
	}
}