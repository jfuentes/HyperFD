package com.objectwave.utility;

import java.awt.*;

public class PointManipulator {

	public static final int BELOW = 3;
	public static final int RIGHT = 2;
	public static final int TOP = 1;
	public static final int LEFT = 4;

	public static Point bottomOf(Component c, int idx, int cnt){
		Rectangle r = c.getBounds();
		int offset = r.width / (2 + cnt);
		return new Point(r.x + (offset * (idx + 1)), r.y + r.height);
	}
	public static Point getStartPosition(Component origin, Component target) {
		return getStartPosition(origin, target, 0, 0);
	}
	public static Point getStartPosition(Component origin, Component target, int idx, int count ) {

		switch ( gridPosition(origin, target)){
			case RIGHT: return rightOf(origin, idx, count );
			case TOP: return topOf(origin, idx, count );
			case LEFT:  return leftOf(origin, idx, count);
			case BELOW: return bottomOf(origin, idx, count);
		}
		return new Point();
	}
	public static Point getStartPosition(Component c, Point target){
		Point origin = c.getLocation();
		origin = new Point(origin.x + (c.getBounds().width / 2), origin.y + (c.getBounds().height / 2));
		int result = gridPosition(origin , target);
		switch ( result){
			case RIGHT: return rightOf(c, 0, 0 );
			case TOP: return topOf(c, 0, 0 );
			case LEFT:  return leftOf(c, 0, 0);
			case BELOW: return bottomOf(c, 0, 0);
		}
		return new Point();
	}
	public static int gridPosition(Component originComp, Component targetComp){
		Point origin = originComp.getLocation();
		origin = new Point(origin.x + (originComp.getBounds().width / 2), origin.y + (originComp.getBounds().height / 2));
		Point target = targetComp.getLocation();
		target = new Point(target.x + (targetComp.getBounds().width / 2), target.y + (targetComp.getBounds().height / 2));
		return gridPosition(origin, target);
	}
	/** Determine's targets location relative to the origin.
	*/
	public static int gridPosition(Point origin, Point target){
		int xDiff = target.x - origin.x;
		int yDiff = target.y - origin.y;
		if(xDiff > 0){
			if(yDiff > 0){
				if(Math.abs(yDiff) > Math.abs(xDiff)) return BELOW;
				else return RIGHT;
			} else {
				if(Math.abs(yDiff) > Math.abs(xDiff)) return TOP;
				else return RIGHT;
			}
		} else {
			if(yDiff > 0){
				if(Math.abs(yDiff) > Math.abs(xDiff)) return BELOW;
				else return LEFT;
			} else {
				if(Math.abs(yDiff) > Math.abs(xDiff)) return TOP;
				else return LEFT;
			}
		}
	}
	public static Point leftOf(Component c, int idx, int cnt){
		Rectangle r = c.getBounds();
		int offset = (r.height / (2 + cnt));

		return new Point(r.x, r.y + (offset * (idx + 1)));
	}
	public static Point rightOf(Component c, int idx, int cnt){
		Rectangle r = c.getBounds();
		int offset = (r.height / (2 + cnt));
		return new Point(r.x + r.width, r.y + (offset * (idx + 1)));
	}
	public static Point topOf(Component c, int idx, int cnt){
		Rectangle r = c.getBounds();
		int offset = r.width / (2 + cnt);
		return new Point(r.x + (offset * (idx + 1)), r.y);
	}
}