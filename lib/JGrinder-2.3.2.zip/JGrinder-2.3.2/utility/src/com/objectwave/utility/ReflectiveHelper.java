/*
 *  Copyright (C) 2001 David Hoag
 *  ObjectWave Corporation
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *  For a full copy of the license see:
 *  http://www.opensource.org/licenses/lgpl-license.html
 */
package com.objectwave.utility;
import com.objectwave.logging.MessageLog;
import java.lang.reflect.*;
/**
 *  A collection of functions that may assist when working with java's
 *  reflective capabilities.
 *
 * @author  dhoag
 * @version  $Id: ReflectiveHelper.java,v 2.1 2001/08/02 16:27:11 dave_hoag Exp $
 */
public class ReflectiveHelper
{
	ObjectFormatter objectConverter;
	/**
	 *  Constructor for the ReflectiveHelper object
	 */
	public ReflectiveHelper()
	{
		initialize();
	}
	/**
	 *  Use the setMethod to set a field property. The property is originally a
	 *  string and it is converted to the correct field type before the set method
	 *  is called. If no set <FieldName>method exists, nothing is done.
	 *
	 * @param  valueToSet String The value to set.
	 * @param  field The field that will ultimately have the set value.
	 * @param  obj The object upon which the setProperty method will be called.
	 * @exception  InvocationTargetException
	 * @exception  IllegalAccessException
	 */
	public void setValue(final Field field, final String valueToSet, final Object obj) throws InvocationTargetException, IllegalAccessException
	{
		final Method method = findMethod(field.getName(), field.getType(), obj.getClass());
		if(method != null)
		{
			Object[] data = new Object[1];
			//Convert the String object into the proper object type
			final Object targetType = objectConverter.convertType(field.getType(), valueToSet);
			data[0] = targetType;
			if(MessageLog.isDebugEnabled(this))
			{
				MessageLog.debug(this, "Setting data to: " + targetType);
			}
			method.invoke(obj, data);
		}
	}
	/**
	 *  Use the setMethod to set a field property.
	 *  If no set <FieldName>method exists, nothing is done.
	 *
	 * @param  field The new Value value
	 * @param  valueToSet The new Value value
	 * @param  obj The new Value value
	 * @exception  InvocationTargetException
	 * @exception  IllegalAccessException
	 */
	public void setValue(final Field field, final Object valueToSet, final Object obj) throws InvocationTargetException, IllegalAccessException
	{
		final Method method = findMethod(field.getName(), field.getType(), obj.getClass());
		if(method != null)
		{
			Object[] data = new Object[1];
			//Convert the String object into the proper object type
			data[0] = valueToSet;
			if(MessageLog.isDebugEnabled(this))
			{
				MessageLog.debug(this, "Setting data to: " + valueToSet.getClass().getName());
			}
			method.invoke(obj, data);
		}
	}
	/**
	 * Use the getMethod to get the value of the provided field.
	 *
	 * @param  field
	 * @param  obj
	 * @return  The Value value
	 * @exception  InvocationTargetException
	 * @exception  IllegalAccessException
	 */
	public Object getValue(final Field field, final Object obj) throws InvocationTargetException, IllegalAccessException
	{
		final Method method = findMethod(field.getName(), obj.getClass());
		Object result = null;
		if(method != null)
		{
			result = method.invoke(obj, new Object[0]);
		}
		return result;
	}
	/**
	 *  Establish the object formatter for converting string properties to their
	 *  actuall class type.
	 */
	protected void initialize()
	{
		objectConverter = new ObjectFormatter();
	}
	/**
	 *  Find the method called set<FieldName> so we can set the value. Property is
	 *  the uppercase name of the fieldName parameter.
	 *
	 * @param  fieldType The class of the field. This should be the set method's
	 *      argument type.
	 * @param  fieldName The name of a field on the target class.
	 * @param  targetClass
	 * @return  java.lang.reflect.Method The reflected method object found on the
	 *      target class.
	 */
	protected Method findMethod(final String fieldName, final Class fieldType, final Class targetClass)
	{
		final Class[] args = new Class[1];
		args[0] = fieldType;
		final char[] name = fieldName.toCharArray();
		name[0] = Character.toUpperCase(name[0]);
		if(MessageLog.isDebugEnabled(this))
		{
			MessageLog.debug(this, "Looking for a set method of " + "set" + String.valueOf(name) + " on class " + targetClass.getName());
		}
		Method method = null;
		try
		{
			method = targetClass.getMethod("set" + String.valueOf(name), args);
		}
		catch(NoSuchMethodException ex)
		{
			MessageLog.warn(this, fieldName + "not set. Method " + "set" + String.valueOf(name) + " not found on class " + targetClass.getName(), ex);
		}
		return method;
	}
	/**
	 *  Find the method called get<FieldName> so we can set the value. Property is
	 *  the uppercase name of the fieldName parameter.
	 *
	 * @param  fieldName The name of a field on the target class.
	 * @param  targetClass
	 * @return  java.lang.reflect.Method The reflected method object found on the
	 *      target class.
	 */
	protected Method findMethod(final String fieldName, final Class targetClass)
	{
		final Class[] args = new Class[0];
		final char[] name = fieldName.toCharArray();
		name[0] = Character.toUpperCase(name[0]);
		if(MessageLog.isDebugEnabled(this))
		{
			MessageLog.debug(this, "Looking for a set method of " + "get" + String.valueOf(name) + " on class " + targetClass.getName());
		}
		Method method = null;
		try
		{
			method = targetClass.getMethod("get" + String.valueOf(name), args);
		}
		catch(NoSuchMethodException ex)
		{
			MessageLog.warn(this, fieldName + "not set. Method " + "set" + String.valueOf(name) + " not found on class " + targetClass.getName(), ex);
		}
		return method;
	}

}
