package com.objectwave.utility;

/**
 * This interface should be implemented by all classes which wish to be
 * treated as a scalar type by the persistence layer.  That is, types
 * besides the fundamental types (Strings, Boolean, Numbers, arrays, and Dates)
 * which will be maintained in a column of a database table.  
 *
 *   Objects which implement this interface should also be listed in the
 * ScalarTypeFactory class, which is used to create objects of this type
 * from a given string.
 */ 
public interface ScalarType 
{

/**
 *  Stringify this object instance in a form which will be
 *  recognized by the ScalarTypeGeneratorIF implementation
 *  for this class.
 */
public String toDatabaseString();
}
