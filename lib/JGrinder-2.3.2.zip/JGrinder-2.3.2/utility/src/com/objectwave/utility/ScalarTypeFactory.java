package com.objectwave.utility;
import com.objectwave.exception.ExceptionBuilder;
import com.objectwave.exception.NotFoundException;
/**
 *  This class is used by the JavaGrinder framework to create new instances of
 *  custom ScalarType objects. By their very nature these objects are
 *  application specific, this class is just a coordinator of the factory
 *  objects necessary to create the new instances.
 *
 * @author  dhoag
 * @version  $Id: ScalarTypeFactory.java,v 2.0 2001/06/11 15:46:53 dave_hoag Exp $
 * @see  ScalarTypeGeneratorIF
 */
public class ScalarTypeFactory
{
	protected static ScalarTypeGeneratorIF[] generators = new ScalarTypeGeneratorIF[50];
	static int size;
	/**
	 *  Use the registered ScalarTypeGenerator to create a new instance of the
	 *  ScalarType object.
	 *
	 * @param  scalarType java.lang.Class The first generator that generates types
	 *      that are assignable to the this parameter will be used to create the
	 *      new instance.
	 * @param  str
	 * @return  java.lang.Object
	 * @exception  java.text.ParseException
	 * @exception  NotFoundException
	 */
	public static ScalarType create(final Class scalarType, final String str) throws java.text.ParseException, NotFoundException
	{
		if(str != null)
		{
			for(int i = 0; i < size; i++)
			{
				final ScalarTypeGeneratorIF gen = generators[i];
				if(gen.typeGenerated().isAssignableFrom(scalarType))
				{
					return gen.createInstance(str);
				}
			}
		}
		throw ExceptionBuilder.notFound("There was no ScalarTypeFactory for the provided ScalarType: " + scalarType);
	}
	/**
	 *  Add a new ScalarTypeGenerator to the list of known generators.
	 *
	 * @param  generator ScalarTypeGenerator
	 */
	public static synchronized void registerGenerator(ScalarTypeGeneratorIF generator)
	{
		generators[size++] = generator;
		if(size == generators.length)
		{
			ScalarTypeGeneratorIF[] tmpGenerators = new ScalarTypeGeneratorIF[generators.length + 50];
			System.arraycopy(generators, 0, tmpGenerators, 0, generators.length);
			generators = tmpGenerators;
		}

	}
}
