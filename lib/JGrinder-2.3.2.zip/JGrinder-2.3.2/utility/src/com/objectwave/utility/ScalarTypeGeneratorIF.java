package com.objectwave.utility;

/**
 * Application-specific types implementing ScalarType should also
 * register an appropriate implementation of this interface with the
 * ScalarTypeFactory, so that the given ScalarType class can
 * be created by the persistence layer.  
 */
public interface ScalarTypeGeneratorIF 
{
/**
 * This method will create an instance of a specific implementation
 * of ScalarType, 
 * @return com.objectwave.persist.ScalarType the generated instance
 * @param dbString java.lang.String the string from which the instance is
 *		to be created.
 */
ScalarType createInstance(String dbString) throws java.text.ParseException;
/**
 * Inform the ScalarTypeFactory what type can be created by this
 * generator.
 * @return java.lang.Class, the imlementation of ScalarType that
 * can be created by this generator.
 */
Class typeGenerated();
}
