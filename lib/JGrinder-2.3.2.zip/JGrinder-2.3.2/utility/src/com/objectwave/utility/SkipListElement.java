package com.objectwave.utility;
/**
* Description: Class for a single node in a SkipList
*/
public class SkipListElement
{
    ///////////////////////////////////////////////////////////////////////////
    // Constructor:
    //   Constructs a new element of a skip list.
    //   level, key and value of the new node are given 
    //   
    public SkipListElement(int level, Object key, Object value)
    {
        this.key = key;
        this.value = value;
        forward = new SkipListElement[level+1];
    }
  
  
    ///////////////////////////////////////////////////////////////////////////
    // getLevel():
    //   returns the level of this node (count starting at 0)
    //
    int getLevel()
    { 
        return forward.length-1;
    }
    
    ///////////////////////////////////////////////////////////////////////////
    // accessible attributes:
    //   access is "friendly", this way all classes in this package can access
    //   the data member directly: performance is increased
    Object key;                        // key data (sort and search criterion)
    Object value;                   // associated value
    SkipListElement forward[];      // array of forward pointers
}
