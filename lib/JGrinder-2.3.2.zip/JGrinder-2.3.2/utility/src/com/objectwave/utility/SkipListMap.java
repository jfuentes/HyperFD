package com.objectwave.utility;
import java.util.Enumeration;

/**
 * Description: Class for a "SkipListMap" as proposed by William Pugh.
 *              His paper is available at ftp://ftp.cs.umd.edu/pub/skipLists
 *
 * @version $Id: SkipListMap.java,v 2.1 2002/07/31 15:55:23 dave_hoag Exp $
 */
public class SkipListMap
{
    // a reference to this object is returned, if during search no
    // element has been found:
    public static final String NOT_FOUND_OBJ = new String("Not found");

    // key of terminator object NIL; all used keys have to be smaller
    // than this one:
    public static final Integer NIL_KEY = new Integer(Integer.MAX_VALUE);
    public static final float GOOD_PROB = 0.25f; // a good probability

	protected SorterComparisonIF comparison = null;
    /**
     * @return com.objectwave.utility.SorterComparisonIF
     */
    public SorterComparisonIF getComparison()
    {
	    return comparison;
    }
    /**
     * @param newValue com.objectwave.utility.SorterComparisonIF
     */
    public void setComparison(SorterComparisonIF newValue)
    {
	    this.comparison = newValue;
    }
	/**
	 * @return 0 if objects are equal.
	 */
	private int compare(final Object lhs, final Object rhs)
	{
		if (comparison != null)
			return comparison.compare(lhs, rhs);
		else
			return lhs.hashCode() - rhs.hashCode();
	}
	/**
	 */
	public SkipListMap()
	{
	    this(100);
	}
    ///////////////////////////////////////////////////////////////////////////
    // Constructor (1):
    //   Constructs a new skip list optimized for the given
    //   expected upper boundary for the number of nodes.
    //   If you expect to have 10000 nodes, call the
    //   constructor as SkipListMap(10000).
    //
    public SkipListMap(long maxNodes)
    {
        // call the constructor (2) with a calculated maximum level
        // and probability set to GOOD_PROB.
        // Maximum level of list is depending on expected number of nodes
        // (see Pugh for mathematical background)
        this(GOOD_PROB,
            (int)Math.ceil(Math.log(maxNodes)/Math.log(1/GOOD_PROB))-1);
    }


    ///////////////////////////////////////////////////////////////////////////
    // Constructor (2):
    //   Constructs a new skip list, for which you can directly set the
    //   probability to increase the level of a new node (often 0.25)
    //   and maximum level of the nodes in the list.
    //   If you are not sure about parameters, use constructor (1)!
    //
    public SkipListMap(float probability, int maxLevel)
    {
        myProbability = probability;
        myMaxLevel = maxLevel;
        myLevel = 0;                  // level of empty list

        // generate the header of the list:
        myHeader = new SkipListElement(myMaxLevel, new Integer(0), null);

        // append the "NIL" element to the header:
        SkipListElement nilElement =
            new SkipListElement(myMaxLevel, NIL_KEY, null);
        for (int i=0; i<=myMaxLevel; i++)
        {
            myHeader.forward[i] = nilElement;
        }
    }


    ///////////////////////////////////////////////////////////////////////////
    // generateRandomLevel():
    //   Generates with help of randomizer the level of a new element.
    //   The higher a level, the less probable it is (see paper).
    //   Levels begin at 0 (not at 1 like in the paper).
    //
    protected int generateRandomLevel()
    {
        int newLevel = 0;
        while (newLevel<myMaxLevel && Math.random()<myProbability )
        {
            newLevel++;
        }
        return newLevel;
    }


    ///////////////////////////////////////////////////////////////////////////
    //   Inserts a new node into the list.
    //   If the key already exists, its node is updated to the new value.
    //
    public void put(Object searchKey, Object value)
    {
        // update holds pointers to the left neighbor element on each level,
        // levels run from 0 up to myMaxLevel:
        SkipListElement[] update = new SkipListElement[myMaxLevel+1];

        // init "cursor" element to header:
        SkipListElement cursor = myHeader;

        // find place to insert the new node:
        for (int i=myLevel; i>=0; i--)
        {
            while ((cursor.forward[i].key != NIL_KEY) && (compare(cursor.forward[i].key, searchKey) < 0))
//            while (cursor.forward[i].key < searchKey)
            {
                cursor = cursor.forward[i];
            }
            update[i] = cursor;
        }
        cursor = cursor.forward[0];

        // element with same key is overwritten:
        if (compare(cursor.key ,searchKey) == 0)
//        if (cursor.key == searchKey)
        {
            cursor.value = value;
        }

        // or an additional element is inserted:
        else
        {
            int newLevel = generateRandomLevel();
            // element has greatest level seen in this list: update list
            if (newLevel > myLevel)
            {
                for (int i=myLevel+1; i<=newLevel; i++)
                {
                    update[i] = myHeader;
                }
                myLevel = newLevel;
            }

            // allocate new element:
            cursor = new SkipListElement(newLevel, searchKey, value);
            for (short i=0; i<=newLevel; i++)
            {
                cursor.forward[i] = update[i].forward[i];
                update[i].forward[i] = cursor;
            }
        }
    }


    ///////////////////////////////////////////////////////////////////////////
    // search():
    //   Search for a given key in list. you get the value associated
    //   with that key or the NOT_FOUND constant.
    //
    public Object get(Object searchKey)
    {
        // init "cursor"-element to header:
        SkipListElement cursor = myHeader;

        // find element in list:
        for (int i=myLevel; i>=0; i--)
        {
            SkipListElement nextElement = cursor.forward[i];
            while ((nextElement.key != NIL_KEY) && compare(nextElement.key , searchKey) < 0)
//            while (nextElement.key < searchKey)
            {
                cursor = nextElement;
                nextElement = cursor.forward[i];
            }
        }
        cursor = cursor.forward[0];

        // if key exists return value else return predefined NOT_FOUND:
        if (compare(cursor.key ,searchKey) == 0) return cursor.value;
//        if (cursor.key == searchKey) return cursor.value;
        else return null;
    }


    ///////////////////////////////////////////////////////////////////////////
    // delete():
    //   If a node with the given key exists, remove it from list.
    //
    public void remove(Object searchKey)
    {
        // update holds pointers to left neighbor elements of each level
        SkipListElement update[] = new SkipListElement[myMaxLevel+1];

        // init "cursor"-element to header:
        SkipListElement cursor = myHeader;

        // find element in list:
        for (int i=myLevel; i>=0; i--)
        {
            SkipListElement nextElement = cursor.forward[i];
            while ((nextElement.key != NIL_KEY) && compare(nextElement.key , searchKey) < 0)
//            while (nextElement.key < searchKey)
            {
                cursor = nextElement;
                nextElement = cursor.forward[i];
            }
            update[i] = cursor;
        }
        cursor = cursor.forward[0];

        // element found, so rebuild list without node:
        if (compare(cursor.key ,searchKey) == 0)
//        if (cursor.key == searchKey)
        {
            for (int i=0; i<=myLevel; i++)
            {
                if (update[i].forward[i] == cursor)
                {
                    update[i].forward[i] = cursor.forward[i];
                }
            }
            // element can be freed now (would happen automatically):
            // element = null;               // garbage collector does the rest...

            // maybe we have to downcorrect the level of the list:
            while (myLevel>0  &&  myHeader.forward[myLevel].key==NIL_KEY)
            {
                myLevel--;
            }
        }
    }


    ///////////////////////////////////////////////////////////////////////////
    // isEmpty():
    //   Returns true if list contains no elements, else false is returned.
    //
    public boolean isEmpty()
    {
        return myHeader.forward[0].key == NIL_KEY;
    }


    ///////////////////////////////////////////////////////////////////////////
    // toString() overwrites java.lang.Object.toString()
    //   Composes a multiline-string describing this list:
    //
    public String toString()
    {
        // inits:
        String result = "";

        // header info:
        result += "SkipListMap Statistics:\n";
        result += "  probability = " + myProbability + "\n";
        result += "  level       = " + myLevel + "\n";
        result += "  max. level  = " + myMaxLevel + "\n";

        // traverse the list and count the levels:
        SkipListElement cursor = myHeader.forward[0];
        int[] countLevel = new int[myMaxLevel+1];
        while (cursor.key != NIL_KEY)
        {
            countLevel[cursor.getLevel()]++;
            cursor = cursor.forward[0];
        }

        for (int i=myMaxLevel; i>=0; i--)
        {
            result += "    Number of Elements at level " + i + " = " + countLevel[i] +"\n";
        }
        return result;
    }
    /**
     */
    public int size()
    {
        SkipListElement cursor = myHeader.forward[0];
        int[] countLevel = new int[myMaxLevel+1];
        while (cursor.key != NIL_KEY)
        {
            countLevel[cursor.getLevel()]++;
            cursor = cursor.forward[0];
        }
        int result = 0;
        for (int i=myMaxLevel; i>=0; i--)
        {
            result += countLevel[i];
        }
        return result;
    }
    /**
     */
    public Enumeration keys()
    {
        return elements(true);
    }
    /**
     */
    public Enumeration elements()
    {
        return elements(false);
    }
    /**
     */
    protected Enumeration elements(final boolean keys)
    {
        return new Enumeration()
        {
            int elementNr = 0;
            SkipListElement cursor;
            //Object Initializer
            {
                cursor = getHeader();
                cursor = cursor.forward[0];//Skip the header element
            }
            //
            public boolean hasMoreElements()
            {
                return cursor.key != NIL_KEY;
            }
            //
            public Object nextElement()
            {
                Object result;
                if(keys)
//                    result = new Integer(cursor.key);
                    result = cursor.key;
                else
                    result = cursor.value;
                cursor = cursor.forward[0];
                elementNr++;
                return result;
            }
        };
    }
    //
    // listInfo() displays information on the current list, including
    // all the current nodes in the list
    //
    public void listInfo()
    {
        String results = this.toString();
        System.out.println(results);

        // traverse SkipListMap at level=0 and print each element:
        int elementNr = 0;
        SkipListElement cursor = getHeader();

        while (cursor.key != NIL_KEY)
        {
            System.out.println("Element: " + elementNr + " key: " + cursor.key + " value: " + cursor.value);

            // move one node forward:
            cursor = cursor.forward[0];
            elementNr++;
        }
    }

    ///////////////////////////////////////////////////////////////////////////
    // Access to members:
    //

    // returns the current level of the list:
    public int getLevel() { return myLevel; }

    // returns the maximum level, which can be reached:
    public int getMaxLevel() { return myMaxLevel; }

    // returns the probability:
    public float getProbability() { return myProbability; }

    // returns the header element:
    public SkipListElement getHeader() { return myHeader; }


    ///////////////////////////////////////////////////////////////////////////
    // private data members:
    //
    private float myProbability;            // probability to increase level
    private int myMaxLevel;                 // upper bound of levels
    private int myLevel;                    // greatest level so far
    private SkipListElement myHeader;       // the header element of list

    /**
     * JUnit tests cases.
     */
    public static class Test extends com.objectwave.test.UnitTestBaseImpl
    {
        public void testGetOnEmpty()
        {
            SkipListMap map = new SkipListMap(2);
            Object res = map.get("one");
            testContext.assertTrue("Object should have been null", res == null);
            res = map.get(new Integer(-1));
            testContext.assertTrue("Object should have been null", res == null);
            map.put(new Integer(-1), "neg - one");
            res = map.get(new Integer(-1));
            testContext.assertEquals("neg - one", res.toString());
        }
        public void testIsEmpty()
        {
            SkipListMap map = new SkipListMap(2);
            testContext.assertTrue("Indicated not empty when it was empty", map.isEmpty());
            map.put("one", "two");
            testContext.assertTrue("Indicated empty when it was not empty", ! map.isEmpty());
        }
        public void testKeys()
        {
            SkipListMap map = new SkipListMap(2);
            map.put("one", "two");
            Enumeration e = map.keys();
            while(e.hasMoreElements())
            {
                testContext.assertEquals("one",e.nextElement());
            }
        }
        public void testCount()
        {
            SkipListMap map = new SkipListMap(2);
            map.put("one", "two");
            map.put("one", "three");
            map.put("oneTwo", "two");
            testContext.assertEquals("three", map.get("one"));
            Enumeration e = map.elements();
            int count = 0;
            while(e.hasMoreElements())
            {
                e.nextElement();
                count++;
            }
            testContext.assertEquals(2, count);
            testContext.assertEquals(2, map.size());
        }
        public void testPut()
        {
            SkipListMap map = new SkipListMap(2);
            map.put("one", "two");
            testContext.assertEquals("two", map.get("one"));
        }
        public static void main(String [] args)
        {
            com.objectwave.test.TestRunner.run(new Test(), args);
        }
    }
}
