package com.objectwave.utility;

import java.util.Vector;

/**
 * @version 1.5
 */
public class Sorter
{
	//Sort Tester
	public static void main(String [] argv)
	{
		int [] intArray = new int[6];
		intArray[0] = 3;
		intArray[1] = 0;
		intArray[2] = 1;
		intArray[3] = 0;
		intArray [4] = 3;
		intArray[5] = 4;
		for(int i = 0; i < intArray.length; i++)
			System.out.print(" " + intArray[i]);
		System.out.println("");
		System.out.println("Sorted to");
		Sorter.quickSort(intArray);
		for(int i = 0; i < intArray.length; i++)
			System.out.print(" " + intArray[i]);
		System.out.println("");
		String [] strArray = new String[7];
		strArray[0] = "Good";
		strArray[1] = "Bad";
		strArray[2] = "Ugly";
		strArray[3] = "Goo";
		strArray[4] = "Mean";
		strArray[5] = "Good";
		strArray[6] = "Goode";
		Sorter.quickSort(strArray);
		for(int i = 0; i < strArray.length; i++)
			System.out.print(" " + strArray[i]);
		System.out.println("");
	String [] testData = {
			"Sales Stephen",
			"Salley Tommy",
			"Sanders Derron",
			"Santo David",
			"Sauber Greg",
			"Sawyer John",
			"Scandle Brian",
			"Scanlan Liam",
			"Scarafile Paul",
			"Schaaf John",
			"Schaefer Daniel",
			"Scharine Jim",
			"Scherb Darryl",
			"Shuda Steve",
			"Siddal Steve",
			"Simerl Jeff",
			"Simpson James",
			"Skosky Bill",
			"Slater Sandy",
			"Smith Douglas",
			"Smith Frank",
			"Smith Jim",
			"Smith Randy",
			"Smoke John",
			"Snelling Kaylene",
			"Solesbee Karen",
			"Sommer Susan",
			"St. Gelais Tom",
			"Stacey Jack",
			"Stainfield Tami",
			"Stapleton Rachel",
			"Steffes John",
			"Stevens Rich",
			"Stokes Bill",
			"Stonebraker Bill",
			"Strang Mike",
			"Sturgill John",
			"Sullivan Mary",
			"Swan Jim",
			"Schachtman Steve",
			"Smith Jack",
			"Silha Dale",
			"Schaaf John",
			"Sherrod David",
			"Shelton Kevin",
			"Smith William",
			"Stentz Jenny",
			"Stiff Stanley",
			"Stiff Steven",
			"Stiff Stanley",
			"Smith Kim",
			"Schuster Rick" };

	String [] testData2 = {
			"Dave's Third Company",
			"Dave's Test Company",
			"ATestCompany",
			"Dave's 4th Co",
			"Franklee Funny Funds",
			"Ear Eye and Nose Investments Inc.",
			"Another New Company",
			"Yet another Company",
			"Blah Blah Blah Company",
			"Daves Company",
			"Last New Company"
	};

		Vector objs = new Vector();
		Vector objs2 = new Vector();
		for(int i = 0; i < testData2.length; i++) {
			objs.addElement(testData2[i]);
			objs2.addElement(new Integer(i));
		}
		Sorter.quickSort(testData2);
		for(int i = 0; i < testData2.length; i++) {
			System.out.println(testData2[i]);
		}
//        Sorter.quickSort(objs);

	}
	/**
	*/
	private static synchronized int partition(int [] intArray, int p, int r, final Object [] alsoSort)
	{
		int x = intArray[p];
		int j, i, compareIdx;
		compareIdx = p;
		while (true){
			for( j = r; intArray[j] > x; j--);
			for( ; ((intArray[j] == x) && (j != compareIdx)); j--);
			for( i = p; intArray[i] < x; i++);
			if( i < j){
				if(intArray[i] == intArray[j]) return j - 1;
				x = intArray[i];
				compareIdx = j;
				intArray[i] = intArray [j];
				intArray[j] = x;
				if(alsoSort != null){
					final Object xObj = alsoSort[i];
					alsoSort[i] = alsoSort[j];
					alsoSort[j] = xObj;
				}
			} else
				return j;
		}
	}
	/**
	*/
	private static synchronized int partition(final Object[] objArray, int p, int r, final Object [] alsoSort, SorterComparisonIF comparison)
	{
		Object x = objArray[p];
		int j, i, compareIdx;
		compareIdx = p;

		while (true){
			for( j = r; comparison.compare(objArray[j],x) > 0; j--);
			for( ; (comparison.compare(objArray[j],x) == 0 && j != compareIdx); j--);
			for( i = p; comparison.compare(objArray[i],x) < 0 ; i++);
			if( i < j){
				if(comparison.compare(objArray[i], objArray[j]) == 0) 
				{
					return j -1;
				}
				x = objArray[i];
				compareIdx = j;

				objArray[i] = objArray [j];
				objArray[j] = x;
				if(alsoSort != null){
					final Object xObj = alsoSort[i];
					alsoSort[i] = alsoSort[j];
					alsoSort[j] = xObj;
				}
			} else
				return j;
		}
	}
	/**
	*/
	private static synchronized int partition(final String [] strArray, int p, int r, final Object [] alsoSort)
	{
		String x = strArray[p];
		int j, i, compareIdx;
		compareIdx = p;

		while (true){
			for( j = r; strArray[j].compareTo(x) > 0; j--);
			for( ; ((strArray[j].compareTo(x) == 0) && (j != compareIdx)); j--);
			for( i = p; strArray[i].compareTo(x) < 0 ; i++);
			if( i < j){
				if(strArray[i].compareTo(strArray[j]) == 0) {
					return j -1;
				}
				x = strArray[i];
				compareIdx = j;

				strArray[i] = strArray [j];
				strArray[j] = x;
				if(alsoSort != null){
					final Object xObj = alsoSort[i];
					alsoSort[i] = alsoSort[j];
					alsoSort[j] = xObj;
				}
			} else
				return j;
		}
	}
	public static synchronized void quickSort(int [] intArray)
	{
		quickSort(intArray, null);
	}
	/**
	*/
	public static synchronized void quickSort(int [] intArray, final Object [] alsoSort)
	{
		quickSortEngine(intArray, 0, intArray.length - 1, alsoSort);
	}
	/**
	*/
	public static synchronized void quickSort(Object[] array, final Object [] alsoSort, SorterComparisonIF comparison)
	{
		quickSortEngine(array, 0, array.length - 1, alsoSort, comparison);
	}
	/**
	*/
	public static synchronized void quickSort(Object[] array, SorterComparisonIF comparison)
	{
		quickSort(array, null, comparison);
	}
	/**
	*/
	public static synchronized void quickSort(final String [] str)
	{
		quickSort(str, (Object[])null);
	}
	/**
	*/
	public static synchronized void quickSort(final String [] str, final Object [] alsoSort)
	{
		// Maybe copy the original string so this method does no mutations.
		/*
		System.out.println(str.length);
		for(int i = 0; i < str.length; i++) {
			if(str[i] == null) str [i] = "";
			System.out.println("\"" + str[i] + "\",");
			if(alsoSort != null)
			{
//    			System.out.println(alsoSort[i]);
			}
		}
		*/
		quickSortEngine(str, 0, str.length - 1, alsoSort);
	}
	/** Returns a new vector. Original is NOT modified.
	*/
	public static synchronized Vector quickSort(Vector objects)
	{
		return quickSort((Vector)objects.clone(), null);
	}
	/**
	 * Both parameters are modified
	 */
	public static synchronized Vector quickSort(Vector objects, Vector alsoSort)
	{
		final int size = objects.size();
		String [] res = new String [size ];
		Object [] original, alsoOriginal = null;

		original = new Object [ objects.size() ];
		objects.copyInto(original);

		for(int i = 0; i < size; i++)
			res[i] = objects.elementAt(i).toString();

	    if(alsoSort != null)
	    {
			String [ ] backup = new String [ res.length ];
			System.arraycopy(res, 0, backup, 0, res.length);
	        alsoOriginal = new Object [ objects.size() ];
			alsoSort.copyInto(alsoOriginal);
			quickSort(backup, alsoOriginal);
	    }

	    quickSort(res, original);

	    for(int i = 0; i < size; i++)
	    {
		    Object obj = original[i];
		    objects.setElementAt(obj, i);
		    if(alsoSort != null)
		    {
		    	obj = alsoOriginal[i];
		    	alsoSort.setElementAt(obj, i);
		    }
		}

		return objects;
	}
	/**
	*/
	private static synchronized void quickSortEngine(final int [] intArray, int p, int r, final Object [] alsoSort)
	{
		// Variables p and r match algorithm book.
		int q = 0;
		if(p < r){
			q = partition(intArray, p, r, alsoSort);
			quickSortEngine(intArray, p, q, alsoSort);
			quickSortEngine(intArray, q + 1, r, alsoSort);
		}
	}
	/**
	*/
	private static synchronized void quickSortEngine( final Object[] objArray, int p, int r, final Object [] alsoSort, SorterComparisonIF comparison)
	{
		// Variables p and r match algorithm book.
		int q = 0;
		if(p < r){
			q = partition(objArray, p, r, alsoSort, comparison);
			quickSortEngine(objArray, p, q, alsoSort, comparison);
			quickSortEngine(objArray, q + 1, r, alsoSort, comparison);
		}
	}
	/**
	*/
	private static synchronized void quickSortEngine( final String [] strArray, int p, int r, final Object [] alsoSort)
	{
		// Variables p and r match algorithm book.
		int q = 0;
		if(p < r){
			q = partition(strArray, p, r, alsoSort);
			quickSortEngine(strArray, p, q, alsoSort);
			quickSortEngine(strArray, q + 1, r, alsoSort);
		}
	}
}