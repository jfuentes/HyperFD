package com.objectwave.utility;

/**
 * Inteface used by the Sorter class to assist allow the user to provide
 * a custom comparison method.
 */
public interface SorterComparisonIF
{
	public static final int LESS_THAN = -1;
	public static final int EQUAL_TO  = 0;
	public static final int GREATER_THAN = 1;

	/**
	 * Compare two objects.  The return value should be one of
	 * LESS_THAN, EQUAL_TO, or GREATER_THAN.  These should correspond to 
	 * some meaningful "a < b", "a == b", and "a > b", respectively.
	 */
	public int compare(Object a, Object b);
}