package com.objectwave.utility;

import java.util.*;
import java.text.*;
/**
 * StringManipulator contains functions that assist with String manipulation.
 * As the language evolves many of these functions will likely become obsolete.
 * An actual supported JDK version of any of these functions should be used instead
 * of using this class.
 *
 * @version 2.2
 */
public class StringManipulator
{
	private static String commonStrings[] =  
		{ "num",      "number",   "at",      "and",      "dollar",   
		  "dollars",  "money",    "amount",  "from",     "of",
		  "for",      "the",      "since",   "chapter",  "percent",
		  "negative", "positive", "equal",   "equals",   "average",
		  "fee",      "fees",     "with",    "estimate", "estimated" };
	private static String commonReplacements[] = 
		{ "#",        "#",        "@",       "&",        "$",
		  "$",        "$",        "$",       "fr",       "",
		  "",         "",         "",        "ch",       "%", 
		  "-",        "+",        "=",       "=",        "avg",
		  "$",        "$",        "w/",      "est.",     "est." };
	/**
	 * Using an inner class for a test case accomplishes at least two things.
	 * Deployment can occur with out code bloat of test cases. (Just don't ship the .class files)
	 * Namespace remains clean. Since the true class name is StringManipulator$Test
	 * It has to be a public class, since the JUnit tests use reflection on the class.
	 */
	public static class Test extends com.objectwave.test.UnitTestBaseImpl
	{
		public static void main(String [ ]args)
		{
			com.objectwave.test.TestRunner.run(new Test(), args);
		}
	    Vector v = null;
	    String stateString;
	    /**
	    */
	    public void testEncryption() //com.objectwave.test.TestImpl context)
	    {
		    String originalString = "this is a PRIVATE string";
		    String password = "password";
		    String encrypted = StringManipulator.xorCrypto(originalString, password);
		    testContext.assertEquals(originalString, StringManipulator.xorCrypto(encrypted, password));
			
		    String passwordTwo = "zippity";
		    encrypted = StringManipulator.xorCrypto("this is a PRIVATE string", passwordTwo);
		    //These two should NOT be equal
		    testContext.assertTrue(StringManipulator.xorCrypto(encrypted, password).equals(originalString) == false );
	    }
	    public void testExtractStrings() //com.objectwave.test.TestImpl context)
	    {
		    String list = "one,two,\"th','ree\",\"four,five\"";
		    Vector v = com.objectwave.utility.StringManipulator.extractStringsDelimiter(list, ",");
		    testContext.assertEquals(6, v.size());
		    v = com.objectwave.utility.StringManipulator.extractStringsDelimiter(list, ',');
		    testContext.assertEquals(4, v.size());
	    }
	    /**
	    */
	    public void testExtractStringsToString() //com.objectwave.test.TestImpl context)
	    {
		    String list = "one,two,\"th','ree\",\"four,five\"";
		    this.v = stringToVector(list);
		    String result = StringManipulator.vectorToString(v);
		    testContext.assertEquals(list, result);
	    }
	    /**
	    */
	    public void testPatternMatching() //com.objectwave.test.TestImpl context)
	    {
		    String patterns[] =  {"hi mom", "ji_mom", "hi_mom", "hi_moj", "h%mom", "hi%mum", "h%", "h%m_m", "hi mom!", "Hi Mom", "hi mom%", "hi mom_" };
		    boolean expected[] = {true,     false,    true,     false,    true,    false,    true, true,    false,     false,    true,      false     };
		    for (int i = 0; i < patterns.length; ++i)
		    {
			    testContext.assertTrue("Failed at index: " + i + " '" + patterns[i] + '\'',
				       StringManipulator.matchesPattern("hi mom", patterns[i]) == expected[i]);
		    }
	    }
	    /**
	    */
	    public void testPatternMatching2() //com.objectwave.test.TestImpl context)
	    {
	
			String  pats[]  = { "matchThis", "*", "mat*", "*Thi", "match*",
								"*ch*", "match***s", "*ma*tch*is*", "ma?ch*" };
			String  strs[]  = { "matchThis", "", "cow", "matchThi", "matchThiss", "somematches" };
			boolean res[][] = {
								{true,  false, false, false, false, false}, // pats[0], strs[0..n]
								{true,  true,  true,  true,  true,  true},  // pats[1], strs[0..n]
								{true,  false, false, true,  true,  false}, // pats[2], strs[0..n]
								{false, false, false, true,  false, false}, // ...
								{true,  false, false, true,  true,  false},
								{true,  false, false, true,  true,  true},
								{true,  false, false, false, true,  false},
								{true,  false, false, false, true,  false},
								{true,  false, false, true,  true,  false},
							  };
	
			int failures = 0;
			int tests = 0;
	
			for (int i=0; i < pats.length; ++i)
			{
				for (int j=0; j < strs.length; ++j)
				{
					if (matchesPattern(strs[j], pats[i], '*', '?') != res[i][j])
					{
						System.out.println("Failed test: pat \"" + pats[i] +
										   "\", str \"" + strs[j] +
										   "\" should have " +
										   (res[i][j] ? "pass" : "fail") + "ed.");
						++failures;
					}
					++tests;
				}
			}
//			System.out.println("Finished " + tests + " case(s): " + failures + " failure(s).");
			testContext.assertTrue("Failed " + failures + " pattern-match test(s)",
			       failures==0);	    
		}
	    /**
	     */
	    public void testReduceStrings() //com.objectwave.test.TestImpl context)
	    {
		    String strs[] = {   "total investment revenue",
							    "number of children",
							    "name of spouse",
							    "ttl. income",
							    "credit rating",
							    "average income estimates",
							    "total amount in bank",
							    "number at chapter 7"};
		    int lengths[] = { 10, 8, 6, 7, 8, 4, 9, 6 }; 
			 
		    for (int i=0; i < strs.length; ++i)
		    {
			    int len = i<lengths.length ? lengths[i] : 10;
			    testContext.assertTrue("String " + strs[i] + " failed to reduce to " + len, reduceString(strs[i], len).length() <= len);
		    }
	    }
	    /**
	     */
	    public void testVectorToStrings()//com.objectwave.test.TestImpl context)
	    {
		    Enumeration e = null;
		    String strings[] = { "This", "That", "one,two,three",
							    ",comma first", "comma last," };
		    Vector v = new Vector();
		    for (int i=0; i < strings.length; ++i)
			    v.addElement(strings[i]);

		    String s = StringManipulator.vectorToString(v);
		    Vector v2 = StringManipulator.stringToVector(s);
		    testContext.assertTrue(strings.length == v2.size());
	    }
	}
	/**
	 * Decode from printable ASCII: all characters < 32 and > 127 were encoded
	 * using '#' as the escape character. '#' was encoded to '##'. The given
	 * char c was encoded to two hex digits preceeded by a '#'.
	 * 
	 * @param str The string being operated upon.
	 */
	public static String convertFromASCII(String str)
	{
		StringBuffer buf = new StringBuffer(str.length());
		for (int i=0; i < str.length(); ++i)
		{
			char c = str.charAt(i);
			if (c == '#')
			{
				if (str.charAt(i+1) == '#') 
				{
					++i;
					buf.append('#');
					continue;
				}
				String hex = "0x" + str.substring(i+1, i+3);
				i += 2;
				try
				{
					int ii = Integer.decode(hex).intValue();
					buf.append((char)ii);
				}
				catch (NumberFormatException e)
				{
				}
			}
			else
				buf.append(c);
		}
		return buf.toString();
	}
	/**
	 * Encode to printable ASCII: all characters < 32 and > 127 are encoded
	 * using '#' as the escape character. '#' is encoded to '##'. The given
	 * char c is encoded to two hex digits preceeded by a '#'.  We assume
	 * that the original char is < 256.  Perhaps later the full range of
	 * char will be supported.
	 * 
	 * @param str The string being operated upon.
	 */
	public static String convertToASCII(String str)
	{
		return convertToASCII(str, "");
	}
	/**
	 * @param str The string being operated upon.
	 * @param alsoEscape
	 */
	public static String convertToASCII(String str, String alsoEscape)
	{
		StringBuffer buf = new StringBuffer(str.length());
		for (int i=0; i < str.length(); ++i)
		{
			char c = str.charAt(i);
			if (c < 32 || c > 127 || alsoEscape.indexOf(c) > -1)
			{ 
				buf.append('#');
				String asHex = Integer.toHexString(c);
				buf.append((asHex.length()==1 ? "0":"") + asHex);
			}
			else if (c == '#')
				buf.append("##");
			else
				buf.append(c);
		}
		return buf.toString();
	}
	/**
	 * Return the string as a double. No exceptions allowed.  If a
	 * NumberFormatException was to occur, return 0.
	 * 
	 * @param aString The string being operated upon.
	 */
	public static double doubleValue(String aString)
	{
		double res = 0;
		String str = toNumber(aString);
		if(str.equals("")) return res;
		try{
		   Double d = Double.valueOf(str);
		   return d.doubleValue();
		} catch (Exception e){}
		return res;
	}
	/**
	 * Break a string out into a vector, using the parameter 'ch' as a delimeter.
	 * This method is operates differently than the method that takes a string as 
	 * the delimeter. Quotes (") and ticks (') are considered. If a delimiter is within
	 * a String or a Character literal, that delimeter is ignored.
	 * 
	 * @param source The string being operated upon.
	 * @param ch The character to use as a delimeter
	 * @return Vector of the elements.
	 */
	public static Vector extractStringsDelimiter( String source, int ch )
	{
	    Vector result = new Vector();
		if(source == null) { return result; }
		int tmpIndex, currentIndex = 0;
		String newString;

        if(ch != '"' && ch != '\'') //We can look for special characters
        {
            int size = source.length();
            boolean inString = false;
            boolean inChar = false;
    		boolean escap  = false;
            StringBuffer current = new StringBuffer();
            for(int i = 0; i < size; ++i)
            {
                char currentCh = source.charAt(i);
                if(currentCh == ch  && !inString && !inChar)
                {
                    result.addElement(current.toString());
                    current = new StringBuffer();
                }
                else
                {
                    current.append(currentCh);
    				if(currentCh == '"' && !escap && !inChar)
						inString = !inString;
					if(currentCh == '\'' && !escap && !inString) inChar = !inChar;
					escap = (currentCh == '\\') && !escap;
                }
            } 
            result.addElement(current.toString());
        }
        else //Old way
        {
		    tmpIndex = source.indexOf(ch);
		    while(tmpIndex >= 0)
		    {
			    newString = source.substring(currentIndex, tmpIndex);
			    result.addElement(newString);
			    currentIndex = ++tmpIndex;
			    tmpIndex = source.indexOf(ch, currentIndex);
		    };
		    newString = source.substring(currentIndex,source.length());
		    result.addElement(newString);
		}
		return result;
	}

	/**
	 * @param source The string being operated upon.
	 * @param ch
	 */
	public static Vector extractStringsDelimiter( String source, String ch )
	{
	    Vector result = new Vector();
		if(source == null) { return result; }
		int tmpIndex, currentIndex = 0;
		String newString;

		tmpIndex = source.indexOf(ch);
		while(tmpIndex >= 0)
		{
			newString = source.substring(currentIndex, tmpIndex);
			result.addElement(newString);
			currentIndex = tmpIndex + ch.length();
			tmpIndex = source.indexOf(ch, currentIndex);
		};
		newString = source.substring(currentIndex,source.length());
		result.addElement(newString);
		return result;
	}
	/**
	 * Return the string as a float. No exceptions allowed.  If a
	 * NumberFormatException was to occur, return 0.
	 * 
	 * @param aString The string being operated upon.
	 */
	public static float floatValue(String aString)
	{
		float res = 0;
		String str = toNumber(aString);
		if(str.equals("")) return res;
		try{
		   Float d = Float.valueOf(str);
		   return d.floatValue();
		} catch (Exception e){}
		return res;
	}
	/**
	 * @param str The string being operated upon.
	 */
	public static Date getDateForString(String str)
	{
		if(str == null) return null;
		if(str.trim().equals("")) return null;
		DateFormat f = DateFormat.getDateInstance(DateFormat.SHORT);
		try {
			Date d = f.parse(str);
			return d;
		} catch (Exception e) { }
		return null;
	}
	/**
	 * Return the string as an integer. No exceptions allowed.  If a
	 * NumberFormatException was to occur, return 0.
	 * 
	 * @param aString The string being operated upon.
	 */
	public static int integerValue(String aString)
	{
		int res = 0;
		String str = toNumber(aString);
		if(str.equals("")) return res;
		try{
		   Integer d = Integer.valueOf(str);
		   return d.intValue();
		} catch (Exception e){}
		return res;
	}
	/**
	 * Allow the use of '*' in defining patterns.  Similar to indexOf.
	 * 
	 * @param pattern
	 * @param target The string being operated upon.
	 */
	public static boolean isPatternMatch(String pattern, String target)
	{
		return isPatternMatch(pattern, target, '*');
	}
	/**
	 * Allow the use of a wildChar in defining patterns.  Similar to indexOf.
	 * Note: matchesPattern() is a more powerful implementation of this. This
	 *       method now calls matchesPattern().
	 * 
	 * @param pattern
	 * @param target The string being operated upon.
	 * @param wildChar
	 */
	public static boolean isPatternMatch(String pattern, String target, char wildChar)
	{
		if(pattern == null) return true;
		return matchesPattern(target, pattern, wildChar, (char)0);
	}
	public static void main(String [] args)
	{
		Test.main(args);
	}
	/**
	 * Check to see if the string str matches the given pattern.  The
	 * pattern is a string conforming to SQL's LIKE pattern standard:
	 * The % character represents 0 or more characters, while _ matches
	 * exactly one character. This is a very primitive recognition
	 * scheme: there can be only one '%' in pattern, and the '%' and '_'
	 * characters cannot be escaped in the pattern.
	 * 
	 * @param str java.lang.String The string being operated upon.
	 * @param pattern java.lang.String
	 * @return true if and only if str matches the pattern.
	 */
	public static boolean matchesPattern(String str, String pattern) 
	{
	    return matchesPattern(str, pattern, '%', '_');
	}
	/**
	 * Determine if the string matches the pattern provided.
	 * 
	 * @param str java.lang.String The string being operated upon.
	 * @param pattern java.lang.String
	 * @param wildStr char, the character which matches 0 or more characters.
	 * @param wildChar char (ex, '_' or '?'), the character which will match any one character
	 * @return boolean
	 */
	public static boolean matchesPattern(String str, String pattern, char wildStr, char wildChar) 
	{
		return matchesPattern(str, pattern, 0, 0, wildStr, wildChar);
	}
	/**
	 * Determine if the string matches the pattern provided.
	 * 
	 * @param str java.lang.String The string being operated upon.
	 * @param pattern java.lang.String
	 * @param wildStr char, the character which matches 0 or more characters.
	 * @param wildChar char (ex, '_' or '?'), the character which will match any one character
	 * @param patPos
	 * @param strPos
	 * @return boolean
	 */
	private static boolean matchesPattern(String str, String pattern, int patPos, int strPos, char wildStr, char wildChar) 
	{
		if (pattern.length() == patPos)
		{
			return str.length() == strPos; // Trivial case: empty pattern string
		}

		// Process each character of pattern, moving the value of "pos" as pattern characters are matched
		// to 0..n str characters.
		//
		int pos = strPos;
		for (int i=patPos; i < pattern.length(); ++i)
		{
			char ch = pattern.charAt(i);
			if (ch == wildStr)
			{
				// If we encounter a wild string character (ex, '*'), then match the remainder of
				// "pattern" to the remainder of "str".
				//
				if (i == pattern.length()-1)
				{
					return true;	// simplest case: '*' is last char, so remainder of pattern must match
				}
				// Call this method recursively for (pos:strlen), (pos+1:strlen), ... (strlen-1:strlen)
				//
				for (int j=pos; j < str.length(); ++j)
				{
					if (matchesPattern(str, pattern, i+1, j, wildStr, wildChar))
					{
						return true;
					}
				}
				return false;
			}
			else
			{
				if (pos >= str.length())
				{
					return false;	// str wasn't long enough.
				}
				if (ch != wildChar && str.charAt(pos) != ch)
				{
					return false;	// character mismatch
				}
				++pos;
			}
		}
		return pos == str.length();
	}
	/**
	 * @param source The string being operated upon.
	 * @param pair
	 * @param start
	 */
	public static String nextValuePair( final String source, final String pair, final int start)
	{
	    return nextValuePair(source, pair, start, false);
	}
	/**
	 * @param source The string being operated upon.
	 * @param pair
	 * @param start
	 */
	public static String nextValuePair( String source, String pair, int start, boolean special)
	{
		if(source == null) { return new String(); }
		int tmpIndex, currentIndex = 0;
		currentIndex = source.indexOf(pair, start);
/*        if(special)
        {
            char firstChar = pair.charAt(0);
            int size = source.length();
            boolean inString = false;
            boolean inChar = false;
    		boolean escap  = false;
            StringBuffer current = new StringBuffer();
            for(int i = 0; i < size; ++i)
            {
    			if(currentCh == '"' && !escap && !inChar)
					inString = !inString;
				if(currentCh == '\'' && !escap && !inString) inChar = !inChar;
				escap = (currentCh == '\\') && !escap;
				if(currentIndex == i)
				{
				    if(firstChar == '"' || firstChar == '\'')
				        if(escap
				}
				
            } 

        }
        else
        {
*/
		    tmpIndex = source.indexOf(pair, currentIndex + 1);
		    if(tmpIndex >= 0)
			    return source.substring(currentIndex + 1 , tmpIndex);
//		}
		return new String();
	}
	/**
	 * Return the source as 1 line of code.
	 * 
	 * @param source The string being operated upon.
	 */
	public static String oneLine( String source)
	{
		String st = "" + source;
		st = st.replace('\r',' ');
		st = st.replace('\n',' ');
		return st;
	}
	/**
	*/
	public static String [] parsePhoneNumber(String phoneNumber)
	{
		String [] result = { phoneNumber };
		phoneNumber = phoneNumber.trim();
		if(phoneNumber.startsWith("0")) return result;
		StringBuffer buf = new StringBuffer();
		int count = 0;
		String area = null;
		String number = null;
		String extension = null;
		for(int i = 0; i < phoneNumber.length(); i++) {
			char c = phoneNumber.charAt(i);
			if(Character.isLetterOrDigit(c) || count > 3)
				buf.append(c);
			if(Character.isLetterOrDigit(c)) {
				if(++count == 3){ 
					area = buf.toString().trim();
					buf = new StringBuffer();
				}
				else
				if(count == 10) {
					number = buf.toString().trim();
					buf = new StringBuffer();
				}
			}
		}
		if(count < 3) return result;
		result = new String [3];
		result[0] = area;
		if(count < 10){
			result[1] = buf.toString().trim();
			return result;
		}
		if(count > 10)
			extension = buf.toString().trim();
		result[1] = number;
		result[2] = extension;

		return result;
	}
	/**
	 * Try to reduce the given string intelligently to fit the given
	 *  number of characters.
	 * 
	 * @param str The string being operated upon.
	 * @param maxNum
	 */
	public static String reduceString(String str, int maxNum)
	{
		if (str.length() <= maxNum) 
			return str;
		if (maxNum < 1)
			return "";

		// Replace common strings with common abbreviations.
		//
		Vector words = stringToVector(str, '\\', ' ', true); 
		int correction = 0;
		for (int i=0; i < words.size(); ++i)
		{
			str = (String)words.elementAt(i-correction);
			int j=0;
			for (; j < commonStrings.length; ++j)
				if (commonStrings[j].equalsIgnoreCase(str))
				{
					if (commonReplacements[j].length() == 0)
						words.removeElementAt(i - correction++);
					else
						words.setElementAt(commonReplacements[j], i-correction);
					break;
				}
		}
		String ret = vectorToString(words, '\\', ' ');
		if (ret.length() <= maxNum)
			return ret;
			
		// Remove spacing, capitalizing the first letter of each word.
		//
		ret = "";
		for (int i=0; i < words.size(); ++i)
		{
			String word = (String)words.elementAt(i);
			word = "" + Character.toUpperCase(word.charAt(0)) + word.substring(1);
			words.setElementAt(word, i);
			ret += word;
		}
		if (ret.length() <= maxNum)
			return ret;
			
		// Remove lowercase vowels that aren't the first letter of a word
		//
		ret = "";
		int reduceBy = ret.length() - maxNum;
		int reducedBy = 0;
		for (int i=0; i < words.size(); ++i)
		{
			StringBuffer buf = new StringBuffer();
			String word = (String)words.elementAt(i);
			buf.append(word.charAt(0));
			for (int j=1; j < word.length(); ++j)
			{
				if ((false&&reducedBy >= reduceBy) || "aeiou".indexOf(word.charAt(j)) < 0)
					buf.append(word.charAt(j));
				else
					++reducedBy;
			}
			words.setElementAt(buf.toString(), i);
			ret += buf.toString();
		}
		if (ret.length() <= maxNum)
			return ret;

		// Truncate string on a per-word basis down to a min of 3 chars-per-word
		//
		reduceBy = ret.length() - maxNum;
		int len = ret.length();
		ret = "";
reduceWords:
		for (int ii=0; ii < reduceBy/words.size(); ++ii)
		{
			int prev = reduceBy;
			for (int i=0; i < words.size(); ++i)
			{
				String word = (String)words.elementAt(i);
				if (word.length() <= 2)
					continue;
				words.setElementAt(word.substring(0, word.length()-1), i);
				if (--reduceBy == 0)
					break reduceWords;
			}
			if (prev == reduceBy)
				break; // nothing changed and nothing will.
		}
		for (int i=0; i < words.size(); ++i)
			ret += words.elementAt(i);
		if (ret.length() <= maxNum)
			return ret;
			
		return ret.substring(0, maxNum);
	}
	/**
	 * With the 'source' string, replace all occurances of 'from' with 'to'.
	 * 
	 * @param source The string being operated upon.
	 * @param from
	 * @param to
	 */
	public static String replaceAllWith(String source, String from, String to)
	{
		StringBuffer result = new StringBuffer(source);
		int idx = source.indexOf(from);
		int lastPos = 0;
		if(idx > -1) result = new StringBuffer();
		while(idx > -1){
			result.append(source.substring(lastPos, idx));
			result.append(to);
			lastPos = idx + from.length();
			idx = source.indexOf(from, lastPos);
			if(idx < 0) result.append(source.substring(lastPos, source.length()));
		}
		return result.toString();
	}
	/**
	 * With the 'source' string, replace the first occurance of 'from' with 'to'.
	 * 
	 * @param source The string being operated upon.
	 * @param from
	 * @param to
	 */
	public static String replaceStringWith(String source, String from, String to)
	{
		String result = source;
		int idx = source.indexOf(from);
		if(idx > -1){
			result = source.substring(0, idx);
			result += to;
			result = result + source.substring(idx + from.length(), source.length());
		}
		return result;
	}
	/**
	 */
	public static Vector stringToVector(String s)
	{
		return stringToVector(s, '\\', ',');
	}
	/**
	 * Convert a delimited string to a vector of strings.
	 */
	public static Vector stringToVector(String s, char escape, char delimiter)
	{
		return stringToVector(s, escape, delimiter, false);
	}
	/**
	 * Convert a delimited string to a vector of strings.
	 */
	public static Vector stringToVector(String s, char escape, char delimiter, boolean ignoreEmptyElements)
	{
		Vector result = new Vector();
		StringBuffer item = new StringBuffer();
		for (int i=0; i < s.length(); ++i)
		{
			char c = s.charAt(i);
			if (c == escape)
			{
				if (++i == s.length())
					return null;
				item.append(s.charAt(i));
				continue;
			}
			if (c == delimiter)
			{
				if (!ignoreEmptyElements || item.length() != 0)
					result.addElement(item.toString());
				item = new StringBuffer();
			}
			else
				item.append(c);
		}
		if (!ignoreEmptyElements || item.length() != 0)
			result.addElement(item.toString());
		return result;
	}
	/**
	 * This will pull out the first number found in the string
	 * parameter.
	 * 
	 * @param aString The string being operated upon.
	 */
	public static String toNumber(String aString)
	{
		if(aString == null) return "";
		char [] string = aString.toCharArray();
		StringBuffer buf = new StringBuffer(aString.length());
		boolean startingNumber = false;
		int count = 0;
	  done:
		for(int i = 0; i < buf.capacity() ; i++)
			{
				char c = string[i];
				if(Character.isDigit(c)){
					startingNumber = true;
					buf.insert(count++, c);
				} else {
					if(startingNumber && (c == '.'))
						  buf.insert(count++, c);
					else
					if(startingNumber && (c != ','))
						break done;
				}
			}
		buf.setLength(count);
		return new String(buf);
	}
	/**
	 * The method name says it all.
	 * 
	 * @param source The string being operated upon.
	 */
	public static String trimLeadingBlanks ( String source)
	{
		char []old = source.toCharArray();
		int sz = old.length;
		int newLength = 0;
		boolean all = false;
		StringBuffer newName = new StringBuffer(sz);
		for(int i = 0; i < sz; i++)
			if(! Character.isSpaceChar(old[i]) || all )
			{
			    all = true;
			    newName.append(old[i]);
			    newLength++;
			}
		newName.setLength(newLength);
		return new String(newName);
	}
	/**
	 */
	public static String vectorToString(Vector v)
	{
		return vectorToString(v, '\\', ',');
	}
	/**
	 * Convert a vector to a delimited string (using vector elements' toString()).
	 */
	public static String vectorToString(Vector v, char escape, char delimiter)
	{
		StringBuffer buf = new StringBuffer();
		if (v == null) return null;
		for (Enumeration e = v.elements(); e.hasMoreElements(); )
		{
			String s = e.nextElement().toString();
			StringBuffer escBuf = new StringBuffer();
			escBuf.ensureCapacity(s.length() + 3);
			for (int j=0; j < s.length(); ++j)
			{
				char c = s.charAt(j);
				if (c == escape || c == delimiter)
					escBuf.append(escape);
				escBuf.append(c);
			}
			if (buf.length() > 0)
				buf.append(delimiter);
			buf.append(escBuf.toString());
		}
		return buf.toString();
	}
	/**
	 *
	 *    This is a rude & crude implementation of the simplest cryptographic
	 *  algorithm known to man.  This encryption is sufficient to protect 
	 *  data from a casual observer or someone with no cryptography skills
	 *  or tools whatsoever, but can be cracked by anyone who really wants
	 *  to.
	 * 
	 * @author Steven Sinclair
	 * @return java.lang.String The encrypted/decrypted text.
	 * @param source java.lang.String The string to encrypt/decrypt
	 * @param password java.lang.String The password to use.
	 */
	public static String xorCrypto(String source, String password) 
	{
	    StringBuffer buf = new StringBuffer(source.length());
	    for (int i=0; i < source.length(); ++i)
	    {
		    int c = source.charAt(i) ^ password.charAt(i % password.length());
		    buf.append((char)(c & 0x7f));
	    }
	    return buf.toString();
	}
	/**
	 * Replace all instances of %## (like %20) with their actual character representation.
	 * All number values MUST be two digits. %02 is valid, %2 is not.
	 * Example: "A%20test" would be "A test"
	 * @param source java.lang.String The source string
	 */
	public static String resolveToCharacters(String source)
	{
		StringBuffer buf = new StringBuffer();
		for(int i = 0; i < source.length(); ++i)
		{
			char c= source.charAt(i);
			if(c == '%')
			{
				String number = String.valueOf(source.charAt(++i)) + source.charAt(++i);
				int val = Integer.parseInt(number, 16);
				//System.out.println("VAL '" + val + "' for number " + number);
				c = (char)val;
				//System.out.println("VAL as char " + c);
				buf.append(c);
			}
			else
			{
				buf.append(c);
			}
		} 
		return buf.toString();
	}
}
