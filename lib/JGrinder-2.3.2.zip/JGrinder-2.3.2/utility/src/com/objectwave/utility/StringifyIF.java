package com.objectwave.utility;

/**
 *  Allows the user to define a stringify method for an object that may not
 *  be the object's toString() result.  This is used in SimpleChoiceGui to
 *  allow a customized display of the data objects.
 */
public interface StringifyIF
{
	/**
	 *  Return a string to identify the given object.
	 */
	public String toString(Object obj);
}