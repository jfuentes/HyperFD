package com.objectwave.utility;

import java.util.*;
import java.text.ParseException;

/**
 *  Includes support for expanded symbols given in the values of symbols.  Prevents
 *  infinitely recursive definitions, for example ("X", "%Y%") and ("Y", "%X%")
 */
public class SymbolExpander extends SymbolReplacer
{
	/************************************************************************
	 *                     Private section
	 */

	private Stack  stack = new Stack();
	private Vector expandedValues = null;

	public SymbolExpander() { super(); }
	public SymbolExpander(char prefix, char suffix) { super(prefix, suffix); }
	public String expandedValueOf(int idx)
	{
		return (expandedValues == null || idx >= expandedValues.size())
					? null : (String)expandedValues.elementAt(idx);
	}
	public String expandedValueOf(String symbol)
	{
		if (expandedValues != null)
		{
			int i = indexOf(symbol);
			if (i >= 0 && i < expandedValues.size())
				return (String)expandedValues.elementAt(i);
		}
		return null;
	}
	public String expandString(String str) throws ParseException
	{
		String result = "";
		int curr = 0;
		while (true)
		{
			// idx = index of the prefix char
			// includedSymbolIdx = Vector index of symbol found
			//
			int idx = nextSymbolInString(str, curr);
			int includedSymbolIdx = foundSymbolIdx;

			if (idx < 0)
				break;
			result += str.substring(curr, idx); // append "in-between"
			if (inStack(includedSymbolIdx))
			{
				throw new ParseException("Symbol \"" + stringOf(includedSymbolIdx) +
										 "\" is a cyclic definition", idx);
			}
			String expandedValue = expandSymbolValue(includedSymbolIdx);
			result += useReplacementPattern(expandedValue);

			// Position curr to index the first char after suffixChar of s.
			curr = idx + stringOf(includedSymbolIdx).length() + 2;
		}
		result += str.substring(curr); // append leftovers
		if (stack.size() > 0)
			stack.pop();
		return result;
	}
	/** Assumed to have been called from expandSymbolValues() or by self (recursed).
	 */
	private String expandSymbolValue(int symbolIdx) throws ParseException
	{
		String result = expandedValueOf(symbolIdx);
		if (result != null)
		   return result; // optimization: avoid re-processing symbols.
		stack.push(new Integer(symbolIdx));
		result = expandString(valueOf(symbolIdx));
		System.out.println("Expanded value of symbol \"" + stringOf(symbolIdx) +
						   "\" is \"" + result + "\"");
		return result;
	}
	/**
	 * Run through the list of symbols
	 */
	public void expandSymbolValues() throws ParseException
	{
		expandedValues = new Vector();
		expandedValues.ensureCapacity(values.size());

		stack = new Stack(); // stack of integer indices into the "symbols"
							 // vector, to avoid infinite recursion on
							 // a cyclical symbol definition subset.
							 // Ex. A contains B, B contain C, C contains A
		String newValue = "";
		for (int i=0; i<symbols.size(); ++i)
		{
			expandedValues.addElement(new String(expandSymbolValue(i)));
		}
	}
	public Vector getExpandedValues() { return expandedValues; }
	private boolean inStack(int i)
	{
		for (Enumeration e = stack.elements(); e.hasMoreElements(); )
			if ( ((Integer)e.nextElement()).intValue() == i)
				return true;
		return false;
	}
	public static void  main(String args[])
	{
		String symbols[] = { "hello", "billy", "X", "Y", "Z" };
		String values[]  = { "world", "bob",   "x",  "y(%hello%%Z%)", "z(Y=%yY%, X=%X%)" };

		SymbolExpander se = new SymbolExpander();
		for (int i=0; i<symbols.length; ++i)
		{
			se.addSymbol(symbols[i], values[i]);
		}

		try
		{
			se.expandSymbolValues();
			System.out.println("Symbol expansion succeeded.");
			System.out.println(se.expandedValues);
		}
		catch (ParseException e)
		{
			System.out.println("Symbol expansion failed: " + e.getMessage());
		}
	}
	public String stringOf(int symbolIdx)
	{ return (String)symbols.elementAt(symbolIdx); }
	public String valueOf(int symbolIdx)
	{ return (String)values.elementAt(symbolIdx); }
}