package com.objectwave.utility;

import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.event.*;
import java.text.ParseException;

/**
 * Symbol Builder. This class is used to build 'symbols' for the SymbolExpander.
 */
public class SymbolExpanderTableModel extends javax.swing.table.AbstractTableModel
{
	private String  columnLabels[] = { "Identifier", "Value", "Expanded Value" };
	private SymbolExpander expander = null;
	private String  newValue = null;

	/**
	*/
	public SymbolExpanderTableModel()
	{
	    expander = new SymbolExpander('{', '}');
	}
	/**
	*/
	public SymbolExpanderTableModel(SymbolExpander _expander)
	{
	    expander = expander;
	}
	/**
	*/
	public SymbolExpanderTableModel(String stringifiedExpander)
	{
	    expander = new SymbolExpander();
	    expander.decodeFromString(stringifiedExpander);
	}
	/**
	*/
	public void dataChanged()
	{
	    fireTableDataChanged();
	}
	private void displayError(String error)
	{
	    displayError(error, "Error In Variables Table!");
	}
	private void displayError(String error, String title)
	{
		JOptionPane.showMessageDialog(
			null, error, "title", JOptionPane.ERROR_MESSAGE);
	}
	/**
	*/
	public void fireTableChanged (TableModelEvent evt)
	{ super.fireTableChanged (evt);	}
	/**
	*/
	public Class getColumnClass(int colIdx)
	{ return Object.class; }
	/**
	*/
	public int getColumnCount()
	{ return columnLabels.length; }
	/**
	*/
	public String getColumnName(int colIdx)
	{
		return (colIdx >= 0 && colIdx < columnLabels.length)
				? columnLabels[colIdx]
				: super.getColumnName(colIdx);
	}
	public SymbolExpander getExpander() { return expander; }
	/**
	*/
	public int getRowCount()
	{ return expander.size() + 1; }
	/**
	*/
	public Object getValueAt(int rowIdx, int colIdx)
	{
	    if (rowIdx >= 0 && rowIdx < expander.size())
	    {
	        switch (colIdx)
	        {
	            case 0: return expander.stringOf(rowIdx);
	            case 1: return expander.valueOf(rowIdx);
	            case 2:
	                String ret = expander.expandedValueOf(rowIdx);
	                if (ret == null)
	                {
	                    try
	                    { expander.expandSymbolValues(); }
	                    catch (ParseException e)
	                    { System.err.println("Parse error: " + e); }
	                    ret = expander.expandedValueOf(rowIdx);
	                }
	                return (ret == null) ? "<error>" : ret;
	            default: return null;
	        }
	    }
	    else if (rowIdx == expander.size())
	    {
	        return (colIdx==1 && newValue != null)
	                    ? newValue : "";
	    }
		return null;
	}
	/**
	*/
	public boolean isCellEditable(int rowIdx, int colIdx)
	{
	    return colIdx != 2;
	}
	/**
	*/
	public void setEditable(boolean value)
	{
	}
	/**
	*/
	public void setValueAt(Object value, int rowIdx, int colIdx)
	{
	    boolean rowAdded = false;
	    String oldValue = null;
	    if (rowIdx >= 0 && rowIdx < expander.size())
	    {
		    if (colIdx == 0)
		    {
		        try
		        {   expander.renameSymbol(rowIdx, (String)value); }
			    catch (IllegalArgumentException e)
			    {
			        displayError("Error renaming symbol: "+e.getMessage());
		  	        fireTableDataChanged(); // revert to old string
		 	        return;
			    }
		    }
		    else
		    {
		        String s = expander.stringOf(rowIdx);
		        oldValue = expander.valueOf(s);
		        if (!expander.updateSymbolValue(s, (String)value))
		        {
		            displayError("Error changing symbol value.");
			        fireTableDataChanged(); // revert to old string
			        return;
		        }
		    }
		}
		else if (rowIdx == expander.size())
		{
		    if (colIdx == 1)
		    {
		        newValue = (String)value;
		    }
		    else if (colIdx == 0)
		    {
		        newValue = (newValue==null ? "" : newValue);
		        try
		        {
		            expander.addSymbol((String)value, newValue);
		            rowAdded = true;
		            newValue = null;
		        }
			    catch (IllegalArgumentException e)
			    {
			        displayError("Error adding symbol: "+e.getMessage());
			        fireTableDataChanged(); // revert to old string
			        return;
			    }
		    }
		}
		try
		{
		    expander.expandSymbolValues();
		    if (colIdx == 1 && rowIdx == expander.size())
		        fireTableCellUpdated(rowIdx, colIdx);
		    else if (rowAdded)
		        fireTableRowsInserted(expander.size()-1, expander.size()-1);
		    else
		        fireTableDataChanged();
		}
		catch (ParseException e)
		{
		    displayError("Error expanding symbols: " + e.getMessage());
		    if (oldValue != null)
		        setValueAt(oldValue, rowIdx, colIdx);
		    fireTableDataChanged();
		}
	}
}