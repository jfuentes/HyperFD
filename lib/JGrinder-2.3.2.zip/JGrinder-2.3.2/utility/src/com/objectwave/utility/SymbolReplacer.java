package com.objectwave.utility;

import java.util.*;
import java.lang.IllegalArgumentException;

public class SymbolReplacer
{
	protected char symbolPrefixChar = '%';
	protected char symbolSuffixChar = '%';
	protected Vector symbols = new Vector();
	protected Vector values  = new Vector();
	protected int    foundSymbolIdx = -1;
	protected String replacementPattern = "(*)";

	public SymbolReplacer()
	{
	}
	public SymbolReplacer(char prefixChar, char suffixChar)
	{
		symbolPrefixChar = prefixChar;
		symbolSuffixChar = suffixChar;
	}
	public void addSymbol(String _symbol, String value)
		throws IllegalArgumentException
	{
		tryIsLegalIdentifier(_symbol);
		tryIsDuplicateSymbol(_symbol, -1);
		symbols.addElement(_symbol);
		values.addElement(value);
	}
	public void ClearSymbols()
	{
		symbols = new Vector();
		values  = new Vector();
	}
	public void decodeFromString(String s)
	{
		Vector encoding = StringManipulator.stringToVector(s, '\\', ';');
		symbolPrefixChar = ( (String)encoding.elementAt(0) ).charAt(0);
		symbolSuffixChar = ( (String)encoding.elementAt(1) ).charAt(0);
		encoding.removeElementAt(0);
		encoding.removeElementAt(0);
		symbols = new Vector();
		values  = new Vector();
		for (Enumeration e = encoding.elements(); e.hasMoreElements(); )
		{
			String i = (String)e.nextElement();
			Vector item = StringManipulator.stringToVector(i, '\\', ',');
			symbols.addElement(item.elementAt(0));
			values.addElement(item.elementAt(1));
		}
	}
	/** Encode as n sets of two, instead of 3 sets of n (for improved readability)
	 *  "symbol,value"
	 *  Final encoding example: "<;>;x,1;y,2;z,3"
	 */
	public String encodeToString()
	{
		Vector encoding = new Vector();
		encoding.addElement("" + symbolPrefixChar);
		encoding.addElement("" + symbolSuffixChar);
		for (int i=0; i<symbols.size(); ++i)
		{
			Vector item = new Vector();
			item.addElement(symbols.elementAt(i));
			item.addElement(values.elementAt(i));
			String s = StringManipulator.vectorToString(item, '\\', ',');
			encoding.addElement(s);
		}
		return StringManipulator.vectorToString(encoding, '\\', ';');
	}
	protected int findSymbolInstance(String symbol, String subject, int fromIdx)
	{
		String findMe = "" + symbolPrefixChar + symbol + symbolSuffixChar;
		return subject.indexOf(findMe, fromIdx);
	}
	public String getReplacementPattern() { return replacementPattern; }
	public Vector getSymbols()        { return symbols; }
	public Vector getValues()         { return values; }
	protected int indexOf(String symbol)
	{
		for (int i = 0; i < symbols.size(); ++i)
			if (symbol.equals((String)symbols.elementAt(i)))
				return i;
		return -1;
	}
	public static void main(String args[])
	{
		char prefix='%', suffix='%';
		int begin=0;
		if (args.length == 0)
		{
			System.out.println("Expected: [prefix<char> [suffix<char>]] sym1 val1 ... symN valN stringToProcess");
			return;
		}
		if (args[begin].startsWith("prefix") && args[begin].length() > 6)
			prefix = args[begin++].charAt(6);
		if (args[begin].startsWith("suffix") && args[begin].length() > 6)
			suffix = args[begin++].charAt(6);
		SymbolReplacer replacer = new SymbolReplacer(prefix, suffix);
		for (int i=begin; i<args.length-1; i+=2)
		{
			System.out.println("Adding symbol,value pair: \"" + args[i] + "\", \"" + args[i+1] + "\"");
			try
			{ replacer.addSymbol(args[i], args[i+1]); }
			catch (IllegalArgumentException e)
			{ System.out.println("Caught exception: " + e.getMessage()); }
		}
		System.out.println("Replace symbols in the string:\n\"" + args[args.length-1] + "\"");
		String newStr = replacer.replaceSymbolsInString(args[args.length-1]);
		System.out.println("\"" + newStr + "\"");

		String encoding = replacer.encodeToString();
		System.out.println("Encoded object: \"" +  encoding + "\"");
		SymbolReplacer r2 = new SymbolExpander();
		r2.decodeFromString(encoding);
		System.out.println("Decoded object:");
		System.out.println("\tPrefix char ..: " + r2.symbolPrefixChar);
		System.out.println("\tSuffix char ..: " + r2.symbolSuffixChar);
		System.out.println("\tSymbols ......: " + r2.symbols);
		System.out.println("\tValues .......: " + r2.values);
	}
	/**
	 */
	protected int nextSymbolInString(String source, int idx)
	{
		int i=idx;
		while (i<source.length())
		{
			i = source.indexOf(symbolPrefixChar, i);
			if (i<0 || i==source.length()-1)
				return -1;
			int end = source.indexOf(symbolSuffixChar, i+1);
			if (end<0)
				return -1;
			String curr = source.substring(i+1, end);
			int ii = curr.lastIndexOf(symbolPrefixChar);
			
			if (ii >= 0) 
			{
				// In the case of "{xx{abc}", we want "abc", not "xx{abc".
				curr = curr.substring(ii+1);
				i += ii+1;
			}
			for (int j=0; j<symbols.size(); ++j)
			{
				String symbol = (String)symbols.elementAt(j);
				if (symbol.equals(curr))
				{
					foundSymbolIdx = j;
					return i;
				}
			}
			i = end;
		}
		return -1;
	}
	public void renameSymbol(int idx, String newName)
		throws IllegalArgumentException
	{
		tryIsLegalIdentifier(newName);
		tryIsDuplicateSymbol(newName, idx);
		symbols.removeElementAt(idx);
		symbols.insertElementAt(newName, idx);
	}
	public String replaceSymbolsInString(String s)
	{
		String newStr = "";
		int i=0;
		while (i < s.length())
		{
			int next = nextSymbolInString(s, i);
			if (next < 0)
				break;
			if (next > i)
				newStr += s.substring(i, next);
			String symbol = (String)symbols.elementAt(foundSymbolIdx);
			newStr += useReplacementPattern((String)values.elementAt(foundSymbolIdx));
			i = next + symbol.length() + 2;
		}
		if (i < s.length())
			newStr += s.substring(i);
		return newStr;
	}
	/**
	 *    Set the replacement pattern, in which any occurances of the 
	 *  character '*' are replaced with the symbol value.  The resulting
	 *  string is used for symbol substitution. The default pattern is
	 *  "(*)", to enclose a mathematical substitution.
	 */
	public void setReplacementPattern(String pattern)
	{
		replacementPattern = (pattern==null) ? "" : pattern;
	}
	/** _symbols.size() had better equal _values.size()
	 */
	public void setSymbols(Vector _symbols, Vector _values)
	{
		symbols = _symbols;
		values  = _values;
	}
	public int size() { return symbols.size(); }
	protected void tryIsDuplicateSymbol(String symbol, int ignoreIdx)
		throws IllegalArgumentException
	{
		String err = "String \"" + symbol + "\" cannot be added as a symbol ";
		String throwErr = null;

		// Ensure that we're not adding a duplicate symbol.
		//
		for (int i=0; i<symbols.size(); ++i)
			if (i != ignoreIdx &&
				symbol.equals((String)symbols.elementAt(i)))
			{
				throwErr = err + "(duplicate symbol).";
				break;
			}

		if (throwErr != null)
			throw new IllegalArgumentException(throwErr);
	}
	protected void tryIsLegalIdentifier(String _symbol)
		throws IllegalArgumentException
	{
		String err = "String \"" + _symbol + "\" cannot be added as a symbol ";
		String throwErr = null;

		// Verify that symbol is all alphanumeric+'_', 1st char being non-numeric
		//
		String symbol = _symbol.toUpperCase();
		if (symbol==null || symbol.length() < 1)
			throw new IllegalArgumentException(err + "(null or empty string).");
		if (symbol.charAt(0) >= '0' && symbol.charAt(0) <= '9')
			throw new IllegalArgumentException(err + "(first char is numeric).");
		for (int i=0; i<symbol.length(); ++i)
			if (!(symbol.charAt(i) >= 'A' && symbol.charAt(i) <= 'Z') &&
				!(symbol.charAt(i) >= '0' && symbol.charAt(i) <= '9') &&
				symbol.charAt(i) != '_')
			{
				throwErr = err + "(non-alphanumberic, non-'_' char)";
				break;
			}
	}
	public boolean updateSymbolValue(String symbol, String newValue)
	{
		int i = indexOf(symbol);
		if (i >= 0)
		{
			values.removeElementAt(i);
			values.insertElementAt(newValue, i);
			return true;
		}
		return false;
	}
	protected String useReplacementPattern(String value)
	{
		String result = "";
		int i=0;
		while (i < replacementPattern.length())
		{
			int curr = replacementPattern.indexOf('*', i);
			if (curr < 0)
				break;
			result += replacementPattern.substring(i, curr);
			result += value;
			i = curr+1;
		}
		if (i < replacementPattern.length())
			result += replacementPattern.substring(i);
		return result;
	}
	public String valueOf(String symbol)
	{
		int i = indexOf(symbol);
		return i<0 ? null : (String)values.elementAt(i);
	}
}