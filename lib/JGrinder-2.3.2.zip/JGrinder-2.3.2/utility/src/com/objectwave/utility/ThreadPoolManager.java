package com.objectwave.utility;

import java.util.*;
/**
 *  A simple thread pool implementation. With only two new lines of code, you
 *  could manage all of your threads. Original Code new Thread(r).start() New
 *  code ThreadPoolManager mgr = new ThreadPoolManager(10); mgr.start(r);
 *
 * @author  David Hoag
 * @version  $Id: ThreadPoolManager.java,v 1.1.1.1 2001/02/13 20:47:02 dhoag Exp
 *      $
 */
public class ThreadPoolManager
{
	protected RunnableQueue waitingRunnables;
	int threadCount = 0;
	int threadLimit = 1;
	ThreadGroup threadGroup;
	boolean shutDown;
	/**
	 * @param  numOfThread
	 * @todo  - Current approach pre allocates all threads. Should try to only make
	 *      them upon demand.
	 */
	public ThreadPoolManager(int numOfThread)
	{
		threadGroup = new ThreadGroup("ThreadPool@" + hashCode());
		shutDown = false;

		threadLimit = numOfThread;
		waitingRunnables = new RunnableQueue();

		//This would pre make the threads.
		for(threadCount = 0; threadCount < threadLimit; threadCount++)
		{
			new ManagedThread(this, threadGroup);
		}
	}
	/**
	 *  Get the threadGroup that contains all of the threads in the thread pool.
	 *
	 * @return  The ThreadGroup value
	 */
	public ThreadGroup getThreadGroup()
	{
		return threadGroup;
	}
	/**
	 *  If the thread pool is being shutdown, this method will return true. Once
	 *  this method returns true, this thread pool can no longer be used.
	 *
	 * @return  The Shutdown value
	 * @see  #shutdown
	 */
	public synchronized boolean isShutdown()
	{
		return shutDown;
	}
	/**
	 *  Remove all runnable objects waiting to execute.
	 *
	 * @return  Runnable [] The runnables who will never see the light of day
	 */
	public synchronized Runnable[] clearQueue()
	{
		Vector them = new Vector(waitingRunnables.getQueueSize() + 2);
		Enumeration enum = waitingRunnables.clearQueue();
		while(enum.hasMoreElements())
		{
			Object obj = enum.nextElement();
			them.addElement(obj);
		}

		Runnable[] result = new Runnable[them.size()];
		them.copyInto(result);
		them = null;

		return result;
	}
	/**
	 *  Gracefully terminate the ThreadPool. No threads are 'shot'. They are given
	 *  a chance to end normally. There maybe runnables in the queue that will
	 *  never see the light of day. All threads will be terminated prior to the
	 *  return of this method. The pool becomes unusable and must be discarded.
	 *
	 * @return  Runnable [] The runnables who will never see the light of day
	 */
	public synchronized Runnable[] shutdown()
	{
		if(isShutdown())
		{
			return new Runnable[0];
		}
		//Subsequent calls result in a -1 result
		shutDown = true;
		notifyAll();
		while(!getThreadGroup().isDestroyed())
		{
			try
			{
				if(threadCount == 0)
				{
					//All threads have left the party

					int count = getThreadGroup().activeCount();
					while(count > 0)
					{
						Thread[] threads = new Thread[count];
						getThreadGroup().enumerate(threads);
						for(int i = 0; i < count; ++i)
						{
							if(threads[i] != null)
							{
								threads[i].join();
							}
						}
						count = getThreadGroup().activeCount();
					}
					getThreadGroup().destroy();
					return clearQueue();
				}
				wait();
			}
			catch(InterruptedException ex)
			{
			}
		}
		return clearQueue();
	}
	/**
	 *  Enqueue the runnable. When a thread becomes available, the parameter
	 *  runnable object will be executed. A 'notify' is called before this method
	 *  is exited. This will wake any waiting threads.
	 *
	 * @param  runnable
	 */
	public synchronized void start(Runnable runnable)
	{
		if(isShutdown())
		{
			throw new IllegalStateException("Attempting to start a thread in shutdown thread pool.");
		}
		waitingRunnables.insertCommand(runnable);
		notify();
	}
	/**
	 *  Called by the managed thread when it is done processing a runnable. The
	 *  managedThread goes into a wait state on the ThreadPool. When
	 *  start(Runnable) is called, the 'notify' method on the ThreadPool is called.
	 *  Some waiting thread will go into action, pick off an element from the list
	 *  of waiting Runnables and begin execution. Upon completion, this method is
	 *  called again.
	 *
	 * @param  mt
	 * @return
	 * @exception  InterruptedException
	 * @see  com.objectwave.utility.ManagedThread
	 */
	protected synchronized boolean threadWaiting(ManagedThread mt) throws InterruptedException
	{
		while(waitingRunnables.getQueueSize() == 0 || isShutdown())
		{
			if(isShutdown())
			{
				//All terminating threads must go through this call
				threadCount--;
				notifyAll();
				return true;
			}
			//If we have nothing to run, go into a wait state.
			wait();
		}
		Runnable r = waitingRunnables.getNextCommand();
		mt.startRunnable(r);
		return false;
	}
	/**
	 *  If we get garbaged collected, shutdown the thread pool.
	 *
	 * @exception  Throwable
	 */
	protected void finalize() throws Throwable
	{
		shutdown();
		super.finalize();
	}
	/**
	 *  Unit Tests
	 *
	 * @author  dhoag
	 * @version  $Id: ThreadPoolManager.java,v 2.1 2002/07/31 15:55:23 dave_hoag Exp $
	 */
	public static class Test extends com.objectwave.test.UnitTestBaseImpl
	{
		/**
		 *  The main program for the Test class
		 *
		 * @param  args The command line arguments
		 */
		public static void main(String[] args)
		{
			com.objectwave.test.TestRunner.run(new Test(), args);
		}
		/**
		 *  Gets the Runnable attribute of the Test object
		 *
		 * @param  str
		 * @param  v
		 * @return  The Runnable value
		 */
		public Runnable getRunnable(final String str, final Vector v)
		{
			return
				new Runnable()
				{
					/**
					 *  Main processing method for the Test object
					 */
					public void run()
					{
						v.addElement(str);
						Enumeration e = v.elements();
						String string = "DoSomethingToTakeTime";
						while(e.hasMoreElements())
						{
							Object obj = e.nextElement();
							string += obj.toString() + "more";
							string += new StringBuffer(obj.toString()).toString();
						}
					}
				};
		}
		/**
		 *  A unit test for JUnit
		 */
		public synchronized void testSomeExecute()
		{
			ThreadPoolManager mgr = new ThreadPoolManager(1);
			Runnable[] runs = new Runnable[2230];
			Vector vector = new Vector();
			for(int i = 0; i < runs.length; ++i)
			{
				runs[i] = getRunnable("aTest" + i, vector);
				mgr.start(runs[i]);
			}
			try
			{
				wait(10);
			}
			catch(InterruptedException ex)
			{
			}
			int count = mgr.shutdown().length;
			testContext.assertTrue("All threads executed despite shutdown!", count > 0);
			testContext.assertEquals("Queue information not accurate!", vector.size() + count, runs.length);
		}
		/**
		 *  A unit test for JUnit
		 */
		public synchronized void testSomeExecute2()
		{
			ThreadPoolManager mgr = new ThreadPoolManager(20);
			Runnable[] runs = new Runnable[3992];
			Vector vector = new Vector();
			for(int i = 0; i < runs.length; ++i)
			{
				runs[i] = getRunnable("aTest" + i, vector);
				mgr.start(runs[i]);
			}
			try
			{
				wait(10);
			}
			catch(InterruptedException ex)
			{
			}
			int count = mgr.shutdown().length;
			testContext.assertTrue("All threads executed despite shutdown!", count > 0);
			testContext.assertEquals("Queue information not accurate!", runs.length, vector.size() + count);
		}
		/**
		 *  A unit test for JUnit
		 */
		public synchronized void testAllExecute()
		{
			ThreadPoolManager mgr = new ThreadPoolManager(1);
			Runnable[] runs = new Runnable[30];
			Vector vector = new Vector();
			for(int i = 0; i < runs.length; ++i)
			{
				runs[i] = getRunnable("aTest" + i, vector);
				mgr.start(runs[i]);
			}
			int count = 0;
			while(vector.size() < 30)
			{
				try
				{
					count++;
					wait(50);
				}
				catch(InterruptedException ex)
				{
				}
				if(count > 1000)
				{
					throw new IllegalThreadStateException("Pool seems to have not executed everything!");
				}
			}
			mgr.shutdown();
			mgr.shutdown();
		}
	}
}
