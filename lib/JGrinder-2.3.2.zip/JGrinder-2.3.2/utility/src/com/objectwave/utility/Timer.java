package com.objectwave.utility;
import java.awt.event.*;

import java.util.*;
/**
 *  This class is based upon an article in JavaWorld.
 *
 * @author  Dave Hoag
 * @version  $Id: Timer.java,v 2.1 2002/07/31 15:55:23 dave_hoag Exp $
 */
public class Timer
{
	protected LockManager lockManager = new LockManager();

	protected Hashtable assocation = new Hashtable();
	private int delay;
	private Timer.Clock clock;
	private boolean is_stopped = false;

	private Mode type;

	private java.awt.event.ActionListener observers = null;
	private Notifier notifier;
	/**
	 *  Description of the Field
	 */
	public final static Mode CONTINUOUS = new Mode();
	/**
	 *  Description of the Field
	 */
	public final static Mode RUNONCE = new Mode();
	/**
	 *  Description of the Field
	 */
	public final static Mode KEEPTHREAD = new Mode();

	/**
	 *  Description of the Field
	 */
	public final static String STOPPED = "stopped";
	/**
	 *  Description of the Field
	 */
	public final static String EXPIRED = "expired";
	/**
	 *  Description of the Field
	 */
	public final static long FOREVER = Long.MAX_VALUE;
	/**
	 * @param  delay int The time between clock ticks.
	 * @param  type Description of Parameter
	 */
	public Timer(int delay, Mode type)
	{
		this.delay = delay;
		this.type = (type == null) ? CONTINUOUS : type;
	}
	/**
	 *  Using this constructor is the same as Timer(delay, Timer.CONTINUOUS );
	 *
	 * @param  delay Description of Parameter
	 * @see  #Timer(int, Mode)
	 */
	public Timer(int delay)
	{
		this(delay, CONTINUOUS);
	}
	/**
	 *  Run the action listener on its own thread in delay amount of time.
	 *
	 * @param  l The action listener upon which to invoke the command.
	 * @param  delay The time in milliseconds to wait.
	 */
	public Timer(ActionListener l, int delay)
	{
		this(delay, RUNONCE);
		addActionListener(l);
		start();
	}
	/**
	 *  The time between clock ticks.
	 *
	 * @param  val The new Delay value
	 */
	public void setDelay(int val)
	{
		delay = val;
	}
	/**
	 * @param  b The new EnableNotifications value
	 */
	public void setEnableNotifications(boolean b)
	{
		clock.setEnableNotifications(b);
	}
	/**
	 * @return  The Stopped value
	 */
	public boolean isStopped()
	{
		return is_stopped;
	}
	/**
	 *  The time between clock ticks.
	 *
	 * @return  The Delay value
	 */
	public int getDelay()
	{
		return delay;
	}
	/**
	 *  Start the timer ticking. If a timer of a type other than RUNONCE is used,
	 *  it is necessary to call stop() to free up resources.
	 *
	 * @see  #stop()
	 */
	public synchronized void start()
	{
		if(clock != null)
		{
			if(type == KEEPTHREAD && clock.hasExpired())
			{
				clock.restart();
				return;
			}
			else
			{
				clock.setEnableNotifications(false);
				clock.interrupt();
			}
		}

		clock = new Clock();
		clock.start();
		is_stopped = false;
	}
	/**
	 *  Stop the timer from ticking. NOTE: This does not stop any running
	 *  actionListeners. This method MUST be called to free up resources.
	 */
	public synchronized void stop()
	{
		if(clock != null)
		{
			clock.interrupt();
		}

		clock = null;
		is_stopped = true;
		notifyAll();
	}
	/**
	 */
	public void finalize()
	{
		if(clock != null)
		{
			throw new Error("Alarm was not stopped before being destroyed");
		}
	}
	/**
	 *  Pause the current thread for at most timeout milliseconds. Before the time
	 *  is completed, the thread may be interrupted from the clock. If there is no
	 *  clock, then this will return immediately.
	 *
	 * @param  timeout Description of Parameter
	 * @return  Description of the Returned Value
	 */
	public synchronized boolean pause(long timeout)
	{
		if(clock == null || !clock.hasExpired())
		{
			try
			{
				wait(timeout);
			}
			catch(InterruptedException e)
			{
				/*
				 * do nothing
				 */
			}
		}
		return !is_stopped;
	}
	/**
	 *  Go into an indefinite wait state until the clock timer ticks. Return
	 *  immediately if the clock is not actively running.
	 *
	 * @return  Description of the Returned Value
	 */
	public boolean waitForTimer()
	{
		return pause(FOREVER);
	}
	/**
	 *  Add an action listener to be notified at every clock tick. The
	 *  'actionCommand' of the action event will either be 'expired' or 'stopped'.
	 *  If it is 'expired', the clock is still running. If it is 'stopped', the
	 *  clock has been stopped. The action listener should decide how to respond to
	 *  the various states. Each ActionListener that has been added will be
	 *  notified of each clock tick. If the action listeners take longer than
	 *  'delay' to execute, the ticks will be queued. An approximation of the queue
	 *  size can be obtained via the 'runningQueueSize()' method. The 'flushQueue'
	 *  method will cause all of those queued up to never execute.
	 *
	 * @param  l The feature to be added to the ActionListener attribute
	 * @see  #flushQueue
	 * @see  #runningQueueSize
	 */
	public synchronized void addActionListener(java.awt.event.ActionListener l)
	{
		boolean start = false;
		if(notifier == null)
		{
			notifier = new Notifier();
			notifier.setDaemon(true);
			start = true;
		}
		WrapperActionListener wl = new WrapperActionListener(l, notifier);
		assocation.put(l, wl);
		observers = AWTEventMulticaster.add(observers, wl);
		if(start)
		{
			notifier.start();
		}
	}
	/**
	 * @param  l Description of Parameter
	 */
	public void removeActionListener(java.awt.event.ActionListener l)
	{
		WrapperActionListener wl = (WrapperActionListener) assocation.get(l);
		if(wl == null)
		{
			return;
		}
		observers = AWTEventMulticaster.remove(observers, wl);
	}
	/**
	 *  An estimate of how many action listeners are have been notified, but have
	 *  yet to execute.
	 *
	 * @return  Description of the Returned Value
	 */
	public int runningQueueSize()
	{
		if(notifier == null)
		{
			return 0;
		}
		return notifier.getEstimateQueueSize();
	}
	/**
	 *  Stop notifying the action listeners with actionEvents.
	 */
	public void flushQueue()
	{
		if(notifier == null)
		{
			return;
		}
		notifier.flush();
	}
	/**
	 *  Wait for all of the action listeners.
	 */
	public void waitForActionListeners()
	{
		if(notifier == null)
		{
			return;
		}
		lockManager.lock(notifier);
		//wait until notifier is complete
		lockManager.release(notifier);
	}

	/**
	 *  Used wrap each action listener. This allows us to interrupt the flow of the
	 *  action listener.
	 *
	 * @author  dhoag
	 * @version  $Id: Timer.java,v 2.1 2002/07/31 15:55:23 dave_hoag Exp $
	 */
	class WrapperActionListener implements ActionListener
	{
		ActionListener list;
		Notifier notif;
		/**
		 *  Constructor for the WrapperActionListener object
		 *
		 * @param  l Description of Parameter
		 * @param  f Description of Parameter
		 */
		public WrapperActionListener(ActionListener l, Notifier f)
		{
			list = l;
			notif = f;
		}
		/**
		 *  Description of the Method
		 *
		 * @param  e Description of Parameter
		 */
		public void actionPerformed(java.awt.event.ActionEvent e)
		{
			if(notif.dontSkip())
			{
				list.actionPerformed(e);
			}
			notif.complete();
		}

	}
	/**
	 *  The class and the thread on which the ActionListeners will execute.
	 *
	 * @author  dhoag
	 * @version  $Id: Timer.java,v 2.1 2002/07/31 15:55:23 dave_hoag Exp $
	 */
	private class Notifier extends Thread
	{
		//The number of times the notifier has been asked to execute.
		protected int runCount = 0;
		//The number of listeners to execute.
		int count = 0;
		boolean run = true;
		/**
		 */
		public void run()
		{
			ActionListener copy;

			while(observers != null)
			{
				boolean lockNeeded = false;
				synchronized(Timer.this)
				{
					if(runCount == 0)
					{
						//Only wait if no requests were made
						try
						{
							lockManager.release(this);
							lockNeeded = true;
							Timer.this.wait();
						}
						catch(InterruptedException e)
						{
							/*
							 * ignore
							 */
						}
					}
					if(lockNeeded)
					{
						lockManager.lock(this);
						lockNeeded = false;
					}
					if((copy = observers) == null)
					{
						notifier = null;
					}
					if(copy != null)
					{
						runCount--;
						if(runCount < 0)
						{
							copy = null;
							runCount = 0;
						}
					}
				}
				if(copy != null)
				{
					if(observers instanceof AWTEventMulticaster)
					{
						count += ((AWTEventMulticaster) observers).count();
					}
					else
					{
						count += 1;
					}
					ActionEvent event = new ActionEvent(this, 0,
							is_stopped ? STOPPED : EXPIRED);
					copy.actionPerformed(event);
				}
			}
		}
		/**
		 * @return  The EstimateQueueSize value
		 */
		protected int getEstimateQueueSize()
		{
			int localCount = 0;
			if(observers instanceof AWTEventMulticaster)
			{
				localCount += ((AWTEventMulticaster) observers).count();
			}
			else
			{
				localCount += 1;
			}
			return localCount * (runCount - 1) + count;
		}
		/**
		 */
		protected void flush()
		{
			runCount = 1;
			run = false;
		}
		/**
		 * @return  Description of the Returned Value
		 */
		protected boolean dontSkip()
		{
			return run;
		}
		/**
		 */
		protected void notifyIt()
		{
			runCount++;
		}
		/**
		 */
		protected void complete()
		{
			count--;
			if(count == 0)
			{
				run = true;
			}
		}
	}
	/**
	 *  The class and the Thread that keeps track of time. It is completely
	 *  independent of any thing else, so the time should always be accurate.
	 *
	 * @author  dhoag
	 * @version  $Id: Timer.java,v 2.1 2002/07/31 15:55:23 dave_hoag Exp $
	 */
	private final class Clock extends Thread
	{
		private boolean expired = false;
		// continuous timers don't expire
		private boolean enableNotifications = true;

		/**
		 *  Constructor for the Clock object
		 */
		Clock()
		{
			setPriority(getThreadGroup().getMaxPriority());
		}

		/**
		 *  Sets the EnableNotifications attribute of the Clock object
		 *
		 * @param  b The new EnableNotifications value
		 */
		public void setEnableNotifications(boolean b)
		{
			enableNotifications = b;
		}
		/**
		 *  Main processing method for the Clock object
		 */
		public void run()
		{
			while(!isInterrupted())
			{
				try
				{
					sleep(delay);
					// release the monitor while sleeping

					if(isInterrupted())
					{
						// don't notify waiting threads if
						break;
					}
					// we've been stopped by the
					// Alarm object.
					synchronized(this)
					{
						//#clock_synch

						expired = true;
						if(enableNotifications)
						{
							synchronized(Timer.this)
							{
								if(notifier != null)
								{
									notifier.notifyIt();
								}

								Timer.this.notifyAll();
								//#clock_notify
							}
						}

						if(type == KEEPTHREAD)
						{
							wait();
							// suspend		//#clock_suspend
						}
						else if(type == RUNONCE)
						{
							synchronized(Timer.this)
							{
								if(Timer.this.clock == this)
								{
									Timer.this.clock = null;
								}
								//#clock_destroy
							}
							break;
						}
					}
				}
				catch(InterruptedException e)
				{
					// don't notify the waiting
					break;
					// threads because an
				}
				// interrupt is used to stop
			}
			// the timer.
		}

		/**
		 *  Description of the Method
		 */
		public synchronized void restart()
		{
			expired = false;
			notify();
		}
		/**
		 *  Description of the Method
		 *
		 * @return  Description of the Returned Value
		 */
		public boolean hasExpired()
		{
			return (type != CONTINUOUS) && expired;
		}
	}

	/**
	 *  Description of the Class
	 *
	 * @author  dhoag
	 * @version  $Id: Timer.java,v 2.1 2002/07/31 15:55:23 dave_hoag Exp $
	 */
	public static class Mode
	{
		/**
		 *  Constructor for the Mode object
		 */
		private Mode()
		{
		}
	}
	/**
	 *  Test case.
	 *
	 * @author  dhoag
	 * @version  $Id: Timer.java,v 2.1 2002/07/31 15:55:23 dave_hoag Exp $
	 */
	public static class Test extends com.objectwave.test.UnitTestBaseImpl
	{
		String lastString = "";
		long lastTime;
		/**
		 * @exception  InterruptedException Description of Exception
		 */
		public void testRunOnceListener() throws InterruptedException
		{
			Timer clock = new Timer(getL("First", false), 300);
			Thread.currentThread().sleep(1000);
			testContext.assertEquals(lastString, "First");
		}
		/**
		 * @exception  InterruptedException Description of Exception
		 */
		public void testWaitForListeners() throws InterruptedException
		{
			Timer clock = new Timer(10, KEEPTHREAD);
			clock.addActionListener(getL("First", true));
			//All three run on each tick
			clock.addActionListener(getL("Middle", true));
			//All three run on each tick
			clock.addActionListener(getL("Last", true));
			//All three run on each tick
			clock.start();
			Thread.currentThread().sleep(200);
			clock.stop();
			clock.waitForActionListeners();
			testContext.assertTrue("Should be FirstMiddleLast, but was" + lastString, lastString.equals("FirstMiddleLast"));
		}
		/**
		 * @exception  InterruptedException Description of Exception
		 */
		public void testRunningQueueSize() throws InterruptedException
		{
			Timer clock = new Timer(10, KEEPTHREAD);
			clock.addActionListener(getL("First", true));
			//All three run on each tick
			clock.addActionListener(getL("Middle", true));
			//All three run on each tick
			clock.addActionListener(getL("Last", true));
			//All three run on each tick
			clock.start();
			Thread.currentThread().sleep(200);
			clock.start();
			Thread.currentThread().sleep(100);
			testContext.assertEquals(3, clock.runningQueueSize());
			//1 should have started but not yet completed.
			clock.stop();
			Thread.currentThread().sleep(1200);
			clock.flushQueue();
			Thread.currentThread().sleep(1000);
//			testContext.assertTrue("Should be FirstMiddle, but was "  + lastString, lastString.equals("FirstMiddleFirst"));
			//Seems unreliable
		}
		/**
		 * @exception  InterruptedException Description of Exception
		 */
		public void testContinuousActionListeners() throws InterruptedException
		{
			Timer clock = new Timer(1000);
			// 1-second continuous timer
			clock.addActionListener(getL("First", false));
			//All three run on each tick
			clock.addActionListener(getL("Middle", false));
			clock.addActionListener(getL("Last", false));
			clock.start();
			Thread.currentThread().sleep(1200);
			testContext.assertTrue("All three should have run once!", (lastString.startsWith("First") && lastString.endsWith("Last")));
			clock.stop();
		}
		/**
		 */
		public void testContinuousTimer()
		{
			long timeNow;
			Timer clock = new Timer(500, Timer.CONTINUOUS);
			//The above is the same as : = new Timer(500);
			timeNow = new java.util.Date().getTime();
			clock.start();
			for(int i = 3; --i >= 0; )
			{
				clock.waitForTimer();
				long newTime = new java.util.Date().getTime();
				long variance = newTime - timeNow;
				timeNow = new java.util.Date().getTime();
				testContext.assertTrue("Timer not within tollerance! " + variance, (variance >= 500 && variance < 550));
			}
			//Stop is necessary to free resources.
			clock.stop();
		}
		/**
		 */
		public void testOneShot()
		{
			long timeNow;
			Timer clock = new Timer(500, Timer.RUNONCE);
			timeNow = new java.util.Date().getTime();
			clock.start();
			for(int i = 3; --i >= 0; )
			{
				clock.waitForTimer();
				long newTime = new java.util.Date().getTime();
				long variance = newTime - timeNow;
				testContext.assertTrue("Timer not within tollerance! " + variance, (variance >= 500 && variance < 550));
				timeNow = new java.util.Date().getTime();
				clock.start();
			}
		}
		/**
		 *  A multi shot is just like a one shot, except that resources are not
		 *  released. A call to stop() is necessary.
		 */
		public void testMultiShot()
		{
			long timeNow;
			Timer clock = new Timer(500, KEEPTHREAD);
			timeNow = new java.util.Date().getTime();
			clock.start();
			for(int i = 3; --i >= 0; )
			{
				clock.waitForTimer();
				long newTime = new java.util.Date().getTime();
				long variance = newTime - timeNow;
				testContext.assertTrue("Timer not within tollerance! " + variance, (variance >= 500 && variance < 550));
				timeNow = new java.util.Date().getTime();
				clock.start();
			}
			//Stop is necessary to free resources.
			clock.stop();
		}
		/**
		 *  For use of the test class.
		 *
		 * @param  str Description of Parameter
		 * @param  stall Description of Parameter
		 * @return  The L value
		 */
		ActionListener getL(final String str, final boolean stall)
		{
			return
				new java.awt.event.ActionListener()
				{
					/**
					 *  Description of the Method
					 *
					 * @param  e Description of Parameter
					 */
					public void actionPerformed(java.awt.event.ActionEvent e)
					{
						Timer.Test.this.lastString += str;
//							lastString += str;
						Timer.Test.this.lastTime = new java.util.Date().getTime();
						synchronized(Timer.Test.this)
						{
							if(stall)
							{
								try
								{
									Timer.Test.this.wait(1000);
								}
								catch(InterruptedException ex)
								{
								}
							}
						}
					}
				};
		}

		/**
		 *  The main program for the Test class
		 *
		 * @param  args The command line arguments
		 */
		public static void main(String[] args)
		{
			com.objectwave.test.TestRunner.run(new Test(), args);
		}
	}
}
