package com.objectwave.utility;

import java.util.Hashtable;
import java.util.Vector;
import java.util.Enumeration;
import java.io.Serializable;
import javax.swing.tree.TreeModel;
import javax.swing.tree.TreePath;
import javax.swing.event.TreeModelListener;
import javax.swing.event.TreeModelEvent;
import javax.swing.event.EventListenerList;

/**  This class differs from the jfc tree implementation in that
* you never worry about TreeNode objects.  You just use this as you would
* any old collection.  This class should probably change from using Vectors
* to contain elements using link lists.  This would provide flexibility
* in what comparison operator to use.
* @fixme - Should be optimized. All hashtables should go and be replaced with a 
* node like structure
*/
public class TreeCollection implements Serializable, TreeModel
{
	Vector root;
	Hashtable allNodes, parents;
	EventListenerList eventList = new EventListenerList();
	String name;
	/**
	* Inner class that provides the ability to enumerate over this collection.
	*/
	class MyEnumeration implements Enumeration
	{
		Enumeration enum;
		MyEnumeration(Enumeration e){
			enum = e;
		}
		
		public boolean hasMoreElements(){ return enum.hasMoreElements(); }
		public Object nextElement(){ 
			Object obj = enum.nextElement();
			enum.nextElement();  //Drop child collection.
			return obj;
		}
	}
	/**
	*/
	public TreeCollection()
	{
		root = new Vector();
		allNodes = new Hashtable(10);
		parents = new Hashtable(10);
	}
	/** Adds new elements to the root of the tree.  If the element
	*  is already in the tree, it is moved to the root of the tree.
	*/
	public void add(Object key)
	{
		moveKeyToExtension(key, root);
	}
	/**
	* Implement TreeModel
	*/
	public void addTreeModelListener(TreeModelListener l)
	{
		eventList.add(TreeModelListener.class, l);
	}
	/**
	*/
	private void buildSubTree(TreeCollection result, Object node)
	{
		Enumeration children = get(node);
		while(children.hasMoreElements()){
			Object child = children.nextElement();
			result.put(node, child);
			buildSubTree(result, child);
		}
	}
	/**
	* Does the object exist in this collection.
	*/
	public boolean contains(Object key)
	{
		if(key == this) return true;
		return allNodes.containsKey(key);
	}
	/** Return an enumeration of the entire contents of collection.
	*/
	public Enumeration elements()
	{
		return ((Hashtable)allNodes.clone()).keys();
	}
	//End Implement TreeModel

	/**
	*/
	protected void fireInsertedEvent(TreeModelEvent e)
	{
		Object[] listeners = eventList.getListenerList();
		for (int i = listeners.length-2; i>=0; i-=2) {
			if (listeners[i]==TreeModelListener.class)
				((TreeModelListener)listeners[i+1]).treeNodesInserted(e);
		}
	}
	/**
	* e.path() returns the path the parent of the changed node(s).
	* e.childIndices() returns the index(es) of the changed node(s).
	*/
	protected void fireTreeNodesChanged(TreeModelEvent e)
	{
		Object[] listeners = eventList.getListenerList();
		for (int i = listeners.length-2; i>=0; i-=2) {
			if (listeners[i]==TreeModelListener.class){
				((TreeModelListener)listeners[i+1]).treeNodesChanged(e);
			}
		}
	}
	/**
	*  Returns the children at the specified key.
	*/
	public Enumeration get(Object key)
	{
		if(key == this) key = null;
		if(key == null) return new MyEnumeration(root.elements());
		Vector target = getVectorFor(key);
		if(target == null) return new Hashtable().keys();
		return new MyEnumeration(target.elements());
	}
	/**
	*/
	public Object getChild(Object parent, int index)
	{
		Vector children = null;
		if(parent == null || parent == this)
			children = root;
		else
			children = getVectorFor(parent);
		if(children == null) return null;
		if(children.size()  < (index * 2) + 1) return null;
		return children.elementAt((index * 2));
	}
	/**
	*/
	public int getChildCount(Object parent)
	{
		if(parent == this) parent = null;
		int size = 0;
		if(parent == null){
			size = root.size();
		}
		else {
			Vector target = getVectorFor(parent);
			if(target == null) return 0;
			size = target.size();
		}
		if(size == 0) return size;
		return size / 2;
	}
	/**
	*/
	private Vector getChildrenCollection(Object key, Vector from)
	{
		int idx = from.indexOf(key);
		return (Vector)from.elementAt(idx + 1);
	}
	/**
	* @param parent If null, look at root values.
	* @return int Index of the child. -1 if child not found at parent.
	*/
	public int getIndexOfChild(Object parent, Object child)
	{
		Vector children = null;
		if(parent == null || parent == this)
			children = root;
		else
			children = getVectorFor(parent);
		if(children == null) return -1;
		int idx = children.indexOf(child);
		if(idx > -1) return idx / 2;
		return -1;
	}
	/**
	*/
	public Object getParent(Object key){ return parents.get(key); }
	public Object getRoot(){ return this; }
	/**
	*/
	public TreeCollection getSubTree(Object key)
	{
		Vector target = (Vector)allNodes.get(key);
		if(target == null) return new TreeCollection();

		TreeCollection result = new TreeCollection();
		Enumeration children = get(key);
		while(children.hasMoreElements()){
			Object child = children.nextElement();
			result.add(child);
			buildSubTree(result, child);
		}
		return result;
	}
	/**
	*/
	private Vector getVectorFor(Object key)
	{
		Vector target = (Vector)allNodes.get(key);
		if(target == null) return null;
		return getChildrenCollection(key, target);
	}
	/**
	*/
	public boolean isEmpty(){ return allNodes.isEmpty(); }
	/**
	* Do we have any children at the node.
	*/
	public boolean isEmpty(Object key)
	{
		Vector target = getVectorFor(key);
		return target == null ? true : target.isEmpty();
	}
	/**
	*/
	public boolean isLeaf(Object node){ return getChildCount(node) == 0;}
	/*  The following exist for testing this class */
	public static void main(String [] args)
	{
		TreeCollection test = new TreeCollection();
		Integer one = new Integer(1);
		Integer two = new Integer(2);
		Integer sub = new Integer(10);
		Integer subSub = new Integer(100);
		test.add(one);
		test.add(two);
		test.add(new Integer(3));
		test.put(one, sub);
		test.put(sub, subSub);
		Enumeration verify;
		try { 
		verify = test.get(one);
		System.out.print("10 : ");
		while(verify.hasMoreElements()) System.out.println(verify.nextElement());
		test.put(two, sub);
		System.out.print("10 : ");
		verify = test.get(two);
		while(verify.hasMoreElements()) System.out.println(verify.nextElement());
		System.out.println("-----");
		verify = test.get(one);
		System.out.print("----- : ");
		while(verify.hasMoreElements()) System.out.println(verify.nextElement());
		System.out.println("-----");
		System.out.println("1, 2, & 3");
		verify = test.elements();
		while(verify.hasMoreElements()) System.out.println(verify.nextElement());
		System.out.println("-----");
		System.out.print("100 : ");
		verify = test.get(sub);
		while(verify.hasMoreElements()) System.out.println(verify.nextElement());
		System.out.println("Sub Tree Test");
		TreeCollection subTree = test.getSubTree(two);
		verify = subTree.get(sub);
		System.out.print("100 : ");
		while(verify.hasMoreElements()) System.out.println(verify.nextElement());
		System.out.print("false : ");
		System.out.println(subTree.contains(one));
		System.out.println("Parent Test");
		System.out.print("10 : ");
		System.out.println(test.getParent(subSub));
		test.remove(sub);
		System.out.println("Removed Parent 10");
		System.out.print("2 : ");
		System.out.println(test.getParent(subSub));
		System.out.println("Pruning Parent");
		test.prune(two);
		System.out.print("false : ");
		System.out.println(test.contains(subSub));
		} catch (Exception e) { System.out.println(e); }
	}
	/**
	* Does the work of maintaining our view of the tree.
	*/
	private void moveKeyToExtension(Object key, Vector dest)
	{
		Vector target = (Vector)allNodes.get(key);
		allNodes.put(key,dest);
		if(target == null){
			dest.addElement(key);
			dest.addElement(new Vector());

			int [] vals = new int [1];
			vals[0] = dest.indexOf(key) / 2;
			Object [] child = new Object [1];
			child[0] = key;
			TreeModelEvent e = new TreeModelEvent(this, pathTo(key), vals, child);
			fireInsertedEvent(e);
		} else {
			if(target == dest) return;
			Vector oldContents = getChildrenCollection(key, target);
			int idx = target.indexOf(key);
			target.removeElementAt(idx);
			target.removeElementAt(idx);
			dest.addElement(key);
			dest.addElement(oldContents);
		}
	}
	/**
	* Path to the parent of key.  At minimum this will contain the
	* root node.
	*/
	public Object [] pathTo(Object key)
	{
		Vector v = new Vector();
		Object parent = getParent(key);
		while(parent != null){
			v.addElement(parent);
			parent = getParent(parent);
		}
		Object [] result = new Object [v.size() + 1];
		result[0] = this;
//		System.out.println(this);
		for(int i = v.size() - 1; i > -1; i--){
			result[i + 1] = v.elementAt(i);
//			System.out.println("i: " + (i + 1) + result[i + 1]);
		}
		return result;
	}
	/**
	* Remove the object 'key' and all children of key.
	*/
	public void prune(Object key)
	{
		Vector target = (Vector)allNodes.get(key);
		if(target == null) return;
		Enumeration children = get(key);
		while(children.hasMoreElements())
			prune(children.nextElement());
		allNodes.remove(key);
		Vector childs = getChildrenCollection(key, target);
		target.removeElement(key);
		target.removeElement(childs);
		parents.remove(key);
	}
	/** Puts the new elment after the existing element.  If the existing
	* element is not in the tree it is just added at the root level.
	* If the new elment is already in the tree, it and it's children are
	* moved to the new elements child.
	*/
	public void put(Object key, Object node)
	{
		Vector target = (Vector)allNodes.get(key);
		Vector content = null;
		if(target == null){
			target = root;
			allNodes.put(key,root);
			root.addElement(key);
			content = new Vector();
			root.addElement(content);
		}
		parents.put(node, key);
		if(content == null)
			content = getChildrenCollection(key, target);
		moveKeyToExtension(node, content);
	}
	/**
	*/
	public void refreshPath(TreePath path)
	{
		int [] vals = new int [1];
		Object key = path.getLastPathComponent();
		vals[0] = getIndexOfChild(getParent(key), key);
		Object [] child = new Object [1];
		child[0] = key;
		TreeModelEvent e = new TreeModelEvent(this, pathTo(key), vals, child);
		fireTreeNodesChanged(e);
	}
	/**
	* Remove the object 'key' and promote all of it's children to have
	* the same parent that 'key' had.
	*/
	public void remove(Object key)
	{
		Enumeration contents = get(key);
		if(contents == null) return;
		Vector original = (Vector)allNodes.get(key);
		Object originalParent = parents.get(key);
		while(contents.hasMoreElements()){
			Object childKey = contents.nextElement();
			moveKeyToExtension(childKey, original);
			if(originalParent == null)
				parents.remove(childKey);
			else
				parents.put(childKey, originalParent);
		}
		if(original != null)
		{
			Vector target = getChildrenCollection(key, original);
			original.removeElement(key);
			original.removeElement(target);
		}
		allNodes.remove(key);
		parents.remove(key);
	}
	/**
	*/
	public void removeTreeModelListener(TreeModelListener l)
	{
		eventList.remove(TreeModelListener.class, l);
	}
	/**
	*/
	public void replace(Object key, Object with)
	{
		Vector target = (Vector)allNodes.get(key);
		if(target == null) return;
		if(with == null) { remove(key); return; }
		int idx = target.indexOf(key);
		target.setElementAt(with, idx);
		allNodes.put(with, target);
		allNodes.remove(key);
		Object parent = parents.get(key);
		parents.remove(key);
		if(with != null && parent != null)
			parents.put(with, parent);
	}
	/**
	*/
	public void setName(String val){ name = val; }
	/**
	*/
	public int size(){ return allNodes.size(); }
	/**
	* @deprecated Get the child count at the object.
	*/
	public int size(Object key){ return getChildCount(key); }
	/**
	* What is the name of 'this' object.
	*/
	public String toString()
	{
		if(name != null) return name;
		String str = new String();
		str += "TreeCollection size" + size();

		return str;
	}
	/**
	*/
	public void valueForPathChanged(TreePath path,Object newValue)
	{
		System.out.println("??----TreeCollection>>valueForPathChanged(path,val)----?");
		System.out.println(path);
		System.out.println(newValue);
	}
}