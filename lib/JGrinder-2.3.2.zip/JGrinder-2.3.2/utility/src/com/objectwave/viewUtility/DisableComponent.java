package com.objectwave.viewUtility;
import com.objectwave.logging.MessageLog;
import java.awt.Component;
import java.awt.Container;
import java.awt.Label;
import java.util.Enumeration;

import java.util.Vector;
import javax.swing.JLabel;
/**
 * @author  trever
 * @version  $Id: DisableComponent.java,v 2.1 2002/02/01 21:21:13 dave_hoag Exp $
 */
public class DisableComponent
{
	private Vector vector;
	private Component component;
	private boolean preserve = false;
	private boolean ignoreLabels = true;

	/**
	 * @param  c The component to toggle
	 */
	public DisableComponent(Component c)
	{
		component = c;
		vector = new Vector();
	}
	/**
	 *Sets the Component attribute of the DisableComponent object
	 *
	 * @param  c The new Component value
	 */
	public void setComponent(Component c)
	{
		component = c;
		vector = new Vector();
	}
	/**
	 *Gets the Component attribute of the DisableComponent object
	 *
	 * @return  The Component value
	 */
	public Component getComponent()
	{
		return component;
	}
	/**
	 *  Disable Container and all of it's children, grandchildren, etc.
	 */
	public void disable()
	{
		MessageLog.debug(this, "Disabling the component");
		vector = new Vector();
		if(component != null)
		{
			disable(component);
		}
		MessageLog.debug(this, "Enable exception list size = " + vector.size());
	}
	/**
	 * @param  c
	 */
	protected void disable(Component c)
	{
		if(ignoreLabels &&
				(Label.class.isInstance(c)) || JLabel.class.isInstance(c))
		{
			return;
		}
		if(Container.class.isInstance(c))
		{
			Component components[] = ((Container) c).getComponents();
			for(int i = 0; i < components.length; ++i)
			{
				disable(components[i]);
			}
		}
		if(preserve && !c.isEnabled())
		{
			vector.addElement(c);
		}
		c.setEnabled(false);
	}
	/**
	 */
	public void enable()
	{
		MessageLog.debug(this, "Enabling the component");
		if(component != null)
		{
			enable(component);
		}
		if(!preserve)
		{
			return;
		}
		for(Enumeration e = vector.elements(); e.hasMoreElements(); )
		{
			try
			{
				((Component) e.nextElement()).setEnabled(false);
			}
			catch(Exception ex)
			{
			}
		}
	}
	/**
	 * @param  c
	 */
	protected void enable(Component c)
	{
		if(ignoreLabels &&
				(Label.class.isInstance(c)) || JLabel.class.isInstance(c))
		{
			return;
		}
		if(Container.class.isInstance(c))
		{
			Component components[] = ((Container) c).getComponents();
			for(int i = 0; i < components.length; ++i)
			{
				enable(components[i]);
			}
		}
		c.setEnabled(true);
	}
	/**
	 * @param  b
	 */
	public void ignoreLabels(boolean b)
	{
		ignoreLabels = b;
	}
	/**
	 * @param  b
	 */
	public void preserveCurrentDisabledness(boolean b)
	{
		preserve = b;
	}
	/**
	 */
	public void toggle()
	{
		if(component != null)
		{
			if(component.isEnabled())
			{
				disable(component);
			}
			else
			{
				enable(component);
			}
		}
	}
}
