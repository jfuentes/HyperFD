package com.objectwave.viewUtility;
import com.objectwave.utility.PointManipulator;

import java.awt.*;
import java.awt.event.*;
import java.util.*;

/**
 * @author  trever
 * @version  $Id: DrawRoutines.java,v 2.1 2002/02/01 21:21:13 dave_hoag Exp $
 */
public class DrawRoutines
{
	/*
	 *  . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
	 */

	/**
	 */
	public final static int HORIZONTAL = 0;
	/**
	 */
	public final static int VERTICAL = 1;

	// initial of 0 is horizontal.  initial of 1 is vertical
	/**
	 * @param  g
	 * @param  origin
	 * @param  target
	 * @param  steps
	 * @param  initial
	 */
	public static void drawLine(Graphics g, Point origin, Point target, int steps, int initial)
	{
		if(steps < 1)
		{
			g.drawLine(origin.x, origin.y, target.x, target.y);
			return;
		}
		int xDiff = -(origin.x - target.x - 1);
		int yDiff = -(origin.y - target.y - 1);
		int xInc = xDiff / steps;
		int yInc = yDiff / steps;
		if(xInc == 0 || yInc == 0)
		{
			g.drawLine(origin.x, origin.y, target.x, target.y);
			return;
		}
		Point p = new Point(origin);
		for(int i = 1; i <= steps; i++)
		{
			int x = p.x;
			int y = p.y;
			if(initial == HORIZONTAL)
			{
				p.translate(xInc, 0);
			}
			else
			{
				p.translate(0, yInc);
			}
			g.setColor(Color.red);
			g.drawLine(x, y, p.x, p.y);
			x = p.x;
			y = p.y;
			if(initial == HORIZONTAL)
			{
				p.translate(0, yInc);
			}
			else
			{
				p.translate(xInc, 0);
			}
			g.setColor(Color.blue);
			g.drawLine(x, y, p.x, p.y);
		}
		g.setColor(Color.green);
		g.drawLine(p.x, p.y, target.x, target.y);
	}
	/*
	 *  . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
	 */
	/**
	 * Draw a filled arrowhead polygon at the second end of the given line (this
	 * does not draw the line).<p>
	 *
	 * @param  x1
	 * @param  y1
	 * @param  x2
	 * @param  y2
	 * @param  arrow_head_len
	 * @param  arrow_head_angle
	 * @param  arrow_inset
	 * @param  g
	 */
	public static void fill_arrowhead(int x1, int y1, int x2, int y2,
			int arrow_head_len, int arrow_head_angle, double arrow_inset, Graphics g)
	{
		/*
		 *  length of the target line we are drawing arrowhead over
		 */
		double dx;
		/*
		 *  length of the target line we are drawing arrowhead over
		 */
		double dy;
		/*
		 *  length of the target line we are drawing arrowhead over
		 */
		double len;

		/*
		 *  values for rotation needed to get from canonical line to target
		 */
		double sin_theta;

		/*
		 *  values for rotation needed to get from canonical line to target
		 */
		double cos_theta;

		/*
		 *  coordinates and values for canonical arrowhead placed on x axis
		 */
		double pt1_x;

		/*
		 *  coordinates and values for canonical arrowhead placed on x axis
		 */
		double pt1_y;

		/*
		 *  coordinates and values for canonical arrowhead placed on x axis
		 */
		double pt2_x;

		/*
		 *  coordinates and values for canonical arrowhead placed on x axis
		 */
		double pt2_y;

		/*
		 *  coordinates and values for canonical arrowhead placed on x axis
		 */
		double pt3_x;

		/*
		 *  coordinates and values for canonical arrowhead placed on x axis
		 */
		double pt3_y;
		double ah_len = (double) arrow_head_len;
		double ah_angle = Math.PI * ((double) arrow_head_angle) / 180.0;

		/*
		 *  final arrowhead points transformed to match the line
		 */
		int result1_x;

		/*
		 *  final arrowhead points transformed to match the line
		 */
		int result1_y;

		/*
		 *  final arrowhead points transformed to match the line
		 */
		int result2_x;

		/*
		 *  final arrowhead points transformed to match the line
		 */
		int result2_y;

		/*
		 *  final arrowhead points transformed to match the line
		 */
		int result3_x;

		/*
		 *  final arrowhead points transformed to match the line
		 */
		int result3_y;

		/*
		 *  figure out the length of the target line
		 */
		dx = (double) (x2 - x1);
		dy = (double) (y2 - y1);
		len = Math.sqrt(dx * dx + dy * dy);

		/*
		 *  bail out now if its zero length (since direction is not determined)
		 */
		if(len == 0)
		{
			return;
		}

		/*
		 *  compute canonical arrow head points (as if on a line on x axis)
		 *
		 *  1
		 *  \
		 *  +-----------2-------0----- x axis --->
		 *  /
		 *  3
		 *
		 *  arrowhead is draw as a 4 point polygon (with pt0 at the tip)
		 */
		pt1_x = len - ah_len * Math.cos(ah_angle);
		pt1_y = ah_len * Math.sin(ah_angle);
		pt2_x = len - (len - pt1_x) * arrow_inset;
		pt2_y = 0;
		pt3_x = pt1_x;
		pt3_y = -pt1_y;

		/*
		 *  sin and cos of rotation to get canonical from x axis to target
		 */
		sin_theta = dy / len;
		cos_theta = dx / len;

		/*
		 *  rotate and translate to get our final points
		 */
		result1_x = (int) (pt1_x * cos_theta - pt1_y * sin_theta + 0.5) + x1;
		result1_y = (int) (pt1_x * sin_theta + pt1_y * cos_theta + 0.5) + y1;
		result2_x = (int) (pt2_x * cos_theta - pt2_y * sin_theta + 0.5) + x1;
		result2_y = (int) (pt2_x * sin_theta + pt2_y * cos_theta + 0.5) + y1;
		result3_x = (int) (pt3_x * cos_theta - pt3_y * sin_theta + 0.5) + x1;
		result3_y = (int) (pt3_x * sin_theta + pt3_y * cos_theta + 0.5) + y1;

		/*
		 *  draw the arrow head polygon
		 */
		int xs[] = {x2, result1_x, result2_x, result3_x};
		int ys[] = {y2, result1_y, result2_y, result3_y};
		g.fillPolygon(xs, ys, 4);
	}

	/**
	 * @param  g
	 * @param  arrow
	 */
	public static void drawArrowLine(Graphics g, ArrowSpec arrow)
	{
		// closest[0] = from (parent)
		// closest[1] = to (child)
		if(arrow.lineColor != null)
		{
			g.setColor(arrow.lineColor);
		}
		g.drawLine(arrow.from.x,
				arrow.from.y,
				arrow.to.x,
				arrow.to.y);
		int height = (arrow.from.y - arrow.to.y);
		int width = (arrow.from.x - arrow.to.x);
		double rads;
		rads = Math.atan(Math.abs((double) height / (double) width));

		if(arrow.from.y < arrow.to.y)
		{
			double angle = Math.toDegrees(rads) + 180;
			rads = Math.toRadians(angle);
		}
		else
		{
			double angle = Math.toDegrees(rads);
			rads = Math.toRadians(angle);
		}

		double cos = Math.cos(rads);
		double sin = Math.sin(rads);

		Polygon p = new Polygon();
		int x = arrow.length;
		int y = arrow.width >> 1;
		int newX = (int) (x * cos - y * sin);
		int newY = (int) (x * sin + y * cos);
		if(arrow.from.x > arrow.to.x && arrow.from.y < arrow.to.y)
		{
			newX = -newX;
		}
		if(arrow.from.x < arrow.to.x && arrow.from.y > arrow.to.y)
		{
			newX = -newX;
		}
		p.addPoint(arrow.to.x + newX, arrow.to.y + newY);

		x = arrow.length;
		y = -(arrow.width >> 1);
		newX = (int) (x * cos - y * sin);
		if(arrow.from.x > arrow.to.x && arrow.from.y < arrow.to.y)
		{
			newX = -newX;
		}
		if(arrow.from.x < arrow.to.x && arrow.from.y > arrow.to.y)
		{
			newX = -newX;
		}
		newY = (int) (x * sin + y * cos);

		p.addPoint(arrow.to.x + newX, arrow.to.y + newY);
		p.addPoint(arrow.to.x, arrow.to.y);

		if(arrow.arrowFillColor != null)
		{
			g.setColor(arrow.arrowFillColor);
		}
		g.fillPolygon(p);

		if(arrow.arrowFillColor != null)
		{
			g.setColor(arrow.arrowColor);
		}
		g.drawPolygon(p);
	}
	/**
	 * @author  trever
	 * @version  $Id: DrawRoutines.java,v 2.1 2002/02/01 21:21:13 dave_hoag Exp $
	 */
	public final static class ArrowSpec
	{

		Color arrowFillColor;
		Color arrowColor;
		Color lineColor;
		Point from;
		Point to;
		int length;
		int width;
		/**
		 *Constructor for the ArrowSpec object
		 *
		 * @param  from
		 * @param  to
		 * @param  length
		 * @param  width
		 * @param  fill
		 * @param  arrow
		 * @param  line
		 */
		public ArrowSpec(Point from, Point to, int length, int width,
				Color fill, Color arrow, Color line)
		{
			this.from = from;
			this.to = to;
			this.length = length;
			this.width = width;
			this.arrowFillColor = fill;
			this.lineColor = line;
			this.arrowColor = arrow;
		}
	}

}
