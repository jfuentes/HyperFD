package com.objectwave.viewUtility;

/**
 * Defines the constraints for a column of components in a FlexGridLayout
 * container.
 */
public class FlexGridColumn implements Cloneable
{
	/**
	 *  The column width will be determined to be the maximum width of all
	 *  of the column's components' preferredSize.
	 */
	public static final int AUTO_WIDTH = -1;

	/**
	 *  Different anchoring values.
	 */
	public static final int CENTER = 0;
	public static final int EAST = 1;
	public static final int WEST = 2;
	public static final int NORTH = 3;
	public static final int SOUTH = 4;
	public static final int NORTHEAST = 5;
	public static final int NORTHWEST = 6;
	public static final int SOUTHEAST = 7;
	public static final int SOUTHWEST = 8;

	/**
	 *  Different fill values.
	 */
	public static final int NONE = 20;
	public static final int BOTH = 21;
	public static final int HORIZONTAL = 22;
	public static final int VERTICAL = 23;

	public int width = AUTO_WIDTH;  // the width of the column.
	public double weight = 0.0;     // the (x-axis) weight of the column
	public int anchor = CENTER;     // the anchor for column components.
	public int fill = NONE;         // the fill factor.

	/**
	 * FlexGridColumn constructor comment.
	 */
	public FlexGridColumn() {
		super();
	}
	/**
	 * A publicized clone method
	 */
	public FlexGridColumn duplicate()
	{
		try { return (FlexGridColumn)this.clone(); }
		catch (CloneNotSupportedException e) { return null; }
	}
	/**
	 * This method was created in VisualAge.
	 * @return java.lang.String
	 */
	public String toString()
	{
		String ret = "[width=";
		ret += (width == AUTO_WIDTH) ? "AUTO_WIDTH" : ""+width;
		ret += ",weight=" + weight + ",anchor=";
		switch (anchor)
		{
			case NORTH:		ret += "NORTH"; break;
			case SOUTH:		ret += "SOUTH"; break;
			case EAST:		ret += "EAST"; break;
			case WEST:		ret += "WEST"; break;
			case NORTHEAST:	ret += "NORTHEAST"; break;
			case NORTHWEST:	ret += "NORTHWEST"; break;
			case SOUTHEAST:	ret += "SOUTHEAST"; break;
			case SOUTHWEST:	ret += "SOUTHWEST"; break;
			case CENTER:	ret += "CENTER"; break;
			default: 		ret += "invalid(" + anchor + ")";
		}
		ret += ",fill=";
		switch (fill)
		{
			case NONE:		ret += "NONE"; break;
			case BOTH:		ret += "BOTH"; break;
			case HORIZONTAL:ret += "HORIZONTAL"; break;
			case VERTICAL:	ret += "VRETICAL"; break;
			default:		ret += "invalid(" + fill + ")";
		}
		return ret + "]";
	}
}