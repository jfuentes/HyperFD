package com.objectwave.viewUtility;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

/**
 *  This class is a simple dialog which allows the user
 *  to specify files for the header and/or footer of some
 *  generated document.  There are also browse buttons
 *  provided to simplify the file specification.  This
 *  class is often used in conjunction with the table
 *  printing functionality of <code>GenericTableModel</code>.
 *
 *  @fixme If there is a browse window open and the user kills
 *  the HeaderFooterSelection dialog, the browse dialog will
 *  survive when it should have dissappeared as well.
 */
public class HeaderFooterSelection extends JDialog
{
	private Frame owner;
	private JCheckBox useHeader;
	private JCheckBox useFooter;
	private JTextField headerText;
	private JTextField footerText;
	private JButton headerBrowse;
	private JButton footerBrowse;
	private JButton okButton;
	private JButton cancelButton;
	private boolean cancelled = false;
	public HeaderFooterSelection(Frame owner,
								 String defaultHeaderName,
								 String defaultFooterName)
	{
		super(owner, "Header / Footer File Selection", true);
		this.owner = owner;
		setBounds(120, 120, 300, 110);
		Container pane = getContentPane();
		GridBagLayout layout = new GridBagLayout();
		pane.setLayout(layout);

		useHeader = new JCheckBox("use header", defaultHeaderName==null);
		useFooter = new JCheckBox("use header", defaultHeaderName==null);
		headerText = new JTextField(defaultHeaderName==null ? "" : defaultHeaderName);
		footerText = new JTextField(defaultFooterName==null ? "" : defaultFooterName);
		headerBrowse = new JButton("browse");
		footerBrowse = new JButton("browse");

		JPanel okCancelPanel = new JPanel();
		okCancelPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 2));
		okButton = new JButton("Ok");
		cancelButton = new JButton("Cancel");
		okCancelPanel.add(okButton);
		okCancelPanel.add(cancelButton);

		GridBagConstraints gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.BOTH;
		gbc.insets = new Insets(2, 2, 2, 2);
		layout.setConstraints(useHeader, gbc);
		layout.setConstraints(useFooter, gbc);
		gbc.weightx = 1.0;
		layout.setConstraints(headerText, gbc);
		layout.setConstraints(footerText, gbc);
		gbc.weightx = 0.0;
		gbc.gridwidth = GridBagConstraints.REMAINDER;
		layout.setConstraints(headerBrowse, gbc);
		layout.setConstraints(footerBrowse, gbc);
		gbc.weightx = 1.0;
		layout.setConstraints(okCancelPanel, gbc);

		pane.add(useHeader);
		pane.add(headerText);
		pane.add(headerBrowse);
		pane.add(useFooter);
		pane.add(footerText);
		pane.add(footerBrowse);
		pane.add(okCancelPanel);

		headerBrowse.addActionListener(new ActionListener()
			{ public void actionPerformed(ActionEvent e)
				{ browse(e.getSource()); }
			});
		footerBrowse.addActionListener(new ActionListener()
			{ public void actionPerformed(ActionEvent e)
				{ browse(e.getSource()); }
			});
		okButton.addActionListener(new ActionListener()
			{ public void actionPerformed(ActionEvent e)
				{ cancelled = false; setVisible(false); }
			});
		cancelButton.addActionListener(new ActionListener()
			{ public void actionPerformed(ActionEvent e)
				{ cancelled = true; setVisible(false); }
			});
	}

	/**
	 *  Register a listener with the ok button for this
	 *  dialog, so that custom behavior can be defined for when the
	 *  ok button is clicked.
	 */
	public void addOkActionListener(ActionListener listener)
	{
		okButton.addActionListener(listener);
	}

	/**
	 *  Browse the file system for a given file.
	 *  The source paramater is assumed to be either
	 *  'headerBrowse' or 'footerBrowse'.
	 * @param source the brose button clicked to inkoke this
	 *  method.
	 */
	private void browse(Object source)
	{
		String title = (source==headerBrowse) ? "header" : "footer";
		title = "Browse for " + title + " file";

		// get file from the browsing resource
		FileDialog fd = new FileDialog(owner, title);
		fd.setFile(source==headerBrowse ? headerText.getText()
										: footerText.getText());
		fd.setMode(FileDialog.LOAD);
		fd.show();
		String newFilename = fd.getFile();
		if (newFilename==null)
			return; // cancelled.
		newFilename = fd.getDirectory() + fd.getFile();

		if (source==headerBrowse)
			headerText.setText(newFilename);
		else
			footerText.setText(newFilename);
	}

	/**
	 *  Return the string given for the footer file name.
	 */
	public String getFooter()
	{
		return footerText.getText();
	}
	/**
	 *  Return the string given for the header file name.
	 */
	public String getHeader()
	{
		return headerText.getText();
	}
	/**
	 *  Return true IIF the cancel button was clicked.
	 */
	public boolean isCancelled()
	{
		return cancelled;
	}
	public static void main(String args[])
	{
		HeaderFooterSelection hf = new HeaderFooterSelection(null, "this", "that");
		hf.setVisible(true);
	}
	/**
	 *  Was/is the "use footer" checkbox checked?
	 */
	public boolean useFooter()
	{
		return this.useFooter.isSelected();
	}
	/**
	 *  Was/is the "use header" checkbox checked?
	 */
	public boolean useHeader()
	{
		return this.useHeader.isSelected();
	}
}