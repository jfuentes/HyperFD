package com.objectwave.viewUtility;

public interface MouseDispatchListener extends java.util.EventListener
{
	public boolean isAllowedToDispatch(java.awt.event.MouseEvent e);
}