package com.objectwave.viewUtility;

import java.awt.*;
import java.awt.event.*;

/**
* Useful when using Swing glass panes. It allows you to listen to 
* mouse events in the Glass pane layer, and then pass them on through to the
* content pane.
*/
public class MouseDispatcher implements MouseListener
{
	Container sourceContainer;
	MouseDispatchListener listener;
	
	public MouseDispatcher(Container source, MouseDispatchListener li)
	{
		sourceContainer = source;
		listener = li;
	}
	void dispatchTheEvent(MouseEvent e)
	{
		int [] x = new int [1];
		x[0] = e.getX();
		int [] y = new int [1];
		y[0] = e.getY();
		Component c = getMyMouseEventTarget(sourceContainer, x, y);
		if(c == null) return;
		sendTo(c, e, x[0], y[0]);
	}
	/**
	 * Fetchs the top-most (deepest) lightweight component that is interested
	 * in receiving mouse events.
	 */
	Component getMyMouseEventTarget(Container source, int [] x, int [] y)
	{
		Component component[] = source.getComponents();
		int ncomponents = component.length;
		
		for (int i = 0 ; i < ncomponents ; i++)
		{
		    Component comp = component[i];
		    Rectangle r = comp.getBounds();
		    if ((comp != null) && (comp.contains(x[0] - r.x, y[0] - r.y)) &&
			(comp.getPeer() instanceof java.awt.peer.LightweightPeer) &&
			(comp.isVisible() == true)) {
			// found a component that intersects the point, see if there is 
			// a deeper possibility.
			if (comp instanceof Container) {
			    Container child = (Container) comp;
			    Rectangle rp = child.getBounds();
			    int [] xn = new int[1];
			    int [] yn = new int[1];
			    xn [0] = x[0] - rp.x;
			    yn [0] = y[0] - rp.y;
			    Component deeper = getMyMouseEventTarget(child, xn, yn);
			    if (deeper != null) {
			        x[0] = xn[0];
			        y[0] = yn[0];
				return deeper;
			    }
			} else {
			    x[0] = x[0] - r.x;
			    y[0] = y[0] - r.y;
				// there isn't a deeper target, but this component is a target
				return comp;
			}
		    }
		}
		// didn't find a child target, return this component if it's a possible target
	    return source;
	}
	public void mouseClicked(MouseEvent e)
	{
		dispatchTheEvent(e);
	}
	public void mouseEntered(MouseEvent e)
	{
		dispatchTheEvent(e);
	}
	public void mouseExited(MouseEvent e)
	{
		dispatchTheEvent(e);
	}
	public void mousePressed(MouseEvent e)
	{
		dispatchTheEvent(e);
	}
	public void mouseReleased(MouseEvent e)
	{
		dispatchTheEvent(e);
	}
	protected void sendTo(Component mouseEventTarget , MouseEvent e, int x , int y)
	{
		MouseEvent retargeted = new MouseEvent(mouseEventTarget, 
											   e.getID(), 
											   e.getWhen(), 
											   e.getModifiers(),
											   x, 
											   y, 
											   e.getClickCount(), 
											   e.isPopupTrigger());
		if(listener.isAllowedToDispatch(retargeted))
			mouseEventTarget.dispatchEvent(retargeted);
	}
}