package com.objectwave.viewUtility;

import java.awt.event.*;
import java.awt.*;
import java.util.Hashtable;
/**
 */
class MouseTracker extends Component
{
	private MouseMotionListener listener = null;
	private MouseListener list = null;
	private boolean vert = false;
	private int col;
	public MouseTracker()
	{
	  enableEvents(AWTEvent.MOUSE_EVENT_MASK);
	  enableEvents(AWTEvent.MOUSE_MOTION_EVENT_MASK);
	}
	/**
	*/
	public MouseTracker(String str) {}
	/**
	*/
	public synchronized void addMouseListener(MouseListener l)
	{
		list = AWTEventMulticaster.add(list, l);
		enableEvents(AWTEvent.MOUSE_EVENT_MASK);
	}
	/**
	*/
	public synchronized void addMouseMotionListener(MouseMotionListener l)
	{
		listener = AWTEventMulticaster.add(listener, l);
		enableEvents(AWTEvent.MOUSE_MOTION_EVENT_MASK);
	}
	public int getColumn(){ return col; }
	/**
	*/
	public Dimension getMinimumSize()
	{
		return getPreferredSize();
	}
	/**
	*/
	public Dimension getPreferredSize()
	{
		return new Dimension(3, 3);
	}
	public boolean isVertical(){ return vert; }
	/**
	*/
	public void paint(Graphics g)
	{
		g.setColor(getBackground());
		g.fillRect(0,0,getSize().width-1,getSize().height-1);
		g.setColor(getForeground());
		g.fillRect(1,1,getSize().width-2,getSize().height-2);
		super.paint(g);
	}
	/**
	*/
	public void processMouseEvent(MouseEvent e)
	{
		if(list != null) {
			switch(e.getID()) {
			  case MouseEvent.MOUSE_RELEASED:
			   list.mouseReleased(e);
			   break;
			  case MouseEvent.MOUSE_ENTERED:
			   list.mouseEntered(e);
			   break;
			  case MouseEvent.MOUSE_EXITED:
			   list.mouseExited(e);
			   break;
			}
		}
		super.processMouseEvent(e);
	}
	/**
	*/
	public void processMouseMotionEvent(MouseEvent e)
	{
		if(listener != null) {
			switch(e.getID()) {
			  case MouseEvent.MOUSE_MOVED:
			   listener.mouseMoved(e);
			   break;
			  case MouseEvent.MOUSE_DRAGGED:
			   listener.mouseDragged(e);
			}
		}
		super.processMouseEvent(e);
	}
	/**
	*/
	public synchronized void removeMouseListener(MouseListener l)
	{
		list = AWTEventMulticaster.remove(
							list, l);
		super.removeMouseListener(l);
	}
	/**
	*/
	public synchronized void removeMouseMotionListener(MouseMotionListener l)
	{
		listener = AWTEventMulticaster.remove(
							listener, l);
		super.removeMouseMotionListener(l);
	}
	public void setColumn(int i){ col = i; }
	/**
	*/
	public void setEnterCursor()
	{
		this.setCursor(new Cursor(Cursor.CROSSHAIR_CURSOR));
/*        Component comp = this;
		while((!( comp instanceof Frame)) && comp != null)
			comp = comp.getParent();
		if(comp == null) return;
		Frame f = (Frame)comp;
		f.setCursor(cursor);
		System.out.println("Cha");
*/
	}
	/**
	*/
	public void setExitCursor()
	{
		this.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
	}
	public void setVertical(boolean aValue){ vert = aValue; }
}