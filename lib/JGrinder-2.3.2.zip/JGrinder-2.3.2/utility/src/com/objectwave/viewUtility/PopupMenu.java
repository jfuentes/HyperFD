package com.objectwave.viewUtility;

import javax.swing.*;
import javax.swing.event.*;
import java.awt.event.*;
import java.awt.*;
import java.beans.*;
import java.util.Vector;
import java.util.Enumeration;
/**
 * Encapsulate all of the support necessary to support popup menus.
 * Use like:
 *      PopupMenu menu = new PopupMenu();
 *      for(int i = 0; i < .length; ++i)
 *      {
 *          menu.add(action[i]);
 *      }
 *      myFrame.addMouseListener(menu);
 *
 * @version $Id: PopupMenu.java,v 2.1 2002/07/31 15:55:23 dave_hoag Exp $
 */
public class PopupMenu extends MouseAdapter implements PopupMenuListener
{
	protected JPopupMenu selectionPopup = null;
	protected java.awt.Point popupPoint;
	java.awt.Component component;
	VetoableChangeSupport beanSupport;
	transient Vector transients;
	/**
	 * Since this class is hiding the popup menu, the PopupMenuEvents will not contain
	 * this class as the source. This method enables the user of this class to determine
	 * if this instance is the source of the PopupMenuEvent.
	 *
	 * @param evt The real popup menu event.
	 */
	public boolean isEventSource(PopupMenuEvent evt)
	{
	    return evt.getSource() == selectionPopup;
	}
    /**
     * Add a PopupMenu listener
     *
     * @param l The Listener to add.
     */
    public void addPopupMenuListener(PopupMenuListener l)
    {
        selectionPopup.addPopupMenuListener(l);
    }
    /**
     * Remove a PopupMenu listener
     *
     * @param l The listener to remove.
     */
    public void removePopupMenuListener(PopupMenuListener l)
    {
        selectionPopup.removePopupMenuListener(l);
    }
    /**
     * Add a VetoableListener to the listener list.
     * Allow listeners to Veto the display of the popup. A PropertyChangeEvent with the property
     * name of 'showPopup' will be generated. The newValue of the event will be the deepest
     * component at that popup point.
     *
     * @param listener  The VetoableChangeListener to be added
     */
    public void addVetoableChangeListener(VetoableChangeListener listener)
    {
        beanSupport.addVetoableChangeListener(listener);
    }
    /**
     * Remove a VetoableChangeListener from the listener list.
     * @param listener  The VetoableChangeListener to be removed
     */
    public void removeVetoableChangeListener( VetoableChangeListener listener)
    {
        beanSupport.removeVetoableChangeListener(listener);
    }
    /**
     */
    public void popupMenuWillBecomeVisible(PopupMenuEvent e){}
    /**
     */
    public void popupMenuCanceled(PopupMenuEvent e){}
    /**
     */
    public void popupMenuWillBecomeInvisible(PopupMenuEvent e)
    {
    	popupClosed();
    }
    /**
	 */
	public PopupMenu()
	{
        selectionPopup= new javax.swing.JPopupMenu();
        selectionPopup.addPopupMenuListener(this);
        beanSupport = new VetoableChangeSupport(this);
        transients = new Vector();
	}
	/**
	 * The point within the 'component' that mouse was righclicked.
	 */
	public Point getPopupPoint()
	{
	    return popupPoint;
	}
	/** */
	protected synchronized void popupClosed()
	{
		Enumeration enum = transients.elements();
		while(enum.hasMoreElements())
		{
			Component obj = (java.awt.Component)enum.nextElement();
			selectionPopup.remove(obj);
		}
	}
	/**
	 * The component in which the mouse was righclicked.
	 */
	public Component getComponent() { return component; }
	/**
	 * In the event we have nested components, this will get the deepest component at that point.
	 *
	 * @return java.awt.Component Deepest component at that point.
	 */
	public Component getPopupComponent()
	{
        return SwingUtilities.getDeepestComponentAt(component, popupPoint.x, popupPoint.y);
	}
	/**
	 * @param e MouseEvent The event
	 */
	public void mousePressed(MouseEvent e)
	{
		if(selectionPopup== null) return;
		if((e.getModifiers() & InputEvent.BUTTON3_MASK) != 0)
		{
			component = (java.awt.Component) e.getSource();
			try
			{
			    popupPoint = e.getPoint();
                beanSupport.fireVetoableChange("showPopup", null, getPopupComponent());
			    selectionPopup.show((java.awt.Component) e.getSource(), e.getPoint().x, e.getPoint().y);
			}
			catch(PropertyVetoException ex)
			{
			    component = null;
			    return;
			}
		}
	}
    /**
     * Delegate to the real popup menu.
     */
    public void addSeparator()
    {
        selectionPopup.addSeparator();
    }
    /**
     * Delegate to the real popup menu.
     */
    public synchronized void addTransientSeparator()
    {
        selectionPopup.addSeparator();
        int count = selectionPopup.getComponentCount() - 1;
        Component separator = selectionPopup.getComponentAtIndex(count);
        transients.addElement(separator);
    }
    /**
     * Append a new menuitem to the end of the menu which
     * dispatches the specified Action object. After the menu is closed, this menu item
     * will be removed from the list of items. Usefull for context specific menus.
     *
	 * @param act The Action object contains all of the information to create both the Menu label
	 * and the action to take upon selection.
     * @see Action
     */
    public synchronized JMenuItem addTransientMenuItem(Action act)
    {
    	JMenuItem item = add(act);
    	transients.addElement(item);
    	return item;
    }
    /**
     * Append a new menuitem to the end of the menu which
     * dispatches the specified Action object.
     *
	 * @param act The Action object contains all of the information to create both the Menu label
	 * and the action to take upon selection.
     * @see Action
     */
    public JMenuItem add(Action act)
    {
        JMenuItem mi;
        if(act.getValue("checkBox") == null)
        {
            mi = new JMenuItem((String)act.getValue(Action.NAME),
                                    (Icon)act.getValue(Action.SMALL_ICON));
        }
        else
        {
            mi = new JCheckBoxMenuItem((String)act.getValue(Action.NAME),
                                    (Icon)act.getValue(Action.SMALL_ICON));
        }
        //mi.setMnemonic(((String)act.getValue(Action.NAME)).charAt(0));
        mi.setHorizontalTextPosition(JButton.RIGHT);
        mi.setVerticalTextPosition(JButton.CENTER);
        mi.setEnabled(act.isEnabled());
        mi.addActionListener(act);
        selectionPopup.add(mi);
        PropertyChangeListener actionPropertyChangeListener = createActionChangeListener(mi);
        act.addPropertyChangeListener(actionPropertyChangeListener);
        return mi;
    }
    /**
     */
    protected PropertyChangeListener createActionChangeListener(JMenuItem b)
    {
        return new ActionChangedListener(b);
    }
    /**
     * Expanded from the default of JPopupMenu to include updates the icon.
     */
    protected class ActionChangedListener implements PropertyChangeListener
    {
        JMenuItem menuItem;
        ActionChangedListener(JMenuItem mi)
        {
            super();
            this.menuItem = mi;
        }
        public void propertyChange(PropertyChangeEvent e)
        {
            String propertyName = e.getPropertyName();
            if (e.getPropertyName().equals(Action.NAME))
            {
                String text = (String) e.getNewValue();
                menuItem.setText(text);
            }
            else
            if (propertyName.equals("enabled"))
            {
                Boolean enabledState = (Boolean) e.getNewValue();
                menuItem.setEnabled(enabledState.booleanValue());
            }
            else
            if (propertyName.equals(Action.SMALL_ICON))
            {
                menuItem.setIcon((Icon)e.getNewValue());
//                menuItem.repaint();
            }
        }
    }
	public static class Test extends com.objectwave.test.UnitTestBaseImpl
	{
		public static void main(String [ ]args)
		{
			com.objectwave.test.TestRunner.run( new Test(), args );
			System.exit(0);
		}
	    /**
	     */
	    public void testActionAdds()
	    {
	        Action act = new AbstractAction("One"){ public void actionPerformed(java.awt.event.ActionEvent e) {} };
	        PopupMenu menu = new PopupMenu();
	        menu.add(act);
	        testContext.assertEquals("One", ((JMenuItem)menu.selectionPopup.getComponentAtIndex(0)).getText());
	    }
	    /**
	     */
	    public void testMenuShow()
	    {
	        System.getProperties().remove("evt");
	        Action act = new AbstractAction("One"){ public void actionPerformed(java.awt.event.ActionEvent e) { System.getProperties().put("evt", e); } };
	        PopupMenu menu = new PopupMenu();
	        menu.add(act);
	        JFrame f = new JFrame("TestFrame");
	        f.setBounds(10,10,100,100);
	        f.getContentPane().addMouseListener(menu);
	        f.setVisible(true);
	        MouseEvent me = new MouseEvent(f.getContentPane(),
                  MouseEvent.MOUSE_PRESSED,
                  new java.util.Date().getTime(),
                  InputEvent.BUTTON3_MASK, 10, 10, 1, false);
	        f.getContentPane().dispatchEvent(me);
	        Thread.currentThread().yield();
	        testContext.assertTrue("Menu failed to activate with a mouse event", menu.selectionPopup.isVisible());
	        ((JMenuItem)menu.selectionPopup.getComponentAtIndex(0)).doClick();
	        testContext.assertTrue("No event occured.", System.getProperties().get("evt") != null);
	        f.dispose();
	    }
	}
}
