package com.objectwave.viewUtility;

import javax.swing.event.*;

/** Allows for tighter interaction with property dialog.  Anyone who
*  implements this interface must also be a subclass of component.
*/
public interface PropertyPanel
{
	public void acceptChanges();
	public void addChangeListener(ChangeListener l);
	public String getTabName();
	public boolean isRendered();
	public void removeChangeListener(ChangeListener l);
	/** Entry point for creating all of the parts of a tab.
	*/
	public void renderTab();
	public void tabSelected();
}
