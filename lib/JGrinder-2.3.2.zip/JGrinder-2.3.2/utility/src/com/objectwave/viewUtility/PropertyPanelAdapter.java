package com.objectwave.viewUtility;

import java.awt.event.*;

import javax.swing.*;
import javax.swing.event.*;

/** Allows for tighter interaction with property dialog.  This implements many of
* the component listeners so that it can update that a screen has changed.
*/
public class PropertyPanelAdapter extends java.awt.Panel
		implements PropertyPanel, javax.swing.event.ChangeListener, ItemListener, DocumentListener, TextListener
{
	protected String tab;
	protected boolean rendered = false;
	protected boolean changed;
	EventListenerList changes = new EventListenerList();

	public PropertyPanelAdapter(String tabName){
		setTabName(tabName);
	}
	public void acceptChanges(){
		if(changed) fillDomainObject();
		changed = false;
	}
	public void addChangeListener(ChangeListener x){
		changes.add(ChangeListener.class, x);
	}
	public void changedUpdate(DocumentEvent e){ hasChanged(true); }
	/**  Subclass me to fill my values when my screen has changed.
	*/
	public void fillDomainObject(){
	}
	public String getTabName(){
		return tab;
	}
	public void hasChanged(boolean aValue){
		changed = aValue;
		// Only notify dialog if going to a true state.
		if(changes != null && aValue) stateChanged();
	}
	public void insertUpdate(DocumentEvent e){ hasChanged(true); }
	public boolean isRendered(){
		return rendered;
	}
	public void itemStateChanged(ItemEvent e){ hasChanged(true); }
	public void removeChangeListener(ChangeListener x){
		changes.remove(ChangeListener.class, x);
	}
	public void removeUpdate(DocumentEvent e){ hasChanged(true); }
	/** Entry point for creating all of the parts of a tab.  This should be
	* overridden.
	*/
	public void renderTab(){
		rendered = true;
		add(new JLabel("Test!"));
	}
	public void setTabName(String aValue){
		tab = aValue;
	}
	public void stateChanged(){
	    ChangeEvent changeEvent = null;
	    if(changes != null){
			// Guaranteed to return a non-null array
			Object[] listeners = changes.getListenerList();
			// Process the listeners last to first, notifying
			// those that are interested in this event
			for (int i = listeners.length-2; i>=0; i-=2){
				if (listeners[i]==ChangeListener.class) {
					// Lazily create the event:
					if (changeEvent == null) changeEvent = new ChangeEvent(this);
					((ChangeListener)listeners[i+1]).stateChanged(changeEvent);
				}
			}
		}
	}
	public void stateChanged(ChangeEvent e){ hasChanged(true); }
	public void tabSelected(){
	}
	public void textValueChanged(TextEvent e){  hasChanged(true); }
}
