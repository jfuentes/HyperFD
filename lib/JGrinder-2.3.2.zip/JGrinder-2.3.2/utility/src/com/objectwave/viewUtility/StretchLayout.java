package com.objectwave.viewUtility;

import javax.swing.*;
import java.awt.*;
import java.util.Hashtable;

/**
 * This layout manager is neat. Check out the reference text for
 *  StretchLayoutConstraints for more information.
 */
public class StretchLayout implements java.awt.LayoutManager
{
	private Hashtable hashtable = null;
	public com.objectwave.utility.DebugOutput debug = new com.objectwave.utility.DebugOutput(0, "StretchLayout: ");
	/**
	 * addLayoutComponent method comment.
	 */
	public void addLayoutComponent(String name, java.awt.Component comp)
	{
	}
	/**
	 * @return com.objectwave.utility.DebugOutput
	 */
	public com.objectwave.utility.DebugOutput getDebug() {
		return debug;
	}
	/**
	 * @return java.util.Hashtable
	 */
	protected Hashtable getHashtable()
	{
		if (hashtable == null)
			hashtable = new Hashtable(10);
		return hashtable;
	}
	/**
	 * layoutContainer method comment.
	 */
	public void layoutContainer(java.awt.Container parent)
	{
		Component[] components = parent.getComponents();
		if (components == null)
			return;
		Hashtable table = getHashtable();
		Rectangle bounds = new Rectangle();
		for (int i=0; i < components.length; ++i)
		{
			StretchLayoutConstraints c = (StretchLayoutConstraints)table.get(components[i]);
			Dimension size = parent.getSize();
			if (c == null)
			{
			    debug.println(6, "Component #" + i + " (" + components[i].hashCode() + ") has no constraints.");
				c = new StretchLayoutConstraints();
			}

			debug.println(6, "For component #" + (i+1) + ":");
			debug.println(6, "\tConstraint: " + c);

			bounds.y = c.top + (int)Math.round(size.height * c.topMult);
			bounds.x = c.left + (int)Math.round(size.width * c.leftMult);
			bounds.height = c.bottom + (int)Math.round(size.height * c.bottomMult) - bounds.y;
			bounds.width = c.right + (int)Math.round(size.width * c.rightMult) - bounds.x;
			debug.println(6, "\tBounds: " + bounds);
			components[i].setBounds(bounds);
		}
	}
	/**
	 * Starts the application.
	 * @param args an array of command-line arguments
	 */
	public static void main(java.lang.String[] args)
	{
		String numbers[] = { "zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten" };
		JPanel panel = new JPanel();
		StretchLayout layout = new StretchLayout();
		panel.setLayout(layout);

		layout.getDebug().setLevel(10);

		StretchLayoutConstraints slcLabel  = new StretchLayoutConstraints();
		StretchLayoutConstraints slcButton = new StretchLayoutConstraints();

		for (int i = 1; i <= 10; ++i)
		{
			JLabel  label  = new JLabel("button " + (i<=190 ? (""+i) : numbers[i]) + ":");
			JButton button = new JButton("button " + i*i);
			slcLabel.top = slcButton.bottom;
			slcLabel.left = 0;
			slcLabel.bottom = slcButton.bottom + label.getPreferredSize().height;
			slcLabel.right = 60;
			layout.setConstraints(label, slcLabel);
			slcButton.top = slcButton.bottom + 2;
			slcButton.left = slcLabel.right + 5;
			slcButton.bottom = slcButton.top + button.getPreferredSize().height;
			slcButton.right = -5;
			slcButton.rightMult = 1.0;
			layout.setConstraints(button, slcButton);
			panel.add(label);
			panel.add(button);
		}

		StretchLayoutConstraints slcLHS = new StretchLayoutConstraints();
		StretchLayoutConstraints slcRHS = new StretchLayoutConstraints();

		slcLHS.top       = slcButton.bottom + 3;
		slcLHS.left      = 0;
		slcLHS.bottom    = 0;
		slcLHS.right     = 0;
		slcLHS.rightMult = 0.5;
		slcLHS.bottomMult= 1.0;

		slcRHS.top       = slcLHS.top;
		slcRHS.left      = 0;
		slcRHS.leftMult  = 0.5;
		slcRHS.bottom    = 0;
		slcRHS.right     = -20;
		slcRHS.rightMult = 1.0;
		slcRHS.bottomMult= 1.0;

		JPanel lhs = new JPanel();
		lhs.setBorder(new javax.swing.border.TitledBorder("Left-Hand Side"));
		layout.setConstraints(lhs, slcLHS);
		panel.add(lhs);
		JPanel rhs = new JPanel();
		rhs.setBorder(new javax.swing.border.TitledBorder("Right-Hand Side"));
		layout.setConstraints(rhs, slcRHS);
		panel.add(rhs);
        JFrame af = null;
		JDialog dialog = new JDialog(af, "test layout", true);
		dialog.setBounds(300, 300, 400, 300);
		dialog.getContentPane().setLayout(new BorderLayout());
		dialog.getContentPane().add(panel);
		dialog.setVisible(true);
		System.exit(0);
	}
	/**
	 * minimumLayoutSize method comment.
	 */
	public java.awt.Dimension minimumLayoutSize(java.awt.Container parent)
	{
		return new Dimension(0, 0);
	}
	/**
	 * preferredLayoutSize method comment.
	 */
	public java.awt.Dimension preferredLayoutSize(java.awt.Container parent)
	{
		return new Dimension(0, 0);
	}
	/**
	 * removeLayoutComponent method comment.
	 */
	public void removeLayoutComponent(java.awt.Component comp)
	{
	}
	/**
	 * This method was created in VisualAge.
	 * @param c java.awt.Component
	 * @param constraints com.objectwave.viewUtility.StretchLayoutConstraints
	 */
	public void setConstraints(Component c, StretchLayoutConstraints constraints)
	{
		debug.println(7, "put component " + c.hashCode());
		getHashtable().put(c, constraints.duplicate());
	}
	/**
	 * This method was created in VisualAge.
	 * @param newValue com.objectwave.utility.DebugOutput
	 */
	public void setDebug(com.objectwave.utility.DebugOutput newValue) {
		this.debug = newValue;
	}
}