package com.objectwave.viewUtility;

/**
 * Constraints for the StretchLayout.
 * Each of the constrained edges of the component (top, left, bottom, right)
 * are defined as a linear equation "S + M*d", where S=scalar, M=multiplier,
 * and d=dimension.  This means that the top-left and bottom-right corners 
 * of the component are defined to be:
 *      (left + width*leftMult, top + height*topMult)
 *      (right + width*rightMult, bottom + height*bottomMult)
 * Where (width,height) are the dimensions of the container.  Although simple,
 * this layout manager is very powerful.
 */
public class StretchLayoutConstraints implements Cloneable
{
	public int top    = 0;
	public int left   = 0;
	public int bottom = 0;
	public int right  = 0;

	/**
	 *  These values should be in the range 0..1
	 */
	public double topMult    = 0.0;
	public double leftMult   = 0.0;
	public double bottomMult = 0.0;
	public double rightMult  = 0.0;
	
	/**
	 * A publicized cloning method.
	 * @return com.objectwave.viewUtility.StretchLayoutConstraints
	 */
	public StretchLayoutConstraints duplicate()
	{
		try
		{
			return (StretchLayoutConstraints)clone();
		} catch (Exception e) { return null; }
	}
	/**
	 * Set all multipliers
	 */
	public void setMultipliers(double top, double left, double bottom, double right)
	{
		this.topMult = top;
		this.leftMult = left;
		this.bottomMult = bottom;
		this.rightMult = right;
	}
	/**
	 * Set all scalar values
	 */
	public void setScalars(int top, int left, int bottom, int right)
	{
		this.top = top;
		this.left = left;
		this.bottom = bottom;
		this.right = right;
	}
	/**
	 * Stringify this object.
	 * @return java.lang.String
	 */
	public String toString()
	{
		String str = "[ scalars (t,l,b,r) -> (" + top + "," + left + "," + bottom + "," + right + ")";
		return str + " ; multipliers (" + topMult + "," + leftMult + "," + bottomMult + "," + rightMult + ") ]";
	}
}