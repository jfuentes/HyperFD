package com.objectwave.viewUtility;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
import com.objectwave.utility.*;
import javax.swing.border.*;
/**
 * Provides the ability to create a vector of buttons from a vector of
 * data.  The method getButtons() will return the buttons generated, and
 * getPanel() will return the buttons contained in a JPanel using a
 * vertically-oriented GridLayout.  Note that the buttons and the panel
 * will automatically update with calls to the various setXxx() methods.
 * The same panel will always be returned for a given instance of this
 * class, while the buttons array will change if and only if the data vector
 * is changed.
 *
 * <b>Displaying Labels:</b><p>
 * The labels for the buttons can be specified if three different
 * ways. A vector of strings can be provided via the setLabels() method,
 * a StringifyIF instance can be provided, or the toString() value of each
 * data element can be used.  If a vector of strings is provided, then that
 * will be used over all other methods.  Otherwise, if a stringifier is
 * defined, then it will be used.  If all else failed the toString() values
 * are used.
 *
 * <p><b>Customizing the Buttons' Appearance</b><br>
 * The font of all of the buttons can be specified simply by calling
 * setFont().  Additionally, the layout can be modified by calling
 * getPanel().setLayout(someLayoutManager).  This should be followed by
 * getPanel().revalidate() if the panel may currently be visible.
 *
 * <p><b>Specifying Button Behavior</b><br>
 * A common behavior can be associated with all of the buttons by calling
 * setAction() with some ActionIF object.  This interface's single method,
 * <i>public void performAction(Object)</i>, is passed the data element
 * associated with the button that was clicked.  This single ActionIF
 * object is applied to all buttons.  If this is not desired for a given
 * button, then simply call removeListener(int), passing the index of the
 * given button.
 */
public class VectorToButtons
{
	private StringifyIF stringifier;
	private ActionIF action;
	private ActionListener actionListener;
	private Vector data;
	private Vector strings;
	private JButton buttons[];
	private JPanel panel;
	private Font font;

	private boolean actionInProgress=false;

	private static class CustomizePanel
	{
		static boolean stringify;
		static boolean flowLayout;
		static VectorToButtons buttonMaker;
		static ActionListener action1;
		static ActionListener action2;
		static JPanel getPanel()
		{
			JPanel panel = new JPanel();
			panel.setBorder(new TitledBorder("Controls"));
			panel.setLayout(new FlowLayout());
			JButton button;
			panel.add(button = new JButton("Caps"));
			button.addActionListener(new ActionListener()
				{ public void actionPerformed(ActionEvent e)
					{
						if (stringify = !stringify)
						{
							buttonMaker.setStringifier(new StringifyIF()
								{ public String toString(Object o)
									{ return o.toString().toUpperCase(); } } );
							buttonMaker.getPanel().revalidate();
						}
						else
						{
							buttonMaker.setStringifier(null);
							buttonMaker.getPanel().revalidate();
						}
					} } );

			panel.add(button = new JButton("Layout"));
			button.addActionListener(new ActionListener()
				{ public void actionPerformed(ActionEvent e)
					{
				  //      buttonMaker.getPanel().removeAll();
						if (flowLayout = !flowLayout)
							buttonMaker.getPanel().setLayout(new FlowLayout());
						else
							buttonMaker.getPanel().setLayout(new GridLayout(buttonMaker.getData().size(),1) );
				  //      for (int i=0; i < buttonMaker.getButtons().length; ++i)
				  //          buttonMaker.getPanel().add(buttonMaker.getButtons()[i]);
						buttonMaker.getPanel().revalidate();
					} } );
			panel.add(button = new JButton("Action1"));
			button.addActionListener(new ActionListener()
				{ public void actionPerformed(ActionEvent e)
					{
						buttonMaker.setAction(new ActionIF()
							{ public void performAction(Object o)
								{ System.out.println("You clicked \"" + o + "\""); } } );
					} } );
			panel.add(button = new JButton("Action2"));
			button.addActionListener(new ActionListener()
				{ public void actionPerformed(ActionEvent e)
					{
						buttonMaker.setAction(new ActionIF()
							{ public void performAction(Object o)
								{
									JOptionPane.showMessageDialog(null,
										"Clicked \"" + o + "\"", "CLICK",
										JOptionPane.INFORMATION_MESSAGE);
								} } );
					} } );
			return panel;
		}
	}
	/**
	 * Constructors:
	 */
	public VectorToButtons() { this(null, null); }
	public VectorToButtons(Vector data) { this(data, null); }
	public VectorToButtons(Vector data, Vector strings)
	{
		setLabels(strings);
		setData(data);
	}
	protected void action(Object source)
	{
		if (action == null || buttons == null || actionInProgress)
			return;
		actionInProgress = true;
		for (int i=0; i < buttons.length; ++i)
		{
			if (source == buttons[i])
			{
				if (data != null && data.size() > i)
					action.performAction(data.elementAt(i));
				else
					action.performAction(null);
			}
		}
		actionInProgress = false;
	}
	public JButton[]   getButtons()     { return buttons; }
	public Vector      getData()        { return data; }
	public Font        getFont()        { return font; }
	public StringifyIF getLabelifier() { return stringifier; }
	public Vector      getLabels()     { return strings; }
	public JPanel      getPanel()       { return panel; }
	/**
	 * The rest of this class definition is for testing:
	 */
	public static void main(String args[])
	{
		Vector v = new Vector(args.length);
		if (args.length == 0)
		{
			System.out.println("[ expected n arguments for n buttons. ]");
			return;
		}
		for (int i=0; i < args.length; ++i)
			v.addElement(args[i]);
		CustomizePanel.buttonMaker = new VectorToButtons(v);
		CustomizePanel.buttonMaker.getPanel().setBorder(new TitledBorder("Panel"));
        JFrame af = null;
		JDialog dialog = new JDialog(af, "Test #1", true);
		dialog.setBounds(100, 100, 400, 400);
		dialog.getContentPane().add("Center", CustomizePanel.buttonMaker.getPanel());
		dialog.getContentPane().add("South",  CustomizePanel.getPanel());
		dialog.setVisible(true);
		System.exit(1);
	}
	/**
	 * Remove the index'th button's action listener.
	 */
	public void removeListener(int index)
	{
		if (index < 0 || buttons==null || index >= buttons.length)
			buttons[index].removeActionListener(actionListener);
	}
	public void setAction(ActionIF act)
	{
		action = act;
	}
	public void setData(Vector data)
	{
		this.data = data;
		updateAll();
	}
	public void setFont(Font f)
	{
		font = f;
		updateFont();
	}
	public void setLabels(Vector strings)
	{
		this.strings = strings;
		updateLabels();
	}
	public void setStringifier(StringifyIF s)
	{
		stringifier = s;
		updateLabels();
	}
	/**
	 * Remake the button vector.
	 */
	protected void updateAll()
	{
		if (data == null)
		{
			buttons = null;
			panel = null;
			return;
		}
		if (actionListener == null)
		{
			actionListener = new ActionListener()
				{ public void actionPerformed(ActionEvent evt) { action(evt.getSource()); } };
		}
		buttons = new JButton[data.size()];
		if (panel == null)
			panel = new JPanel();
		else
			panel.removeAll();
		panel.setLayout(new GridLayout(buttons.length, 1));
		for (int i=0; i < buttons.length; ++i)
		{
			Object datum = data.elementAt(i);
			buttons[i] = new JButton();
			buttons[i].setOpaque(true);
			buttons[i].addActionListener(actionListener);
			panel.add(buttons[i]);
		}
		updateLabels();
		updateFont();
	}
	protected void updateFont()
	{
		if (font == null)
			return;
		for (int i=0; i < buttons.length; ++i)
			buttons[i].setFont(font);
	}
	protected void updateLabels()
	{
		if (buttons == null)
			return;
		for (int i=0; i < buttons.length; ++i)
		{
			String title="";
			if (strings != null && strings.size() > i)
				title = (String)strings.elementAt(i);
			else if (stringifier == null && (data==null || data.size()<=i))
				title = "";
			else
			{
				Object o = data.elementAt(i);
				title = stringifier==null ? (""+o) : stringifier.toString(o);
			}
			buttons[i].setText(title);
		}
	}
}