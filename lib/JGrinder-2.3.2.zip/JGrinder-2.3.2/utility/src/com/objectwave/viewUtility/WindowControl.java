package com.objectwave.viewUtility;

import java.awt.*;

/**
* Some generic routines that will manipulate various UI properties.
*/
public class WindowControl extends java.lang.Object
{
	/**
	*/
	public static void centerWindow(Window win)
	{
		Dimension screenDim = Toolkit.getDefaultToolkit().getScreenSize();
		// If larger than screen, reduce window width or height
		if (screenDim.width < win.getSize().width) {
			win.setSize(screenDim.width, win.getSize().height);
		}
		if (screenDim.height < win.getSize().height) {
			win.setSize(win.getSize().width, screenDim.height);
		}
		// Center Frame, Dialogue or Window on screen
		int x = (screenDim.width - win.getSize().width) / 2;
		int y = (screenDim.height - win.getSize().height) / 2;
		win.setLocation(x, y);
	}
	/**
	*/
	public static void enforceMinimumSize(Component comp, int minWidth, int minHeight)
	{
		if (comp.getSize().width < minWidth) {
			comp.setSize(minWidth, comp.getSize().height);
		}
		if (comp.getSize().height < minHeight) {
			comp.setSize(comp.getSize().width, minHeight);
		}
	}
}