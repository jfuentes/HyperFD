import junit.framework.TestCase;
import junit.framework.Test;
import com.objectwave.test.BatchRunner;
/**
 * A simple wrapper
 * to load all of tests that have been embeded as ObjectWave tests.
 */
public class RunAllTest extends TestCase
{
	public static Test suite()
	{
		return new BatchRunner().getTestRunner(null).getMasterSuite();
	}
}
