
cd $1
cd bin
pwd 
rmiregistry &
sleep 1
java -cp . de.htwdd.ga.rmi.RemoteFitness

