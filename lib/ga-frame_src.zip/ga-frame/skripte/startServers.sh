
dir=`pwd`

for server in `cat serverList` 
do
	echo $server
	ssh $server $dir/rmiStart.sh $dir &
done
