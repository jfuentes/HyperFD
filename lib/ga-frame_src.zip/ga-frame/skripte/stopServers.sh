
for server in `cat serverList` 
do
	echo $server
	ssh $server killall java
	ssh $server killall rmiregistry
done
