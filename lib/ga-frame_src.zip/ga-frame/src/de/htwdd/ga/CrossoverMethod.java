package de.htwdd.ga;

/**
 * Classes implementing this interface provide a {@link de.htwdd.ga.GeneticAlgorithm} with a mating
 * strategy.
 */
public interface CrossoverMethod
{

	/**
	 * Creates a set of new individuals based on the chromosomes of the parents.
	 * 
	 * @param parents a set of mating candidates
	 * @param chromosomeLength the length of an individuals chromosome. Provided because
	 *        <tt>BitSet</tt> does not calculate it's length correctly
	 * @return a set of "children"
	 */
	public Individual[] crossover(Individual[] parents, int chromosomeLength);

}
