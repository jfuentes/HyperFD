package de.htwdd.ga;

import de.htwdd.ga.util.IndividualSorter;

/**
 * An implementation of <tt>ReplacmentStrategy</tt> that forms the next generation of individuals
 * by selecting the fittest individuals from the parent and child population. The size of the new
 * population equals the size of the parent population. <br>
 * {@link de.htwdd.ga.GeneticAlgorithm} uses this replacement strategy by default.
 */
public class Elitism implements ReplacementStrategy
{

	/**
	 * {@inheritDoc}
	 */
	public Individual[] replace(Individual[] population, Individual[] children)
	{
		// merge old population + children
		Individual pool[] = new Individual[population.length + children.length];
		System.arraycopy(population, 0, pool, 0, population.length);
		System.arraycopy(children, 0, pool, population.length, children.length);

		// sort and shrink
		IndividualSorter.sortIndividuals(pool);
		System.arraycopy(pool, 0, population, 0, population.length);

		return population;
	}

}
