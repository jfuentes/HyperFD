package de.htwdd.ga;

import de.htwdd.ga.util.GaXmlUtil;

/**
 * Use this class to initialize a genetic algorithm with a population specified in a file.
 */
public class FileInitialization extends InitializationFunction
{
	private String	filename	= null;

	/**
	 * @param filename XML file containing the initial population
	 */
	public FileInitialization(String filename)
	{
		super();
		this.filename = filename;
	}

	/**
	 * Extracts an initial population from the file specified in the constructor.
	 */
	@Override
	public Individual[] initializePopulation()
	{
		return GaXmlUtil.extractFromFile(filename).toArray(new Individual[0]);
	}
}
