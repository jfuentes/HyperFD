package de.htwdd.ga;

import java.util.BitSet;

/**
 * Basic interface that has to be implemented to provide a <tt>GeneticAlgorithm</tt> with a
 * problem specific fitness function.
 * 
 * @see de.htwdd.ga.GeneticAlgorithm
 */
public interface FitnessFunction
{

	/**
	 * Calculate the fitness for a given chromosome.
	 * 
	 * @param chromosome 
	 * @return the fitness of the given chromosome
	 */
	public abstract double computeFitness(BitSet chromosome);

}
