package de.htwdd.ga;

import java.util.concurrent.CyclicBarrier;

import de.htwdd.ga.util.QueuedArrayList;

/**
 * The <tt>GeneticAlgorithm</tt> class is able to spread the calculation of a population on
 * multiple threads. <br>
 * A <tt>FitnessRunner</tt> is provided with a queue of individuals. As long as the queue contains
 * individuals, the <tt>FitnessRunner.
 */
public class FitnessRunner extends Thread
{
	/**
	 * The <tt>FitnessRunner</tt> takes individuals from this queue to update their fitness.
	 * 
	 * @uml.property name="queue"
	 */
	private QueuedArrayList<Individual>	queue;

	/**
	 * The <tt>FitnessFunction</tt> this thread uses.
	 * 
	 * @uml.property name="fitnessFunction"
	 */
	private FitnessFunction				fitnessFunction	= null;

	/**
	 * If <tt>true</tt>, this thread's fitness function does not work properly.
	 * 
	 * @uml.property name="broken"
	 */
	private boolean						broken			= false;

	/**
	 * Creates and initializes a new <tt>FitnessRunner</tt> thread.
	 * 
	 * @param queue holds the individuals that have to be updated
	 * @param fitnessFunction
	 */
	public FitnessRunner(QueuedArrayList<Individual> queue, FitnessFunction fitnessFunction)
	{
		this.fitnessFunction = fitnessFunction;
		this.queue = queue;
	}

	private CyclicBarrier	barrier;

	/**
	 * Takes individuals from the queue (while it is not empty) and updates their fitness.<br>
	 * If the update process of an individual failed (<tt>RuntimeException</tt> occured), the
	 * individual is pushed back into the queue and the <tt>FitnessRunner</tt> is marked <i>broken</i>.
	 */
	@Override
	public void run()
	{
		Individual individual;

		while (!isInterrupted())
		{
			try
			{
				barrier.await();

				if (!broken)
					while (null != (individual = queue.take()))
					{
						individual.setFitnessFunction(fitnessFunction);
						try
						{
							individual.updateFitness();
						}
						catch (RuntimeException e)
						{
							e.printStackTrace();
							queue.put(individual);
							broken = true;
							break;
							// return;
						}
					}
				
				barrier.await();
			}
			catch (Exception e)
			{
				System.out.println("Thread interrupted");
				return;
			}
		}
	}

	/**
	 * @uml.property name="broken"
	 */
	public boolean isBroken()
	{
		return broken;
	}

	/**
	 * @uml.property name="fitnessFunction"
	 */
	public FitnessFunction getFitnessFunction()
	{
		return fitnessFunction;
	}

	public void setBarrier(CyclicBarrier barrier)
	{
		this.barrier = barrier;
	}
}
