package de.htwdd.ga;

import java.rmi.Naming;
import java.util.ArrayList;
import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;

import de.htwdd.ga.rmi.RemoteFitness;
import de.htwdd.ga.rmi.RemoteFitnessFunction;
import de.htwdd.ga.rmi.RemoteFitnessInterface;
import de.htwdd.ga.util.IndividualSorter;
import de.htwdd.ga.util.QueuedArrayList;

/**
 * The central class of the genetic algorithm framework. It administrates the populations, connects
 * the different strategies and controls the evolution process.<br>
 * The mutation rate is set to 10% by default.<br>
 * The different strategies are initialized with the following default values:
 * <ul>
 * <li>{@link de.htwdd.ga.InitializationFunction}</li>
 * <li>{@link de.htwdd.ga.RandomSelection}</li>
 * <li>{@link de.htwdd.ga.SinglePointCrossover}</li>
 * <li>{@link de.htwdd.ga.Elitism}</li>
 * </ul>
 * <p>
 * A program that wants to use <tt>GeneticAlgorithm</tt> has to instantiate this class and provide
 * at least an implementation of {@link de.htwdd.ga.FitnessFunction}. All other strategies do not
 * nessecarilly have to be overwritten.
 * </p>
 * <p>
 * The evolutionary process is controlled by the <tt>run</tt> method, which implements the
 * template method pattern (see sequence diagram {@link de.htwdd.ga}). That makes it easy for
 * subclasses to customize the evolutionary process.
 * </p>
 * <p>
 * <tt>GeneticAlgorithm</tt> is able to spread the calculation of a population's fitness on
 * multiple threads (see {@link de.htwdd.ga.FitnessRunner}). To do so, set the property
 * <tt>multiThreaded</tt> to <tt>true</tt>. <br>
 * Whenever the genetic algorithm calculates the fitness of a population, it will spread the
 * calculation on (number of processors) threads. This does only make sense if the genetic algorithm
 * runs on a multi processor machine and if the calculation of the fitness function takes much more
 * time than the thread creation.<br>
 * Multithreading is disabled by default.
 * </p>
 * <p>
 * If you want to define your own subclass of <tt>GeneticAlgorithm</tt>, please note that the
 * current population is not always in a random order! So if you want to have a "shuffled"
 * population, you explicitly have to shuffle it.
 * </p>
 * 
 * @uml.dependency supplier="de.htwdd.ga.CrossoverMethod"
 */
public class GeneticAlgorithm
{
	/**
	 * The number of threads created if the genetic algorithm runs in multithread mode.
	 * <code>numThreads = availableProcessors</code>
	 */
	protected static int			numThreads			= Runtime.getRuntime()
																.availableProcessors();

	/**
	 * The current generation of individuals.
	 * 
	 * @uml.property name="population"
	 * @uml.associationEnd readOnly="true" multiplicity="(0 -1)" dimension="1" ordering="true"
	 *                     aggregation="composite" inverse="population:de.htwdd.ga.Individual"
	 */
	protected Individual[]			population;

	/**
	 * The crossover strategy.
	 * 
	 * @uml.property name="crossoverMethod"
	 * @uml.associationEnd multiplicity="(1 1)" aggregation="shared"
	 *                     inverse="population:de.htwdd.ga.CrossoverMethod"
	 */
	protected CrossoverMethod		crossoverMethod		= new SinglePointCrossover();

	/**
	 * The strategy to select mating candidates.
	 * 
	 * @uml.property name="selectionStrategy"
	 * @uml.associationEnd multiplicity="(1 1)" aggregation="shared"
	 *                     inverse="geneticAlgorithm:de.htwdd.ga.SelectionStrategy"
	 */
	protected SelectionStrategy		selectionStrategy	= new RandomSelection();
	/**
	 * The replacement strategy.
	 * 
	 * @uml.property name="replacementStrategy"
	 * @uml.associationEnd aggregation="shared"
	 *                     inverse="geneticAlgorithm:de.htwdd.ga.ReplacementStrategy"
	 */
	protected ReplacementStrategy	replacementStrategy	= new Elitism();

	/**
	 * The mating candidates defined by the selection strategy.
	 * 
	 * @uml.property name="selectList" multiplicity="(0 -1)" dimension="1"
	 */
	protected Individual[]			matingCandidates;

	/**
	 * Calculates the fitness of the current generation and selects a set of mating candidates.
	 */
	protected void runSelection()
	{
		calculateFitness(population);
		matingCandidates = selectionStrategy.select(population);
	}

	/**
	 * Creates a set of children from the mating candidates.
	 */
	protected void runReproduction()
	{
		children = crossoverMethod.crossover(matingCandidates, chromosomeLength);
		calculateFitness(children);
	}

	/**
	 * Runs the replacement process on <tt>population</tt> and <tt>children</tt> to create the
	 * next generation of individuals. Depending on the mutation rate, some of the individuals are
	 * also forced to mutate.
	 */
	protected void runReplacement()
	{
		population = replacementStrategy.replace(population, children);

		for (Individual individual : population)
			if (Math.random() <= mutationRate)
				individual.mutate();
		calculateFitness(population);
	}

	/**
	 * @return the fitness of the fittest individual of the current population.
	 */
	public double getBestFitness()
	{
		IndividualSorter.sortIndividuals(population);

		return population[0].getFitness();
	}

	/**
	 * Getter of the property <tt>crossoverMethod</tt>
	 * 
	 * @return Returns the crossoverMethod.
	 * @uml.property name="crossoverMethod"
	 */
	public CrossoverMethod getCrossoverMethod()
	{
		return crossoverMethod;
	}

	/**
	 * Setter of the property <tt>crossoverMethod</tt>
	 * 
	 * @param crossoverMethod The crossoverMethod to set.
	 * @uml.property name="crossoverMethod"
	 */
	public void setCrossoverMethod(CrossoverMethod crossoverMethod)
	{
		if (null == crossoverMethod)
			throw new RuntimeException("crossover method must not be null");

		this.crossoverMethod = crossoverMethod;
	}

	/**
	 * The length of all individual's chromosomes.
	 * 
	 * @uml.property name="chromosomeLength"
	 */
	protected int		chromosomeLength;

	/**
	 * The maximum number of generations this <tt>GeneticAlgorithm</tt> will run.
	 * 
	 * @uml.property name="maxCycles"
	 */
	protected int		maxCycles;

	/**
	 * If <tt>getBestFitness()</tt> returns a value greater than or equal to
	 * <tt>terminationFitness</tt>, the evolutionary process stops.
	 * 
	 * @uml.property name="terminationFitness"
	 */
	protected double	terminationFitness;

	/**
	 * Getter of the property <tt>chromosomeLength</tt>
	 * 
	 * @return Returns the chromosomeLength.
	 * @uml.property name="chromosomeLength"
	 */
	public int getChromosomeLength()
	{
		return chromosomeLength;
	}

	/**
	 * Setter of the property <tt>chromosomeLength</tt>
	 * 
	 * @param chromosomeLength The chromosomeLength to set.
	 * @uml.property name="chromosomeLength"
	 */
	public void setChromosomeLength(int chromosomeLength)
	{
		this.chromosomeLength = chromosomeLength;
	}

	/**
	 * Setter of the property <tt>maxCycles</tt>
	 * 
	 * @param maxCycles The maxCycles to set.
	 * @uml.property name="maxCycles"
	 */
	public void setMaxCycles(int maxCycles)
	{
		this.maxCycles = maxCycles;
	}

	/**
	 * Getter of the property <tt>maxCycles</tt>
	 * 
	 * @return Returns the maxCycles.
	 * @uml.property name="maxCycles"
	 */
	public int getMaxCycles()
	{
		return maxCycles;
	}

	/**
	 * Getter of the property <tt>terminationFitness</tt>
	 * 
	 * @return Returns the terminationFitness.
	 * @uml.property name="terminationFitness"
	 */
	public double getTerminationFitness()
	{
		return terminationFitness;
	}

	/**
	 * Setter of the property <tt>terminationFitness</tt>
	 * 
	 * @param terminationFitness The terminationFitness to set.
	 * @uml.property name="terminationFitness"
	 */
	public void setTerminationFitness(double terminationFitness)
	{
		this.terminationFitness = terminationFitness;
	}

	private FitnessFunction	fitnessFunction	= null;
	

	/**
	 * Controls the evolutionary process, see {@link de.htwdd.ga} for a sequence diagram.
	 */
	public final void run()
	{
		if (null == fitnessFunctionClass)
			throw new RuntimeException("fitness function not set");

		// initialize fitness functions
		if (multiThreaded)
		{
			for (int iRunner = 0; iRunner < numThreads; ++iRunner)
			{
				FitnessFunction function;
				if (useRMI)
				{
					try
					{
						RemoteFitnessInterface remoteFitness = remoteReferences.get(iRunner);
						remoteFitness.initialize(instantiateFitnessFunction());
						function = new RemoteFitnessFunction(remoteFitness);
					}
					catch (Exception e)
					{
						System.err.println("error while instantiating remote fitness function");
						continue;
					}
				}
				else
					function = instantiateFitnessFunction();

				FitnessRunner runner = new FitnessRunner(individualQueue, function);
				fitnessRunners.add(runner);
			}
			
			barrier = new CyclicBarrier(fitnessRunners.size() + 1);
			for (FitnessRunner runner : fitnessRunners)
			{
				runner.setBarrier(barrier);
				runner.start();
			}
		}
		else
			fitnessFunction = instantiateFitnessFunction();

		population = initializationFunction.initializePopulation();

		for (cycle = 0; cycle < maxCycles; ++cycle)
		{
			runSelection();
			runReproduction();
			runReplacement();

			if (getBestFitness() >= terminationFitness)
			{
				++cycle;
				break;
			}
		}

		for (FitnessRunner runner : fitnessRunners)
			runner.interrupt();
		fitnessRunners.clear();

		System.out.println(String.format("genetic algorithm terminated after %,d cycles", cycle));
		System.out.println(String.format("maximum fitness is %f", getBestFitness()));
	}

	/**
	 * The strategy to create an initial population.
	 * 
	 * @uml.property name="initializationFunction"
	 * @uml.associationEnd multiplicity="(1 1)" aggregation="shared"
	 *                     inverse="geneticAlgorithm:de.htwdd.ga.InitializationFunction"
	 */
	protected InitializationFunction	initializationFunction	= new de.htwdd.ga.InitializationFunction();

	/**
	 * Getter of the property <tt>initializationFunction</tt>
	 * 
	 * @return Returns the initializationFunction.
	 * @uml.property name="initializationFunction"
	 */
	public InitializationFunction getInitializationFunction()
	{
		return initializationFunction;
	}

	/**
	 * Setter of the property <tt>initializationFunction</tt>
	 * 
	 * @param initializationFunction The initializationFunction to set.
	 * @uml.property name="initializationFunction"
	 */
	public void setInitializationFunction(InitializationFunction initializationFunction)
	{
		if (null == initializationFunction)
			throw new RuntimeException("initialization function must not be null");

		this.initializationFunction = initializationFunction;
		initializationFunction.setGeneticAlgorithm(this);
	}

	/**
	 * Getter of the property <tt>population</tt>
	 * 
	 * @return Returns the individuals.
	 * @uml.property name="population"
	 */
	public Individual[] getPopulation()
	{
		return population;
	}

	/**
	 * Getter of the property <tt>selectionStrategy</tt>
	 * 
	 * @return Returns the selectionStrategy.
	 * @uml.property name="selectionStrategy"
	 */
	public SelectionStrategy getSelectionStrategy()
	{
		return selectionStrategy;
	}

	/**
	 * Setter of the property <tt>selectionStrategy</tt>
	 * 
	 * @param selectionStrategy The selectionStrategy to set.
	 * @uml.property name="selectionStrategy"
	 */
	public void setSelectionStrategy(SelectionStrategy selectionStrategy)
	{
		this.selectionStrategy = selectionStrategy;
	}

	/**
	 * Getter of the property <tt>replacementStrategy</tt>
	 * 
	 * @return Returns the replacementStrategy.
	 * @uml.property name="replacementStrategy"
	 */
	public ReplacementStrategy getReplacementStrategy()
	{
		return replacementStrategy;
	}

	/**
	 * Setter of the property <tt>replacementStrategy</tt>
	 * 
	 * @param replacementStrategy The replacementStrategy to set.
	 * @uml.property name="replacementStrategy"
	 */
	public void setReplacementStrategy(ReplacementStrategy replacementStrategy)
	{
		if (null == replacementStrategy)
			throw new RuntimeException("replacement strategy must not be null");

		this.replacementStrategy = replacementStrategy;
	}

	/**
	 * @uml.property name="populationSize"
	 */
	protected int	populationSize;

	/**
	 * Getter of the property <tt>populationSize</tt>
	 * 
	 * @return Returns the populationSize.
	 * @uml.property name="populationSize"
	 */
	public int getPopulationSize()
	{
		return populationSize;
	}

	/**
	 * Setter of the property <tt>populationSize</tt>
	 * 
	 * @param populationSize The populationSize to set.
	 * @uml.property name="populationSize"
	 */
	public void setPopulationSize(int populationSize)
	{
		this.populationSize = populationSize;
	}

	/**
	 * Children of the current population.
	 * 
	 * @uml.property name="children"
	 * @uml.associationEnd readOnly="true" multiplicity="(0 -1)" dimension="1" ordering="true"
	 *                     aggregation="composite" inverse="geneticAlgorithm:de.htwdd.ga.Individual"
	 */
	protected Individual[]	children;

	/**
	 * Getter of the property <tt>children</tt>
	 * 
	 * @return Returns the childrens.
	 * @uml.property name="children"
	 */
	public Individual[] getChildren()
	{
		return children;
	}

	/**
	 * Creates and initializes a new <tt>GeneticAlgorithm</tt>
	 * 
	 * @param chromosomeLength
	 * @param maxCycles the maximum number of generations to run
	 * @param terminationFitness if this fitness is reached, the algorithm terminates
	 * @param populationSize
	 */
	public GeneticAlgorithm(int chromosomeLength, int maxCycles, double terminationFitness,
			int populationSize)
	{
		this.chromosomeLength = chromosomeLength;
		this.maxCycles = maxCycles;
		this.terminationFitness = terminationFitness;
		this.populationSize = populationSize;

		initializationFunction.setGeneticAlgorithm(this);
	}

	/**
	 * Prepares the <tt>GeneticAlgorithm</tt> for cluster usage. <br>
	 * Note that rmiregistry has to be active and <tt>RemoteFitness</tt> has to be registered on
	 * all servers.
	 * 
	 * @param servernames list of RMI servers
	 */
	public final void activateRMI(String[] servernames)
	{
		multiThreaded = true;
		useRMI = true;
		remoteReferences = new ArrayList<RemoteFitnessInterface>();

		for (String host : servernames)
		{
			String url = String.format("rmi://%s:1099/%s", host, RemoteFitness.SERVICE_NAME);
			try
			{
				RemoteFitnessInterface remoteFitness = (RemoteFitnessInterface) Naming.lookup(url);
				remoteReferences.add(remoteFitness);

				int numRemoteThreads = remoteFitness.availableThreads();
				for (int iThread = 1; iThread < numRemoteThreads; ++iThread)
				{
					remoteFitness = (RemoteFitnessInterface) Naming.lookup(url);
					remoteReferences.add(remoteFitness);
				}
			}
			catch (Exception e)
			{
				//e.printStackTrace();
				System.err.println("unable to connect to " + url);
			}
		}

		numThreads = remoteReferences.size();
	}

	/**
	 * calculates the fitness of the given population. If <tt>multiThreaded</tt> is set to
	 * <tt>true</tt>, the calculation is spread on multiple threads.
	 * 
	 * @param individuals
	 */
	public final void calculateFitness(Individual[] individuals)
	{

		if (multiThreaded)
		{
			for (Individual individual : individuals)
				individualQueue.put(individual);

			do
			{
				try
				{
					// Runner aufwecken
					barrier.await();

					// auf Ende des Runnerdurchlaufs warten
					barrier.await();
				}
				catch (InterruptedException e)
				{
					throw new RuntimeException(e);
				}
				catch (BrokenBarrierException e)
				{
					throw new RuntimeException(e);
				}
			}
			while (!individualQueue.isEmpty());
		}
		else
		{
			for (int iIndividual = 0; iIndividual < individuals.length; ++iIndividual)
			{
				individuals[iIndividual].setFitnessFunction(fitnessFunction);
				individuals[iIndividual].updateFitness();
			}
		}
	}

	/**
	 * All individuals use this static property to instantiate their fitness function. An exception
	 * will occur, if this property is not set properly.
	 * 
	 * @uml.property name="fitnessFunction"
	 */
	private Class						fitnessFunctionClass	= null;

	/**
	 * This value defines the percentage of a population that will be forced to mutate.
	 * 
	 * @uml.property name="mutationRate"
	 */
	protected double							mutationRate			= 0.1;

	/**
	 * If set to true, the fitness calculation will run on multiple threads.
	 * 
	 * @uml.property name="multiThreaded"
	 */
	protected boolean							multiThreaded			= false;

	protected int								cycle;

	private boolean								useRMI					= false;

	private ArrayList<RemoteFitnessInterface>	remoteReferences;

	private ArrayList<FitnessRunner>			fitnessRunners			= new ArrayList<FitnessRunner>();

	private QueuedArrayList<Individual>			individualQueue			= new QueuedArrayList<Individual>();

	private CyclicBarrier	barrier;

	/**
	 * Instantiates the fitness function defined by the property <tt>fitnessFunction</tt>
	 * 
	 * @return a new instance of fitnessFunction
	 */
	public FitnessFunction instantiateFitnessFunction()
	{
		FitnessFunction result = null;

		try
		{
			result = (FitnessFunction) fitnessFunctionClass.newInstance();
		}
		catch (InstantiationException e)
		{
			e.printStackTrace();
		}
		catch (IllegalAccessException e)
		{
			e.printStackTrace();
		}
		catch (ClassCastException e)
		{
			throw new RuntimeException("submitted class is not of type de.htwdd.ga.FitnessFunction");
		}

		return result;
	}

	/**
	 * Setter of the property <tt>fitnessFunction</tt>
	 * 
	 * @param fitnessFunction The fitnessFunction to set.
	 * @uml.property name="fitnessFunction"
	 */
	public void setFitnessFunction(Class fitnessFunction)
	{
		if (null == fitnessFunction)
			throw new RuntimeException("fitness function not set");

		fitnessFunctionClass = fitnessFunction;
	}

	/**
	 * Getter of the property <tt>mutationRate</tt>
	 * 
	 * @return Returns the mutationRate.
	 * @uml.property name="mutationRate"
	 */
	public double getMutationRate()
	{
		return mutationRate;
	}

	/**
	 * @uml.property name="mutationRate"
	 */
	public void setMutationRate(double mutationRate)
	{
		this.mutationRate = mutationRate;
	}

	/**
	 * Getter of the property <tt>multiThreaded</tt>
	 * 
	 * @return Returns the multiThreaded.
	 * @uml.property name="multiThreaded"
	 */
	public boolean isMultiThreaded()
	{
		return multiThreaded;
	}

	/**
	 * /** Setter of the property <tt>multiThreaded</tt>
	 * 
	 * @param multiThreaded
	 * @uml.property name="multiThreaded"
	 */
	public void setMultiThreaded(boolean multiThreaded)
	{
		this.multiThreaded = multiThreaded;
	}

}
