package de.htwdd.ga;

import java.util.BitSet;
import java.util.StringTokenizer;

import org.jdom.Element;

/**
 * This class represents an individual in a population used by a genetic algorithm. An individual is
 * identified by it's chromosome (represented by a <tt>BitSet</tt>). <br>
 * An individual has the ability to calculate it's fitness by using the fitness function class
 * defined (as a static member) by <tt>GeneticAlgorithm</tt>.<br>
 * An individual also has the ability to mutate.
 * 
 * @see de.htwdd.ga.GeneticAlgorithm
 */
public class Individual
{

	/**
	 * Forces the individual to flip a randomly selected bit in it's chromosome.
	 */
	public void mutate()
	{
		int index = (int) (Math.random() * chromosome.length());
		chromosome.flip(index);
		upToDate = false;
	}

	/**
	 * The individual's chromosome, represented by a <tt>BitSet</tt>
	 * 
	 * @uml.property name="chromosome"
	 */
	private BitSet	chromosome;

	/**
	 * Getter of the property <tt>chromosome</tt>
	 * 
	 * @return Returns the chromosome.
	 * @uml.property name="chromosome"
	 */
	public BitSet getChromosome()
	{
		return chromosome;
	}

	/**
	 * Setter of the property <tt>chromosome</tt>. Sets the individual's upToDate flag to false.
	 * 
	 * @param chromosome The chromosome to set.
	 * @uml.property name="chromosome"
	 */
	public void setChromosome(BitSet chromosome)
	{
		this.chromosome = chromosome;
		upToDate = false;
	}

	/**
	 * The individual's current fitness.
	 * 
	 * @uml.property name="fitness" readOnly="true"
	 */
	private double	fitness;

	/**
	 * Getter of the property <tt>fitness</tt>
	 * 
	 * @return Returns the fitness.
	 * @uml.property name="fitness"
	 */
	public double getFitness()
	{
		updateFitness();

		return fitness;
	}

	/**
	 * Calculates the individual's fitness if the <tt>upToDate</tt> flag is set to <tt>false</tt>.
	 */
	public void updateFitness()
	{
		if (!upToDate)
		{
			fitness = fitnessFunction.computeFitness(chromosome);
			upToDate = true;
		}
	}

	/**
	 * If set to false, this flag indicates that the individual's fitness has to be recalculated.
	 * 
	 * @uml.property name="upToDate" readOnly="true"
	 */
	private boolean	upToDate;

	/**
	 * Getter of the property <tt>upToDate</tt>
	 * 
	 * @return Returns the upToDate.
	 * @uml.property name="upToDate"
	 */
	public boolean getUpToDate()
	{
		return upToDate;
	}

	/**
	 * The instance of <tt>FitnessFunction</tt> this individual uses to calculate it's fitness.
	 * The concrete class of this member is defined by
	 * {@link de.htwdd.ga.GeneticAlgorithm#fitnessFunction}.
	 * 
	 * @uml.property name="fitnessFunction"
	 * @uml.associationEnd multiplicity="(1 1)" aggregation="composite"
	 *                     inverse="individual:de.htwdd.ga.FitnessFunction"
	 */
	private FitnessFunction	fitnessFunction	= null;

	/**
	 * Creates a new individual.<br>
	 * This constructor <b>does not</b> create a chromosome.
	 */
	public Individual()
	{

	}

	/**
	 * Getter of the property <tt>fitnessFunction</tt>
	 * 
	 * @return Returns the fitnessFunction.
	 * @uml.property name="fitnessFunction"
	 */
	public FitnessFunction getFitnessFunction()
	{
		return fitnessFunction;
	}

	/**
	 * Setter of the property <tt>fitnessFunction</tt>
	 * 
	 * @param fitnessFunction The fitnessFunction to set.
	 * @uml.property name="fitnessFunction"
	 */
	public void setFitnessFunction(FitnessFunction fitnessFunction)
	{
		this.fitnessFunction = fitnessFunction;
	}

	/**
	 * Creates an XML representation of this individual.
	 * 
	 * @return a JDOM-Element
	 */
	public Element createXML()
	{
		Element xmlIndividual = new Element("individual");
		xmlIndividual.setAttribute("fitness", Double.toString(fitness));
		xmlIndividual.setAttribute("upToDate", Boolean.toString(upToDate));

		StringBuffer bufChromosome = new StringBuffer();
		for (int iGene = 0; iGene < chromosome.length(); iGene++)
		{
			bufChromosome.append(chromosome.get(iGene));
			bufChromosome.append(';');
		}
		xmlIndividual.setAttribute("chromosome", bufChromosome.toString());

		return xmlIndividual;
	}

	/**
	 * Configures an individual specified by an XML element.
	 * 
	 * @param xmlIndividual a JDOM-Element
	 */
	public void extractFromXML(Element xmlIndividual)
	{
		upToDate = Boolean.parseBoolean(xmlIndividual.getAttributeValue("upToDate"));
		fitness = Double.parseDouble(xmlIndividual.getAttributeValue("fitness"));

		StringTokenizer chromosomeToken = new StringTokenizer(xmlIndividual
				.getAttributeValue("chromosome"), ";");
		chromosome = new BitSet();
		int iToken = 0;
		while (chromosomeToken.hasMoreTokens())
		{
			Boolean gene = Boolean.parseBoolean(chromosomeToken.nextToken());
			if (gene)
				chromosome.set(iToken);
			++iToken;
		}
	}
}
