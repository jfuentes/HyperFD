package de.htwdd.ga;

import java.util.BitSet;

import de.htwdd.ga.util.IndividualSorter;

/**
 * This class is used by a GeneticAlgorithm to create an initial population of individuals.<br>
 * The size of the initial population is defined by the population size of the genetic algorithm
 * multiplied by initializationCoeff. If the generated population is bigger than the population
 * size, only the fittest individuals are taken to form the initial population.
 */
public class InitializationFunction
{

	/**
	 * Initialization coefficient.
	 * 
	 * @uml.property name="initializationCoeff"
	 */
	private double				initializationCoeff	= 1.0;

	/**
	 * @uml.property name="geneticAlgorithm"
	 * @uml.associationEnd multiplicity="(1 1)"
	 *                     inverse="initializationFunction:de.htwdd.ga.GeneticAlgorithm"
	 */
	protected GeneticAlgorithm	geneticAlgorithm	= null;

	/**
	 * Getter of the property <tt>geneticAlgorithm</tt>
	 * 
	 * @return Returns the geneticAlgorithm.
	 * @uml.property name="geneticAlgorithm"
	 */
	public GeneticAlgorithm getGeneticAlgorithm()
	{
		return geneticAlgorithm;
	}

	/**
	 * Setter of the property <tt>geneticAlgorithm</tt>
	 * 
	 * @param geneticAlgorithm The geneticAlgorithm to set.
	 * @uml.property name="geneticAlgorithm"
	 */
	public void setGeneticAlgorithm(GeneticAlgorithm geneticAlgorithm)
	{
		this.geneticAlgorithm = geneticAlgorithm;
	}

	/**
	 * Creates an initial population and returns the fittest individuals.
	 * 
	 * @return an initial population of inidividuals. Length == geneticAlgorithm.populationSize
	 */
	public Individual[] initializePopulation()
	{
		int populationSize = geneticAlgorithm.getPopulationSize();
		int initialSize = (int) (populationSize * initializationCoeff);
		Individual initialPopulation[] = new Individual[initialSize];

		int chromosomeLength = geneticAlgorithm.getChromosomeLength();

		// generate individuals
		for (int iIndividual = 0; iIndividual < initialSize; iIndividual++)
		{
			Individual individual = new Individual();
			initialPopulation[iIndividual] = individual;

			BitSet chromosome = new BitSet(chromosomeLength);
			// System.out.println("length: " + chromosomeLength + " real length: " +
			// chromosome.length() + " size: " + chromosome.size());
			individual.setChromosome(chromosome);

			// initialize chromosome
			for (int iGene = 0; iGene < chromosomeLength; iGene++)
			{
				if (Math.random() < 0.5)
					chromosome.clear(iGene);
				else
					chromosome.set(iGene);
			}

			StringBuffer out = new StringBuffer();
			for (int iBit = 0; chromosomeLength > iBit; ++iBit)
				out.append(chromosome.get(iBit));
			// System.out.println("length: " + chromosomeLength + " real length: " +
			// chromosome.length() + " size: " + chromosome.size());
			// System.out.println("chromosome: " + out.toString());
		}

		// take the fittest individuals only
		if (initialSize > populationSize)
		{
			geneticAlgorithm.calculateFitness(initialPopulation);
			IndividualSorter.sortIndividuals(initialPopulation);

			Individual tempPopulation[] = new Individual[populationSize];
			System.arraycopy(initialPopulation, 0, tempPopulation, 0, populationSize);
			initialPopulation = tempPopulation;
		}

		return initialPopulation;
	}

	/**
	 * Getter of the property <tt>initializationCoeff</tt>
	 * 
	 * @return Returns the initializationCoeff.
	 * @uml.property name="initializationCoeff"
	 */
	public double getInitializationCoeff()
	{
		return initializationCoeff;
	}

	/**
	 * Setter of the property <tt>initializationCoeff</tt>
	 * 
	 * @param initializationCoeff The initializationCoeff to set.
	 * @uml.property name="initializationCoeff"
	 */
	public void setInitializationCoeff(double initializationCoeff)
	{
		this.initializationCoeff = initializationCoeff;
	}

}
