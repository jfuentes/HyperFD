package de.htwdd.ga;

import java.util.ArrayList;
import java.util.Random;

/**
 * An implementation of <tt>SelectionStrategy</tt> that randomly selects pairs of
 * individuals from a population. <br>
 * {@link de.htwdd.ga.GeneticAlgorithm} uses this selection strategy by default.
 */
public class RandomSelection implements SelectionStrategy
{

	/**
	 * {@inheritDoc}
	 */
	public Individual[] select(Individual[] population)
	{

		Random rand = new Random();
		int numCandidates = (int) (rand.nextFloat() * population.length / 2.0f) * 2;

		ArrayList<Individual> tempPopulation = new ArrayList<Individual>();
		for (Individual individual : population)
			tempPopulation.add(individual);

		Individual[] candidates = new Individual[numCandidates];
		for (int iIndividual = 0; iIndividual < numCandidates; ++iIndividual)
		{
			int index = (int) (Math.random() * tempPopulation.size());
			candidates[iIndividual] = tempPopulation.remove(index);
		}

		return candidates;
	}

}
