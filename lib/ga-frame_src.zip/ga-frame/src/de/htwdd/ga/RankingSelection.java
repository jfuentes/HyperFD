package de.htwdd.ga;

import java.util.ArrayList;
import java.util.Random;

import de.htwdd.ga.util.IndividualSorter;

/**
 * An implementation of <tt>SelectionStrategy</tt> which uses a ranking based algorithm.
 * {@link de.htwdd.ga.GeneticAlgorithm} uses this selection strategy by default.
 */
public class RankingSelection implements SelectionStrategy
{
	private double	minPossibility;
	private double	maxPossibility;

	/**
	 * Sets the min- and maxPossibility of the <tt>RankingSelection</tt>.
	 * Condition: 0 <= min <= max <= 1.0
	 * @param minPossibility
	 * @param maxPossibility
	 * @throws RuntimeException if the condition violated.
	 */
	public RankingSelection(double minPossibility, double maxPossibility)
	{
		if (minPossibility >= maxPossibility || minPossibility < 0 || minPossibility > 1.0
				|| maxPossibility > 1.0)
			throw new RuntimeException("Invalid possibilities.");

		this.minPossibility = minPossibility;
		this.maxPossibility = maxPossibility;
	}

	/**
	 * {@inheritDoc}
	 */
	public Individual[] select(Individual[] population)
	{

		Random rand = new Random();

		IndividualSorter.sortIndividuals(population);

		ArrayList<Individual> tmpMatingPool = new ArrayList<Individual>();

		double stepSize = (maxPossibility - minPossibility) / population.length;

		for (int iIndividual = 0; iIndividual < population.length; ++iIndividual)
		{
			if (rand.nextDouble() > minPossibility + stepSize * iIndividual)
				tmpMatingPool.add(population[iIndividual]);
		}
		
		if (tmpMatingPool.size()%2 > 0)
			tmpMatingPool.remove(tmpMatingPool.size()-1);

		return tmpMatingPool.toArray(new Individual[tmpMatingPool.size()]);
	}

}
