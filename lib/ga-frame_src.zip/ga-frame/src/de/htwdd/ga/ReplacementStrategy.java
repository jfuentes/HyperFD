package de.htwdd.ga;

/**
 * This interface has to be implemented to provide a {@link de.htwdd.ga.GeneticAlgorithm} with a
 * strategy to select those individuals from a parent and a child population that will form the next
 * generation of individuals.
 */
public interface ReplacementStrategy
{

	/**
	 * Constructs a new generation of individuals based on a parent and a child population.
	 * 
	 * @param population parents
	 * @param children
	 * @return next generation of individuals
	 */
	public Individual[] replace(Individual[] population, Individual[] children);

}
