package de.htwdd.ga;

/**
 * This interface has to be implemented to provide a genetic algorithm with a strategy to select
 * mating candidates from a population.
 */
public interface SelectionStrategy
{
	/**
	 * Selects mating candidates from the given population. The number of individuals returned by
	 * this function has to be <b>even</b>.
	 * 
	 * @param population
	 * @return an array containing mating candidates
	 */
	public Individual[] select(Individual[] population);
}
