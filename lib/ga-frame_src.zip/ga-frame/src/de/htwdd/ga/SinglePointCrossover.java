package de.htwdd.ga;

import java.util.BitSet;

/**
 * An implementation of {@link de.htwdd.ga.CrossoverMethod} that creates new individuals by mating
 * pairs of parent individuals. The children's chromosomes are created by randomly choosing a single
 * crossover point in the parents chromosome and switching the chromosomes. <br>
 * {@link de.htwdd.ga.GeneticAlgorithm} uses this crossover strategy by default.
 */
public class SinglePointCrossover implements CrossoverMethod
{

	/**
	 * {@inheritDoc}
	 */
	public Individual[] crossover(Individual[] parents, int chromosomeLength)
	{
		Individual children[] = new Individual[parents.length];

		for (int iIndividual = 0; iIndividual < parents.length; iIndividual += 2)
		{
			Individual child1 = new Individual();
			Individual child2 = new Individual();
			children[iIndividual] = child1;
			children[iIndividual + 1] = child2;

			int crossoverPoint = (int) (Math.random() * chromosomeLength);

			BitSet chromosome1 = (BitSet) parents[iIndividual].getChromosome().clone();
			BitSet chromosome2 = (BitSet) parents[iIndividual + 1].getChromosome().clone();

			BitSet tmpChromosom1 = (BitSet) chromosome1.clone();
			BitSet tmpChromosom2 = (BitSet) chromosome2.clone();

			chromosome1.clear(crossoverPoint, chromosomeLength - 1);
			chromosome2.clear(crossoverPoint, chromosomeLength - 1);

			tmpChromosom1.clear(0, crossoverPoint);
			tmpChromosom2.clear(0, crossoverPoint);

			chromosome1.or(tmpChromosom2);
			chromosome2.or(tmpChromosom1);

			child1.setChromosome(chromosome1);
			child2.setChromosome(chromosome2);
		}

		return children;
	}

}
