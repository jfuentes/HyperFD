package de.htwdd.ga.examples;

import java.util.BitSet;
import java.util.List;

import de.htwdd.ga.GeneticAlgorithm;
import de.htwdd.ga.Individual;
import de.htwdd.ga.RankingSelection;
import de.htwdd.ga.TwoPointCrossover;
import de.htwdd.ga.util.GaXmlUtil;

/**
 * A simple example for genetic algorithms which implements the "knapsack problem" with nine artifacts.
 */
public class KnapSack 
{
	/**
	 * @param args server names, if you want to use RMI
	 */
	public static void main(String[] args)
	{
		KnapsackFitness.delay = 0;

		GeneticAlgorithm algorithm = new GeneticAlgorithm(KnapsackFitness.NUM_ITEMS, 100, 66, 20);
		algorithm.setFitnessFunction(KnapsackFitness.class);
		algorithm.setCrossoverMethod(new TwoPointCrossover());
		algorithm.setMutationRate(0.1);
		algorithm.setSelectionStrategy(new RankingSelection(.3, .4));
		algorithm.setMultiThreaded(true);
		
		if (args.length > 0)
			algorithm.activateRMI(args);
		
		algorithm.run();
		
		Individual[] population = algorithm.getPopulation();
		displayPopulation(population);

		GaXmlUtil.writeToFile(population, "test.xml");
		List<Individual> population2 = GaXmlUtil.extractFromFile("test.xml");
		displayPopulation(population2.toArray(new Individual[0]));
	}

	/**
	 * @param population
	 */
	private static void displayPopulation(Individual[] population)
	{
		StringBuffer out = new StringBuffer();
		for (Individual individual : population)
		{
			BitSet b = individual.getChromosome();
			
			out.append("individual ");
			for (int i = 0; i < KnapsackFitness.NUM_ITEMS; i++)
			{
				if (b.get(i))
					out.append("x ");
				else
					out.append("- ");
			}
			out.append("\n");
		}
		System.out.println(out.toString());
	}

}
