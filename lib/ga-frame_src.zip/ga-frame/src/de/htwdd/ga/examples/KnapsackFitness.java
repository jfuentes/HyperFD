package de.htwdd.ga.examples;

import java.io.Serializable;
import java.util.BitSet;

import de.htwdd.ga.FitnessFunction;

/**
 * Example fitness function used by the <tt>KnapSack</tt> example.
 */
public class KnapsackFitness implements FitnessFunction, Serializable
{
	private static final long	serialVersionUID	= 9020412044265211544L;

	public static final int		NUM_ITEMS			= 9;

	private static final int	MAX_WEIGHT			= 58;

	private int					knapSackArray[][]	= { { 3, 3 }, { 7, 5 }, { 4, 2 }, { 12, 11 },
			{ 8, 4 }, { 10, 6 }, { 9, 2 }, { 14, 15 }, { 10, 12 }, { 12, 9 } };

	public static long			delay				= 0;

	public double computeFitness(BitSet chromosome)
	{
		int weightSum = 0, valueSum = 0;
		for (int iGene = 0; iGene < NUM_ITEMS; ++iGene)
		{
			if (chromosome.get(iGene))
			{
				weightSum += knapSackArray[iGene][0];
				valueSum += knapSackArray[iGene][1];
			}
		}

		if (delay > 0)
		{
			long timestamp = System.currentTimeMillis() + delay;

			while (System.currentTimeMillis() <= timestamp);
		}

		if (weightSum <= MAX_WEIGHT)
			return valueSum;
		else
			return 0;
	}
}
