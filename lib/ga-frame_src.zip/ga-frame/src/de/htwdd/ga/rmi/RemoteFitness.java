package de.htwdd.ga.rmi;

import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.BitSet;

import de.htwdd.ga.FitnessFunction;

/**
 * Implementation of <tt>RemoteFitnessInterface</tt>, this class will run on the "fitness
 * servers".
 */
public class RemoteFitness extends UnicastRemoteObject implements RemoteFitnessInterface
{
	private static final long	serialVersionUID	= 2L;

	/**
	 * The name under which <tt>RemoteFitnessInterface</tt> can be looked up.
	 */
	public static final String	SERVICE_NAME		= "RemoteFitness";

	/**
	 * The fitness function used for all fitness calculations.
	 * 
	 * @uml.property name="fitnessFunction"
	 */
	private FitnessFunction		fitnessFunction		= null;

	/**
	 * Default constructor.
	 * 
	 * @throws RemoteException
	 */
	public RemoteFitness() throws RemoteException
	{
	}

	/**
	 * {@inheritDoc}
	 */
	public int availableThreads() throws RemoteException
	{
		return Runtime.getRuntime().availableProcessors();
	}

	/**
	 * {@inheritDoc}
	 */
	public double computeFitness(BitSet chromosome) throws RemoteException
	{
		System.out.println("starting fitness calculation...");
		return fitnessFunction.computeFitness(chromosome);
	}

	/**
	 * {@inheritDoc}
	 */
	public void initialize(FitnessFunction fitnessFunction) throws RemoteException
	{
		this.fitnessFunction = fitnessFunction;
	}

	/**
	 * Registers <tt>RemoteFitness</tt> to the RMI registry.
	 * 
	 * @param args no arguments needed
	 */
	public static void main(String[] args)
	{
		try
		{
			System.out.println("Registering RemoteFitness");
			RemoteFitness remoteFitness = new RemoteFitness();
			Naming.rebind(RemoteFitness.SERVICE_NAME, remoteFitness);
			System.out.println("  Done.");
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}
}
