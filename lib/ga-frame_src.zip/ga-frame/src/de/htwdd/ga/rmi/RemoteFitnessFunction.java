package de.htwdd.ga.rmi;

import de.htwdd.ga.FitnessFunction;
import java.rmi.RemoteException;
import java.util.BitSet;

/**
 * Wrapper class to use RMI based fitness calculation in the same way as local fitness calculation.
 */
public class RemoteFitnessFunction implements FitnessFunction
{
	/**
	 * @uml.property name="remoteFitness"
	 */
	private RemoteFitnessInterface	remoteFitness;

	/**
	 * Creates a new <tt>RemoteFitnessFunction</tt>.
	 * 
	 * @param remoteFitness the remote fitness function to wrap
	 */
	public RemoteFitnessFunction(RemoteFitnessInterface remoteFitness)
	{
		this.remoteFitness = remoteFitness;
	}

	/**
	 * Uses the remote fitness function to calculate the chromosome's fitness
	 * 
	 * @param chromosome
	 */
	public double computeFitness(BitSet chromosome)
	{
		try
		{
			return remoteFitness.computeFitness(chromosome);
		}
		catch (RemoteException e)
		{
			throw new RuntimeException("Remote Fitness Exception");
		}
	}

}
