package de.htwdd.ga.rmi;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.BitSet;

import de.htwdd.ga.FitnessFunction;

/**
 * Provides methods needed to calculate the fitness of individuals on remote servers.
 */
public interface RemoteFitnessInterface extends Remote
{
	/**
	 * Calculates the number of fitness functions that can be ran simultanously on the remote host.
	 * 
	 * @return number of remote threads
	 * @throws RemoteException
	 */
	public int availableThreads() throws RemoteException;

	/**
	 * The provided instance of fitness function will be used for all further fitness calculations.
	 * 
	 * @param fitnessFunction
	 * @throws RemoteException
	 */
	public void initialize(FitnessFunction fitnessFunction) throws RemoteException;

	/**
	 * Uses the fitness function provided by <tt>initialize</tt> to calculate the chromosome's
	 * fitness.
	 * 
	 * @param chromosome
	 * @return the chromosome's fitness
	 * @throws RemoteException
	 */
	public double computeFitness(BitSet chromosome) throws RemoteException;
}
