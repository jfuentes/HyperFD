package de.htwdd.ga.util;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;
import org.jdom.output.Format;
import org.jdom.output.XMLOutputter;

import de.htwdd.ga.Individual;

/**
 * This utility class is able to save an array of individuals to a file and to extract a population
 * from a file. <br>
 * To use this functionality, the JDOM-library has to be in the classpath.
 */
public class GaXmlUtil
{
	/**
	 * Writes a population to a file.
	 * 
	 * @param population array of individuals to be saved
	 * @param filename
	 */
	public static void writeToFile(Individual[] population, String filename)
	{
		try
		{
			Element xmlPopulation = new Element("population");
			for (Individual individual : population)
				xmlPopulation.addContent(individual.createXML());

			Document document = new Document(xmlPopulation);
			XMLOutputter outputter = new XMLOutputter(Format.getPrettyFormat());
			FileOutputStream outFile = new FileOutputStream(filename);
			outputter.output(document, outFile);
		}
		catch (FileNotFoundException e)
		{
			e.printStackTrace();
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
	}

	/**
	 * Extracts a poplation from an XML file.
	 * 
	 * @param filename file containing a population
	 * @return the extracted population
	 */
	public static List<Individual> extractFromFile(String filename)
	{
		File populationFile = new File(filename);
		if (!populationFile.exists() || populationFile.isDirectory())
		{
			System.err.println("unable to open " + filename);
			return null;
		}
		
		return extractFromFile(populationFile);
	}

	/**
	 * Extracts a poplation from an XML file.
	 * 
	 * @param file file containing a population
	 * @return the extracted population
	 */
	@SuppressWarnings("unchecked")
	public static List<Individual> extractFromFile(File populationFile)
	{
		try
		{
			ArrayList<Individual> population = new ArrayList<Individual>();

			SAXBuilder builder = new SAXBuilder();
			Document doc = builder.build(populationFile);
			Element xmlPopulation = doc.getRootElement();
			if (!xmlPopulation.getName().equals("population"))
				throw new RuntimeException(populationFile.getName() + " does not contain a population");

			for (Element xmlIndividual : (List<Element>) xmlPopulation.getChildren("individual"))
			{
				Individual individual = new Individual();
				individual.extractFromXML(xmlIndividual);

				population.add(individual);
			}

			return population;
		}
		catch (JDOMException e)
		{
			e.printStackTrace();
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}

		return null;
	}
}
