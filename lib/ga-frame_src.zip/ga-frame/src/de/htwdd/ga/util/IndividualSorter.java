package de.htwdd.ga.util;

import java.util.Arrays;
import java.util.Comparator;

import de.htwdd.ga.Individual;

/**
 * This utility class sorts an array of individuals based on their fitness. The resulting array is
 * sorted in decreasing order.
 */
public class IndividualSorter implements Comparator<Individual>
{
	private static IndividualSorter	sorter	= new IndividualSorter();

	/**
	 * sorts an array of individuals based on their fitness.
	 * 
	 * @param individuals the array of individuals to be sorted
	 */
	public static void sortIndividuals(Individual[] individuals)
	{
		Arrays.sort(individuals, sorter);
	}

	/**
	 * compares to individuals based on their fitness.
	 */
	public int compare(Individual individual1, Individual individual2)
	{
		return (int) Math.signum(individual2.getFitness() - individual1.getFitness());
	}
}
