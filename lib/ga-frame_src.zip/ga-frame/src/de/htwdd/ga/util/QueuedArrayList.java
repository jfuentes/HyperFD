package de.htwdd.ga.util;

import java.util.ArrayList;

/**
 * This is a simple wrapper class to have synchronized
 * access to a <code>ArrayList</code>.
 */
public class QueuedArrayList<T> extends ArrayList<T>
{
	private static final long	serialVersionUID	= 1L;

	public synchronized T take()
	{
		if (isEmpty())
			return null;
		else
			return remove(0);
	}

	public synchronized void put(T element)
	{
		add(element);
	}
}
